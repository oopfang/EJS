let express = require('express');
let router = express.Router();
let fsx = require('fs-extra');
let path = require('path');
let formidable = require('formidable');
let sha1 = require('js-sha1');

/* GET home page. */
router.get('/:type/:fileName', function(req, res, next) {
  console.log(req);

  let f = path.join(req.svrRoot, '/abc/ccd/abc.txt');
  fsx.outputFile(f, 'aaaa', err => {
    if (err) {
      res.apiErr(err);
    } else {
      res.apiOk('创建成功');
    }
  });
  // res.render('index', { title: 'Express' });
});

module.exports = router;
