let str0 = {
  code: '000',
  title: 'CentOS7关闭IPV6',
  msg: `
-- 编辑 /etc/default/grub 文件。
-- 找到 GRUB_CMDLINE_LINUX 所在行，
-- 将原来的 GRUB_CMDLINE_LINUX="xxxxxxxxxx" 更改为 GRUB_CMDLINE_LINUX="ipv6.disable=1 xxxxxxxxxx"
	`
};

let str1 = {
  code: '001',
  title: 'mongoDB环境迁移说明：',
  msg: `
如果在开发过程中，将远端mongoDB的绑定地址设为了允许外网访问（或 0.0.0.0），建议迁移到正式环境后，更改为本地绑定(127.0.0.1)
	`
};

module.exports = {
  str0
};
