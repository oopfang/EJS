let util = require('util');
let Evt = require('events').EventEmitter;

class Messager {
  constructor() {
    this.emitter = new Evt(this);
    this.queue = [];
  }
  onEvent(eventName, callback) {
    this.emitter.on(eventName, callback);
  }
  emitEvent(eventName, arg) {
    this.emitter.emit(eventName, arg);
  }
  msgIn(msg) {
    return new Promise((resolve, reject) => {
      this.queue.push(msg);
      this.emitEvent('msgin', '');
      resolve();
    });
  }
  msgOut() {
    return this.queue.shift();
  }
  clear() {
    this.queue = [];
  }
};

util.inherits(Messager, Evt);

module.exports = Messager