let fs = require('fs');
let amqp = require('amqplib/callback_api');
let tEnumLog = require('tframe-enum').log;
let mongoose = require('mongoose');
let preBend = require('tframe-prebend');
let tErr = preBend.preError;
let confStr = fs.readFileSync('../sys_conf/.config', 'utf8').replace(/.*\/\/.*\r\n/g, '');
let conf = preBend.preConfig(JSON.parse(confStr)).config;

let logTypes = Object.keys(tEnumLog.logLevel);
let _args = process.argv.slice(2);
let severities = _args.length > 0 ? _args : logTypes;
let dbUri = `mongodb://${conf.db.logDb.dbHost}:${conf.db.logDb.dbPort}/${conf.app.appName}`;

console.log(`Notes:
        you can also use specified type to run this log server. such as:

        node index.js error   (that will be watching error type log only)

        or

        node index.js info error    (that will be watching both info and error type log)

        or just like this

        node index.js   (this time, the server will start with all log types by default)

any way, you can use any combination with key(s) which is in object ('tframe-enum/log/logLevel') to start it!`)
console.log('%s\x1B[32m%s\x1b[0m', '\nlogSvr is watching on：  ', `${conf.server.logSvr.addr}:${conf.server.logSvr.port}.\n\n`);
console.log("%s\x1B[32m%s\x1b[0m", 'route key(s) is：  ', `${severities.join(", ")}`);
console.log('\n\n')

const logSchema = {};

const logTblSchema = {
  logType: String,
  logLevel: String,
  indexCode: String,
  detailCode: String,
  memo: String,
  logOnDate: String
};

let getSchema = (tp, level) => {
  let _str = `${tp}_${level}`;
  if (!logSchema[_str]) {
    logSchema[_str] = mongoose.model(_str, logTblSchema);
  }
  return logSchema[_str];
};

// 初始化日志表结构对象;
let init = function () {
  for (let v of Object.keys(tEnumLog.actTypeCode)) {
    for (let l of Object.keys(tEnumLog.actLevelCode)) {
      getSchema(v, l);
    }
  }
};

let errHandler = (err, conn) => {
  tErr(err);
  if (conn) conn.close(() => {
    process.exit(1);
  });
}

let on_connect = (err, conn) => {
  if (err !== null) return errHandler(err);
  process.once('SIGINT', () => {
    conn.close();
  });

  mongoose.connect(
    dbUri, {
      useNewUrlParser: true
    },
    function (err) {
      if (err) {
        console.log('\n\n');
        tErr('系统强制关闭了该服务端！');
        return errHandler(err, conn);
      } else {
        console.log('日志数据库连接成功');
        init();
        conn.createChannel((err, ch) => {
          if (err !== null) return errHandler(err, conn);
          let ex = 'direct_logs';
          let exopts = {
            durable: true
          };
          ch.assertExchange(ex, 'direct', exopts);
          ch.assertQueue('', {
            exclusive: true
          }, (err, ok) => {
            if (err !== null) return errHandler(err, conn);
            let queue = ok.queue;
            let i = 0;

            let sub = err => {
              if (err !== null) return errHandler(err, conn);
              else if (i < severities.length) {
                ch.bindQueue(queue, ex, severities[i], {}, sub);
                i++;
              }
            }
            ch.consume(queue, logMessage, {
              noAck: true
            }, err => {
              if (err !== null) return errHandler(err, conn);
              console.log('[*] Waiting for logs. To exit press CTRL + C.\n');
              preBend.preSvr.svrOk(`${conf.app.appName} - logSvr\n`, conf.app.appVer, conf.server.logSvr.addr, conf.server.logSvr.port);
              sub(null);
            });
          });
        });
      }
    }
  );
}

let setLog = msg => {
  if (msg.type && msg.level && msg.detailCode) {
    let LogObj = getSchema(msg.type, msg.level);
    let _detail = tEnumLog.detailCode[msg.detailCode];
    let log = new LogObj({
      logType: msg.type,
      logLevel: msg.level,
      memo: msg.memo || _detail || '未提供详细的描述',
      indexCode: msg.detailCode ? msg.detailCode[0] : 'Z',
      detailCode: _detail || tEnumLog.detailCode['Z000'],
      logOnDate: `${new Date().toLocaleString()}`
    });
    log
      .save()
      .then(() => console.log('日志记录完成'))
      .catch(err => {
        tErr(err);
      });
  } else {
    tErr('传入的日志信息不完整，无法记录');
  }
}

let logMessage = msg => {
  console.log('  [x] %s:\'%s\'', msg.fields.routingKey, msg.content.toString());
  let _msg = JSON.parse(msg.content.toString());
  setLog(_msg);
}

amqp.connect(`amqp://${conf.server.logSvr.addr}:${conf.server.logSvr.port}`, on_connect);
