let express = require('express');
let router = express.Router();
let enumObj = require('tframe-enum');
let enum_log = enumObj.log;
let tPbend = require('tframe-prebend');
// 渠道表
const _cTblName = '__sysChannel';
// 用户表
const _uTblName = '_sysUser';
// 用户渠道映射表
const _uCtblName = '_sysUserChannel';

let tErr = tPbend.preError;
let tErrMsg = tPbend.preSvr.errToStr;
let getErr = (errMsg, errCode) => {
  let _defaultMsg = '渠道信息处理失败!';
  let _err = tErr(errMsg || _defaultMsg, errCode || 500);
  _err.reason = errMsg || _defaultMsg;
  return _err;
};

const _queryStr = `SELECT id, pid, code, namezh, chargemanid, memo, fullPath FROM __sysChannel WHERE stopped = 0 AND deleted = 0 ORDER BY pid, tLeft DESC;`;
const _qureyUserStr = `SELECT id, pid, code, name, namezh FROM ${_uTblName} WHERE jobNo <> '' AND stopped = 0 AND deleted = 0;`;

// 将数据记录行转换为可输出的节点对象
let getNodeObj = record => {
  return {
    id: record.id,
    pid: record.pid,
    code: record.code,
    namezh: record.namezh,
    chargemanid: record.chargemanid,
    fullPath: record.fullPath,
    memo: record.memo,
    children: []
  };
};

// 将行式数据表记录转换为树状主从JS对象
let _orgListToObj = channelList => {
  let _outObj = {};
  if (channelList && channelList.length > 0) {
    // 获取行式数据集除根记录之外的影子对象
    let _objFlat = {};
    for (let v of channelList) {
      _objFlat[v.id] = getNodeObj(v);
    }
    while (channelList.length > 0) {
      let _currItem = channelList.pop();
      if (_currItem.pid > 0) {
        _objFlat[_currItem.pid].children.push(_objFlat[_currItem.id]);
        delete(_objFlat[_currItem.id]);
      } else {
        _outObj = _objFlat[_currItem.id];
        _outObj.isRoot = true;
      }
    }
  }
  return _outObj;
};

// 将待插入值转换为单引号包裹的字符串
let _getStr = (key, val) => {
  return `${key} = '${val}'`;
};

// 获取渠道列表
router.get('/list', async (req, res, next) => {
  try {
    let _resList = await dbObj.dbExec(`${_queryStr}${_qureyUserStr}`);
    let _objFlat = {};
    for (let v of _resList[0]) {
      _objFlat[v.id] = v;
    }
    let _resObj = _orgListToObj(_resList[0]);
    res.apiOk({
      obj: _resObj,
      objFlat: _objFlat,
      users: _resList[1]
    });
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 新增渠道节点
router.post('/add', async (req, res, next) => {
  try {
    let {
      pid,
      code,
      namezh,
      chargemanid
    } = req.body;

    let _orgFlat = {};
    (await dbObj.dbExec(`SELECT id, fullPath FROM ${_cTblName};`)).forEach(v => {
      _orgFlat[v.id] = {
        pid: v.pid,
        fullPath: v.fullPath
      };
    });

    let _strRight = `SELECT tRight FROM ${_cTblName} WHERE id = ${pid};`;
    let _leftVal = ((await dbObj.dbExec(_strRight))[0]).tRight;
    if (_leftVal && _leftVal > 1) {
      let _strL = `UPDATE ${_cTblName} SET tLeft = tLeft + 2 WHERE tLeft >  ${_leftVal};`;
      let _strR = `UPDATE ${_cTblName} SET tRight = tRight + 2 WHERE tRight >=  ${_leftVal};`;
      await dbObj.dbExec(`${_strL}${_strR}`);
      let _str = `INSERT INTO \`${_cTblName}\` (\`pid\`, \`code\`, \`namezh\`, \`chargemanid\`, \`tLeft\`, \`tRight\`, \`fullPath\`) 
      VALUES('${pid}', '${code}', '${namezh}', '${chargemanid}', '${_leftVal}', '${_leftVal + 1}', '${_orgFlat[pid].fullPath} \/ ${namezh}');
      `;
      let _resList = (await dbObj.dbExec(`${_str}${_queryStr}`))[1];
      let _objFlat = {};
      for (let v of _resList) {
        _objFlat[v.id] = v;
      }
      let _resObj = _orgListToObj(_resList);
      res.apiOk({
        obj: _resObj,
        objFlat: _objFlat
      });
    } else {
      let eType = enum_log.actTypeCode.db;
      let eLevel = enum_log.actLevelCode.error;
      let _msg = '节点二叉值获取失败';
      let eCode = 'B300';
      setLog(eType, eLevel, _msg, eCode);
      let _err = getErr(_msg, 500);
      next(_err);
    }
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 修改渠道节点信息
router.put('/reInfo', async (req, res, next) => {
  try {
    let {
      id,
      pid,
      code,
      namezh,
      chargemanid,
      fullPath
    } = req.body;
    let _str = `UPDATE ${_cTblName} SET code = '${code}', pid = '${pid}', namezh = '${namezh}', chargemanid = '${chargemanid}', fullPath = '${fullPath}' WHERE id = ${id};`;
    let _resList = (await dbObj.dbExec(`${_str}${_queryStr}`))[1];
    let _objFlat = {};
    for (let v of _resList) {
      _objFlat[v.id] = v;
    }
    let _resObj = _orgListToObj(_resList);
    res.apiOk({
      obj: _resObj,
      objFlat: _objFlat
    });
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 删除渠道节点
router.put('/stop', async (req, res, next) => {
  try {
    let _id = req.body.id;
    // 受影响的渠道范围ID
    let _procStr = `CALL bTreeDel(${_id}, '${_cTblName}')`;
    let resIds = (await dbObj.dbExec(_procStr))[0].map(v => v.id).join(',');
    let _userUpStr = `DELETE FROM ${_uCtblName} WHERE cid IN (${resIds});`;
    let _resList = (await dbObj.dbExec(`${_userUpStr}${_queryStr}`))[1];
    let _objFlat = {};
    for (let v of _resList) {
      _objFlat[v.id] = v;
    }
    let _resObj = _orgListToObj(_resList);
    res.apiOk({
      obj: _resObj,
      objFlat: _objFlat
    });
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});


module.exports = router;
