/* 
  解决前端页面在token过期后，浏览器重新打开停留在缓存页面无法跳转到登陆页面的问题
*/

let express = require('express');
let router = express.Router();

/* 登录 */
router.get('/*', async (req, res, next) => {
  res.apiOk('resOk');
});

module.exports = router;
