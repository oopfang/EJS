let express = require('express');
let router = express.Router();
let enumObj = require('tframe-enum');
let enum_log = enumObj.log;
let dayjs = require('dayjs');
let tPbend = require('tframe-prebend');
// 雇员表
let _uTblName = '_sysUser';
// 组织表
let _oTblName = '__sysOrgs';
// 渠道表
let _cTblName = '__sysChannel';
// 用户组织映射表
const _uOtblName = '_sysUserOrgan';
// 用户渠道映射表
const _uCtblName = '_sysUserChannel';

let tErr = tPbend.preError;
let tErrMsg = tPbend.preSvr.errToStr;
let getErr = (errMsg, errCode) => {
  let _defaultMsg = '组织信息处理失败!';
  let _err = tErr(errMsg || _defaultMsg, errCode || 500);
  _err.reason = errMsg || _defaultMsg;
  return _err;
};

const _queryOrg = `SELECT \`id\`, \`namezh\`, \`pid\`, \`chargemanid\`, \`fullPath\` FROM \`__sysOrgs\` WHERE stopped = 0 AND deleted = 0;`;
const _queryChannel = `SELECT \`id\`, \`namezh\`, \`pid\`, \`chargemanid\`, \`fullPath\` FROM \`__sysChannel\` WHERE stopped = 0 AND deleted = 0;`;
const _queryEmployee = `SELECT a.\`id\`, a.\`pid\`, a.\`jobNo\`, a.\`code\`, a.\`name\`, a.\`namezh\`, CASE a.\`gender\` WHEN 1 THEN '男' ELSE '女' END AS gender, a.\`phoneWork\`, a.\`phonePrivate\`, a.\`email\`, a.\`avatar\`, a.\`staffDate\`, a.\`memo\`, a.\`suspened\`, b.\`oid\`, c.\`cid\` FROM \`_sysUser\` a
LEFT JOIN (SELECT \`pid\`, GROUP_CONCAT(\`oid\`) AS oid FROM \`_sysUserOrgan\` GROUP BY \`pid\`) b ON a.\`id\` = b.\`pid\`
LEFT JOIN (SELECT \`pid\`, GROUP_CONCAT(\`cid\`) AS cid FROM \`_sysUserChannel\` GROUP BY \`pid\`) c ON a.\`id\` = c.\`pid\`
WHERE a.\`deleted\` = 0 AND a.\`code\` <> 'admin' AND a.\`code\` <> 'auth' AND a.\`code\` <> 'test' AND a.\`jobNo\` <> '' AND a.\`accType\` = 1;`;

// 获取雇员列表
router.get('/list', async (req, res, next) => {
  try {
    let _resList = await dbObj.dbExec(`${_queryOrg}${_queryChannel}${_queryEmployee}`);
    res.apiOk({
      orgList: _resList[0],
      channelList: _resList[1],
      employeeList: _resList[2]
    });
  } catch (err) {
    let eType = enum_log.actTypeCode.userOperat;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 新增雇员
router.post('/add', async (req, res, next) => {
  try {
    let { id, pid, code, name, namezh, genderVal, phoneWork, phonePrivate, email, orgs, channel } = req.body;
    let _jNoStr = `SELECT \`key\`, title FROM __dictStr WHERE \`group\` = 'autoNo';`;
    let _newStr = `INSERT INTO ${_uTblName}(pid, code, name, namezh, gender, phoneWork, phonePrivate, email) VALUES('${pid}', '${code}', '${name}', '${namezh}', '${genderVal}', '${phoneWork}', '${phonePrivate}', '${email}');`
    let _resNewObj = (await dbObj.dbExec(`${_jNoStr}${_newStr}`));
    let _numObj = _resNewObj[0];
    let _newId = _resNewObj[1].insertId;
    let _orgVals = orgs.map(v => `(${_newId}, ${v.id})`).join(",");
    let _channelVals = channel.map(v => `(${_newId}, ${v.id})`).join(',');
    let _orgStr = `INSERT INTO ${_uOtblName}(pid, oid) VALUES${_orgVals} ON DUPLICATE KEY UPDATE \`oid\` = VALUES(oid);`;
    let _channelStr = `INSERT INTO ${_uCtblName}(pid, cid) VALUES${_channelVals} ON DUPLICATE KEY UPDATE \`cid\` = VALUES(cid);`;
    let _numFlat = {};
    _numObj.forEach(v => {
      _numFlat[v.code] = v.namezh;
    });
    let _jonNum = ('0').repeat(parseInt(_numFlat.jobNoLen) - (`${_newId}`).length);
    let _jobSmb = `${_numFlat.jobNoPre}${_jonNum}${_newId}`;
    let _newEmployeeStr = `SELECT a.\`id\`, a.\`pid\`, a.\`jobNo\`, a.\`code\`, a.\`name\`, a.\`namezh\`, CASE a.\`gender\` WHEN 1 THEN '男' ELSE '女' END AS gender, a.\`phoneWork\`, a.\`phonePrivate\`, a.\`email\`, a.\`avatar\`, a.\`staffDate\`, a.\`memo\`, a.\`suspened\`, b.\`oid\`, c.\`cid\` FROM \`_sysUser\` a
      LEFT JOIN (SELECT \`pid\`, GROUP_CONCAT(\`oid\`) AS oid FROM \`${_uOtblName}\` GROUP BY \`pid\`) b ON a.\`id\` = b.\`pid\`
      LEFT JOIN (SELECT \`pid\`, GROUP_CONCAT(\`cid\`) AS cid FROM \`${_uCtblName}\` GROUP BY \`pid\`) c ON a.\`id\` = c.\`pid\`
      WHERE a.\`id\` = ${_newId};`;
    let _orgCharge = orgs.filter(v => v.incharge);
    let _channelCharge = channel.filter(v => v.incharge);
    let _orgChargeStr = '';
    let _channelChargeStr = '';
    if (_orgCharge.length > 0) {
      _orgChargeStr = _orgCharge.map(v => `UPDATE ${_oTblName} SET chargemanid = ${_newId} WHERE id = ${v.id};`).join('');
    }
    if (_channelCharge.length > 0) {
      _channelChargeStr = _channelCharge.map(v => `UPDATE ${_cTblName} SET chargemanid = ${_newId} WHERE id = ${v.id};`).join('');
    }
    let _upStr = `UPDATE ${_uTblName} SET jobNo = '${_jobSmb}' WHERE id = ${_newId};`;
    let _onNewObj = await dbObj.dbExec(`${_upStr}${_orgStr}${_channelStr}${_newEmployeeStr}${_orgChargeStr}${_channelChargeStr}`);
    res.apiOk(_onNewObj[3][0]);
  } catch (err) {
    let eType = enum_log.actTypeCode.userOperat;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 新增雇员账号
router.post('/addAcc', async (req, res, next) => {
  try {
    let { code, name, namezh, gender, roleId, accType } = req.body.data;
    let _jNoStr = `SELECT \`key\`, title FROM __dictStr WHERE \`group\` = 'autoNo';`;
    let _newStr = `INSERT INTO ${_uTblName}(pid, code, name, namezh, gender, roleId, accType) VALUES('1', '${code}', '${name}', '${namezh}', '${gender}', '${roleId}', '${accType}');`
    let _resNewObj = (await dbObj.dbExec(`${_jNoStr}${_newStr}`));
    let _newId = _resNewObj[1].insertId;
    let _orgStr = `INSERT INTO ${_uOtblName}(pid, oid) VALUES('${_newId}, '1') ON DUPLICATE KEY UPDATE \`oid\` = VALUES(oid);`;
    let _channelStr = `INSERT INTO ${_uCtblName}(pid, cid) VALUES('${_newId}, '1') ON DUPLICATE KEY UPDATE \`cid\` = VALUES(cid);`;
    dbObj.dbExec(`${_orgStr}${_channelStr}`);
    let _strAcc = `SELECT a.id, a.code, a.namezh, a.avatar, a.gender, a.roleId, CASE WHEN a.accType = 1 THEN \'雇员账号\' ELSE \'外部账号\' END AS accountType, a.signup, a.lastsignin, a.lastsignout, a.lastip, a.memo, a.stopped, a.deleted, a.createby, a.changeby, b.oid FROM _sysUser a LEFT JOIN(SELECT pid, GROUP_CONCAT(oid) AS oid FROM _sysUserOrgan GROUP BY pid) b ON a.id = b.pid WHERE a.id = ${_newId};`
    let resNewUser = await dbObj.dbExec(_strAcc);
    res.apiOk(resNewUser[0]);
  } catch (err) {
    let eType = enum_log.actTypeCode.userOperat;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

router.put('/edit', async (req, res, next) => {
  try {
    let { id, pid, name, namezh, genderVal, phoneWork, phonePrivate, email, orgs, channel } = req.body;
    let _orgVals = orgs.map(v => `(${id}, ${v.id})`).join(',');
    let _channelVal = channel.map(v => `(${id}, ${v.id})`).join(',');
    let _upStr = `UPDATE ${_uTblName} SET pid = '${pid}', name = '${name}', namezh = '${namezh}', gender = '${genderVal}', phoneWork = '${phoneWork}', phonePrivate = '${phonePrivate}', email = '${email}' WHERE id = ${id};`;
    let _orgStr = `INSERT INTO ${_uOtblName}(pid, oid) VALUES${_orgVals} ON DUPLICATE KEY UPDATE \`oid\` = VALUES(oid);DELETE FROM ${_uOtblName} WHERE pid = ${id} AND oid NOT IN (${orgs.map(v => v.id).join(',')});`;
    let _channelStr = `INSERT INTO ${_uCtblName}(pid, cid) VALUES${_channelVal} ON DUPLICATE KEY UPDATE \`cid\` = VALUES(cid);DELETE FROM ${_uCtblName} WHERE pid = ${id} AND cid NOT IN (${channel.map(v => v.id).join(',')});`;
    let _newEmployeeStr = `SELECT a.\`id\`, a.\`pid\`, a.\`jobNo\`, a.\`code\`, a.\`name\`, a.\`namezh\`, CASE a.\`gender\` WHEN 1 THEN '男' ELSE '女' END AS gender, a.\`phoneWork\`, a.\`phonePrivate\`, a.\`email\`, a.\`avatar\`, a.\`staffDate\`, a.\`memo\`, a.\`suspened\`, b.\`oid\`, c.\`cid\` FROM \`_sysUser\` a
      LEFT JOIN (SELECT \`pid\`, GROUP_CONCAT(\`oid\`) AS oid FROM \`${_uOtblName}\` GROUP BY \`pid\`) b ON a.\`id\` = b.\`pid\`
      LEFT JOIN (SELECT \`pid\`, GROUP_CONCAT(\`cid\`) AS cid FROM \`${_uCtblName}\` GROUP BY \`pid\`) c ON a.\`id\` = c.\`pid\`
      WHERE a.\`id\` = ${id};`;
    let _orgCharge = orgs.filter(v => v.incharge);
    let _channelCharge = channel.filter(v => v.incharge);
    let _orgChargeStr = '';
    let _channelChargeStr = '';
    if (_orgCharge.length > 0) {
      _orgChargeStr = _orgCharge.map(v => `UPDATE ${_oTblName} SET chargemanid = ${id} WHERE id = ${v.id};`).join('');
    }
    if (_channelCharge.length > 0) {
      _channelChargeStr = _channelCharge.map(v => `UPDATE ${_cTblName} SET chargemanid = ${id} WHERE id = ${v.id};`).join('');
    }
    let _resObj = await dbObj.dbExec(`${_upStr}${_orgStr}${_channelStr}${_newEmployeeStr}${_orgChargeStr}${_channelChargeStr}`);
    res.apiOk(_resObj[3][0]);
  } catch (err) {
    let eType = enum_log.actTypeCode.userOperat;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 对雇员停职
router.put('/stop', async (req, res, next) => {
  try {
    await dbObj.dbExec(`UPDATE ${_uTblName} SET stopped = 1 WHERE id = ${req.body.id};`);
    res.apiOk('ok');
  } catch (err) {
    let eType = enum_log.actTypeCode.userOperat;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 对雇员离职
router.put('/del', async (req, res, next) => {
  try {
    let _id = req.body.id;
    let _strUser = `UPDATE ${_uTblName} SET outDate = '${dayjs().format(enumObj.sys.dateFormatStr.strDateTime)}', roleId = '3', stopped = 1, deleted = 1 WHERE id = ${_id};`;
    let _strOrg = `UPDATE ${_oTblName} SET chargemanid = 1 WHERE chargemanid = ${_id};`;
    let _strChannel = `UPDATE ${_cTblName} SET chargemanid = 1 WHERE chargemanid = ${_id};`;
    let _strUo = `DELETE FROM ${_uOtblName} WHERE pid = ${_id};`;
    let _strUc = `DELETE FROM ${_uCtblName} WHERE pid = ${_id};`;
    await dbObj.dbExec(`${_strUser}${_strOrg}${_strChannel}${_strUo}${_strUc}`);
    res.apiOk('ok');
  } catch (err) {
    let eType = enum_log.actTypeCode.userOperat;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

module.exports = router;
