let express = require('express');
let tErr = require('tframe-prebend').preError;
let preOrms = require('tframe-orms').preOrms;
let crud = require('tframe-enum').crud;
let router = express.Router();
let _execer = require('../utility/execer');

// 任务补偿
let _taskMakeUp = task => {
  try {
    if (task) {
      if (Array.isArray(task)) {
        return task.map(v => {
          return _taskMakeUp(v);
        });
      } else if (typeof task === 'string') {
        return task;
      } else {
        let {
          $after,
          ...taskLeft
        } = task;
        let _checkTask = preOrms.taskVerify(task);
        let currOrm = global.orms[task.bizIdent];
        if (currOrm) {
          task.define = currOrm;
          if ($after) {
            task.$after = _taskMakeUp($after);
          }
          return task;
        } else {
          throw tErr('请求参数中指定标识的业务模块不存在', 403);
        }
      }
    } else {
      throw tErr('未提供执行任务，已拒绝执行', 403);
    }
  } catch (err) {
    throw tErr(err, 403);
  }
};

// 任务调度器
let _taskDispatch = async (task, lastId) => {
  try {
    let _task = _taskMakeUp(task);
    if (_task) {
      if (Array.isArray(_task)) {
        return await Promise.all(_task.map(v => {
          _taskDispatch(v);
        }));
      } else if (typeof task === 'string') {
        return await _execer(task);
      } else {
        let _cmd = [];
        let {
          $after,
          ...taskLeft
        } = _task;
        if (taskLeft.$act === crud.act.add) {
          let _insertSet = taskLeft.define.setInsert;
          if (lastId && _insertSet && _insertSet.asDetail && taskLeft.data && Array.isArray(taskLeft.data) && taskLeft.data.length > 0) {
            taskLeft.data = taskLeft.data.map(v => {
              v.pid = lastId;
              return v;
            });
          }
        }
        _cmd.push(preOrms.task2Sql(taskLeft));
        let _func = task.define[`${task.$act}Act`];
        if (_func) {
          /* 传入参数
             @待执行的SQL命令
             @db执行器
             @任务调度器_taskDispatch（本函数自身）
             @补偿后的请求任务
          */
          return await _func(_cmd.length > 1 ? _cmd : _cmd[0], _execer, _taskDispatch, _task);
        } else {
          return await _execer(_cmd.length > 1 ? _cmd : _cmd[0]);
        }
      }
    } else {
      throw tErr('未提供执行任务，已拒绝执行', 403);
    }
  } catch (err) {
    throw tErr(err, 403);
  }
};

// 请求调度器
let reqMgr = async (req, lastId) => {
  try {
    if (req) {
      // 判断请求是否是数组
      if (Array.isArray(req)) {
        // 是（肯定不包括串联管道）
        return await Promise.all(req.map((v => {
          return reqMgr(v);
        })));
      } else {
        // 否（需要校验是否存在串联管道）
        let {
          $before,
          $after,
          ...currTask
        } = req;
        if ($before) {
          let _resRooter = {
            $before: await reqMgr($before)
          };
          if ($after) {
            _resRooter.$after = await reqMgr($after);
          }
          return _resRooter;
        } else {
          let _preFix = global.config.app.prefix ? `${global.config.app.prefix}_` : '';
          req.bizIdent = `${_preFix}${req.bizIdent}`;
          let _currRes = await _taskDispatch(req, lastId);
          if ($after) {
            if (Array.isArray($after)) {
              for (let v of $after) {
                if (req.$act === crud.act.add && v.$act === crud.act.add && _currRes.insertId && _currRes.insertId > 0) {
                  _currRes.$after = await reqMgr(v, _currRes.insertId);
                } else {
                  _currRes.$after = await reqMgr(v);
                }
              }
            } else {
              if (req.$act === crud.act.add && $after.$act === crud.act.add && _currRes.insertId && _currRes.insertId > 0) {
                _currRes.$after = await reqMgr($after, _currRes.insertId);
              } else {
                _currRes.$after = await reqMgr($after);
              }
            }
          }
          return _currRes;
        }
      }
    } else {
      throw tErr('请求参数为空，请求未执行!', 403);
    }
  } catch (err) {
    throw tErr(err, 403);
  }
};

router.get('/:bizId/obj', async (req, res, next) => {
  try {
    let _resAll = await reqMgr(req.query);
    if (Array.isArray(req.query)) {
      res.apiOk(_resAll.map((v, k, arr) => {
        return k === 0 ? v[0] : v;
      }))
    } else {
      if (_resAll.$before) {
        if (Array.isArray(_resAll.$before)) {
          let _resNew = _resAll.$before[0];
          if (_resNew && _resAll.$after) {
            _resNew.$after = _resAll.$after;
            res.apiOk(_resNew);
          } else {
            res.apiErr(tErr('没有获取到任何数据'));
          }
        } else {
          let _resNew = _resAll.$before;
          if (_resAll.$after) {
            _resNew.$after = _resAll.$after;
          }
          res.apiOk(_resNew);
        }
      } else {
        let _resNew = _resAll[0];
        if (_resAll.$after) {
          _resNew.$after = _resAll.$after;
        }
        res.apiOk(_resNew);
      }
    }
  } catch (err) {
    res.apiErr(err, 403);
  }
});

router.get('/:bizId/list', async (req, res, next) => {
  try {
    let _resAll = await reqMgr(req.query);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err, 403)
  }
});

router.get('/range', async (req, res, next) => {
  try {
    let _resAll = await reqMgr(req.query);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err, 403);
  }
});

router.post('/:bizId', async (req, res, next) => {
  try {
    let _resAll = await reqMgr(req.body);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err, 403);
  }
});

// router.put('/:bizId', async (req, res, next) => {
//   try {
//     let _resAll = await reqMgr(req.body);
//     res.apiOk(_resAll);
//   } catch (err) {
//     res.apiErr(err, 403);
//   }
// });

// /** 类审批操作
//  */
// router.put('/appro', async (req, res, next) => {
//   try {
//     let { bizIdent, id, title = '审批', val } = req.body;
//     let _currVal = parseInt(val);
//     if (!bizIdent || !id || id < 1 || (val !== undefined && isNaN(_currVal))) {
//       res.apiErr(new Error(`${title}要素不完整，${title}失败！`), 403);
//     } else {
//       let _resAppro = await _execer(`UPDATE ${bizIdent} SET approStep = ${_currVal || 0} + 1 WHERE id = ${id};`);
//       res.apiOk(`${title}成功!`);
//     }
//   } catch (err) {
//     res.apiErr(err, 403);
//   }
// });

/**
 * 废除指定ID的业务
 * @option参数： bizIdent[必须]、id[必须]
 */
router.put('/biz/stop', async (req, res, next) => {
  try {
    let { bizIdent, id } = req.body;
    let _resAll = await _execer(`UPDATE ${bizIdent} SET stopped = 1 WHERE id = ${id};`);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err, 403);
  }
});

router.delete('/:bizId', async (req, res, next) => {
  try {
    let _resAll = await reqMgr(req.query);
    res.apiOk(_resAll.affectedRows);
  } catch (err) {
    res.apiErr(err, 403);
  }
});

module.exports = router;
