let express = require('express');
let router = express.Router();
let _execer = require('../utility/execer');
let UudCode = require('../utility/getUud');
let qr = require('qr-image');
let tGlb = require('tframe-globalext');
let { getByUuId } = require('../utility/blockChain');

tGlb();
let Tdate = globalThis.smpoo.Tdate;
const checkTypeDef = {
  1: '退检合格',
  2: '修补后合格',
  3: '已过临保',
  4: '已报废'
};

router.get('/qr',function(req,res){
  var code = qr.image('http://192.168.199.44:3000/chainBlock',{type:'png'});
  res.setHeader('Content-type', 'image/png');
  code.pipe(res);
});

router.get('/', async (req, res, next) => {
  try {
    let _str = `SELECT a.pid AS billReturenAskId, a.\`code\`, a.custId, b.custNamezh, a.province, a.city, a.prodId, 
    c.producNamezh, a.spec, d.specNamezh, a.size, e.sizeNamezh, a.unit, c.price, c.picAddr,
    a.checkTypeId, f.checkTypeNamezh, a.dateValidityEnd, a.reason, a.memo 
    FROM inventory a
    LEFT JOIN (SELECT id, namezh AS custNamezh FROM customer) b ON a.custId = b.id
    LEFT JOIN (SELECT id, namezh AS producNamezh, price, picAddr FROM produc) c ON a.prodId = c.id
    LEFT JOIN (SELECT id, namezh AS specNamezh FROM groupColor) d ON a.spec = d.id
    LEFT JOIN (SELECT id, namezh AS sizeNamezh FROM groupSize) e ON a.size = e.id
    LEFT JOIN (SELECT \`key\`, title AS checkTypeNamezh FROM __dictInt WHERE \`group\` = 'returnQualityType') f ON a.checkTypeId = f.\`key\`
    WHERE a.uuCodePub = '2752581' AND a.uuCodePrive = '*-*-007-1-70-6-0-10-050-0-*-2';`;
    // 退货申请
    let _str1 = `SELECT a.quantityAsk, e.reasonName, b.dateAsk, DATE_FORMAT(a.createby, '%T') AS timeAsk, b.returnTypeNamezh
      FROM returenAskDetail a
      LEFT JOIN (
        SELECT c.id, c.dateAsk, d.returnTypeNamezh FROM billReturenAsk c
        LEFT JOIN (SELECT \`key\`, title AS returnTypeNamezh FROM __dictInt WHERE \`group\` = 'returnType') d ON c.returnTypeId = d.\`key\`
        WHERE c.id = 4
      ) b ON a.pid = b.id
      LEFT JOIN (SELECT id, namezh AS reasonName FROM ruleVerify) e ON a.reason = e.id
      WHERE pid = 4 AND prodId = 1 AND spec = 2 AND size = 3;`
    // 退货入库
    let _str2 = `SELECT dateStroeIn, DATE_FORMAT(createby, '%T') AS timeStroeIn FROM billStockIn WHERE pid = 6;`;
    // 退货检验
    let _str3 = `SELECT a.dateValidityEnd, b.checkTypeNamezh, DATE_FORMAT(a.createby, '%T') AS timeValidityEnd
    FROM billVrifyDetail a
    LEFT JOIN (SELECT \`key\`, title AS checkTypeNamezh FROM __dictInt WHERE \`group\` = 'returnQualityType') b ON a.checkTypeId = b.\`key\`
    WHERE a.uuCodePub = '1221723' AND a.uuCodePrive = '*-*-*-0-010-3-2-007-60-33-10-2';`;
    // 商城销售
    let _str4 = `SELECT DATE_FORMAT(createby, '%Y-%m-%d') AS dateSales, DATE_FORMAT(createby, '%T') AS timeSales FROM billPickDetail WHERE id = 3;`;
    
    let [a, [b], [c], [d], [e], [f]] = await Promise.all([
      // 此处的传参代码需通过二维码的公码和私钥解析出的唯一码替代
      getByUuId('20200716063728331'),
      _execer(_str),
      _execer(_str1),
      _execer(_str2),
      _execer(_str3),
      _execer(_str4)
    ]);
    // 是否已查询到上链信息
    b.inChain = a && a.length;
    let _chainObj = {};
    for (let v of a) {
      _chainObj[v.action] = v.txid;
    }

    b.namezhChain = (b.inChain && (a[0].pcname || '')) || '未查询到上链信息';
    b.specAndSizeNamezh = `${b.specNamezh} / ${b.sizeNamezh}`;
    b.provinceAndCity = `${b.province}-${b.city}`;
    b.co2 = a.co2 || '80.7'
    // 退货申请数据
    b.returnAskObj = c;
    // 退货入库数据
    d.txid = _chainObj.inbound || '该交易未取得上链信息'
    b.stroeInObj = d;
    // 退货检验数据
    b.checkObj = e;
    // 销售数据
    f.txid = _chainObj.outbound || '该交易未取得上链信息'
    b.salesObj = f;
    b.chainList = a || [];
    b.checkTypeDefNamezh = checkTypeDef[b.checkTypeId];
    b.custPageUrl = `/chainBlock/custQuery/${b.prodId}`;
    // b.qrImg = await qr.imageSync('http://192.168.199.44:3000/chainBlock', {type: 'png'});
    res.render('blockChain.ejs', b);
  } catch (err) {
    let { message, stack } = err;
    res.render('error.ejs', { message, stack });
  }
});

router.get('/custQuery/:id', async (req, res, next) => {
  try {
    // let [a] = await _execer(`SELECT id, namezh, province, city FROM customer WHERE id = ${req.params.id};`);
    let [a] = await _execer(`SELECT id, namezh, province, city FROM customer WHERE id = 1;`);
    if (a) {
      a.provinceAndCity = `${a.province}-${a.city}`;
      res.render('custNull.ejs', a);
    } else {
      res.render('recordNull.ejs', {tips: '查询到该单位'});
    }
  } catch (err) {
    console.error(err);
    let { message, stack } = err;
    res.render('error.ejs', { message, stack });
  }
});

module.exports = router;
