let express = require('express');
let router = express.Router();
let enumObj = require('tframe-enum');
let enum_log = enumObj.log;
let tPbend = require('tframe-prebend');
// 组织表
const _oTblName = '__sysOrgs';
// 用户表
const _uTblName = '_sysUser';
// 用户组织映射表
const _uOtblName = '_sysUserOrgan';

let tErr = tPbend.preError;
let tErrMsg = tPbend.preSvr.errToStr;
let getErr = (errMsg, errCode) => {
  let _defaultMsg = '组织信息处理失败!';
  let _err = tErr(errMsg || _defaultMsg, errCode || 500);
  _err.reason = errMsg || _defaultMsg;
  return _err;
};

const _queryStr = `SELECT id, pid, code, namezh, organtypeid, chargemanid, memo, orderIndex, fullPath FROM __sysOrgs WHERE stopped = 0 AND deleted = 0 ORDER BY pid, orderIndex DESC;`;

// 将数据记录行转换为可输出的节点对象
let getNodeObj = record => {
  return {
    id: record.id,
    pid: record.pid,
    code: record.code,
    namezh: record.namezh,
    organtypeid: record.organtypeid,
    chargemanid: record.chargemanid,
    orderIdx: record.orderIndex,
    memo: record.memo,
    children: []
  };
};

// 将行式数据表记录转换为树状主从JS对象
let _orgListToObj = orgList => {
  let _outObj = {};
  if (orgList && orgList.length > 0) {
    // 获取行式数据集除根记录之外的影子对象
    let _objFlat = {};
    for (let v of orgList) {
      _objFlat[v.id] = getNodeObj(v);
    }
    while (orgList.length > 0) {
      let _currItem = orgList.pop();
      if (_currItem.pid > 0) {
        _objFlat[_currItem.pid].children.push(_objFlat[_currItem.id]);
        delete(_objFlat[_currItem.id]);
      } else {
        _outObj = _objFlat[_currItem.id];
        _outObj.isRoot = true;
      }
    }
  }
  return _outObj;
};

// 将待插入值转换为单引号包裹的字符串
let _getStr = (key, val) => {
  return `${key} = '${val}'`;
};

// 将传入的组织数据数组转换为数据表UPDATE字符串
let _getValueStr = arr => {
  return arr.map(v => {
    if (v) {
      let {
        id,
        pid,
        namezh,
        organtypeid,
        chargemanid,
        memo,
        orderIndex
      } = v;
      return `UPDATE ${_oTblName} SET ${_getStr('pid', pid)}, ${_getStr('namezh', namezh)}, ${_getStr('organtypeid', organtypeid)}, ${_getStr('chargemanid', chargemanid)}, ${_getStr('memo', memo)}, ${_getStr('orderIndex', orderIndex)} WHERE ${_getStr('id', id)};`
    } else {
      return '';
    }
  }).join('');
};

// 获取组织列表
router.get('/list', async (req, res, next) => {
  try {
    let _resList = await dbObj.dbExec(_queryStr);
    let _resObj = _orgListToObj(_resList);
    res.apiOk(_resObj);
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 新增组织节点
router.post('/add', async (req, res, next) => {
  try {
    let {
      pid,
      code,
      namezh,
      organtypeid,
      chargemanid,
      memo,
      subCount
    } = req.body;

    let _orgFlat = {};
    (await dbObj.dbExec(`SELECT id, fullPath FROM ${_oTblName};`)).forEach(v => {
      _orgFlat[v.id] = {
        pid: v.pid,
        fullPath: v.fullPath
      };
    });

    let _strRight = `SELECT tRight FROM ${_oTblName} WHERE id = ${pid};`;
    let _leftVal = ((await dbObj.dbExec(_strRight))[0]).tRight;
    if (_leftVal && _leftVal > 1) {
      let _strL = `UPDATE ${_oTblName} SET tLeft = tLeft + 2 WHERE tLeft >  ${_leftVal};`;
      let _strR = `UPDATE ${_oTblName} SET tRight = tRight + 2 WHERE tRight >=  ${_leftVal};`;
      await dbObj.dbExec(`${_strL}${_strR}`);
      let _str = `INSERT INTO \`${_oTblName}\` (\`pid\`, \`code\`, \`namezh\`, \`organtypeid\`, \`chargemanid\`, \`memo\`, \`orderIndex\`, \`tLeft\`, \`tRight\`, \`fullPath\`) 
      VALUES('${pid}', '${code}', '${namezh}', '${organtypeid}', '${chargemanid}', '${memo}', '${subCount}', '${_leftVal}', '${_leftVal + 1}', '${_orgFlat[pid].fullPath} \/ ${namezh}');
      `;
      let _newId = (await dbObj.dbExec(_str)).insertId;
      res.apiOk(_newId);
    } else {
      let eType = enum_log.actTypeCode.db;
      let eLevel = enum_log.actLevelCode.error;
      let _msg = '节点二叉值获取失败';
      let eCode = 'B300';
      setLog(eType, eLevel, _msg, eCode);
      let _err = getErr(_msg, 500);
      next(_err);
    }
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 修改机构节点信息
router.put('/reInfo', async (req, res, next) => {
  try {
    let { id, code, namezh, memo } = req.body;
    let _str = `UPDATE ${_oTblName} SET code = '${code}', namezh = '${namezh}', memo = '${memo}' WHERE id = ${id};`;
    await dbObj.dbExec(_str);
    res.apiOk('ok');
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 重新设置组织列表
router.put('/reset', async (req, res, next) => {
  try {
    let _str = _getValueStr(req.body);
    let _resChange = await dbObj.dbExec(`${_str}${_queryStr}`);
    let _resObj = _orgListToObj(_resChange[_resChange.length - 1]);
    res.apiOk(_resObj);
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 注销组织节点
router.put('/stop', async (req, res, next) => {
  try {
    let _id = req.body.id;
    // 受影响的组织范围ID
    let _orgIdListStr = `SELECT id FROM ${_oTblName} a, (SELECT tLeft, tRight FROM ${_oTblName} WHERE id = ${_id}) b  WHERE a.tLeft >= b.tLeft AND a.tRight <= b.tRight AND a.stopped = 0 AND a.deleted = 0`;
    let _orgIdList = (await dbObj.dbExec(_orgIdListStr)).map(v => v.id).join(',');
    if (_orgIdList) {
      // 受影响的用户ID
      let _userIdListStr = `SELECT DISTINCT pid AS id FROM ${_uOtblName} WHERE oid IN (${_orgIdList});DELETE FROM _sysUserOrgan WHERE oid IN (${_orgIdList});`;
      let _execResult = await dbObj.dbExec(_userIdListStr);
      let _userIdList = '';
      if (_execResult[0].length > 0) {
        _userIdList = _execResult[0].map(v => v.id).join(',');
      }
      // 注销组织节点
      let _orgStopStr = `UPDATE ${_oTblName} SET deleted = 1 WHERE id IN (${_orgIdList});`;
      let _resUser = [];
      if (_userIdList) {
        // 查询受影响的用户列表
        let _unBindUserStr = `SELECT id, namezh, avatar FROM ${_uTblName} WHERE id IN (${_userIdList});`;
        let _oldOrgStr = `SELECT a.pid, a.oid, b.fullPath FROM ${_uOtblName} a LEFT JOIN (SELECT id, fullPath FROM ${_oTblName}) b ON a.oid = b.id WHERE a.pid IN (${_userIdList});`
        let _resOldUser = await dbObj.dbExec(`${_unBindUserStr}${_oldOrgStr}`);
        _resUser = _resOldUser[0].map(v => {
          let _oldOrgs = [];
          if (_resOldUser[1].length > 0) {
            _oldOrgs = _resOldUser[1].filter(vOrg => vOrg.pid === v.id && vOrg.oid > 1);
          }
          return {
            ...v,
            newOrgId: -1,
            oldOrg: _oldOrgs
          }
        });
      }
      await dbObj.dbExec(_orgStopStr);
      let _resNewOrg = await dbObj.dbExec(_queryStr);
      res.apiOk({
        newOrg: _orgListToObj(_resNewOrg),
        userSet: _resUser
      });
    } else {
      let eType = enum_log.actTypeCode.security;
      let eLevel = enum_log.actLevelCode.error;
      let _msg = '符合条件的组织节点查询失败，未做变更';
      let eCode = 'A200';
      setLog(eType, eLevel, _msg, eCode);
      next(getErr(new Error(_msg)));
    }
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 注销组织后的用户从属变更
router.put("/userReorg", async (req, res, next) => {
  try {
    let _arr = req.body;
    if (_arr.length > 0) {
      let _str = _arr.map(v => {
        return `INSERT INTO ${_uOtblName}(pid, oid) VALUES(${v.id}, ${v.newOrgId}) ON DUPLICATE KEY UPDATE \`oid\` = VALUES(oid);`
      }).join('');
      await dbObj.dbExec(_str);
    }
    res.apiOk('ok');
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = "A200";
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});


module.exports = router;
