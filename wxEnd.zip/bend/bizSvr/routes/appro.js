let express = require('express');
let router = express.Router();
let enumObj = require('tframe-enum');
let crud = enumObj.crud;
let enum_log = enumObj.log;
let tPbend = require('tframe-prebend');

let tErr = tPbend.preError;
let tErrMsg = tPbend.preSvr.errToStr;
let getErr = (errMsg, errCode) => {
  let _defaultMsg = '审批信息获取失败!';
  let _err = tErr(errMsg || _defaultMsg, errCode || 500);
  _err.reason = errMsg || _defaultMsg;
  return _err;
};

// 获取用户账号的指令
let _strAcc = 'SELECT a.id, a.code, a.namezh, a.avatar, a.gender, a.roleId, CASE WHEN a.accType = 1 THEN \'雇员账号\' ELSE \'外部账号\' END AS accountType, a.signup, a.lastsignin, a.lastsignout, a.lastip, a.memo, a.stopped, a.deleted, a.createby, a.changeby, b.oid FROM _sysUser a LEFT JOIN(SELECT pid, GROUP_CONCAT(oid) AS oid FROM _sysUserOrgan GROUP BY pid) b ON a.id = b.pid WHERE a.deleted = 0;'
// 获取角色的菜单授权细节的指令
let _strRoleMenu = 'SELECT id, pid, menuId, crudVal, extendVal, bizVal, disFieldRange FROM _roleGroupMenu ORDER BY pid, menuId;';

// 获取授权中心基本信息
router.get('/base', async (req, res, next) => {
  try {
    let _resArr = [];
    // 获取系统账号信息
    let _strRole = 'SELECT id, code, namezh, memo, stopped FROM _roleGroup;';
    let _strMenu = 'SELECT id, pid, code, name, namezh, level, hasSub, seedBizCode, seedBizTitle, bizApproCount, nodeRoles, nodeTypes, nodeUsers, nodeConditions, memo, orderIndex FROM _sysMenu WHERE code <> \'auth\' ORDER BY pid, orderIndex;';
    let _strOrg = 'SELECT id, pid, code, namezh, organtypeid, tLeft, tRight, fullPath FROM __sysOrgs;';
    let _strOrgType = 'SELECT id, code, namezh FROM __sysOrgType';
    let _str = `${_strAcc}${_strRole}${_strRoleMenu}${_strMenu}${_strOrg}${_strOrgType}`;
    let _resAppend = await dbObj.dbExec(_str);
    let _resOrms = {};
    for (let v of Object.keys(global.orms)) {
      let _currObj = global.orms[v];
      //  && !_currObj.setInsert.hybrid
      if (!_currObj.setInsert.asDetail) {
        _resOrms[v] = _currObj;
      }
    }
    let _resMenu = [];
    let _flowMenu = [];
    for (let v of _resAppend[3]) {
      if (v.level === 1) {
        let _vMenu = {
          id: v.id,
          pid: v.pid,
          title: v.namezh,
          key: v.code,
          icon: v.ico,
          orderIndex: v.orderIndex
        };
        if (v.hasSub) {
          _vMenu.children = [];
        }
        _resMenu.push(_vMenu);
      } else {
        let _idx = _resMenu.findIndex(vmenu => {
          return vmenu.id === v.pid;
        });
        if (_idx > -1 && _resMenu[_idx].children) {
          _resMenu[_idx].children.push({
            id: v.id,
            pid: v.pid,
            title: v.namezh,
            key: v.code,
            icon: v.ico,
            orderIndex: v.orderIndex
          });
        }
      }
      // 排除 settingSys 和 settingUser 等 setting 开头的ORM
      if (v.code.indexOf('setting') !== 0 && v.code !== 'home' && v.code !== 'reportWall') {
        if (v.level === 1) {
          if (v.hasSub === 0) {
            _flowMenu.push(v);
          }
        } else {
          _flowMenu.push(v);
        }
      }
    }
    let _orgs = {};
    for (let v of _resAppend[4]) {
      _orgs[`${v.id}`] = {
        id: v.id,
        pid: v.pid,
        code: v.code,
        namezh: v.namezh,
        organtypeid: v.organtypeid,
        tLeft: v.tLeft,
        tRight: v.tRight,
        fullPath: v.fullPath
      };
    }
    let _orgType = {};
    for (let v of _resAppend[5]) {
      _orgType[`${v.id}`] = v;
    }

    let _resObj = {
      orms: _resOrms,
      account: _resAppend[0],
      role: _resAppend[1],
      roleMenu: _resAppend[2],
      // 主从结构的菜单列表
      menus: _resMenu,
      // 工作流设计中的菜单列表
      flowMenu: _flowMenu,
      // 扁平结构的菜单列表
      menuFlat: _resAppend[3].map(v => {
        return {
          id: v.id,
          pid: v.pid
        };
      }),
      orgs: _orgs,
      orgType: _orgType
    }
    res.apiOk(_resObj);
  } catch (err) {
    let eType = enum_log.actTypeCode.security;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// [用户级] 修改密码
router.put('/userRePwd', async (req, res, next) => {
  try {
    let {
      id,
      code,
      namezh,
      oldPwd,
      newPwd
    } = req.body;
    if (id > 0 && oldPwd && newPwd) {
      let _orm = global.orms['users'];
      // 查询旧密码
      let _pwdOld = (await dbObj.dbExec(`SELECT uPwd FROM _sysUser WHERE id = ${id};`))[0].uPwd;
      if (_pwdOld === oldPwd) {
        // 处理新密码
        await dbObj.dbExec(`UPDATE _sysUser SET uPwd = '${newPwd}' WHERE id = ${id};`);
        let eType = enum_log.actTypeCode.security;
        let eLevel = enum_log.actLevelCode.info;
        let _msg = `用户 [${code}: ${namezh}] 更改了密码`;
        let eCode = 'G000';
        setLog(eType, eLevel, _msg, eCode);
        res.apiOk('密码修改成功');
      } else {
        let eType = enum_log.actTypeCode.security;
        let eLevel = enum_log.actLevelCode.warning;
        let _msg = `用户 [ ${code}: ${namezh} ] 更改密码时提供了错误的原始密码`;
        let eCode = 'G100';
        setLog(eType, eLevel, _msg, eCode);
        next(getErr('原始密码错误!', 403));
      }
    } else {
      let eType = enum_log.actTypeCode.userOperat;
      let eLevel = enum_log.actLevelCode.error;
      let _msg = `用户 [${code}: ${namezh}]试图修改密码时提供的参数校验失败`;
      let eCode = 'A200';
      setLog(eType, eLevel, _msg, eCode);
      next(getErr('密码修改失败', 403));
    }
  } catch (err) {
    let eType = enum_log.actTypeCode.svr;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'D200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

// 封停/启用指定账号
router.put('/acc/forbidden', async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    let _str = `UPDATE _sysUser SET stopped = ${req.body.isStop} WHERE id = ${req.body.id};`;
    let resForb = await dbObj.dbExec(_str);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `账号[ id: ${req.body.id} ]被封停`;
    let eCode = 'G000';
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(resForb);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`账号封停失败！原因：${err}`));
  }
});

// [管理级]重置指定账号的密码为初始密码
router.put('/acc/rePwd', async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    let _str = `UPDATE _sysUser SET uPwd = '7c4a8d09ca3762af61e59520943dc26494f8941b' WHERE id = ${req.body.id};`;
    let resForb = await dbObj.dbExec(_str);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `账号[ id: ${req.body.id} ]的密码被重置为初始密码`;
    let eCode = 'G000';
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(resForb);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`密码重置失败！原因：${err}`));
  }
});

// 创建角色
router.post('/role/add', async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    let {
      code,
      namezh,
      memo
    } = req.body;
    let resCreate = await dbObj.dbExec(`INSERT INTO _roleGroup(code, namezh, memo, stopped) VALUES('${code}', '${namezh}', '${memo}', 0);`);
    let _resNewRole = await dbObj.dbExec(`SELECT id, code, namezh, memo, stopped FROM _roleGroup WHERE id = ${resCreate.insertId};`);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `创建了新的角色${namezh}，角色ID为：${resCreate.insertId}`;
    let eCode = 'G000';
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(_resNewRole[0]);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`角色创建失败！原因：${err}`));
  }
});

// 角色变更
router.put('/role/reset', async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    let {
      id,
      roleStr
    } = req.body;
    let _str = `UPDATE _sysUser SET roleId = REPLACE('${roleStr}', ' ', '') WHERE id = ${id};`;
    let resRerole = await dbObj.dbExec(_str);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `账号[ id: ${id} ]的角色被更改为[${roleStr}]`;
    let eCode = 'G000';
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(resRerole);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`角色变更失败！原因：${err}`));
  }
});

// 角色的菜单授权变更
router.put('/role/reMenu', async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    if (Array.isArray(req.body) && req.body.length > 0) {
      let _roleId = req.body[0].pid;
      let _disableId = await dbObj.dbExec
      await dbObj.dbExec(`DELETE FROM _roleGroupMenu WHERE pid = ${_roleId};`)
      let _data = req.body.map(v => {
        return `('${v.pid}', '${v.menuId}')`;
      });
      let resMenu = await dbObj.dbExec(`INSERT INTO _roleGroupMenu (\`pid\`, \`menuId\`) VALUES ${_data.join(',')};${_strRoleMenu}`);
      let eLevel = enum_log.actLevelCode.info;
      let _msg = `角色[ id: ${_roleId} ]的菜单授权被更改`;
      let eCode = 'G000';
      setLog(eType, eLevel, _msg, eCode);
      res.apiOk(resMenu[1]);
    } else {
      res.apiOk('无需变更菜单授权');
    }
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`角色的菜单授权变更失败！原因：${err}`));
  }
});

// 角色的操作权限变更
router.put('/role/reOperat', async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    let {
      roleId,
      menuId,
      crudVal,
      extendVal,
      bizVal,
      disRange
    } = req.body;
    if (roleId && menuId && crudVal !== undefined && extendVal !== undefined && bizVal !== undefined && roleId > 0 && menuId > 0) {
      let _str = `UPDATE _roleGroupMenu SET crudVal = '${crudVal}', extendVal = '${extendVal}', bizVal = '${bizVal}', disFieldRange = '${disRange}' WHERE pid = '${roleId}' AND menuId = '${menuId}';`;
      let resReOpt = await dbObj.dbExec(`${_str}${_strRoleMenu}`);
      let eLevel = enum_log.actLevelCode.info;
      let _msg = `角色[ id: ${roleId} ]的操作授权被更改`;
      let eCode = 'G000';
      setLog(eType, eLevel, _msg, eCode);
      res.apiOk(resReOpt[1]);
    } else {
      let eLevel = enum_log.actLevelCode.error;
      let _msg = tErrMsg(err);
      let eCode = 'A200';
      setLog(eType, eLevel, _msg, eCode);
      next(getErr(`角色的操作授权变更被拒绝！原因：传入的参数不正确`));
    }
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'A200';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`角色的操作授权变更失败！原因：${err}`));
  }
});

// 删除指定角色
router.delete("/role/del", async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  let id = req.query.id;
  try {
    // 执行角色条目删除
    await dbObj.dbExec(`DELETE FROM _roleGroup WHERE id = ${id};`);
    // 更新已有用户中 roleId 包含 '角色id,' 字样的记录
    await dbObj.dbExec(`UPDATE _sysUser SET roleId = REPLACE(roleId, '\,${id}\,', '\,');`);
    // 获取传入ID的字符表示的长度
    let _len = (`${id}`).length + 1;
    // 更新已有用户中 roleId 以 '角色id,' 开头的记录
    await dbObj.dbExec(`UPDATE _sysUser SET roleId = RIGHT(roleId, LENGTH(roleId) - ${_len}) WHERE id IN (SELECT a.id FROM ((SELECT id FROM _sysUser WHERE roleId LIKE '${id}\,\%') a));`);
    // 更新已有用户中 roleId 以 ',角色id' 结束的记录
    await dbObj.dbExec(`UPDATE _sysUser SET roleId = LEFT(roleId, LENGTH(roleId) - ${_len}) WHERE id IN (SELECT a.id FROM ((SELECT id FROM _sysUser WHERE roleId LIKE '\%\,${id}') a));`);
    // 重新获取刷新后的用户账号列表
    let resAcc = await dbObj.dbExec(_strAcc);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `删除了ID为${id}的角色`;
    let eCode = "G000";
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(resAcc);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = "A200";
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`角色[ id: ${id} ]删除失败！原因：${err}`));
  }
});

// 返回流程设定时所需的值源列表
router.get("/flow/record", async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  let _tblName = req.query.tblName;
  try {
    let resRecord = await dbObj.dbExec(`SELECT id, code, namezh FROM ${_tblName};`);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `在流程设计环节请求了${_tblName}的全表记录`;
    let eCode = "B000";
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(resRecord);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = "A200";
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`流程设计环节${_tblName}业务的节点条件的值源请求失败！原因：${err}`));
  }
});

// 对指定工作流进行变更
router.put("/flow/add", async (req, res, next) => {
  let eType = enum_log.actTypeCode.security;
  try {
    let { code, keys, titles, roles, types, users, cdts } = req.body;
    let _resStr = `SELECT id, pid, code, name, namezh, level, hasSub, seedBizCode, seedBizTitle, bizApproCount, nodeRoles, nodeTypes, nodeUsers, nodeConditions, memo, orderIndex FROM _sysMenu WHERE code = '${code}';`;
    // 格式化用户集合
    let _userSet = users.map(v => {
      return v.join(',');
    }).join('|');
    // 格式化条件集合
    let _conditionSet = cdts.map(v => {
      let _arrSub = Object.keys(v);
      if (_arrSub.length > 0) {
        let _tmpArr = [];
        for (let _vKey of _arrSub) {
          let _vSub = v[_vKey];
          if (_vSub.code && _vSub.namezh && _vSub.symbol && _vSub.value !== undefined) {
            _tmpArr.push(JSON.stringify(_vSub));
          } else {
            _tmpArr.push('');
          }
        }
        return _tmpArr.join(',');
      } else {
        return '';
      }
    }).join('@|@');
    let resRecord = await dbObj.dbExec(`UPDATE _sysMenu SET seedBizCode = '${keys.join(',')}', seedBizTitle = '${titles.join(',')}', bizApproCount = '${keys.length}', nodeRoles = '${roles.join(',')}', nodeTypes = '${types.join(',')}', nodeUsers = '${_userSet}', nodeConditions = '${_conditionSet}' WHERE code = '${code}';${_resStr}`);
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `在流程设计环节创建/变更了${code}的流程设定`;
    let eCode = "B000";
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(resRecord[1]);
  } catch (err) {
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = "A200";
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(`在流程设计环节创建/变更！原因：${err}`));
  }
});

module.exports = router;
