let express = require('express');
let router = express.Router();
let addDemoData = require('../utility/addDemoData');
let addDemoInvt = require('../utility/invtDemo');
let _execer = require('../utility/execer');

// 创建基础资料演示数据
router.post('/', async (req, res, next) => {
  try {
		let _str = addDemoData();
    let _resAll = await _execer(_str);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err);
  }
});

// 创建库存演示数据
router.post('/invt', async (req, res, next) => {
  try {
		let _str = addDemoInvt();
    let _resAll = await _execer(_str);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err);
  }
});

module.exports = router;
