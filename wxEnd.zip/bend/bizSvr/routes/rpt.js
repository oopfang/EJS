let express = require('express');
let router = express.Router();
let _execer = require('../utility/execer');
let tGlb = require('tframe-globalext');

tGlb();

// 小程序获取商品列表
router.get('/returnByProd', async (req, res, next) => {
  try {
		let tId = req.query.typeId;
		let _fStr = '';
		if (tId && tId > 0) {
			_fStr = ` WHERE a.checkTypeId = ${tId} `;
		}
    let _str = `SELECT c.*, d.specName, e.sizeName, f.checkTypeName FROM (
			SELECT a.prodId, b.prodName, a.spec, a.size, a.checkTypeId, SUM(a.quantity) AS quantity, SUM(b.price) AS price, SUM(a.quantity * b.price) AS cost FROM billVrifyDetail a
			LEFT JOIN (SELECT id, namezh AS prodName, price FROM produc) b ON a.prodId = b.id ${_fStr}
			GROUP BY a.prodId, b.prodName, a.spec, a.size, a.checkTypeId
			) c
			LEFT JOIN (SELECT id, namezh AS specName FROM groupColor) d ON c.spec = d.id 
			LEFT JOIN (SELECT id, namezh AS sizeName FROM groupSize) e ON c.size = e.id 
			LEFT JOIN (SELECT \`key\`, title AS checkTypeName FROM __dictInt WHERE \`group\` = 'returnQualityType') f ON c.checkTypeId = f.\`key\`;`;
    let _resAll = await _execer(_str);
    res.apiOk(_resAll);
  } catch (err) {
    res.apiErr(err);
  }
});

module.exports = router;
