let express = require('express');
let router = express.Router();
let fsx = require('fs-extra');
let path = require('path');
let uuid = require('node-uuid');
let formidable = require('formidable');
let _execer = require('../utility/execer');

// 以时间日期创建CODE
let _getCodeByDate = () => {
  let _dt = new Date();
  let _y = _dt.getFullYear();
  let _m = `${_dt.getMonth() + 1}`.padStart(2, 0);
  let _d = `${_dt.getDate()}`.padStart(2, 0);
  let _h = `${_dt.getHours()}`.padStart(2, 0);
  let _mt = `${_dt.getMinutes()}`.padStart(2, 0);
  let _s = `${_dt.getSeconds()}`.padStart(2, 0);
  let _sss = `${_dt.getMilliseconds()}`.padStart(3, 0);
  return `${_y}${_m}${_d}${_h}${_mt}${_s}${_sss}`;
};

router.post('/', async (req, res, next) => {
  try {
    let _appDir = global.uploaderBoot;
    let _tmpDir = path.join(_appDir, 'tmpFile');
    fsx.ensureDirSync(_tmpDir);
    let form = new formidable.IncomingForm();
    form.keepExtensions = true;
    form.uploadDir = _tmpDir;
    let fmtReq = reqObj => {
      return new Promise((resolve, reject) => {
        form.parse(req, (err, fields, file) => {
          if (err) {
            reject(err);
          } else {
            let keys = Object.keys(file);
            let _destArr = [];
            for (let v of keys) {
              let _currFile = file[v];
              let _pathOldFull = _currFile.path;
              let _pathOldOnly = path.dirname(_pathOldFull);
              let _fileOldOnly = path.basename(_pathOldFull);
              let _extName = path.extname(_pathOldFull) || '';
              let _pathNew = path.join(_appDir, v);
              fsx.ensureDirSync(_pathNew);
              let _fileNameNew = `${_getCodeByDate()}${uuid.v4()}${_extName}`;
              let _destNew = path.join(_pathNew, _fileNameNew);
              fsx.ensureDirSync(_pathNew);

              fsx.moveSync(_pathOldFull, _destNew);
              let resDir = _destNew.split(_appDir);
              let resDir2 = resDir[1].substr(1, resDir[1].length).replace(/\\/g, '/');
              _destArr.push(resDir2);
            }
            resolve(_destArr);
          }
        });
      });
    }
    let _currFile = await fmtReq(req);
    res.apiOk(_currFile[0]);
  } catch (err) {
    console.log({
      type: 'error from bend svr',
      msg: err
    })
    res.apiErr(err);
  }
});

router.put('/append', async (req, res, next) => {
  try {
    let { id, appendix } = req.body;
    let _upStr = `UPDATE  SET appendix = CASE WHEN appendix = '' OR appendix IS NULL THEN '${appendix}' ELSE CONCAT(appendix, ',', '${appendix}') END WHERE id = ${id};`;
    await _execer(_upStr);
    res.apiOk({
      id
    });
  } catch (err) {
    res.apiErr(err);
  }
});

module.exports = router;
