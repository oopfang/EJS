let express = require('express');
let router = express.Router();
let jwt = require('jwt-simple');
let dayjs = require('dayjs');
let enumObj = require('tframe-enum');
let enum_log = enumObj.log;
let tPbend = require('tframe-prebend');
let _uTblName = '_sysUser';
let checkDict = require('../utility/checkDict');
let _execer = require('../utility/execer');

let tErr = tPbend.preError;
let tErrMsg = tPbend.preSvr.errToStr

/* 登录 */
router.get('/in', checkDict, async (req, res, next) => {
  let getErr = (errMsg, errCode) => {
    let _defaultMsg = 'Sign in Refused!';
    let _err = tErr(errMsg || _defaultMsg, errCode || 401);
    _err.reason = errMsg || _defaultMsg;
    return _err;
  };
  try {
    let {
      code,
      uPwd,
      roleId
    } = req.query.by;
    if (!code) {
      let eType = enum_log.actTypeCode.sign;
      let eLevel = enum_log.actLevelCode.warning;
      let _msg = '用户名为空';
      let eCode = 'E201';
      setLog(eType, eLevel, _msg, eCode);
      next(getErr('用户名不能为空'));
    } else if (!uPwd) {
      let eType = enum_log.actTypeCode.sign;
      let eLevel = enum_log.actLevelCode.warning;
      let _msg = `用户：[${code}]尝试登陆时，提供的密码为空`;
      let eCode = 'E201';
      setLog(eType, eLevel, _msg, eCode);
      next(getErr('密码不能为空'));
    } else {
      let _userStr = `SELECT \`id\`, \`code\`, \`namezh\`, \`gender\`, \`avatar\`, \`uPwd\`, \`roleId\`, \`accType\`, \`stopped\` FROM ${_uTblName} WHERE code = '${code}';`;
      let _orgStr = `SELECT \`id\`, \`fullPath\` FROM \`__sysOrgs\` WHERE \`id\` IN (SELECT \`oid\` FROM \`_sysUserOrgan\` WHERE \`pid\` = (SELECT \`id\` FROM \`_sysUser\` WHERE \`code\` = '${code}'));`;
      let resDt = await _execer(`${_userStr}${_orgStr}`);
      let resUser = resDt[0][0];
      resUser.orgs = resDt[1];
      let _errStr = '';
      if (resDt[0].length > 0) {
        if (uPwd !== resUser.uPwd) {
          let eType = enum_log.actTypeCode.security;
          let eLevel = enum_log.actLevelCode.warning;
          let _msg = `用户[${code}]尝试登陆时使用了错误的密码`;
          let eCode = 'G202';
          setLog(eType, eLevel, _msg, eCode);
          _errStr = '密码不正确';
        }
      } else {
        let eType = enum_log.actTypeCode.security;
        let eLevel = enum_log.actLevelCode.warning;
        let _msg = `用户使用了错误的，或系统不存在的账号[${code}]尝试登陆`;
        let eCode = 'G201';
        setLog(eType, eLevel, _msg, eCode);
        _errStr = '用户不存在';
      }
      if (_errStr) {
        next(getErr(_errStr));
      } else {
        let _token = jwt.encode({
            iss: resUser.id,
            exp: dayjs()
              .add(4, 'hour')
              .valueOf()
          },
          global.config.app.secretKey
        );
        // 获取并设置菜单
        let _resMenu = [];
        let {
          $crud,
          $extend,
          ..._bizPart
        } = rightsObj;
        let _bizRight = {};
        for (let v of Object.keys(_bizPart)) {
          _bizRight[v] = {
            keys: _bizPart[v].handler.getKeys(),
            tiltes: _bizPart[v].handler.getTitles(),
            maxStep: _bizPart[v].maxStep
          };
        }
        if (!resUser.stopped) {
          // [0] 菜单
          let _strMenu = `SELECT id, pid, code, name, namezh, ico, url, level, hasSub, seedBizCode, seedBizTitle, bizApproCount, orderIndex FROM _sysMenu 
          WHERE id IN (SELECT menuId FROM _roleGroupMenu WHERE pid IN (${roleId === -1 ? resUser.roleId : roleId})) AND stopped = 0 AND deleted = 0 ORDER BY pid, orderIndex;`;
          // [3] 渠道
          let _strUpdate = `UPDATE ${_uTblName} SET lastip = '${req.userIp}', lastsignin = CURRENT_TIMESTAMP WHERE code = '${code}';`;
          let _resStr = `${_strMenu}${_strUpdate}`;
          let _resAppand = await _execer(_resStr);
          for (let v of _resAppand[0]) {
            if (v.level === 1) {
              let _vMenu = {
                id: v.id,
                title: v.namezh,
                key: v.code,
                icon: v.ico
              };
              if (v.hasSub) {
                _vMenu.children = [];
              }
              _resMenu.push(_vMenu);
            } else {
              let _idx = _resMenu.findIndex(vmenu => {
                return vmenu.id === v.pid;
              });
              if (_idx > -1) {
                _resMenu[_idx].children.push({
                  id: v.id,
                  title: v.namezh,
                  key: v.code
                });
              }
            }
          }
          if (_resMenu.length > 0) {
            _resMenu = _resMenu.filter(v => {
              if (v.children && v.children.length === 0) {
                return false;
              } else {
                return true;
              }
            });
            _resMenu[0].active = true;
          }
          let eType = enum_log.actTypeCode.sign;
          let eLevel = enum_log.actLevelCode.info;
          let _msg = `用户 [${code}]: [${resUser.namezh}]登陆成功`;
          let eCode = 'E000';
          setLog(eType, eLevel, _msg, eCode);

        } else {
          let eType = enum_log.actTypeCode.security;
          let eLevel = enum_log.actLevelCode.warning;
          let _msg = `被停用或锁定的用户 [${code}: ${resUser.namezh}] 尝试登陆`;
          let eCode = 'G203';
          setLog(eType, eLevel, _msg, eCode);
        }
        res.apiOk({
          id: resUser.id,
          pid: resUser.pid,
          code: code,
          namezh: resUser.namezh,
          gender: resUser.gender,
          avatar: resUser.avatar,
          channelid: resUser.channelid,
          organid: resUser.organid,
          token: _token,
          stopped: resUser.stopped,
          $after: {
            _menu: _resMenu,
            _dict: global.dict,
            _bizRight: _bizRight
          }
        });
      }
    }
  } catch (err) {
    let eType = enum_log.actTypeCode.svr;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'E201';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

/* token校验（用于缓存页面刷新后的加载 */
router.get('/check', async (req, res, next) => {
  next();
});

/* 注销 */
router.put('/out', async (req, res, next) => {
  let getErr = (errMsg, errCode) => {
    let _defaultMsg = '退出登陆时的痕迹更新存在问题';
    let _err = tErr(errMsg || _defaultMsg, errCode || 403);
    _err.reason = errMsg || _defaultMsg;
    return _err;
  };
  try {
    let {
      id,
      code,
      namezh
    } = req.body;
    // 更新登陆痕迹
    let _str = `UPDATE ${_uTblName} SET lastsignout = CURRENT_TIMESTAMP WHERE id = ${id};`;
    let resDt = await _execer(_str);
    let eType = enum_log.actTypeCode.sign;
    let eLevel = enum_log.actLevelCode.info;
    let _msg = `用户 [${code}: ${namezh}] 正常退出`;
    let eCode = 'E001';
    setLog(eType, eLevel, _msg, eCode);
    res.apiOk(`用户 [${code}: ${namezh}] 已退出登陆`);
  } catch (err) {
    let eType = enum_log.actTypeCode.sign;
    let eLevel = enum_log.actLevelCode.error;
    let _msg = tErrMsg(err);
    let eCode = 'E202';
    setLog(eType, eLevel, _msg, eCode);
    next(getErr(err));
  }
});

module.exports = router;
