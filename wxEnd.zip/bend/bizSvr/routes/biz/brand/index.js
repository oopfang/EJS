let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let { _getInsertStr, _getUpdateStr } = require('../../../utility/sqlStr');
	
let objFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.query);
		if (Array.isArray(req.query)) {
			res.apiOk(_resAll.map((v, k, arr) => {
				return k === 0 ? v[0] : v;
			}))
		} else {
			if (_resAll.$before) {
				if (Array.isArray(_resAll.$before)) {
					let _resNew = _resAll.$before[0];
					if (_resNew && _resAll.$after) {
						_resNew.$after = _resAll.$after;
						res.apiOk(_resNew);
					} else {
						res.apiErr(tErr('没有获取到任何数据'));
					}
				} else {
					let _resNew = _resAll.$before;
					if (_resAll.$after) {
						_resNew.$after = _resAll.$after;
					}
					res.apiOk(_resNew);
				}
			} else {
				let _resNew = _resAll[0];
				if (_resAll.$after) {
					_resNew.$after = _resAll.$after;
				}
				res.apiOk(_resNew);
			}
		}
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.* FROM brand a;`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403)
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let { $act, bizIdent, data } = req.body;
		let [a] = data;
		let _tblName = 'brand';
		let [b] = await _execer(`SELECT id FROM ${_tblName} WHERE id = ${a.id}`);
		let _str = '';
		if (!b) {
			_str = _getInsertStr(_tblName, a);
		} else {
			_str = _getUpdateStr(_tblName, a);
		}
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.by.id;
		let _str = `DELETE FROM brand WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
module.exports = {
	objFunc,
	listFunc,
	postFunc,
	putFunc,
	delFunc
};
