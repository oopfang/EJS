let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let approGetByBill = require('../../../utility/approGetByBill');
// let { sendForIn } = require('../../../utility/blockChain');
	
let objFunc = async (req, res, next) => {
	try {
		let _id = req.query[0].by.id;
		let _str1 = `SELECT * FROM billStockIn WHERE id = ${_id};`;
		let _str2 = `SELECT * FROM billStockInDetail WHERE pid = ${_id};`;
		let [[a], b] = await _execer(`${_str1}${_str2}`);
		res.apiOk([a, b, approGetByBill(a, req.userAccess.approReturnAsk, true, global.bizApproStep.billStockIn)]);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.id, a.\`code\`, IFNULL(a.dateStroeIn, '未入库') AS dateStroeIn, a.fromBillNo, b.namezh AS wHouseNamezh, c.title AS stroeInTypeNamezh, a.quantity, a.quantityAct
		FROM billStockIn a
		LEFT JOIN (SELECT id, namezh FROM warehouse) b ON a.wHouseId = b.id
		LEFT JOIN (SELECT \`key\`, title FROM __dictInt WHERE \`group\` = 'storeInType') c ON a.stroeInTypeId = c.\`key\`
		WHERE a.stopped = 0 AND a.deleted = 0
		ORDER BY a.createby DESC;`;
		let _strCount = `SELECT COUNT(id) AS count FROM billStockIn WHERE recived = 1;`;
		let [a, [b]] = await _execer(`${_str}${_strCount}`);
		res.apiOk({
			list: a,
			count: b.count
		});
	} catch (err) {
		res.apiErr(err, 403)
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let { id, pid, val, recived } = req.body;
		let _strRecived = recived ? ', recived = 1' : '';
		let _str = `UPDATE billStockInDetail SET quantityAct = ${val}, recived = 1 WHERE id = ${id};
		UPDATE billStockIn a, (SELECT SUM(recived) AS num, COUNT(id) AS cnt FROM billStockInDetail WHERE pid = ${pid}) b
		SET a.dateStroeIn = DATE_FORMAT(NOW(), '%Y-%m-%d'), 
		a.quantityAct = (SELECT SUM(IFNULL(quantityAct, 0)) FROM billStockInDetail WHERE pid = ${pid} AND recived = 1),
		a.recived = CASE WHEN b.num = b.cnt THEN 1 ELSE 0 END
		WHERE id = ${pid};`;
		let _strObj = `SELECT a.\`code\` AS billNo, b.nameen, b.prodName, b.\`code\` FROM billStockInDetail a
		LEFT JOIN (SELECT id, \`code\`, \`name\` AS nameen, namezh AS prodName FROM produc) b ON a.prodId = b.id
		WHERE a.id = ${id};`;
		let _resAll = await _execer(`${_str}${_strObj}`);
		// let [b] = _resAll.pop();
		// if (b) {
		// 	sendForIn({
		// 		code: b.billNo,
		// 		ename: b.nameen,
		// 		cname: b.prodName,
		// 		pcode: b.code
		// 	});
		// }
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};

let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.id;
		let _str = `DELETE FROM billPickUp WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
module.exports = {
	objFunc,
	listFunc,
	postFunc,
	putFunc,
	delFunc
};
