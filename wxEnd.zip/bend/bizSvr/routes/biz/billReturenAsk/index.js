let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let dayjs = require('dayjs');
let approGetByBill = require('../../../utility/approGetByBill');

let objFunc = async (req, res, next) => {
	try {
		let _id = req.query[0].by.id;
		let _str1 = `SELECT * FROM billReturenAsk WHERE id = ${_id};`;
		let _str2 = `SELECT * FROM returenAskDetail WHERE pid = ${_id};`;
		let [[a], b] = await _execer(`${_str1}${_str2}`);
		let _resAll = [a, b, approGetByBill(a, req.userAccess.approReturnAsk, req.currUserId === a.operator, global.bizApproStep.billReturenAsk)];
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.id, a.dateAsk, b.namezh AS custNamezh, c.\`title\` AS returnTypeNamezh, a.billOriginalNo, d.namezh AS operatorNamezh, e.\`title\` AS askStateNamezh, a.memo 
		FROM billReturenAsk a 
		LEFT JOIN (SELECT id, namezh FROM customer) b ON a.custId = b.id 
		LEFT JOIN (SELECT \`key\`, \`title\` FROM __dictInt WHERE \`group\` = 'returnType') c ON a.returnTypeId = c.\`key\`
		LEFT JOIN (SELECT id, namezh FROM _sysUser) d ON a.operator = d.id
		LEFT JOIN (SELECT \`key\`, \`title\` FROM __dictInt WHERE \`group\` = 'requestType') e ON a.askStateId = e.\`key\`
		WHERE a.stopped = 0 AND a.deleted = 0
		ORDER BY a.createby DESC;`;
		let _strCount = `SELECT COUNT(id) AS count FROM billReturenAsk WHERE approStep = 2;`;
		let [a, [b]] = await _execer(`${_str}${_strCount}`);
		res.apiOk({
			list: a,
			count: b.count
		});
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let _initCode = BigInt(Date.getCode());
		let _obj1 = req.body.data[0];
		let _getObj2 = (pid) => {
			return req.body.$after.map((v, k) => {
				_initCode++;
				return `INSERT INTO returenAskDetail(pid, code, prodId, spec, size, unit, quantityAsk, reason, province, city) VALUES('${pid}', '${_initCode}', ${v.prodId}, '${v.spec}', 
				'${v.size}', '${v.unit}', '${v.quantityAsk}', '${v.reason}', '${v.province}', '${v.city}');`;
			}).join('');
		};
		let _str1 = `INSERT INTO billReturenAsk(code, dateAsk,  custId,  returnTypeId,  billOriginalTypeId,  billOriginalNo,  operator,  askStateId, memo) 
		VALUES ('${_initCode}', '${_obj1.dateAsk}',  '${_obj1.custId}',  '${_obj1.returnTypeId}',  '${_obj1.billOriginalTypeId}',  '${_obj1.billOriginalNo}',  
		'${_obj1.operator}',  '${_obj1.askStateId}', '${_obj1.memo}');`;

		let _resAll = await _execer(_str1);
		let _newId = _resAll.insertId;
		let _str2 = _getObj2(_newId);
		await _execer(_str2);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.id;
		let _str = `DELETE FROM billPickUp WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};

// DATE_FORMAT(NOW(), '%Y-%m-%d')
let approFunc = async (req, res, next) => {
	try {
		if (req.resApprov.flowStart && req.resApprov.currStep === 2) {
			let _returnId = req.body.id;
			let _str = `INSERT INTO \`billStockIn\` (\`pid\`, \`code\`, \`stroeInTypeId\`, \`fromBillNo\`, \`quantity\`, \`memo\`, \`approStep\`) 
			SELECT id, \`code\`, 1, \`code\`, (SELECT SUM(IFNULL(quantityAsk,0)) FROM returenAskDetail WHERE pid = ${_returnId}), '退货审批自动生成', 0 FROM billReturenAsk WHERE id = ${_returnId};
			SELECT \`code\`, prodId, spec, size, unit, quantityAsk FROM returenAskDetail WHERE pid = ${_returnId};`;
			let [a, b] = await _execer(_str);
			let _currPid = a.insertId;
			let _strDetail = b.map(v => {
				return `(${_currPid}, '${v.code}', '${v.prodId}', '${v.spec}', '${v.size}', '${v.unit}', '${v.quantityAsk}', '${req.currUserId}', '退货审批自动生成')`;
			}).join(',');
			if (_strDetail) {
				_str = `INSERT INTO \`billStockInDetail\` (\`pid\`, \`code\`, \`prodId\`, \`spec\`, \`size\`, \`unit\`, \`quantity\`, \`operator\`, \`memo\`)
				VALUES ${_strDetail};`;
				await _execer(_str);
				res.apiOk(req.resApprov);
			} else {
				await _execer(`DELETE FROM \`billStockIn\` WHERE id = ${_currPid};`);
				throw new Error('没有任何退货明细，操作失败！');
			}
		} else {
			res.apiOk(req.resApprov);
		}
	} catch (err) {
		res.apiErr(err);
	}
};

let apiFunc = async (req, res, next) => {
	try {

		let _resAll = await reqMgr(req.query);
		let _resAllOther = _resAll.map(v => {
			let { name, namezh, ...other } = v;
			return other;
		});
		res.apiOk(_resAllOther);
	} catch (err) {
		res.apiErr(err, 403)
	}
};

let getRptFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.prodId, b.namezh AS prodNamezh, a.spec, c.namezh AS specNamezh, a.size, d.namezh AS sizeNamezh, a.quantity, a.checkTypeId, e.title AS checkTypeNamezh FROM billVrifyDetail a
		LEFT JOIN (SELECT id, namezh FROM produc) b ON a.prodId = b.id
		LEFT JOIN (SELECT id, namezh FROM groupColor) c ON a.spec = c.id
		LEFT JOIN (SELECT id, namezh FROM groupSize) d ON a.size = d.id
		LEFT JOIN (SELECT \`key\`, title FROM __dictInt WHERE \`group\` = 'returnQualityType') e ON a.checkTypeId = e.\`key\`;`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err);
	}
};

module.exports = {
	objFunc,
	listFunc,
	postFunc,
	putFunc,
	delFunc,
	approFunc,
	apiFunc,
	getRptFunc
};
