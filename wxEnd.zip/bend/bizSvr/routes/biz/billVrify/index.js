let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let dayjs = require('dayjs');
const codeFmtStr = 'YYYYMMDDHHmmssSSS';
let Tdate = globalThis.smpoo.Tdate;
let UudCode = require('../../../utility/getUud');
	
let objFunc = async (req, res, next) => {
	try {
		res.apiOk({});
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.query);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403)
	}
};
	
let listTobeFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.*, b.custId, b.custNamezh FROM billStockIn a
		LEFT JOIN (SELECT c.id, c.custId, d.namezh AS custNamezh FROM billReturenAsk c
			LEFT JOIN (SELECT id, namezh FROM customer) d ON c.custId = d.id
		) b ON a.pid = b.id
		WHERE a.checked = 0 AND a.quantityCkb < a.quantityAct
		ORDER BY a.id;`;

		let _strDetail = `SELECT a.id, a.\`code\`, a.prodId, c.namezh AS prodNamezh, a.spec, d.namezh AS specNamezh, a.size, e.namezh AS sizeNamezh, a.unit, a.quantity, 
		a.quantityAct, a.quantityCkb FROM billStockInDetail a
		RIGHT JOIN (SELECT id, checked FROM billStockIn) b ON a.pid = b.id
		LEFT JOIN (SELECT id, namezh FROM produc) c ON a.prodId = c.id
		LEFT JOIN (SELECT id, namezh FROM groupColor) d ON a.spec = d.id
		LEFT JOIN (SELECT id, namezh FROM groupSize) e ON a.size = e.id
		WHERE a.recived = 1 AND b.checked = 0 ORDER BY b.id, c.namezh, d.namezh, e.namezh;`
		let [a, b] = await _execer(`${_str}${_strDetail}`);
		for (let v of a) {
			v.detail =  b.filter(vDetail => {
				return vDetail.pid = v.id;
			});
		}
		res.apiOk(a);
	} catch (err) {
		res.apiErr(err, 403)
	}
};

let checkFunc = async (req, res, next) => {
	try {
		let { billId, checkTypeId, ...item } = req.body;
		let _str = `UPDATE billStockInDetail SET quantityCkb = quantityCkb + 1 WHERE id = ${item.id};
		UPDATE billStockIn SET quantityCkb = quantityCkb + 1, checked = CASE WHEN quantityAct = quantityCkb THEN 1 ELSE 0 END WHERE id = ${billId};
		INSERT INTO \`billVrifyDetail\` (\`pid\`, \`code\`, \`prodId\`, \`spec\`, \`size\`, \`unit\`, \`quantity\`, \`uuCodePub\`, \`uuCodePrive\`, \`checkTypeId\`, \`memo\`) 
		VALUES('${item.pid}', '${dayjs().format(codeFmtStr)}', '${item.prodId}', '${item.spec}', '${item.size}', '${item.unit}', 1, '${item.uuCodePub}', '${item.uuCodePrive}', '${checkTypeId}', '${item.memo || ''}');`;
		await _execer(_str);
		res.apiOk({});
	} catch (err) {
		res.apiErr(err);
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let { billObj, prodItem } = req.body;
		let _str = `SELECT id FROM billVrify WHERE \`code\` = ${billObj.code};`;
		let [a] = await _execer(_str);
		let _oldPid = prodItem.pid
		if (!a) {
			_str = `INSERT INTO \`billVrify\` (\`pid\`, \`code\`, \`dateCheck\`, \`operator\`, \`billReturnAskId\`, \`allGood\`, \`memo\`) 
			VALUES (${billObj.id}, '${billObj.code}', NOW(), '${prodItem.operator}', '${billObj.pid}', '0', '由退货鉴验创建，dateCheck为首次鉴验日期');`;
			let resIst = await _execer(_str);
			prodItem.pid = resIst.insertId;
		} else {
			prodItem.pid = a.id;
		}
		let _codeStr = Tdate.getCode();
		let _uuCodeObj = UudCode.encodeUud(prodItem.uuCode);
		_str = `INSERT INTO \`billVrifyDetail\` (\`pid\`, \`code\`, \`prodId\`, \`spec\`, \`size\`, \`unit\`, \`quantity\`, 
		\`uuCodePub\`, \`uuCodePrive\`, \`checkTypeId\`, \`dateValidityEnd\`, \`memo\`) 
		VALUES (${prodItem.pid}, '${_codeStr}', '${prodItem.prodId}', '${prodItem.spec}', '${prodItem.size}', '${prodItem.unit}', '${prodItem.quantity}', 
		'${_uuCodeObj.pubKey}', '${_uuCodeObj.prvKey}', '${prodItem.state}', '${prodItem.dateValidityEnd}', '${prodItem.memo}');`
		let _strUp = `UPDATE billStockInDetail SET quantityCkb = quantityCkb + 1 WHERE pid = ${_oldPid} AND prodId = ${prodItem.prodId} AND spec = ${prodItem.spec} AND size = ${prodItem.size};`;
		let _strUpMaster = `UPDATE billStockIn a, (SELECT SUM(quantityCkb) AS quantityCkb FROM billStockInDetail WHERE pid = ${_oldPid}) b SET a.quantityCkb = b.quantityCkb WHERE a.id = ${_oldPid};`;
		let _resAll = await reqMgr(`${_str}${_strUp}${_strUpMaster}`);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.id;
		let _str = `DELETE FROM billPickUp WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
module.exports = {
	objFunc,
	listFunc,
	listTobeFunc,
	checkFunc,
	postFunc,
	putFunc,
	delFunc
};
