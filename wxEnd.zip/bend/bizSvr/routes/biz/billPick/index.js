let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let setPick = require('../../../utility/setPick');
let { sendForOut } = require('../../../utility/blockChain');
	
let objFunc = async (req, res, next) => {
	try {
		let _id = req.query.by.id;
		let _str = `SELECT a.id, a.pid, a.\`code\`, b.\`code\` AS fromBillNo, b.dateDelivery, a.dateStorePick, b.quantity AS quantityDeliv, e.quantity AS quantityPick, a.alreadyDone FROM billPick a
		LEFT JOIN (
			SELECT c.id, c.\`code\`, c.dateDelivery, d.quantity FROM billAdviceSend c
			LEFT JOIN (SELECT pid, SUM(quantity) AS quantity FROM billAdviceSendDetail GROUP BY pid) d ON c.id = d.pid
		) b ON a.pid = b.id
		LEFT JOIN (SELECT pid, SUM(quantity) AS quantity FROM billPickDetail GROUP BY pid) e ON a.id = e.pid WHERE a.id = ${_id} AND a.stopped = 0 AND a.deleted = 0;`;
		let _strDetail = `SELECT * FROM billPickDetail WHERE pid = ${_id} AND stopped = 0 AND deleted = 0;`;
		let [a, b] = await _execer(`${_str}${_strDetail}`);
		res.apiOk([a[0], b]);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.id, a.pid, a.\`code\`, b.\`code\` AS fromBillNo, b.dateDelivery, a.dateStorePick, b.quantity AS quantityDeliv, e.quantity AS quantityPick, CASE a.alreadyDone WHEN 1 THEN '是' ELSE '否' END AS alreadyDone FROM billPick a
		LEFT JOIN (
			SELECT c.id, c.\`code\`, c.dateDelivery, d.quantity FROM billAdviceSend c
			LEFT JOIN (SELECT pid, SUM(quantity) AS quantity FROM billAdviceSendDetail GROUP BY pid) d ON c.id = d.pid
		) b ON a.pid = b.id
		LEFT JOIN (SELECT pid, SUM(quantity) AS quantity FROM billPickDetail GROUP BY pid) e ON a.id = e.pid
		WHERE a.stopped = 0 AND a.deleted = 0
		ORDER BY id DESC;`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403)
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.id;
		let _str = `DELETE FROM billPickUp WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};

let picOver = async (req, res, next) => {
	try {
		let _str = `${setPick.main(req.body)}${setPick.billSend(req.body.pid)}`;
		if (!_str) {
			res.apiErr(new Error('请求数据不合规，没有执行任何处理'));
		} else {
			let _resAll = await _execer(_str);
			let _pid = _resAll[_resAll.length - 1].insertId;
			let _strChain = `SELECT a.\`code\` AS billNo, b.nameen, b.prodName, b.\`code\` FROM billPickDetail a
			LEFT JOIN (SELECT id, \`code\`, \`name\` AS nameen, namezh AS prodName FROM produc) b ON a.prodId = b.id
			WHERE a.pid = (SELECT id FROM billPick WHERE pid = 2);`;
			let _strOver = `${setPick.billSendDetail(_pid)}${setPick.pickOver(req.body.pid)}${_strChain}`;
			let _resPick = await _execer(_strOver);
			// 创建上链数据
			let b = _resPick.pop();
			if (b) {
				sendForOut(b.map(v => {
					return {
						code: v.billNo,
						ename: v.nameen,
						cname: v.prodName,
						pcode: v.code
					};
				}));
			}
			res.apiOk({
				done: 1
			});
		}
	} catch (err) {
		res.apiErr(err);
	}
};
	
module.exports = {
	objFunc,
	listFunc,
	postFunc,
	putFunc,
	delFunc,
	picOver
};
