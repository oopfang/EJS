let fs = require('fs');
let path = require('path');
let express = require('express');
let approvExec = require('../../utility/approExec');
let router = express.Router();

let _getJs = () => {
	return new Promise((resolve, reject) => {
		fs.readdir(path.resolve(__filename, '..'), (err, list) => {
			if (!err) {
				resolve(list);
			} else {
				reject(err);
			}
		});
	});
};

let _init = async () => {
	let res = await _getJs();
	for (let v of res) {
		let [a, b] = v.split('.');
		if (!b) {
			let { objFunc, listFunc, postFunc, putFunc, postFuncFromInvt, delFunc, approFunc, sendNotice, picOver, apiFunc, listTobeFunc, checkFunc } = require(`./${v}/index`);
			if (objFunc) {
				router.get(`/${a}/obj`, objFunc);
			}
			if (listFunc) {
				router.get(`/${a}/list`, listFunc);
			}
			if (postFunc) {
				router.post(`/${a}/add`, postFunc);
			}
			// if (getRptFunc) {
			// 	router.post(`/${a}/getRpt`, getRptFunc);
			// }
			if (putFunc) {
				router.put(`/${a}/edit`, putFunc);
			}
			if (delFunc) {
				router.delete(`/${a}/del`, delFunc);
			}
			if (approFunc) {
				router.put(`/${a}/approv`, approvExec, approFunc);
			}
			if (sendNotice) {
				router.put(`/${a}/sendNotice`, sendNotice);
			}
			if (picOver) {
				router.put(`/${a}/picOver`, picOver);
			}
			if (apiFunc) {
				router.get(`api${a}/list`, apiFunc);
			}
			if (listTobeFunc) {
				router.get(`/${a}/listTobe`, listTobeFunc);
			}
			if (checkFunc) {
				router.put(`/${a}/check`, checkFunc);
			}
			if (a === 'billAdviceSend' && postFuncFromInvt) {
				router.post(`/${a}/addByInvt`, postFuncFromInvt);
			}
		};
	};
};

_init();

module.exports = router;



