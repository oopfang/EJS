let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let dayjs = require('dayjs');
let approGetByBill = require('../../../utility/approGetByBill');
let globalInit = require('tframe-globalext');
globalInit();
let Tdate = globalThis.smpoo.Tdate;

let objFunc = async (req, res, next) => {
	try {
		let _id = req.query[0].by.id;
		let _str1 = `SELECT * FROM billAdviceSend WHERE id = ${_id};`;
		let _str2 = `SELECT * FROM billAdviceSendDetail WHERE pid = ${_id};`;
		let [[a], b] = await _execer(`${_str1}${_str2}`);
		let _resAll = [a, b, approGetByBill(a, req.userAccess.approReturnAsk, req.currUserId === a.operator, global.bizApproStep.billAdviceSend)];
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.id, a.dateDelivery, a.fromBillNo, b.namezh AS custNamezh, a.phone, a.custAddr, c.quantity, d.title AS deliveryTypeNamezh, CASE a.alreadyDone WHEN 1 THEN '是' ELSE '否' END AS alreadyDone FROM billAdviceSend a
		LEFT JOIN (SELECT id, namezh FROM customer) b ON a.custId = b.id 
		LEFT JOIN (SELECT pid, SUM(quantity) AS quantity FROM billAdviceSendDetail GROUP BY pid) c ON c.pid = a.id
		LEFT JOIN (SELECT \`key\`, title FROM __dictInt WHERE \`group\` = 'deliveryType') d ON d.\`key\` = a.deliveryType
		ORDER BY id DESC;`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let _initCode = BigInt(Date.getCode());
		let _obj1 = req.body.data[0];
		let _getObj2 = pid => {
			return req.body.$after[0].data.map((v, k) => {
				_initCode++;
				return `INSERT INTO billAdviceSendDetail(pid, code, prodId, spec, size, unit, quantity) VALUES('${pid}', '${_initCode}', ${v.prodId}, '${v.spec}', 
				'${v.size}', '${v.unit}', '${v.quantity}');`;
			}).join('');
		};
		let _getObj2Pick = pid => {
			let _strArr = [];
			for (let v of req.body.$after[0].data) {
				for (let i = 0; i < v.quantity; i++) {
					_initCode++;
					_strArr.push(`INSERT INTO \`billPickDetail\` (\`pid\`, \`code\`, \`prodId\`, \`spec\`, \`size\`, \`unit\`, \`quantity\`, \`quantityPick\`, \`memo\`, \`stopped\`)
					VALUES ('${pid}', '${_initCode}', '${v.prodId}', '${v.spec}', '${v.size}', '${v.unit}', '1', '0', '通知单自动生成', 1);`);
				}
			}
			return _strArr.join('');
		};

		let _str1 = `INSERT INTO billAdviceSend(\`code\`, \`dateDelivery\`, \`fromBillNo\`, \`custId\`, \`phone\`, \`custAddr\`, \`operator\`, \`deliveryType\`, \`memo\`) 
		VALUES ('${_initCode}', '${_obj1.dateDelivery}', '${_obj1.fromBillNo}', '${_obj1.custId}', '${_obj1.phone}', '${_obj1.custAddr}', '${_obj1.operator}', '${_obj1.deliveryType}', '${_obj1.memo}');`;

		let _resAll = await _execer(_str1);
		let _newId = _resAll.insertId;
		
		let _str1Pick = `INSERT INTO \`billPick\` (\`pid\`, \`code\`, \`operator\`, \`orderId\`, \`memo\`, \`stopped\`)
		VALUES ('${_newId}', '${_initCode}', '${_obj1.operator}', '-1', '通知单自动生成', 1);`;
		let _resAllPick = await _execer(_str1Pick);

		let _newIdPick = _resAllPick.insertId;
		let _str2 = _getObj2(_newId);
		let _str2Pick = _getObj2Pick(_newIdPick);
		await _execer(`${_str2}${_str2Pick}`);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};

// 从库存中进行再销售
let postFuncFromInvt = async (req, res, next) => {
	try {
		let { data, detail } = req.body;
		let { dateDelivery, custId, memo } = data;
		let { prodId, spec, size, quantity } = detail;
		let _codeArr = Tdate.getCode(4 + quantity);
		let _memoStr = memo ? `，${memo}` : '';
		let _str = `INSERT INTO billAdviceSend(\`code\`, dateDelivery, custId, deliveryType, memo) VALUES('${_codeArr.pop()}', '${dateDelivery}', ${custId}, 4, '库存再销售${_memoStr}');`;
		let a = await _execer(_str);
		let _strArr = [];
		let _pid = a.insertId;
		_str = `INSERT INTO billAdviceSendDetail(pid, \`code\`, prodId, spec, size, unit, quantity, memo) VALUES (${_pid}, '${_codeArr.pop()}', ${prodId}, ${spec}, ${size}, '件', ${quantity}, '库存再销售')`;
		await _execer(_str);

		// 创建拣货单
      let _str1Pick = `INSERT INTO \`billPick\` (\`pid\`, \`code\`, \`operator\`, \`orderId\`, \`memo\`, \`stopped\`)
      VALUES ('${_pid}', '${_codeArr.pop()}', '1', '-1', '库存再销售通知单自动生成', 1);`;
      let _resAllPick = await _execer(_str1Pick);

      let _getObj2Pick = pid => {
        _strArr = [];
        for (let i = 0; i < quantity; i++) {
            _strArr.push(`INSERT INTO \`billPickDetail\` (\`pid\`, \`code\`, \`prodId\`, \`spec\`, \`size\`, \`unit\`, \`quantity\`, \`quantityPick\`, \`memo\`, \`stopped\`)
            VALUES ('${pid}', '${_codeArr.pop()}', '${prodId}', '${spec}', '${size}', '件', '1', '0', '库存再销售通知单自动生成', 1);`);
        };
        return _strArr.join('');
      };

      let _str2Pick = _getObj2Pick(_resAllPick.insertId);
			await _execer(_str2Pick);
			
			// 相对于微信商城，本次并未采取自动完成通知发货，而是采取手工通知发货的模式
		res.apiOk({});
	} catch (err) {
		res.apiErr(err);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.id;
		let _str = `DELETE FROM billPickUp WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};

// DATE_FORMAT(NOW(), '%Y-%m-%d')
let approFunc = async (req, res, next) => {
	try {
		if (req.resApprov.flowStart && req.resApprov.currStep === 2) {
			let _returnId = req.body.id;
			let _str = `INSERT INTO \`billStockIn\` (\`pid\`, \`code\`, \`stroeInTypeId\`, \`fromBillNo\`, \`quantity\`, \`memo\`, \`approStep\`) 
			SELECT id, \`code\`, 1, \`code\`, (SELECT SUM(IFNULL(quantityAsk,0)) FROM billAdviceSendDetail WHERE pid = ${_returnId}), '退货审批自动生成', 0 FROM billAdviceSend WHERE id = ${_returnId};
			SELECT \`code\`, prodId, spec, size, unit, quantityAsk FROM billAdviceSendDetail WHERE pid = ${_returnId};`;
			let [a, b] = await _execer(_str);
			let _currPid = a.insertId;
			let _strDetail = b.map(v => {
				return `(${_currPid}, '${v.code}', '${v.prodId}', '${v.spec}', '${v.size}', '${v.unit}', '${v.quantityAsk}', '${req.currUserId}', '退货审批自动生成')`;
			}).join(',');
			if (_strDetail) {
				_str = `INSERT INTO \`billStockInDetail\` (\`pid\`, \`code\`, \`prodId\`, \`spec\`, \`size\`, \`unit\`, \`quantity\`, \`operator\`, \`memo\`)
				VALUES ${_strDetail};`;
				await _execer(_str);
				res.apiOk(req.resApprov);
			} else {
				await _execer(`DELETE FROM \`billStockIn\` WHERE id = ${_currPid};`);
				throw new Error('没有任何退货明细，操作失败！');
			}
		} else {
			res.apiOk(req.resApprov);
		}
	} catch (err) {
		res.apiErr(err);
	}
};

let sendNotice = async (req, res, next) => {
	try {
		let { id } = req.body;
		let _str = `UPDATE billPick SET stopped = 0 WHERE pid = ${id};
		UPDATE billPickDetail SET stopped = 0 WHERE pid IN (SELECT id FROM billPick WHERE pid = ${id});
		UPDATE billAdviceSend SET alreadyDone = 1 WHERE id = ${id};`;
		await _execer(_str);
		res.apiOk({
			done: 1
		});
	} catch (err) {
		res.apiErr(err);
	}
};

let apiFunc = async (req, res, next) => {
	try {

		let _resAll = await reqMgr(req.query);
		let _resAllOther = _resAll.map(v => {
			let { name, namezh, ...other } = v;
			return other;
		});
		res.apiOk(_resAllOther);
	} catch (err) {
		res.apiErr(err, 403)
	}
};

module.exports = {
	objFunc,
	listFunc,
	postFunc,
	postFuncFromInvt,
	putFunc,
	delFunc,
	approFunc,
	sendNotice,
	apiFunc
};
