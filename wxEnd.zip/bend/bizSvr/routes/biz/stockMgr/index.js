let _execer = require('../../../utility/execer');
	
let listFunc2 = async (req, res, next) => {
	try {
		let _str = `SELECT a.prodId, b.prodNamezh, a.spec, c.specNamezh, a.size, d.sizeNamezh, a.cellCode, SUM(a.quantity) AS quantity FROM inventory a
		LEFT JOIN (SELECT id, namezh AS prodNamezh FROM produc) b ON a.prodId = b.id
		LEFT JOIN (SELECT id, namezh AS specNamezh FROM groupColor) c ON a.spec = b.id
		LEFT JOIN (SELECT id, namezh AS sizeNamezh FROM groupSize) d ON a.size = b.id
		WHERE cellCode IS NOT NULL AND cellCode <> ''
		GROUP BY a.prodId, b.prodNamezh, a.spec, c.specNamezh, a.size, d.sizeNamezh, a.cellCode;`;
		let _resAll = await _execer(_str);

		let _obj = {};
		let _setW = new Set();
		let _setZ = new Set();
		let _setD = new Set();
		let _setL = new Set();
		let _setC = new Set();
		for (let v of _resAll) {
			let [w, z, d, l, c] = v.cellCode.split('-');
			if (!_obj[w]) _obj[w] = {};
			if (!_obj[w][z]) _obj[w][z] = {};
			if (!_obj[w][z][d]) _obj[w][z][d] = {};
			if (!_obj[w][z][d][l]) _obj[w][z][d][l] = {};
			if (!_obj[w][z][d][l][c]) _obj[w][z][d][l][c] = [];
			_obj[w][z][d][l][c].push(v);
			_setW.add(w);
			_setZ.add(z);
			_setD.add(d);
			_setL.add(l);
			_setC.add(c);
		}
		let _arrW = Array.from(_setW);
		let _arrZ = Array.from(_setZ);
		let _arrD = Array.from(_setD);
		let _arrL = Array.from(_setL);
		let _arrC = Array.from(_setC);

		_setW = null;
		_setZ = null;
		_setD = null;
		_setL = null;
		_setC = null;
		res.apiOk({
			invt: _obj,
			arrW: _arrW,
			arrZ: _arrZ,
			arrD: _arrD,
			arrL: _arrL,
			arrC: _arrC
		});
	} catch (err) {
		res.apiErr(err, 403)
	}
};

let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.id, a.pid, k.returnFor, a.custId, e.custBuildType, e.custNamezh, a.province, CONCAT(a.province, '-', a.city) AS city, a.city AS cityOrigan, 
		a.prodId, b.prodNamezh, a.spec, c.specNamezh, a.size, d.sizeNamezh, a.checkTypeId, m.checkType, a.cellCode,
		ROUND(timestampdiff(day,a.dateValidityEnd, NOW()) / 360) AS diffDay, SUM(a.quantity) AS quantity FROM inventory a
			LEFT JOIN (SELECT id, namezh AS prodNamezh FROM produc) b ON a.prodId = b.id
			LEFT JOIN (SELECT id, namezh AS specNamezh FROM groupColor) c ON a.spec = c.id
			LEFT JOIN (SELECT id, namezh AS sizeNamezh FROM groupSize) d ON a.size = d.id
			LEFT JOIN (SELECT f.id, f.namezh AS custNamezh, g.title AS custBuildType FROM customer f LEFT JOIN (SELECT \`key\`, title FROM __dictInt WHERE \`group\` = 'custBuildType') g ON f.custBuildType = g.\`key\`) e ON a.custId = e.id
			LEFT JOIN (SELECT h.id, j.returnFor FROM returenAskDetail h LEFT JOIN (SELECT id, namezh AS returnFor FROM ruleVerify) j ON h.reason = j.id) k ON a.pid = k.id
			LEFT JOIN (SELECT \`key\`, title AS checkType FROM __dictInt WHERE \`group\` = 'returnQualityType') m ON a.checkTypeId = m.\`key\`
		WHERE cellCode IS NOT NULL AND cellCode <> ''
		GROUP BY a.id, a.pid, k.returnFor, a.custId, e.custBuildType, a.province, a.city, a.prodId, b.prodNamezh, a.spec, c.specNamezh, a.size, d.sizeNamezh, a.checkTypeId, a.cellCode,
		m.checkType, ROUND(timestampdiff(day,a.dateValidityEnd, NOW()) / 360);`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err);
	}
};
	
module.exports = {
	listFunc
};
