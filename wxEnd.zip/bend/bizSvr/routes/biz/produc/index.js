let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let { _getInsertStr, _getUpdateStr } = require('../../../utility/sqlStr');
	
let objFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.query);
		if (Array.isArray(req.query)) {
			res.apiOk(_resAll.map((v, k, arr) => {
				return k === 0 ? v[0] : v;
			}))
		} else {
			if (_resAll.$before) {
				if (Array.isArray(_resAll.$before)) {
					let _resNew = _resAll.$before[0];
					if (_resNew && _resAll.$after) {
						_resNew.$after = _resAll.$after;
						res.apiOk(_resNew);
					} else {
						res.apiErr(tErr('没有获取到任何数据'));
					}
				} else {
					let _resNew = _resAll.$before;
					if (_resAll.$after) {
						_resNew.$after = _resAll.$after;
					}
					res.apiOk(_resNew);
				}
			} else {
				let _resNew = _resAll[0];
				if (_resAll.$after) {
					_resNew.$after = _resAll.$after;
				}
				res.apiOk(_resNew);
			}
		}
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _str = `SELECT a.*, b.namezh AS brandNamezh FROM produc a
		LEFT JOIN (SELECT id, namezh FROM brand) b ON a.brandId = b.id;`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403)
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let { $act, bizIdent, data } = req.body;
		let [a] = data;
		let [b] = await _execer(`SELECT id FROM produc WHERE id = ${a.id}`);
		let _str = '';
		if (!b) {
			_str = _getInsertStr('produc', a, 'spec', 'size', 'brandNamezh');
		} else {
			_str = _getUpdateStr('produc', a, 'spec', 'size', 'brandNamezh');
		}
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		// let { asImg, imgPath, ...other } = req.body;
		// if (asImg) {
		// 	let _str = `UPDATE `;
		// } else {
		// 	let _resAll = await reqMgr(other);
		// 	res.apiOk(_resAll);
		// }
		let _resAll = await reqMgr(other);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.by.id;
		let _str = `DELETE FROM produc WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
module.exports = {
	objFunc,
	listFunc,
	postFunc,
	putFunc,
	delFunc
};
