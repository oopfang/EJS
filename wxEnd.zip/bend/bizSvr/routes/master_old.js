/* 
  主数据查询路由
*/

let express = require('express');
let router = express.Router();
let _execer = require('../utility/execer');
const _defaultDef = {
  dept: {
    tblName: '__sysOrgs',
    listRange: ['pid', 'organtypeid', 'chargemanid']
  },
  hr: {
    tblName: '_sysUser',
    listRange: ['pid', 'name', 'jobNo', 'gender', 'phoneWork', 'phonePrivate', 'email', 'avatar', 'accType']
  },
  channel: {
    tblName: '__sysChannel',
    listRange: ['chargemanid']
  },
  customer: {
    listRange: ['custBuildType', 'phone', 'addr', 'orgCode', 'bank', 'account']
  },
  produc: {
    listRange: ['seasonId', 'groupStoryId', 'genderId', 'brandId', 'groupAgeId', 'groupFitId', 'price', 'picAddr']
  },
  warehouse: {
    listRange: ['pid', 'storeUnitType']
  }
};

let _getDictDefObj = keyStr => {
  let _currObj = _defaultDef[keyStr];
  if (_currObj) {
    return {
      tblName: _currObj.tblName || keyStr,
      listRange: _currObj.listRange || []
    };
  } else {
    return {
      tblName: keyStr,
      listRange: []
    };
  }
};

/* 根据关键词索引主数据 */
router.get('/obj', async (req, res, next) => {
  let _resObj = {};
  let _keyStr = req.query.keys;
  if (_keyStr) {
    let _strArr = [];
    let _resArr = [];
    let _isSingle = (_keyStr.length === 1);
    let _dictObj = {};
    let _listStr = '';
    if (_isSingle) {
      let _strTmp = '';
      _dictObj = _getDictDefObj(_keyStr);
      _listStr = _dictObj.listRange.length ? `, '${_dictObj.listRange.join('', '')}'` : '';
      _strArr = [`SELECT id AS \`key\`, namezh AS title${_listStr} FROM ${_dictObj.tblName} WHERE stopped = 0 AND deleted = 0;`];
    } else if (Array.isArray(_keyStr)) {
      _strArr = _keyStr.map(v => {
        _dictObj = _getDictDefObj(v);
        _listStr = _dictObj.listRange.length ? `, ${_dictObj.listRange.join(', ')}` : '';
        return `SELECT id AS \`key\`, namezh AS title${_listStr} FROM ${_dictObj.tblName} WHERE stopped = 0 AND deleted = 0;`
      });
    }
    _resArr = await _execer(_strArr.join(''));
    let i = 0;
    if (_isSingle) {
      _resObj[_keyStr[0]] = _resArr;
    } else {
      for (let v of _resArr) {
        _resObj[_keyStr[i]] = v;
        i++;
      }
    }
  }
  res.apiOk(_resObj);
});

module.exports = router;
