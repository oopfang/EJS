/* 
  主数据查询路由
*/

let express = require('express');
let router = express.Router();
let _execer = require('../utility/execer');
const _defaultDef = {
  dept: {
    tblName: '__sysOrgs',
    listRange: ['pid', 'organtypeid', 'chargemanid']
  },
  hr: {
    tblName: '_sysUser',
    listRange: ['pid', 'name', 'jobNo', 'gender', 'phoneWork', 'phonePrivate', 'email', 'avatar', 'accType']
  },
  channel: {
    tblName: '__sysChannel',
    listRange: ['chargemanid']
  },
  customer: {
    listRange: ['custBuildType', 'phone', 'province', 'city', 'addr', 'orgCode', 'bank', 'account']
  },
  produc: {
    listRange: ['brandId', 'groupFitId', 'price', 'picAddr', 'co2', 'mainImg']
  },
  groupColor: {
    listRange: ['prodTypeId']
  },
  groupSize: {
    listRange: ['prodTypeId']
  },
  warehouse: {
    listRange: ['pid', 'storeUnitType']
  },
  role: {
    tblName: '_roleGroup',
    listRange: []
  }
};

let _getDictDefObj = keyStr => {
  let _currObj = _defaultDef[keyStr];
  if (_currObj) {
    return {
      tblName: _currObj.tblName || keyStr,
      listRange: _currObj.listRange || []
    };
  } else {
    return {
      tblName: keyStr,
      listRange: []
    };
  }
};

let _getKeysArr = arr => {
  return arr.map(v => {
    let { tblName, listRange } = _getDictDefObj(v);
    let _addixStr = '';
    if (listRange.length) {
      _addixStr = `, ${listRange.join(', ')}`;
    }
    return `SELECT id AS \`key\`, namezh AS title${_addixStr} FROM ${tblName} WHERE stopped = 0 AND deleted = 0;`;
  });
};

/* 根据关键词索引主数据 */
router.get('/dict', async (req, res, next) => {
  let _keyStr = req.query.keys;
  let _resArr = [];
  let _resObj = {};
  let _isSingle = (_keyStr.length === 1);
  let _strArr = _keyStr.map(v => {
    return `SELECT \`key\`, title FROM __dictInt WHERE \`group\` = '${v}';`;
  });
  if (_strArr.length) {
    _resArr = await _execer(_strArr.join(''));
    let i = 0;
    for (let v of (_isSingle ? [_resArr]: _resArr)) {
      _resObj[_keyStr[i]] = v;
      i++;
    }
  }
  res.apiOk(_resObj);
});

/* 根据关键词索引基础资料，并以主数据方式返回 */
router.get('/masterAsDict', async (req, res, next) => {
  let _keyStr = req.query.keys;
  let _resArr = [];
  let _resObj = {};
  let _isSingle = (_keyStr.length === 1);
  let _strArr = _getKeysArr(_keyStr);
  if (_strArr.length) {
    _resArr = await _execer(_strArr.join(''));
    let i = 0;
    for (let v of (_isSingle ? [_resArr]: _resArr)) {
      _resObj[_keyStr[i]] = v;
      i++;
    }
  }
  res.apiOk(_resObj);
});

module.exports = router;
