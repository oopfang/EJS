let fs = require('fs');
let path = require('path');
let express = require('express');
let router = express.Router();

let _getJs = () => {
	return new Promise((resolve, reject) => {
		fs.readdir(path.resolve(__filename, '..'), (err, list) => {
			if (!err) {
				resolve(list);
			} else {
				reject(err);
			}
		});
	});
};

let _init = async () => {
	let res = await _getJs();
	for (let v of res) {
		let [a, b] = v.split('.');
		if (a !== 'index' && b && b === 'js') {
			let _funcObj = require(`./${v}/index`);
			router.get(`/${a}/getObj`, _funcObj.objFunc);
			router.get(`/${a}/getList`, _funcObj.listFunc);
			router.post(`/${a}/itemAdd`, _funcObj.postFunc);
			router.put(`/${a}/itemEdit`, _funcObj.putFunc);
			router.delete(`/${a}/itemDel`, _funcObj.delFunc);
		};
	};
};

_init();

module.exports = router;