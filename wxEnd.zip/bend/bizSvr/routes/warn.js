let express = require('express');
let router = express.Router();
let _execer = require('../utility/execer');
let Tdate = globalThis.smpoo.Tdate;

// 获取效期预警列表
router.get('/dateEndList', async (req, res, next) => {
  try {
		let _strSelect = `SELECT a.id, a.pid, a.\`code\`, a.prodId, b.namezh AS prodNamezh, a.spec, c.namezh AS specNamezh, a.size, d.namezh AS sizeNamezh, a.unit, 
		a.uuCodePub, a.uuCodePrive, a.checkTypeId, a.dateValidityEnd FROM billVrifyDetail a
		LEFT JOIN (SELECT id, namezh FROM produc) b ON a.prodId = b.id
		LEFT JOIN (SELECT id, namezh FROM groupColor) c ON a.spec = c.id
		LEFT JOIN (SELECT id, namezh FROM groupSize) d ON a.size = d.id`;
		// 效期记录为空
		let _str0 = `${_strSelect} WHERE a.dateValidityEnd IS NULL OR a.dateValidityEnd = '';`;
		// 当天到期
		let _str1 = `${_strSelect} WHERE TO_DAYS(a.dateValidityEnd) = TO_DAYS(NOW());`;
		// 大于0小于等于3
		let _str3 = `${_strSelect} WHERE DATE_SUB(CURDATE(),INTERVAL 3 DAY) <= DATE(a.dateValidityEnd);`;
		// 大于3小于等于7
		let _str7 = `${_strSelect} WHERE DATE_SUB(CURDATE(),INTERVAL 7 DAY) <= DATE(a.dateValidityEnd);`;
		// 大于7天
		let _strM = `${_strSelect} WHERE DATE_SUB(CURDATE(),INTERVAL 7 DAY) > DATE(a.dateValidityEnd);`;
    let _resObj = await _execer(`${_str0}${_str1}${_str3}${_str7}${_strM}`);
    res.apiOk(_resObj);
  } catch (err) {
    res.apiErr(err, 403);
  }
});

module.exports = router;
