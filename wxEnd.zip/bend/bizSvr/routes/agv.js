let express = require('express');
let tErr = require('tframe-prebend').preError;
let preOrms = require('tframe-orms').preOrms;
let crud = require('tframe-enum').crud;
let router = express.Router();
let _execer = require('../utility/execer');
let UudCode = require('../utility/getUud');
let setPick = require('../utility/setPick');
let tGlb = require('tframe-globalext');
let dayjs = require('dayjs');
let { sendForIn } = require('../utility/blockChain');

tGlb();
let Tdate = globalThis.smpoo.Tdate;

let _tagCache = {
  storeout: '出库指令'
};

let _funcOut = () => {
  return `SELECT a.id, a.dateDelivery, a.fromBillNo, b.namezh AS custNamezh, a.phone, a.custAddr, c.quantity, d.title AS deliveryTypeNamezh, CASE a.alreadyDone WHEN 1 THEN '是' ELSE '否' END AS alreadyDone FROM billAdviceSend a
  LEFT JOIN (SELECT id, namezh FROM customer) b ON a.custId = b.id 
  LEFT JOIN (SELECT pid, SUM(quantity) AS quantity FROM billAdviceSendDetail GROUP BY pid) c ON c.pid = a.id
  LEFT JOIN (SELECT \`key\`, title FROM __dictInt WHERE \`group\` = 'deliveryType') d ON d.\`key\` = a.deliveryType
  ORDER BY id DESC;`;
}

let _stroeOutFunc = async param => {
  try {
    let _num = 1;
    if (param.optNum !== undefined) {
      _num = parseInt(param.optNum);
    }
    let _str = `UPDATE billAdviceSendDetail SET quantityLeft = quantityLeft - ${_num} WHERE id = ${param.id};
    SELECT id, prodId, spec, size, quantityLeft, 'K01KZ1D01L01C0100A' AS storeId FROM billAdviceSendDetail WHERE quantityLeft > 0;`;
    let _resAll = await _execer(_str);
    return _resAll[1];
  } catch (err) {
    throw err;
  }
};

router.get('/', async (req, res, next) => {
  try {
    let _str = `SELECT id, prodId, spec, size, quantityLeft, 'K01KZ1D01L01C0100A' AS storeId FROM billAdviceSendDetail WHERE quantityLeft > 0;`;
    let _resAll = await _execer(_str);
    res.apiOk(_resAll);
  } catch (err) {
    console.error(err);
    res.apiErr(err, 403)
  }
});

let _stroeInByUuid = async (uuid, cellCode, code) => {
  try {
    let { prodId, spec, size, fromCustId, state } = UudCode.resolveUUd(uuid);
    let { pubKey, prvKey } = UudCode.encodeUud(uuid);
    let resUUid = await _execer(`SELECT * FROM inventory WHERE uuCodePrive = '${prvKey}' AND uuCodePub = '${pubKey}';`);
    if (!resUUid.length) {
      let _code = Tdate.getCode();
      // 获取本商品的退货原因
      let _strReason = `SELECT reason FROM returenAskDetail WHERE pid = (
        SELECT id FROM billReturenAsk WHERE id = (
        SELECT pid FROM billStockIn WHERE id = (
        SELECT pid FROM billVrify WHERE id = (SELECT pid FROM billVrifyDetail WHERE uuCodePrive = '${prvKey}' AND uuCodePub = '${pubKey}')
        ))) AND prodId = ${prodId} AND spec = ${spec} AND size = ${size};`;
      let _strCust = `SELECT province, city FROM customer WHERE id = ${fromCustId};`;
      let [[reason], [{ province, city }]] = await _execer(`${_strReason}${_strCust}`);
      return `('${_code}', ${fromCustId}, '${province}', '${city}', '${prodId}', '${spec}', '${size}', 1, '${state}', '${state}', 1, ${reason || 1}, '${cellCode}', '${pubKey}', '${prvKey}', '机器人上架入库')`;
    } else {
      throw new Error('该商品已上架，不能重复操作');
    }
  } catch (err) {
    throw err;
  }
}

// 小程序获取商品列表
router.get('/prodList', async (req, res, next) => {
  try {
    let _str = `SELECT * FROM produc;SELECT * FROM groupColor;SELECT * FROM groupSize;`;
    let [a, b, c] = await _execer(_str);
    let prod = a.map(v => {
      v.specList = `${v.spec || ''}`.split(',');
      v.sizeList = `${v.size || ''}`.split(',');
      return v;
    });
    res.apiOk([prod, b, c]);
  } catch (err) {
    apiErr(err);
  }
});

// 入库上报
router.post('/storein', async (req, res, next) => {
  try {
    let _errMsg = [];
    let { uuid, cellLocal, state, errCode } = req.body;
    if (!uuid) {
      _errMsg.push('uuid 值');
    }
    if (!cellLocal) {
      _errMsg.push('cellLocal 值');
    }
    if (typeof state === 'undefined') {
      _errMsg.push('state 值');
    }

    if (_errMsg.length) {
      let _eStr = _errMsg.map(v => `【${v}】`).join('，');
      res.apiErr(new Error(`接口上传的参数未提供：${_eStr}`));
    } else {
      let _ck = parseInt(state);
      if (_ck) {
        let _strVal = await _stroeInByUuid(uuid, cellLocal);
        let _str = `INSERT INTO \`inventory\` (\`code\`, \`custId\`, \`province\`, \`city\`, \`prodId\`, \`spec\`, \`size\`, \`stateIn\`, \`stateVerify\`, \`checkTypeId\`, \`quantity\`, \`reason\`, \`cellCode\`, \`uuCodePub\`, \`uuCodePrive\`, \`memo\`) VALUES ${_strVal};`;
        await _execer(_str);
        let { prodId } = UudCode.resolveUUd(uuid);
        let [a] = await _execer(`SELECT \`code\`, namezh FROM produc WHERE id = ${prodId};`);
        sendForIn({
          "code": `${Tdate.getCode()}`,
          "ename": `${uuid}`,
          "cname": `${a.namezh}`,
          "pcode": `${a.code}`
        });
        res.apiOk('入库上报成功');
      } else {
        res.apiErr(new Error(errCode || '因接口通知入库未成功，因此本次接入未记录。'));
      }
    }
  } catch (err) {
    console.error(err);
    res.apiErr(err, 403);
  }
});

// 出库任务查询
router.get('/storeout', async (req, res, next) => {
  try {
    let _str = `SELECT id, pid, prodId, spec, size, quantity, pid AS orderId, CONCAT(prodId, '-', spec, '-', size) AS tag FROM billPickDetail WHERE quantityPick = 0 AND stopped = 0 AND deleted = 0;`;
    let _str2 = `SELECT prodId, spec, size, cellCode, quantity, CONCAT(prodId, '-', spec, '-', size) AS tag FROM inventory
    WHERE CONCAT(prodId, '-', spec, '-', size) IN (SELECT CONCAT(prodId, '-', spec, '-', size) FROM billPickDetail) AND cellCode <> '' AND cellCode IS NOT NULL;`;
    let [a, b] = await _execer(`${_str}${_str2}`);
    let _obj = {};
    for (let v of b) {
      if (!_obj[v.tag]) {
        _obj[v.tag] = [];
      }
      _obj[v.tag].push(v);
    }
    let _resAll = [];
    for (let v of a) {
      for (let i = 0; i < v.quantity; i++) {
        if (_obj[v.tag] && _obj[v.tag].length) {
          v.cellCode =( _obj[v.tag].pop()).cellCode;
        } else {
          v.cellCode = '库存不足';
        }
        _resAll.push(v);
      }
    }

    res.apiOk(_resAll);
  } catch (err) {
    console.error(err);
    res.apiErr(err, 403);
  }
});

// 出库结论上报
router.post('/storeout', async (req, res, next) => {
  try {
    let { id, pid, orderId, uuid, state } = req.body;
    let _errMsg = [];
    if (!id) {
      _errMsg.push('id 值');
    }
    if (!pid) {
      _errMsg.push('pid 值');
    }
    if (!orderId) {
      _errMsg.push('orderId 值');
    }
    if (!uuid) {
      _errMsg.push('uuid 值');
    }
    if (typeof state === 'undefined') {
      _errMsg.push('state 值');
    }

    if (_errMsg.length) {
      let _eStr = _errMsg.map(v => `【${v}】`).join('，');
      res.apiErr(new Error(`接口上传的参数未提供：${_eStr}`));
    } else {
      let { prodId, spec, size } = UudCode.resolveUUd(uuid);
      let _queryStr = `SELECT id, pid, prodId, spec, size FROM billPickDetail WHERE id = ${id} AND pid = ${pid} AND prodId = ${prodId} AND spec = ${spec} AND size = ${size};`;
      let [_resCheck] = await _execer(_queryStr);
      if (!_resCheck) {
        _errMsg.push(`接口上传的参数无效, 请检查 【id】， 【pid】， 【uuid】`);
      }
      if (_errMsg.length) {
        res.apiErr(new Error(_errMsg.join('')));
      } else {
        let _str = `${setPick.main(req.body)}`;
        if (!_str) {
          res.apiErr(new Error('接口返回的数据不符合规范，出库上报失败'));
        } else {
          await _execer(_str);
          // let { prvKey, pubKey } = UudCode.encodeUud(uuid);
          // _str = `DELETE FROM billPickDetail WHERE \`uuCodePub\`= '${pubKey}' AND \`uuCodePrive\` = '${prvKey}' AND pid = ${pid};`;
          _str = `DELETE FROM billPickDetail WHERE id = ${id};`;
          await _execer(_str);
          res.apiOk('出库上报成功');
        }
      }
    }
  } catch (err) {
    console.error(err);
    res.apiErr(err, 403);
  }
});

// 库存查询
router.get('/storeview', async (req, res, next) => {
  try {
    let _str = `SELECT prodId, spec, size, quantity, cellCode FROM inventory;`;
    let _resAll = await _execer(_str);
    let x = {
      '范例': {
        '产品1-ID': {
          '规格1-ID': {
            '型号1-ID': {
              '货架号-1': '数量',
              '货架号-2': '数量'
            },
            '型号2-ID': {
              '货架号': '数量'
            }
          },
          '规格2-ID': {
            '型号ID': {
              '货架号': '数量'
            }
          }
        },
        '产品2-ID': {
          '规格ID': {
            '型号ID': {
              '货架号': '数量'
            }
          }
        }
      }
    };
    let _obj = {};
    for (let v of _resAll) {
      let { prodId, spec, size, cellCode } = v;
      if (!_obj[prodId]) {
        _obj[prodId] = {};
        _obj[prodId][spec] = {};
        _obj[prodId][spec][size] = {};
        _obj[prodId][spec][size][cellCode] = 1;
      } else {
        if (!_obj[prodId][spec]) {
          _obj[prodId][spec] = {};
          _obj[prodId][spec][size] = {};
          _obj[prodId][spec][size][cellCode] = 1;
        } else {
          if (!_obj[prodId][spec][size]) {
            _obj[prodId][spec][size] = {};
            _obj[prodId][spec][size][cellCode] = 1;
          } else {
            if (!_obj[prodId][spec][size][cellCode]) {
              _obj[prodId][spec][size][cellCode] = 1;
            } else {
              _obj[prodId][spec][size][cellCode] = _obj[prodId][spec][size][cellCode] + 1;
            }
          }
        }
      }
    }

    res.apiOk([
      x,
      _obj
    ]);
  } catch (err) {
    console.error(err);
    res.apiErr(err, 403);
  }
});

let _random = (lower, upper) => {
  return Math.floor(Math.random() * (upper - lower + 1)) + lower;
};

// 获取有效的测试 UUID
router.get('/getUuid', async (req, res, next) => {
  try {
    let { prodId, spec, size } = req.query;
    let _dt1 = dayjs().format('YYYY-MM-DD');
    let _strH = `${_random(1, 23)}`;
    let _strM = `${_random(1, 59)}`;
    let _strS = `${_random(1, 59)}`;
    let _strDate = `${_dt1} ${_strH.padStart(2, '0')}:${_strM.padStart(2, '0')}:${_strS.padStart(2, '0')}:000`;
    let x = {
      fromCustId: 12, 
      prodId, 
      spec, 
      size, 
      dateCheck: _strDate, 
      opteratorId: 15, 
      state: 1
    };
    res.apiOk(UudCode.getUud(x));
    // res.apiErr('此模拟接口已停用，请使用正式数据');
  } catch (err) {
    throw err;
  }
});

module.exports = router;
