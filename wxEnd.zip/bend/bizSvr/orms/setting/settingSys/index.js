module.exports = {
  namezh: '系统级设置'
};