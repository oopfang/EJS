module.exports = {
  namezh: '用户级设置'
};
