import enumObj from 'tframe-enum';

module.exports = {
  namezh: '首页仪表盘',
  setSelect: {
    dataFrom: enumObj.db.dataFrom.view
  }
};
