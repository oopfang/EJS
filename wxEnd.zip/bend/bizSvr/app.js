// 引用 tFrame-utility 组件
let express = require('express');
let fs = require('fs');
let path = require('path');
let preBend = require('tframe-prebend');
let tEnum = require('tframe-enum');
let torm = require('tframe-orms');
let tfile = require('tframe-file');
let MysqlEg = require('tframe-mysql');
let compression = require('compression');
let coreTables = require('./reserve/tables');
let coreRecord = require('./reserve/records');
let coreProc = require('./reserve/procs');
let Tcore = require('./reserve/core');
let globalInit = require('tframe-globalext');
let approGetByUser = require('./utility/approGetByUser');

globalInit();

let app = express();
// 开启服务端压缩
app.use(compression());

// 全局配置文件
let confStr = fs.readFileSync('../sys_conf/.config', 'utf8').replace(/.*\/\/.*\r\n/g, '');
let confile = preBend.preConfig(JSON.parse(confStr));
let _conf = confile.config;

let jwt = require('jwt-simple');
require('express-async-errors');
let favicon = require('serve-favicon');
let cors = require('cors');
let bodyParser = require('body-parser');
let amqp = require("amqplib/callback_api");

let enum_sys = tEnum.sys;
let enum_log = tEnum.log;
let enum_biz = tEnum.biz;
let enum_event = tEnum.event;

preBend.preSvr.svrBoot();

let logCnn = null;

let errHandler = (err) => {
  console.error(err);
  if (logCnn) logCnn.close(function () {
    logCnn = null;
    Promise.reject(err);
  });
};

let getLogCnn = () => {
  return new Promise((resolve, reject) => {
    amqp.connect(`amqp://${_conf.server.logSvr.addr}:${_conf.server.logSvr.port}`, (err, conn) => {
      if (err !== null) {
        errHandler(err);
        console.error('由于日志服务的消息队列连接失败，阻止了系统启动');
        process.exit(1);
      };
      logCnn = conn;
      resolve();
    })
  });
};

// let _setLog = (msg) => {}

// 全局日志处理器
global.setLog = (logType, logLevel, memo, detailCode) => {
  // if (logType && logLevel) {
  //   let msg = {
  //     type: logType,
  //     level: logLevel,
  //     memo: memo,
  //     detailCode: detailCode
  //   };
  //   let ex = 'direct_logs';
  //   let exopts = {
  //     durable: true
  //   };

  //   let on_channel_open = (err, ch) => {
  //     if (err !== null) return errHandler(err);
  //     ch.assertExchange(ex, 'direct', exopts, function (err, ok) {
  //       ch.publish(ex, msg.level, new Buffer.from(JSON.stringify(msg)));
  //     });
  //   }

  //   if (logCnn) {
  //     logCnn.createChannel(on_channel_open);
  //   } else {
  //     getLogCnn().then(resCnn => {
  //       logCnn.createChannel(on_channel_open);
  //     });
  //   }
  // }
};

process.on('rejectionHandled', p => {
  let _msg = '全局捕获的异常';
  console.log((_msg));
  setLog(enum_log.actTypeCode.unknown, enum_log.actLevelCode.error, _msg, 'Z200');
});

process.on('unhandledRejection', (reason, p) => {
  let _msg = '未处理的异常';
  console.log((_msg));
  console.log(reason);
  setLog(enum_log.actTypeCode.unknown, enum_log.actLevelCode.error, reason, 'Z200');
});

// 路由模块引入
let agv = require('./routes/agv');
let appro = require('./routes/appro');
let orgs = require('./routes/orgs');
let channel = require('./routes/channel');
let sign = require('./routes/sign');
let hr = require('./routes/hr');
let biz = require('./routes/biz');
let tomorrow = require('./routes/tomorrow');
let fLoader = require('./routes/fLoader');
let master = require('./routes/master');
let demo = require('./routes/demo');
let api = require('./routes/api.js');
let rpt = require('./routes/rpt.js');
let warn = require('./routes/warn.js');
let chainBlock = require('./routes/chainBlock.js');

// 路由预处理
app.use((req, res, next) => {
  req.currUserId = req.headers['x-access-id'] || -1;
  preBend.preRoutes(req, res, next);
});

// 跨域处理
app.use(
  cors({
    origin: function (origin, callback) {
      callback(null, true);
    },
    methods: ['PUT', 'POST', 'GET', 'DELETE', 'OPTIONS'],
    exposedHeaders: ['Authorization'],
    allowedHeaders: [
      'Origin',
      'Authorization',
      'Accept',
      'Content-Type',
      'Content-Length',
      'X-Requested-With',
      'Accept-Encoding',
      'Access-Control-Allow-Origin',
      'Access-Control-Allow-Credentials',
      'x-access-token',
      'x-access-id'
    ],
    credentials: true
  })
);

app.use(express.static('static'));
let ejs = require('ejs');
// app.set('views', __dirname + '\\views');
app.set('views', path.join(__dirname, 'views'));
// app.engine('.html', ejs.__express);
app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);

/* 设置全局变量
 */
// 全局默认枚举
global.enumBiz = enum_biz;
global.enumLog = enum_log;
global.enumSys = enum_sys;
// 全局配置对象
global.config = _conf;

let getTask = mds => {
  return new Promise((resolve, reject) => {
    try {
      let _tk = {};
      let _tkVal = {};
      mds.forEach((v, k, arr) => {
        Object.keys(arr[k]).forEach((vt, kt, arrt) => {
          // 如果配置文件中没有定义 tblName，则用 index.js 文件所在的目录名代替
          let _currMds = arr[k][vt];
          _currMds.tblName = _currMds.tblName || vt;
          let _subTask = torm.preOrms.init(_currMds);
          if (_subTask) {
            _tk[_subTask.fullDefine.tblName] = _subTask.taskCreate;
            _tkVal[`${_subTask.fullDefine.tblName}Val`] = _subTask.taskDefalutVal;
          }
          let {
            values,
            ...otherDefine
          } = _subTask.fullDefine;
          global.orms[vt] = otherDefine;
        });
      });
      resolve({
        task: _tk,
        taskVal: _tkVal
      });
    } catch (err) {
      reject(err);
    }
  });
}

let dbBoot = async mds => {
  // 响应DB处理器事件的控制台回显和服务终止
  let dbEventEcho = (msg, isErr = false) => {
    if (msg && typeof msg === 'string') {
      let eType = enum_log.actTypeCode.db;
      let eLevel = isErr ? enum_log.actLevelCode.error : enum_log.actLevelCode.info;
      let eCode = isErr ? enum_log.detailCode.B300 : 'B000';
      setLog(eType, eLevel, msg, eCode);
      if (isErr) {
        console.log('\x1B[31m\x1B[39m', msg);
        process.exit(1);
      } else {
        console.log(msg);
      }
    } else {
      console.log(
        '\x1B[31m\x1B[39m',
        '事件传入的 msg 参数不正确，未能写入日志。'
      );
    }
  };
  // 响应SQL命令执行过程中的控制台回显
  let sqlEventEcho = (msg, isErr = false) => {
    if (msg && typeof msg === 'string') {
      let eType = enum_log.actTypeCode.db;
      let eLevel = isErr ?
        enum_log.actLevelCode.error :
        enum_log.actLevelCode.info;
      let eCode = isErr ? enum_log.detailCode.B300 : 'B000';
      setLog(eType, eLevel, msg, eCode);
      if (isErr) {
        console.log('\x1B[31m\x1B[39m', msg);
      } else {
        console.log(msg);
      }
    } else {
      console.log(
        '\x1B[31m\x1B[39m',
        '事件传入的 msg 参数不正确，未能写入日志。'
      );
    }
  };

  let mysqlEg = new MysqlEg(_conf.db.bizDb);
  mysqlEg.onEvent(enum_event.initOk, dbEventEcho);
  mysqlEg.onEvent(enum_event.initMsg, dbEventEcho);
  mysqlEg.onEvent(enum_event.initErr, msg => {
    dbEventEcho(msg, true);
  });
  mysqlEg.onEvent(enum_event.sqlOk, sqlEventEcho);
  mysqlEg.onEvent(enum_event.sqlErr, msg => {
    sqlEventEcho(msg, true);
  });

  global.orms = {};
  // 默认的输入输出注入函数
  let defaultInjectFunc = (param) => {
    return null;
  };
  
  let { task, taskVal} = await getTask(mds);
  let resCk = await mysqlEg.dbCheck();
  let resDb = await mysqlEg.init([task, taskVal]);


  // 单例DB访问对象
  global.dbObj = mysqlEg;
  let _menuStr = `SELECT \`code\`, maxStep FROM _sysMenu;`;
  // 加载系统保留模块
  await mysqlEg.dbExec(coreTables);
  let a = await mysqlEg.dbExec(_menuStr);
  let _obj = {};
  for (let v of a) {
    _obj[v.code] = v.maxStep;
  }
  global.bizApproStep = _obj;
  try {
    await mysqlEg.dbExec(coreRecord);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      console.log('跳过默认值创建');
      setLog(enum_log.actTypeCode.db, enum_log.actLevelCode.info, `该异常是由于系统核心记录已存在造成，属于正常范围。详情如下：\n${err.stack}`, 'D201');
    } else {
      console.log(err);
      setLog(enum_log.actTypeCode.svr, enum_log.actLevelCode.error, err.stack, 'B000');
      console.log('系统核心记录加载失败，已停止启动');
      process.exit(1);
    }
  }
  await Promise.all(coreProc.map(vps => {
    return mysqlEg.dbExec(vps);
  }));

  // 准备加载业务权限集
  // let _resSeed = await mysqlEg.dbExec(bizCmd.getSeedStr);
  let tCore = new Tcore();
  global.rightsObj = {
    ...(await tCore.getRights())
  };
  global.$orgs = await tCore.getOrgs();

  preBend.preSvr.svrOk(_conf.app.appName, _conf.app.appVer, _conf.server.bizSvr.addr, _conf.server.bizSvr.port);
};

let moduleBoot = async () => {
  let resModule = await Promise.all([
    tfile.preModule(path.join(__dirname, 'orms', 'bill')),
    tfile.preModule(path.join(__dirname, 'orms', 'custom')),
    tfile.preModule(path.join(__dirname, 'orms', 'dict')),
    // tfile.preModule(path.join(__dirname, 'orms', 'sys')),
    tfile.preModule(path.join(__dirname, 'orms', 'setting'))
  ]);

  console.log('ORM模型加载成功！');
  return await dbBoot(resModule);
};

moduleBoot();

app.use('/sign', sign);

app.use('/tomorrow/', tomorrow);
app.use('/appro', appro);
app.use('/orgs', orgs);
app.use('/channel', channel);
app.use('/hr', hr);
app.use('/biz/', approGetByUser, biz);
app.use('/agv', agv);
app.use('/master', master);
app.use('/demo', demo);
app.use('/fLoader', fLoader);
app.use('/api', api);
app.use('/rpt', rpt);
app.use('/warn', warn);
app.use('/chainBlock', chainBlock);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  let err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function (err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.apiErr(err);
});

module.exports = app;
