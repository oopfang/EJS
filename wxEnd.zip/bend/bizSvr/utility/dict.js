let _execer = require('./execer');
const _strGroupId = `SELECT b.* FROM (SELECT MAX(id) AS maxId, \`group\` FROM __dictInt GROUP BY \`group\`) a LEFT JOIN (SELECT * FROM __dictInt b) b ON a.maxId = b.id ORDER BY a.\`group\`;
SELECT b.* FROM (SELECT MAX(id) AS maxId, \`group\` FROM __dictStr GROUP BY \`group\`) a LEFT JOIN (SELECT * FROM __dictStr b) b ON a.maxId = b.id ORDER BY a.\`group\`;`
const _strGroup = `SELECT DISTINCT \`group\` FROM __dictInt;SELECT DISTINCT \`group\` FROM __dictStr;`;
const _strVal = `SELECT \`key\`, \`title\`, \`group\` FROM __dictInt;SELECT \`key\`, \`title\`, \`group\` FROM __dictStr;`;
const _strChannel = 'SELECT id, pid, code, namezh, chargemanid, tLeft, tRight FROM __sysChannel WHERE stopped = 0 AND deleted = 0;';
const _groupDesc = {};

// 获取同组的新增ID值（基于字典表的ID规则：前3位组序列，后4位组内序列）
let _getIdForNext = id => {
  let _arr1 = [];
  let _arr2 = [];
  let i = 0;
  for (let v of `${id}`) {
    if (i < 3) {
      _arr1.push(v);
    } else {
      _arr2.push(v);
    }
    i++;
  };
  let _str = `${parseInt(_arr2.join('')) + 1}`.padStart(4, '0');
  return `${_arr1.join('')}${_str}`;
};
// 获取新组的起始ID
let _getIdForNewGroup = () => {
  let _id = Math.max(..._groupDesc.map(v => {
    return v.id;
  }));
  return _id.substr(0, 3) + 100;
};

// 字典缓存初始化或重建函数
let _getInit = () => {
  return new Promise((resolve, reject) => {
		let _str = `${_strGroupId}${_strGroup}${_strVal}${_strChannel}`;
    _execer(_str)
      .then(res => {
				let [a, b, c, d, e, f, g] = res;
        global.dict = {};
        for (let v of a) {
          let {
            group,
            ...other
          } = v;
          _groupDesc[group] = {
            tblName: '__dictInt',
            ...other
          };
        }
        for (let v of b) {
          let {
            group,
            ...other
          } = v;
          _groupDesc[group] = {
            tblName: '__dictStr',
            ...other
          };
        }

        for (let v of [c, d]) {
          for (let vItem of v) {
            global.dict[vItem.group] = [];
          }
        }
        for (let v of e) {
          global.dict[v.group].push({
            key: v.key,
            title: v.title
          });
        }
        for (let v of f) {
          global.dict[v.group].push({
            key: v.key,
            title: v.title
          });
        }
        let _channelObj = {};
        for (let v of g) {
          _channelObj[`${v.id}`] = {
            id: v.id,
            pid: v.pid,
            code: v.code,
            namezh: v.namezh,
            chargemanid: v.chargemanid,
            tLeft: v.tLeft,
            tRight: v.tRight
          };
        }
        global.dict.channel = _channelObj;
				// console.log('全局字典缓存初始化成功！');
        resolve('全局字典缓存初始化成功！');
      })
      .catch(err => {
				console.error(`全局字典缓存初始化失败，原因是\n ${err}`);
        reject(err);
      });
  });
};

// 获取字典数据的新增语句
let _getStrAdd = (key, title, group, memo, geometric = 0) => {
  if (key !== undefined && title !== undefined && group) {
    let _groupObj = _groupDesc[group];
    let _tblName = _groupObj.tblName;
    let _str = '';
    if (_groupObj[group]) {
      let _newId = `${_groupObj.id.sub}`
      return `INSERT INTO ${_tblName}(\`id\`, \`key\`, \`title\`, \`group\`, \`memo\`, \`geometric\`) 
				VALUES('${_getIdForNext(_groupObj.id)}', '${key}', '${title}','${group}','${_groupObj.memo}','${_groupObj.geometric}');`;
    } else {
      if (memo) {
        let _newId = `${_getIdForNewGroup()}0001`;
        _str = `INSERT INTO ${_tblName}(\`id\`, \`key\`, \`title\`, \`group\`, \`memo\`, \`geometric\`) 
				VALUES('${_newId}', '${key}', '${title}','${group}','${memo}','${geometric}');`;
      } else {
        return '';
      }
    }
  } else {
    return '';
  }
};

// 获取字典数据的更新语句
let _getStrUpdate = (keyOld, title, group, keyNew) => {
  if (keyOld !== undefined && title !== undefined && group) {
		let _newKey = keyNew && (keyNew !== keyOld) ? keyNew : keyOld;
		let _groupObj = _groupDesc[group];
		return `UPDATE ${_groupObj.tblName} SET \`key\` = '${_newKey}', \`title\` = '${title}' WHERE \`key\` = '${keyOld}' AND \`group\` = '${group}';`;
	} else {
		return '';
	}
};

class Tdict {
	constructor() {}

  // 字典全局缓存初始化
  static async init() {
    try {
      let res = await _getInit()
      console.log(res);
      return res;
    } catch (err) {
      throw err;
    }
  }

  // 在字典表中添加字典项并更新缓存
  static async add(key, title, group, memo, geometric = 0) {
    await _execer(_getStrAdd(key, title, group, memo || '', geometric || 0));
    await _getInit();
  }

  // 更新字典表中的字典项
  static async update(key, title, group) {
    await _execer(_getStrUpdate(key, title, group, memo || '', geometric || 0));
    await _getInit();
  }
};

module.exports = Tdict;
