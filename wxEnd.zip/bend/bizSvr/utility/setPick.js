let UudCode = require('../utility/getUud');

module.exports = {
  main: (data, inPc) => {
    let _strArr = [];
    if (Array.isArray(data) && data.length) {
      for (let v of data) {
        if (v.state === 1) {
          if (v.inPc) {
            _strArr.push(`UPDATE billPickDetail SET quantityPick = 1, stopped = 1, deleted = 1 WHERE pid = ${v.id};`);
          } else {
            let {
              pubKey,
              prvKey
            } = UudCode.encodeUud(v.uuid || '');
            _strArr.push(`UPDATE billPickDetail SET quantityPick = 1, uuCodePub = '${pubKey}', uuCodePrive = '${prvKey}', stopped = 1, deleted = 1 WHERE id = ${v.id};`);
            _strArr.push(`DELETE FROM inventory WHERE uuCodePub = '${pubKey}' AND uuCodePrive = '${prvKey}';`);
          }
        }
      }
      if (data[0].inPc) {
        _strArr.push(`UPDATE billPick SET alreadyDone = 1 WHERE id = ${data[0].id};`);
      } else {
        _strArr.push(`UPDATE billPick SET alreadyDone = 1 WHERE id = ${data[0].pid};`);
      }
    } else {
      if (data.state === 1) {
        if (data.inPc) {
          _strArr.push(`UPDATE billPickDetail SET quantityPick = 1, stopped = 1, deleted = 1 WHERE pid = ${data.id};`);
          _strArr.push(`UPDATE billPick SET alreadyDone = 1, stopped = 1, deleted = 1 WHERE id = ${data.id};`);
        } else {
          let {
            pubKey,
            prvKey
          } = UudCode.encodeUud(data.uuid || '');
          _strArr.push(`UPDATE billPickDetail SET quantityPick = 1, uuCodePub = '${pubKey}', uuCodePrive = '${prvKey}', stopped = 1, deleted = 1 WHERE id = ${data.id};`);
          _strArr.push(`DELETE FROM inventory WHERE uuCodePub = '${pubKey}' AND uuCodePrive = '${prvKey}';`);
          _strArr.push(`UPDATE billPick SET alreadyDone = 1 WHERE id = ${data.pid};`);
        }
      }
    }
    return _strArr.join('');
  },
  // 拣货完成标志，pid 指出库通知单ID
  pickOver: pid => {
    return `UPDATE billSend SET dateStoreOut = DATE_FORMAT(NOW(), '%Y-%m-%d'), alreadyDone = 0, stopped = 0 WHERE pid = ${pid};
		UPDATE billSendDetail SET stopped = 0 WHERE billDeliveryNoticeId = ${pid};`;
  },
  // 创建出库单
  billSend: pid => {
		return `INSERT INTO billSend(\`pid\`, \`code\`, \`dateStoreOut\`, \`custId\`, \`phone\`, \`custAddr\`, \`memo\`, \`stopped\`) 
		SELECT id, \`code\`, DATE_FORMAT(NOW(), '%Y-%m-%d') AS dateStoreOut, custId, phone, custAddr, '拣货完成自动创建' AS memo, 1 FROM billAdviceSend WHERE id = ${pid};`;
	},
	// 创建出库单明细
	billSendDetail: pid => {
    return `INSERT INTO billSendDetail(pid, \`code\`, billDeliveryNoticeId, prodId, spec, size, unit, quantity, memo, stopped)
		SELECT ${pid}, \`code\`, pid, prodId, spec, size, unit, quantity, '拣货完成自动创建', 1 FROM billAdviceSendDetail WHERE pid = 6;`;
	}
};
