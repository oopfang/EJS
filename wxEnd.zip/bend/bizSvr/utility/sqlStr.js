const SKIP_KEYS = ['id', 'stopped', 'deleted', 'createby', 'changeby', 'byid', 'orderIndex', 'tLeft', 'tRight', 'approStep'];

let _getInsertStr = (tblName, obj, ...ignore) => {
  let _isArr = Array.isArray(obj);
  let _keys = _isArr ? Object.keys(obj[0]) : Object.keys(obj);
  let skips = Array.from(new Set([...(ignore || []), ...SKIP_KEYS]));
  let _arrKeys = [];
  let _arrVals = [];
  for (let v of _keys) {
    if (!skips.includes(v)) {
      _arrKeys.push(v);
      if (!_isArr) {
        _arrVals.push(`'${obj[v]}'`);
      }
    }
  }
  if (_isArr) {
    let i = 0;
    for (let v of obj) {
      let _subArr = [];
      _arrVals.push(_arrKeys.map(vKey => {
        return `'${v[vKey]}'`;
      }));
      i++;
    }
  }

  let _currVal = !_isArr ? `(${_arrVals.join(', ')})` : _arrVals.map(v => {
    return `(${v.join(', ')})`;
  }).join(', ');
  let _resStr = `INSERT INTO ${tblName}(${_arrKeys.map(v => `\`${v}\``).join(', ')}) VALUES${_currVal};`;
  console.log(_resStr);
  return _resStr;
};

let _getUpdateStr = (tblName, obj, ...ignore) => {
  let _isArr = Array.isArray(obj);
  let _keys = _isArr ? Object.keys(obj[0]) : Object.keys(obj);
  let skips = [...(ignore || []), ...SKIP_KEYS];
  if (_keys.includes('id')) {
    let _arr = [];
    if (!_isArr) {
      for (let v of _keys) {
        if (v !== 'id' && !skips.includes(v)) {
          let _str = `\`${v}\` = '${obj[v]}'`;
          _arr.push(_str);
        }
      }
      return `UPDATE ${tblName} SET ${_arr.join(', ')} WHERE id = ${obj.id};`
    } else {
      for (let v of obj) {
        let _subArr = [];
        for (let vSub of _keys) {
          if (vSub !== 'id' && !skips.includes(vSub)) {
            _subArr.push(`\`${vSub}\` = '${v[vSub]}'`);
          }
        }
        _arr.push(`UPDATE ${tblName} SET ${_subArr.join(', ')} WHERE id = ${v.id};`);
      }
      return _arr.join('\n');
    }
  }
};

module.exports = {
  _getInsertStr,
  _getUpdateStr
};
