let _execer = require('../utility/execer');

/** 中间件：获取当前请求用户对应的审批权限
 */
module.exports = async (req, res, next) => {
	try {
		let [a = {}] = await _execer(`SELECT approReturnAsk, approRecive, approCheck, approSend FROM _sysUser WHERE id = ${req.currUserId};`);
		req.userAccess = {
			approReturnAsk: a.approReturnAsk || 0,
			approRecive: a.approRecive || 0,
			approCheck: a.approCheck || 0,
			approSend: a.approSend || 0
		};
		next();
	} catch (err) {
		res.apiErr(error, 403);
	}
};
