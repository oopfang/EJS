let rp = require('request-promise');
let dayjs = require('dayjs');
// 通用查询地址
let _getUrl = url => `https://rlom.chinacloudsites.cn/api`;
// 仅限于商品查询的地址
let _getUrlQuery = url => `http://rlom.chinacloudsites.cn/query`;


let _remoteFuncGet = (url, param) => {
	return new Promise((resolve, reject) => {
		let opt = {
			url: _getUrl(url),
			headers: {
					"content-type": "application/json",
			},
			json: true
		};
		if (param && Object.keys(param).length) {
			opt.qs = param;
		}

		rp(opt)
		.then(res => {
			resolve(res);
		})
		.catch(err => {
			reject(err);
		});
	});
};

let _remoteFuncPost = (url, data) => {
	let dtVal = JSON.parse(JSON.stringify(data));
	return new Promise((resolve, reject) => {
		let opt = {
			url: _getUrl(url),
			method: 'POST',
			body: dtVal || {},
			json: true
		};
		rp(opt)
		.then(res => {
			resolve(res);
		})
		.catch(err => {
			reject(err);
		});
	});
};

// 用于商品查询的新POST方法
let _remoteFuncPostForQuery = (url, data) => {
	return new Promise((resolve, reject) => {
		let opt = {
			url: _getUrlQuery(url),
			method: 'POST',
			body: data || {},
			json: true
		};
		rp(opt)
		.then(res => {
			resolve(res);
		})
		.catch(err => {
			reject(err);
		});
	});
};

// 入库节点上链
let sendForIn = async obj => {
	try {
		obj.action = 'inbound';
		obj.time = dayjs().format('YYYY/MM/DD HH:mm');
		let _res = await _remoteFuncPost('', obj);
		return _res;
	} catch (err) {
		console.error(err);
		throw err;
	}
};

// 出库节点上链
let sendForOut = async arr => {
	try {
		let _res = await Promise.all(arr.map(v => {
			v.action = 'outbound';
			v.time = dayjs().format('YYYY/MM/DD HH:mm');
			return _remoteFuncPost('', v);
		}));
		return _res;
	} catch (err) {
		console.error(err);
		throw err;
	}
};

// 商品查询
let getByUuId = async uuidStr => {
	try {
		let obj = {
			action: '',
			time: '',
			code: '',
			ename: '',
			pcode: uuidStr
		};
		let _res = await _remoteFuncPostForQuery('', obj);
		return _res;
	} catch (err) {
		console.error(err);
		throw err;
	}
};

module.exports = {
	sendForIn,
	sendForOut,
	getByUuId
};
