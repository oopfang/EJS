let { _getInsertStr } = require('./sqlStr');
let dayjs = require('dayjs');
let globalInit = require('tframe-globalext');
let getUud = require('./getUud');

globalInit();
let Tdate = globalThis.smpoo.Tdate;

let _province = ['上海', '北京', '广东', '四川', '山东', '湖北', '辽宁', '安徽', '陕西', '江苏', '甘肃'];
let _city = ['上海', '北京', '深圳', '成都', '青岛', '武汉', '沈阳', '芜湖', '西安', '苏州', '宁夏'];

// 取随机数
let _random = (lower, upper) => {
  return Math.floor(Math.random() * (upper - lower + 1)) + lower;
};

// 获取省市地址
let _getAddrInfo = () => {
	let _idx = _random(0, _province.length - 1);
	let _resP = _province[_idx];
	let _resC = _city[_idx];
	return [_resP, _resC];
};

// 随机获取日期
let _getDate = () => {
	let _y = _random(2000, 2020);
	let _m = `${(_random(1, 12))}`.padStart(2, '0');
	let _d = `${(_random(1, 28))}`.padStart(2, '0');
	return `${_y}-${_m}-${_d}`;
};

module.exports = (startId = 301, num = 300) => {
	let _arr = [];
	let _codeArr = Tdate.getCode(num + 1);
	for (let i = 0; i < num; i++) {
		let pc = _getAddrInfo();
		let _prodId = _random(1, 200);
		let _specId = _random(1, 8);
		let _sizeId = _random(1, 10);
		let _custId = _random(1, 100);
		let _state = _random(1, 4);
		let _uud = getUud.getUud({
			fromCustId: _custId, 
			prodId: _prodId, 
			spec: _specId, 
			size: _sizeId, 
			dateCheck: _getDate(), 
			opteratorId: 1, 
			state: _state
		});
		let _bar = getUud.encodeUud(_uud);
		let _cCode = `M1-Z1-D1-L1-C1-01`;
		_arr.push({
			pid: _random(1, 5),
			code: _codeArr.pop(),
			custId: _custId,
			prodId: _prodId,
			spec: _specId,
			size: _sizeId,
			unit: '件',
			quantity: 1,
			province: pc[0],
			city: pc[1],
			stateIn: _random(0, 1),
			stateVerify: _random(1, 4),
			checkTypeId: _state,
			dateValidityEnd: _getDate(),
			cellCode: _cCode,
			uuCodePub: _bar.pubKey,
			uuCodePrive: _bar.prvKey
		});
	}
	return _getInsertStr('inventory', _arr);
};
