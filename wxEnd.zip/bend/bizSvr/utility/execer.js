let tErr = require('tframe-prebend').preError;

module.exports = async cmd => {
  try {
    if (Array.isArray(cmd)) {
      return await Promise.all(cmd.map(v => {
        return _execer(v);
      }));
    } else if (typeof cmd === 'string') {
      let resExec = await dbObj.dbExec(cmd);
      return resExec;
    } else if (cmd.sqlCmd) {
      let x = await dbObj.dbExec(cmd.sqlCmd);
      return x;
    } else {
      return null;
    }
  } catch (err) {
    throw tErr(err, 403);
  }
}