let _execer = require('../utility/execer');

/** 类审批操作的执行中间件
 */
module.exports = async (req, res, next) => {
  try {
    let { bizIdent, id, title = '审批', val, ...def } = req.body;
    let _currVal = parseInt(def.currStep || 0);
    if (!bizIdent || !id || id < 1 || isNaN(_currVal) || _currVal < 0) {
			next(new Error(`${title}要素不完整，${title}失败！`), 403);
    } else {
      let isDisagree = !val;
      let _valUpdate = isDisagree ? 0 : _currVal + 1;
      let _str = `UPDATE ${bizIdent} SET approStep = ${_valUpdate} WHERE id = ${id}; SELECT stopped FROM ${bizIdent} WHERE id = ${id};`;
			let [a, [b]] = await _execer(_str);
			req.resApprov = {     
        // 审批状态下的已审级次
        currStep: _valUpdate,
        // 流程是否已经开始
        flowStart: _valUpdate > 0,
        // 流程是否已经关闭
        flowEnd: _valUpdate === global.bizApproStep[bizIdent].maxStep,
        // 本单是否已作废
        stopped: b.stopped,
        // 是否具有审批权限
        hasAccess: req.userAccess.approReturnAsk === _valUpdate,
        // 是否为创建者
        isCreator: def.isCreator
      };
			next();
    }
  } catch (err) {
		next(err);
  }
};
