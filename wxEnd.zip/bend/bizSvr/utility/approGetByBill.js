/** 中间件：根据DB查询的单据对象获取流程节点标志
 * @param { Object } billInfo DB查询的单据对象数据
 * @param { Object } hasAccess 是否具有审批权限
 * @param { Object } isCreator 是否是单据创建者
 */
module.exports = (billInfo, hasAccess, isCreator, maxStep) => {
	let _tp = billInfo ? typeof billInfo : 'null';
	if (_tp === 'object' && Array.isArray(billInfo)) _tp = 'array';
	let _strIn = 'in function approGetByBill.';
	if (_tp !== 'object') throw new Error(`Invalid param, Expect Object but get ${_tp} ${_strIn}`);
	let { approStep, stopped } = billInfo;
	if (approStep === undefined) throw new Error(`Invalid param, 'approStep' can't be undefined ${_strIn}`);
	if (maxStep === undefined) throw new Error(`Invalid param, 'maxStep' can't be undefined ${_strIn}`);
	if (stopped === undefined) throw new Error(`Invalid param, 'stopped' can't be undefined ${_strIn}`);
	return {
		// 审批状态下的已审级次
		currStep: approStep,
		// 流程是否已经开始
		flowStart: approStep > 0,
		// 流程是否已经关闭
		flowEnd: approStep === maxStep,
		// 本单是否已作废
		stopped,
		// 是否具有审批权限
		hasAccess: hasAccess === approStep,
		// 是否为创建者
		isCreator
	};
};
