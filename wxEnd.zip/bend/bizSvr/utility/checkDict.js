const TDict = require('./dict');

module.exports = async (req, res, next) => {
	try {
		if (!global.dict) {
      let resDict = await TDict.init();
			console.log(resDict);
			next();
		} else {
			next();
		}
	} catch (err) {
		next(err);
	}
}