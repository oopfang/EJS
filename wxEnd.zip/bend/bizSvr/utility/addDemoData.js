let { _getInsertStr } = require('./sqlStr');
let dayjs = require('dayjs');
let globalInit = require('tframe-globalext');
let lastNameStr = require('./demo/lastNameStr');
let _province = ['上海', '北京', '广东', '四川', '山东', '湖北', '辽宁', '安徽', '陕西', '江苏', '甘肃'];
let _city = ['上海', '北京', '深圳', '成都', '青岛', '武汉', '沈阳', '芜湖', '西安', '苏州', '宁夏'];
let _strList = '春信贵丰东弘同富飞庆万康万鼎隆高久协德高正禄如通公盈春谦皇贵伟荣旺利辉圣广安合亨吉如利如公佳华飞元正瑞丰聚兴长福元优多乾巨久德祥洪仁乾富隆安鑫德乾广伟复久多耀顺同福东昌洪亚盛欣元优耀佳昌益欣丰乾美长隆如福圣耀洪升合寿宏禄中辉辉浩裕顺伟汇发富茂宏盈信宝佳东恒中久多德百耀欣茂凯源台盈祥升满昌康泰同富高生元晶优谦义康进长复优华成耀发贵义茂乾宝高优泰益瑞高福优旺谦源长富润恒吉乾仁义益聚泰贵鑫协协多隆康欣鼎源耀贵昌禄协圣本庆兴鑫协正浩仁益高晶如隆凯进泰公多成通发同满乾升禄宏伟裕光贵正飞聚全裕耀百亚乾福乾安伟捷春禄美厚富泰顺义益捷中益本洪泰润凯佳盈捷厚荣大福耀协润美鑫广如德进源满谦长公进正元康荣协久泰升顺鑫广如德进源满谦';
let _companyTypeList = ['科技', '金融', '生物', '物流', '工程建设', '网络', '实业'];
let _companyOrg = ['公司', '有限公司', '股份有限公司', '集团'];
let _phonePre = ['130', '131', '133', '134', '137', '138', '188'];
let _numList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
let _letterList = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
let _firstName = '赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章';
let _bankList = ['招商银行', '建设银行', '工商银行', '农业银行', '交通银行', '光大银行'];
let _bankType = ['分行', '支行', '营业部'];
let _prodLastLetter = ['霜', '皂']
let _prodLastLetterType = [
	['护手', '润肤', '润白', '防晒', '去皱', '美白', '呵护', '宝宝', '防冻', '修正'],
	['沐浴', '香薰', '洗衣', '净白', '手工', '婴儿', '控油', '美白', '清洁']
];
let _prodNamez = ['迪拜', '植物', '精粹', '花香', '骆驼', '便携', '创意', '柔护', '欣沁', '居家', '麋鹿', '阿波罗之梦', '人参', '滋润', '嫩肤', '洁雅', '水润', '凡士林', '维生素', '微泡'];


globalInit();
let Tdate = globalThis.smpoo.Tdate;

// 取随机数
let _random = (lower, upper) => {
  return Math.floor(Math.random() * (upper - lower + 1)) + lower;
};

// 从字典集中随机取出指定长度字符
let _getVal = (arr, len, splitStr, ...splitPosition) => {
	let _arr = [];
	let _pArr = splitPosition || [];
	let _isResObj = (typeof arr[0] === 'object');
	for (let i = 0; i < len; i++) {
		if (typeof _pArr[0] !== 'undefined' && _pArr[0] === i) {
			_arr.push(splitStr || ' ');
			_pArr.shift();
		} else {
			let _idx = _random(0, arr.length - 1);
			_arr.push(arr[_idx]);
		}
	}
	if (_isResObj) {
		return _arr;
	} else {
		return _arr.join('');
	}
};

// 获取公司名称
let _getCompany = city => {
	let n = _getVal(_strList, _random(2, 4));
	let t = _getVal(_companyTypeList, 1);
	let o = _getVal(_companyOrg, 1);
	return `${city}${n}${t}${o}`;
};

// 获取随机姓名
let _getName = () => {
	let x = _getVal(_firstName, 1);
	let mLen = _random(1, 2);
	let m = _getVal(lastNameStr, mLen);
	return `${x}${m}`;
};

// 获取随机电话
let _getPhone = () => {
	return `${_getVal(_phonePre, 1)}${_getVal(_numList, 8)}`;
};

// 获取随机银行
let _getBank = city => {
	return `${_getVal(_bankList, 1)}${city}${_getVal(_bankType, 1)}`;
};

// 获取银行账号
let _getBankAccount = () => {
	return _getVal(_numList, 17, '-', 4, 9, 14);
};

// 获取省市地址
let _getAddrInfo = () => {
	let _idx = _random(0, _province.length - 1);
	let _resP = _province[_idx];
	let _resC = _city[_idx];
	let _resA = `${_getVal(_strList, _random(2, 3))}路${_getVal(_numList, 3)}号`;
	return [_resP, _resC, _resA];
};

// 客户
let _getCustomer = (startId = 1, num = 100) => {
	let _arr = [];
	let _codeArr = Tdate.getCode(num + 1);
	for (let i = 0; i < num; i++) {
		let _currCode = _codeArr.pop();
		let pc = _getAddrInfo();
		_arr.push({
			id: startId + i + 1,
			pid: -1,
			code: _currCode,
			name: _currCode,
			namezh: _getCompany(pc[1]),
			custBuildType: _random(1, 3),
			linkMan: _getName(),
			phone: _getPhone(),
			bank: _getBank(pc[1]),
			account: _getBankAccount(),
			province: pc[0],
			city: pc[1],
			addr: pc[2],
			orgCode: _getVal(_numList, 16)
		});
	}
	return _arr;
};

// 获取品牌
let _getBrand = (startId = 0) => {
	return [{
		id: startId + 1,
		code: 'rxd',
		name: 'Rxd',
		namezh: '儒象岛',
		brandBlongType: '1'
	}, {
		id: startId + 2,
		code: 'yiye',
		name: 'YIYE',
		namezh: '唯一',
		brandBlongType: '1'
	}, {
		id: startId + 3,
		code: 'minan',
		name: 'MINAN',
		namezh: '加净',
		brandBlongType: '1'
	}, {
		id: startId + 4,
		code: 'shen',
		name: 'SHEN',
		namezh: '清神',
		brandBlongType: '1'
	}, {
		id: startId + 5,
		code: 'heroist',
		name: 'HEROIST',
		namezh: '草集',
		brandBlongType: '1'
	}, {
		id: startId + 6,
		code: 'home',
		name: 'HOME',
		namezh: '家洁',
		brandBlongType: '1'
	}, {
		id: startId + 7,
		code: 'zhe',
		name: 'ZHE',
		namezh: '点泽',
		brandBlongType: '1'
	}, {
		id: startId + 8,
		code: 'cui',
		name: 'CUI',
		namezh: '精粹',
		brandBlongType: '1'
	}];
};

// 产品
let _getProduct = (startId = 1, num = 100) => {
	let _arr = [];
	let _codeArr = Tdate.getCode(num * 10 + 10);
	let _brandList = _getBrand();
	for (let m = 0; m < 2; m ++) {
		let gType = m + 1;
		for (let i = 0; i < num; i++) {
			let _currCode = _codeArr.pop();
			let _nZh = _getVal(_prodLastLetter, 1);
			let _nZhType = _getVal(_prodLastLetterType[m], 1);
			let [_bdObj] = _getVal(_brandList, 1);
			let _namezhStr = _getVal(_prodNamez, 2);
			let _namezhFull = `${_bdObj.namezh}(${_bdObj.name})${_namezhStr}${_nZhType}${_nZh}`;
			_arr.push({
				id: startId + i + 1,
				pid: -1,
				code: _currCode,
				name: _currCode,
				namezh: _namezhFull,
				brandId: _bdObj.id,
				groupFitId: gType,
				price: (_random(10, 30)).toFixed(2),
				co2: (Math.random()).toFixed(3),
				picAddr: '',
				mainImg: '',
				memo: ''
			})
		}
	}
	return _arr;
}

let _cmdSet = [{
		title: '获取客户',
		tbl: 'customer',
		data: _getCustomer
	}, {
		title: '获取品牌',
		tbl: 'brand',
		data: _getBrand
	}, {
		title: '获取产品',
		tbl: 'produc',
		data: _getProduct
	}];


module.exports = () => {
	let _arr = [];
	for (let v of _cmdSet) {
		_arr.push(_getInsertStr(v.tbl, v.data()));
	}
	return _arr.join('');
};
