/* =======================================*/
/*             预置存储过程集合              */
/*========================================*/

// 创建二叉树的节点插入函数
// 存储过程：bTreeAdd
// 说明：对指定的表的指定ID下挂载新的二叉节点，并更新所有值；
// 参数：
// @parent_id：待新增节点的父级ID
// @orderIdx：待新增节点在当前父级中的排序值[起始为：0]
// @tblName：待新增节点的表名称
// CREATE DEFINER = \`root\`@\`%\` PROCEDURE \`bTreeAdd\`(IN parent_id BIGINT, IN orderIdx INT, IN tblName VARCHAR(100))
// COMMENT '在新增操作前对表中的二叉值进行预重置\\r\\n[注：]必须在记录新增前执行'
let bTreeAdd = `DROP PROCEDURE IF EXISTS bTreeAdd;
  CREATE DEFINER=\`root\`@\`%\` PROCEDURE \`bTreeAdd\`(IN parent_id BIGINT, IN orderIdx INT, tblName VARCHAR(100))
  COMMENT '在新增操作前对表中的二叉值进行预重置\\r\\n[注：]必须在记录新增前执行'
  BEGIN
  IF(orderIdx = 0) THEN
    SET @stra = CONCAT('id = ', parent_id);
  ELSE
    SET @stra = CONCAT('pid = ', parent_id, ' AND orderIndex = ', orderIdx - 1);
  END IF;

  -- 获取插入位置的tRight值的执行指令
  SET @strInR = CONCAT('SELECT tRight INTO @vRight', ' FROM ', tblName, ' WHERE ', @stra, ';');
  -- 更新tLeft值的执行指令
  SET @strNewL = CONCAT('UPDATE ', tblName, ' SET tLeft = tLeft + 2 ', 'WHERE tLeft >  @vRight', ';');
  -- 更新tRight值的执行指令
  SET @strNewR = CONCAT('UPDATE ', tblName, ' SET tRight = tRight + 2 ', 'WHERE tRight >=  @vRight', ';');

  PREPARE cmdInR FROM @strInR;
  PREPARE cmdNewL FROM @strNewL;
  PREPARE cmdNewR FROM @strNewR;

  EXECUTE cmdInR;
  EXECUTE cmdNewL;
  EXECUTE cmdNewR;
  SELECT @vRight AS newLeft;
  END`;

// 创建二叉树的节点的物理删除函数
let bTreeDelPhysic = `DROP PROCEDURE IF EXISTS bTreeDelPhysic;
  CREATE DEFINER=\`root\`@\`%\` PROCEDURE \`bTreeDelPhysic\`(IN node_id BIGINT, tblName VARCHAR(100))
	COMMENT '二叉树的节点的物理删除函数'
	BEGIN
	-- 获取待删除节点的父级tLeft 和 tRight的值
	SELECT tleft, tright INTO @upperLeft, @upperRight FROM tblName WHERE id = (SELECT pid FROM tblName WHERE id = node_id);

	-- 获取要删除的tLeft和tRight范围
	SELECT tleft, tright INTO @vLeft, @vRight FROM tblName WHERE id = node_id;
	-- 遵照查询出的删除范围执行节点及其下的子节点的删除
	DELETE FROM tblName WHERE tleft >= @vLeft AND tright <= @vRight;
	-- 计算更新步长
	SET @stepValue = (@vRight - @vLeft + 1);
	-- 更新剩余记录的tLeft和tRight值
	UPDATE tblName SET tleft = tleft - @stepValue WHERE tleft > @upperLeft;
	UPDATE tblName SET tright = tright - @stepValue;
  END`;

let bTreeDel = `DROP PROCEDURE IF EXISTS bTreeDel;
  CREATE DEFINER=\`root\`@\`%\` PROCEDURE \`bTreeDel\`(IN nodeId BIGINT, tblName VARCHAR(100))
    COMMENT '二叉树的节点的伪删除函数'
  BEGIN
	-- @id：要删除的节点 ID
	-- @tblName：表名称
	SET @tLeft = -1;
  SET @tRight = -1;
  SET @selectStr = CONCAT('SELECT tLeft, tRight INTO @tLeft, @tRight FROM ', tblName, ' WHERE id = ', nodeId, ';');
  PREPARE cmdSelect FROM @selectStr;
  EXECUTE cmdSelect;
  SET @updateStr = CONCAT('UPDATE ', tblName, ' SET stopped = 1, deleted = 1 WHERE tLeft >= @tLeft AND tRight <= @tRight;');
  PREPARE cmdUpdate FROM @updateStr;
  EXECUTE cmdUpdate;
  SET @returnStr = CONCAT('SELECT id FROM ', tblName, ' WHERE tLeft >= @tLeft AND tRight <= @tRight;');
  PREPARE cmdReturn FROM @returnStr;
  EXECUTE cmdReturn;
  END`;

let bTreeMove = `DROP PROCEDURE IF EXISTS bTreeMove;
  CREATE DEFINER=\`root\`@\`%\` PROCEDURE \`bTreeMove\`(IN moveId BIGINT, IN toId BIGINT, tblName VARCHAR(100))
  BEGIN
	-- 移动指定ID的记录后的tLeft和tRight重建
	-- @moveId：要移动的记录的顶层ID（被移动记录的ID可能是其他记录的PID）
	-- @toId：插入点的ID，被移动的记录将插入到该记录之后
	-- @tblName：表名
  -- 初始化变量避免缓存
	SET @oldLeft = -1;
	SET @oldRight = -1;
	SET @oldStep = -1;
	SET @pointLeft = -1;
	SET @pointRight = -1;
	SET @pointPid = -999;
	SET @pointPath = '';
	-- 替换前的原父级路径
  SET @oldPath = '';
	SET @newPath = '';
	-- 要移动的原始数据查询
	SET @oldStr = CONCAT('SELECT tLeft, tRight, tRight - tLeft + 1 INTO @oldLeft, @oldRight, @oldStep FROM ', tblName, ' WHERE id = ', moveId, ';');
  PREPARE cmdOld FROM @oldStr;
  EXECUTE cmdOld;
  IF @oldLeft > 0 AND @oldRight > 0 AND @oldStep > 0 THEN
		-- 查询插入点的信息
		SET @pointStr = CONCAT('SELECT tLeft, tRight, pid, fullPath INTO @pointLeft, @pointRight, @pointPid, @pointPath FROM ', tblName, ' WHERE id = ', toId, ';');
		PREPARE cmdPoint FROM @pointStr;
		EXECUTE cmdPoint;

    -- 避免重复刷新
    IF (@oldLeft - @pointLeft <> 1) THEN
      -- 缓存受影响数据范围的ID集合
      SET @oldIdStr1 = CONCAT('UPDATE ', tblName, ' SET byid = 0;');
      SET @oldIdStr2 = CONCAT('UPDATE ', tblName, ' SET byid = -999 WHERE tLeft >= @oldLeft AND tRight <= @oldRight;');
      PREPARE cmdOldId1 FROM @oldIdStr1;
      PREPARE cmdOldId2 FROM @oldIdStr2;
      EXECUTE cmdOldId1;
      EXECUTE cmdOldId2;
      
      SET @oldPathStr = CONCAT('SELECT fullPath INTO @oldPath FROM ', tblName, ' WHERE id = (SELECT pid FROM ', tblName, ' WHERE id = ', moveId ,');');
      SET @newPathStr = CONCAT('SELECT fullPath INTO @newPath FROM ', tblName, ' WHERE id = ', toId, ';');
      PREPARE cmdOldPath FROM @oldPathStr;
      PREPARE cmdNewPath FROM @newPathStr;
      EXECUTE cmdOldPath;
      EXECUTE cmdNewPath;
      
      -- 从二叉链中卸载要移动的节点
      SET @dropStr = CONCAT('UPDATE ', tblName, ' SET tRight = tRight - @oldStep WHERE tRight > @oldRight;');
      PREPARE cmdDrop FROM @dropStr;
      EXECUTE cmdDrop;
      -- 预处理插入点及其以下的数据
      SET @preStrLeft = CONCAT('UPDATE ', tblName, ' SET tLeft = tLeft + @oldStep WHERE (tLeft > @pointRight OR (tLeft > @pointLeft AND tRight <= @pointRight)) AND byid = 0;');
      SET @preStrRight = CONCAT('UPDATE ', tblName, ' SET tRight = tRight + @oldStep WHERE (tRight >= @pointRight OR (tLeft > @pointLeft AND tRight <= @pointRight)) AND byid = 0;');
      PREPARE cmdPreLeft FROM @preStrLeft;
      PREPARE cmdPreRight FROM @preStrRight;
      EXECUTE cmdPreLeft;
      EXECUTE cmdPreRight;
      -- 移动预期数据到指定的二叉链上
      SET @moveStr = CONCAT('UPDATE ', tblName, ' SET fullPath = REPLACE(fullPath, @oldPath, @newPath), tLeft = @pointLeft + (tLeft - @oldLeft + 1), tRight = (@pointLeft + (tLeft - @oldLeft + 1))+ (tRight - tLeft) WHERE byid = -999;');
      PREPARE cmdMove FROM @moveStr;
      EXECUTE cmdMove;

      SET @pidStr = CONCAT('UPDATE ', tblName, ' SET pid = @pointPid WHERE id = ', moveId, ';');
      PREPARE cmdPid FROM @pidStr;
      EXECUTE cmdPid;

      SET @clearStr = CONCAT('UPDATE ', tblName, ' SET byid = 0;');
      PREPARE cmdClear FROM @clearStr;
      EXECUTE cmdClear;
    END IF;
  END IF;
  
  END`

module.exports = [bTreeAdd, bTreeDelPhysic, bTreeDel, bTreeMove];
