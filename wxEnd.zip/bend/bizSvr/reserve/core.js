let tEnumRight = require('tframe-enum').sys.seed;
let Tright = require('tframe-rights');

// 获取已定义的业务权限种子的SQL指令
const getSeedStr = `SELECT \`code\`, \`seedBizCode\` AS seedCode, \`seedBizTitle\` AS seedTitle, \`bizApproCount\` FROM \`_sysMenu\` WHERE \`bizApproCount\` > 0 AND \`seedBizCode\` IS NOT NULL AND \`seedBizCode\` <> '' AND  \`seedBizTitle\` IS NOT NULL AND \`seedBizTitle\` <> '';`;

// 获取全局组织数据
let getOrgStr = `SELECT id, pid, code, namezh, organtypeid, chargemanid, memo, orderIndex, tLeft, tRight From __sysOrgs WHERE stopped = 0 AND deleted = 0 ORDER BY pid, orderIndex DESC;`

class Tcore {
  constructor() {}
  async getRights() {
    let bizArr = await global.dbObj.dbExec(getSeedStr);
    let _bizObj = {};
    for (let v of bizArr) {
      let _subObj = {};
      let _keys = v.seedCode.split(',');
      let _vals = v.seedTitle.split(',');
      _keys.forEach((v, k, arr) => {
        _subObj[v] = _vals[k];
      });
      _bizObj[v.code] = {
        handler: new Tright(_subObj),
        maxStep: v.bizApproCount
      };
    };
    return {
      $crud: new Tright(tEnumRight.crud),
      $extend: new Tright(tEnumRight.crud),
      ..._bizObj
    }
  };
  async getOrgs() {
    let _orgs = {};
    let _orgList = await global.dbObj.dbExec(getOrgStr);
    for (let v of _orgList) {
      _orgs[v.id] = v;
    }
    return _orgs;
  }
}

module.exports = Tcore;
