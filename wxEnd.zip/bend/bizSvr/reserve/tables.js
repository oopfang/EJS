/* ========================================*/
/*             预置系统表集合                */
/*=========================================*/

// 内置字典表（数字型键值）
let sysDictInt = `CREATE TABLE IF NOT EXISTS \`__dictInt\` (
  \`id\` bigint(20) NOT NULL COMMENT '字典ID',
  \`key\` bigint(20) NOT NULL COMMENT '字典key',
  \`title\` varchar(20) DEFAULT NULL COMMENT '字典Title',
  \`group\` varchar(20) NOT NULL COMMENT '字典归类',
  \`memo\` text COMMENT '字典描述',
  \`geometric\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '键类型，0：流水序列，1：等比序列',
  PRIMARY KEY (\`id\`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '内置字典表_数字型键值';`;

// 内置字典表（字符型键值）
let sysDictStr = `CREATE TABLE IF NOT EXISTS \`__dictStr\` (
  \`id\` bigint(20) NOT NULL COMMENT '字典ID',
  \`key\` varchar(100) NOT NULL COMMENT '字典key',
  \`title\` varchar(20) DEFAULT NULL COMMENT '字典Title',
  \`group\` varchar(20) NOT NULL COMMENT '字典归类',
  \`memo\` text COMMENT '字典描述',
  \`geometric\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '键类型，0：流水序列，1：等比序列',
  PRIMARY KEY (\`id\`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '内置字典表_字符型键值';`;

// 渠道列表
let sysChannel = `CREATE TABLE IF NOT EXISTS \`__sysChannel\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '渠道ID',
  \`pid\` bigint(20) DEFAULT NULL COMMENT '上级渠道ID',
  \`code\` varchar(20) NOT NULL COMMENT '渠道代码',
  \`namezh\` varchar(20) DEFAULT NULL COMMENT '渠道名称',
  \`chargemanid\` bigint(20) DEFAULT '1' COMMENT '负责人ID',
  \`memo\` text COMMENT '备注',
  \`stopped\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '禁用标识',
  \`deleted\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '伪删除标记',
  \`createby\` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '行记录创建的时间戳',
  \`changeby\` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '行记录修改的时间戳',
  \`byid\` bigint(20) NOT NULL DEFAULT '0' COMMENT 'hybrid模式同步标志',
  \`tLeft\` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'btreeLeft',
  \`tRight\` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'btreeRight',
  \`fullPath\` varchar(200) DEFAULT '' COMMENT '树节点的完整显示路径',
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET=utf8mb4 COMMENT='渠道列表';`;

// 角色组
let roleGroup = `CREATE TABLE IF NOT EXISTS \`_roleGroup\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色组ID',
  \`code\` varchar(20) NOT NULL COMMENT '角色组代码',
  \`namezh\` varchar(20) DEFAULT NULL COMMENT '角色组名称',
  \`memo\` text COMMENT '备注',
  \`stopped\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '已停用',
  \`deleted\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '已删除',
  \`createby\` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间戳',
  \`changeby\` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改的时间戳',
  PRIMARY KEY (\`id\`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COMMENT = '角色组';`;

  // 角色组菜单
let roleGroupMenu = `CREATE TABLE IF NOT EXISTS \`_roleGroupMenu\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  \`pid\` bigint(20) DEFAULT '-1' COMMENT '角色组ID',
  \`menuId\` bigint(20) DEFAULT '-1' COMMENT '菜单ID',
  \`crudVal\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '该角色的CRUD授权值',
  \`extendVal\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '该角色的Extend授权值',
  \`bizVal\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '该角色的Biz授权值',
  \`disFieldRange\` varchar(100) DEFAULT '' COMMENT '该角色的屏蔽字段序列',
  \`stopped\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '停用标记',
  \`deleted\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  PRIMARY KEY (\`id\`),
  UNIQUE KEY \`index_menu\` (\`pid\`,\`menuId\`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COMMENT = '角色菜单授权表';`;

  // 系统菜单表
let sysMenu = `CREATE TABLE IF NOT EXISTS \`_sysMenu\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  \`pid\` bigint(20) NOT NULL DEFAULT '-1' COMMENT '父级ID',
  \`code\` varchar(20) NOT NULL COMMENT '菜单代码',
  \`name\` varchar(20) DEFAULT NULL COMMENT '英文名称',
  \`namezh\` varchar(20) DEFAULT NULL COMMENT '中文名称',
  \`ico\` varchar(20) DEFAULT 'h-icon-menu' COMMENT '图标',
  \`url\` varchar(40) NOT NULL DEFAULT '/home' COMMENT '导航地址',
  \`level\` int(11) NOT NULL DEFAULT '1' COMMENT '菜单级别',
  \`hasSub\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否含有子集',
  \`maxStep\` int(4) DEFAULT '1' COMMENT '最大审批索引（从0开始）',
  \`seedBizCode\` varchar(100) DEFAULT '' COMMENT '业务审核权限种子代码',
  \`seedBizTitle\` varchar(100) DEFAULT '' COMMENT '业务审核权限种子名称',
  \`bizApproCount\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '业务审核总级次',
  \`nodeRoles\` varchar(100) DEFAULT '' COMMENT '各节点角色ID集合',
  \`nodeTypes\` varchar(100) DEFAULT '' COMMENT '各节点审批类型',
  \`nodeUsers\` varchar(300) DEFAULT '' COMMENT '各节点审批用户ID集合',
  \`nodeConditions\` varchar(3000) DEFAULT '' COMMENT '各节点审批条件',
  \`memo\` text COMMENT '备注',
  \`stopped\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '停用标记',
  \`deleted\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  \`orderIndex\` int(11) NOT NULL DEFAULT '-1' COMMENT '记录排序标识',
  PRIMARY KEY (\`id\`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COMMENT = '系统菜单表，\r\n由于前端组件的原因，在v8.0中，导航地址并非 /url字段，而是code，\r\n在后续版本中，会启用 url字段';`;

// 组织机构树
let sysOrg = `CREATE TABLE IF NOT EXISTS \`__sysOrgs\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  \`pid\` bigint(20) NOT NULL DEFAULT '1' COMMENT '上级机构ID',
  \`code\` varchar(20) NOT NULL COMMENT '机构代码',
  \`namezh\` varchar(20) NOT NULL COMMENT '机构名称',
  \`organtypeid\` bigint(20) NOT NULL DEFAULT '3' COMMENT '机构类型ID',
  \`chargemanid\` bigint(20) DEFAULT NULL COMMENT '负责人ID',
  \`memo\` text COMMENT '备注',
  \`stopped\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '禁用标识',
  \`deleted\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '已注销标记',
  \`createby\` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '行记录创建的时间戳',
  \`changeby\` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '行记录修改的时间戳',
  \`byid\` bigint(20) NOT NULL DEFAULT '0' COMMENT 'hybrid模式同步标志',
  \`orderIndex\` int(11) NOT NULL DEFAULT '0' COMMENT '组织节点顺序',
  \`tLeft\` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'btreeLeft',
  \`tRight\` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'btreeRight',
  \`fullPath\` varchar(200) DEFAULT '' COMMENT '树节点的完整显示路径',
  PRIMARY KEY (\`id\`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COMMENT = '组织机构表';`;

// 机构类型
let sysOrgType = `CREATE TABLE IF NOT EXISTS \`__sysOrgType\` (
  \`id\` bigint(20) NOT NULL COMMENT '类型ID',
  \`code\` varchar(20) NOT NULL COMMENT '类型key',
  \`namezh\` varchar(20) DEFAULT NULL COMMENT '类型名称',
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机构类型表';`;

// 系统用户表
let sysUser = `CREATE TABLE IF NOT EXISTS \`_sysUser\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  \`pid\` bigint(20) NOT NULL DEFAULT '1' COMMENT '汇报对象ID',
  \`jobNo\` varchar(20) NOT NULL DEFAULT '' COMMENT '工号',
  \`code\` varchar(20) NOT NULL COMMENT '登陆账号',
  \`name\` varchar(30) DEFAULT NULL COMMENT '英文名称',
  \`namezh\` varchar(20) DEFAULT NULL COMMENT '中文名称',
  \`gender\` tinyint(4) DEFAULT '1',
  \`phoneWork\` varchar(20) DEFAULT '' COMMENT '工作号码',
  \`phonePrivate\` varchar(11) DEFAULT '' COMMENT '私人手机号',
  \`email\` varchar(30) DEFAULT '' COMMENT '邮箱',
  \`avatar\` varchar(20) DEFAULT 'userHeader' COMMENT '用户头像(相对地址)',
  \`uPwd\` varchar(40) NOT NULL DEFAULT '40bd001563085fc35165329ea1ff5c5ecbdbbeef' COMMENT '用户密码(初始：smpoo_2018)',
  \`staffDate\` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '入职日期',
  \`outDate\` datetime DEFAULT NULL COMMENT '离职日期',
  \`roleId\` varchar(100) DEFAULT '3' COMMENT '所属角色ID',
  \`accType\` tinyint(4) DEFAULT '1' COMMENT '账号类型(1：雇员账号, 2：外部账号)',
  \`signup\` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  \`lastsignin\` datetime DEFAULT '1900-01-01 00:00:00' COMMENT '上次登陆时间',
  \`lastsignout\` datetime DEFAULT '1900-01-01 00:00:00' COMMENT '上次登出时间',
  \`lastip\` varchar(46) DEFAULT NULL COMMENT '最后一次登入IP',
  \`approReturnAsk\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否允许审批退货申请',
  \`approRecive\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否允许收货操作',
  \`approCheck\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否允许检验操作',
  \`approSend\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否允许出库操作',
  \`memo\` text COMMENT '备注',
  \`suspened\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '停职标识',
  \`stopped\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '业务停用标记',
  \`deleted\` tinyint(4) NOT NULL DEFAULT '0' COMMENT '离职标记',
  \`createby\` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '行记录创建的时间戳',
  \`changeby\` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '行记录修改的时间戳',
  \`tLeft\` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'btreeLeft',
  \`tRight\` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'btreeRight',
  PRIMARY KEY (\`id\`),
  UNIQUE KEY \`index_code\` (\`code\`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

DROP TRIGGER IF EXISTS delRelation;
CREATE TRIGGER \`delRelation\` AFTER DELETE ON \`_sysUser\` FOR EACH ROW BEGIN
DELETE FROM \`_sysUserOrgan\` WHERE pid = OLD.id;
DELETE FROM \`_sysUserChannel\` WHERE pid = OLD.id;
END;`;

// 用户渠道映射表
let sysUserChannel = `CREATE TABLE IF NOT EXISTS \`_sysUserChannel\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`pid\` bigint(20) NOT NULL COMMENT '所属用户ID',
  \`cid\` bigint(20) NOT NULL DEFAULT '1' COMMENT '所属渠道ID',
  PRIMARY KEY (\`id\`),
  UNIQUE KEY \`onlyIndex\` (\`pid\`,\`cid\`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;`;

// 用户组织映射表
let sysUserOrg = `CREATE TABLE IF NOT EXISTS \`_sysUserOrgan\` (
  \`id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`pid\` bigint(20) NOT NULL COMMENT '所属用户ID',
  \`oid\` bigint(20) NOT NULL DEFAULT '1' COMMENT '所属组织ID',
  PRIMARY KEY (\`id\`),
  UNIQUE KEY \`onlyIndex\` (\`pid\`,\`oid\`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;`

module.exports = `${sysChannel}
${sysDictInt}
${sysDictStr}
${roleGroup}
${roleGroupMenu}
${sysMenu}
${sysOrg}
${sysOrgType}
${sysUser}
${sysUserChannel}
${sysUserOrg}`;
