/*
**** 预置指令集
*/

module.exports = {};
