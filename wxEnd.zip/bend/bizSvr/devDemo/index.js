let tGlb = require('tframe-globalext');
const UudCode = require('../utility/getUud');
tGlb();
let Tdate = globalThis.smpoo.Tdate;

let _arr = [{
  fromCustId: 12,
  prodId: 33,
  spec: 33,
  size: '4',
  dateCheck: '2020-06-23',
  opteratorId: 15,
  state: 1
}, {
  fromCustId: 13,
  prodId: 34,
  spec: 34,
  size: '5',
  dateCheck: '2020-06-23',
  opteratorId: 16,
  state: 2
}, {
  fromCustId: 14,
  prodId: 35,
  spec: 35,
  size: '6',
  dateCheck: '2020-06-23',
  opteratorId: 17,
  state: 3
}, {
  fromCustId: 15,
  prodId: 36,
  spec: 36,
  size: '7',
  dateCheck: '2020-06-23',
  opteratorId: 18,
  state: 4
}, {
  fromCustId: 16,
  prodId: 37,
  spec: 37,
  size: '8',
  dateCheck: '2020-06-23',
  opteratorId: 19,
  state: 5
}, {
  fromCustId: 17,
  prodId: 38,
}, {
  fromCustId: 14,
  prodId: 35,
  spec: 35,
  size: '6',
  dateCheck: '2020-06-23',
  opteratorId: 17,
  state: 3
}, {
  fromCustId: 15,
  prodId: 36,
  spec: 36,
  size: '7',
  dateCheck: '2020-06-23',
  opteratorId: 18,
  state: 4
}, {
  fromCustId: 16,
  prodId: 37,
  spec: 37,
  size: '8',
  dateCheck: '2020-06-23',
  opteratorId: 19,
  state: 5
}, {
  fromCustId: 17,
  prodId: 38,
  spec: 38,
  size: '9',
  dateCheck: '2020-06-23',
  opteratorId: 20,
  state: 6
}, {
  fromCustId: 18,
  prodId: 39,
}, {
  fromCustId: 15,
  prodId: 36,
  spec: 36,
  size: '7',
  dateCheck: '2020-06-23',
  opteratorId: 18,
  state: 4
}, {
  fromCustId: 16,
  prodId: 37,
  spec: 37,
  size: '8',
  dateCheck: '2020-06-23',
  opteratorId: 19,
  state: 5
}, {
  fromCustId: 17,
  prodId: 38,
  spec: 38,
  size: '9',
  dateCheck: '2020-06-23',
  opteratorId: 20,
  state: 6
}, {
  fromCustId: 18,
  prodId: 39,
  spec: 39,
  size: '10',
  dateCheck: '2020-06-23',
  opteratorId: 21,
  state: 7
}, {
  fromCustId: 19,
  prodId: 40,
}, {
  fromCustId: 16,
  prodId: 37,
  spec: 37,
  size: '8',
  dateCheck: '2020-06-23',
  opteratorId: 19,
  state: 5
}, {
  fromCustId: 17,
  prodId: 38,
  spec: 38,
  size: '9',
  dateCheck: '2020-06-23',
  opteratorId: 20,
  state: 6
}, {
  fromCustId: 18,
  prodId: 39,
  spec: 39,
  size: '10',
  dateCheck: '2020-06-23',
  opteratorId: 21,
  state: 7
}, {
  fromCustId: 19,
  prodId: 40,
  spec: 40,
  size: '11',
  dateCheck: '2020-06-23',
  opteratorId: 22,
  state: 8
}, {
  fromCustId: 20,
  prodId: 41,
}, {
  fromCustId: 17,
  prodId: 38,
  spec: 38,
  size: '9',
  dateCheck: '2020-06-23',
  opteratorId: 20,
  state: 6
}, {
  fromCustId: 18,
  prodId: 39,
  spec: 39,
  size: '10',
  dateCheck: '2020-06-23',
  opteratorId: 21,
  state: 7
}, {
  fromCustId: 19,
  prodId: 40,
  spec: 40,
  size: '11',
  dateCheck: '2020-06-23',
  opteratorId: 22,
  state: 8
}, {
  fromCustId: 20,
  prodId: 41,
  spec: 41,
  size: '12',
  dateCheck: '2020-06-23',
  opteratorId: 23,
  state: 9
}, {
  fromCustId: 21,
  prodId: 42,
}, {
  fromCustId: 18,
  prodId: 39,
  spec: 39,
  size: '10',
  dateCheck: '2020-06-23',
  opteratorId: 21,
  state: 7
}, {
  fromCustId: 19,
  prodId: 40,
  spec: 40,
  size: '11',
  dateCheck: '2020-06-23',
  opteratorId: 22,
  state: 8
}, {
  fromCustId: 20,
  prodId: 41,
  spec: 41,
  size: '12',
  dateCheck: '2020-06-23',
  opteratorId: 23,
  state: 9
}, {
  fromCustId: 21,
  prodId: 42,
  spec: 42,
  size: '13',
  dateCheck: '2020-06-23',
  opteratorId: 24,
  state: 10
}, {
  fromCustId: 22,
  prodId: 43,
}, {
  fromCustId: 19,
  prodId: 40,
  spec: 40,
  size: '11',
  dateCheck: '2020-06-23',
  opteratorId: 22,
  state: 8
}, {
  fromCustId: 20,
  prodId: 41,
  spec: 41,
  size: '12',
  dateCheck: '2020-06-23',
  opteratorId: 23,
  state: 9
}, {
  fromCustId: 21,
  prodId: 42,
  spec: 42,
  size: '13',
  dateCheck: '2020-06-23',
  opteratorId: 24,
  state: 10
}];

let _strList = [];
const STR_PRE = `INSERT INTO \`inventory\` (\`code\`, \`prodId\`, \`spec\`, \`size\`, \`quantity\`, \`uuCodePub\`, \`uuCodePrive\`, \`memo\`)`;
let _codes = Tdate.getCode(_arr.length);

let _str_after = [];
for (let v of _arr) {
  if (v.dateCheck) {
    let _dt = (v.dateCheck || '').split(' ');
    v.dateCheck = _dt[0];
    let _uuc = UudCode.getUud(v);
    let {
      pubKey,
      prvKey
    } = UudCode.encodeUud(_uuc);
    _str_after.push(`('${_codes.pop()}', '${v.prodId}', '${v.spec}', '${v.size}', 1, '${pubKey}', '${prvKey}', '初始化入库')`);
  }
}

module.exports = `${STR_PRE} VALUES ${_str_after.join(',')};`;
