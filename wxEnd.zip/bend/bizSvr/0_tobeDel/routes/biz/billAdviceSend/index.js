let tErr = require('tframe-prebend').preError;
let _execer = require('../../../utility/execer');
let reqMgr = require('../../../utility/reqMgr');
let dayjs = require('dayjs');
	
let objFunc = async (req, res, next) => {
	try {
		let _id = req.query[0].by.id;
		let _str1 = `SELECT * FROM billAdviceSend WHERE id = ${_id} AND stopped = 0 AND deleted = 0;`;
		let _str2 = `SELECT * FROM billAdviceSendDetail WHERE pid = ${_id} AND stopped = 0 AND deleted = 0;`;
		let _resAll = await _execer(`${_str1}${_str2}`);
		res.apiOk([_resAll[0][0], _resAll[1]]);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let listFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.query);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403)
	}
};
	
let postFunc = async (req, res, next) => {
	try {
		let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
		let _obj1 = req.body.data[0];
		let _getObj2 = (pid) => {
			return req.body.$after.map((v, k) => {
				let _subObj = v.data[0];
				return `INSERT INTO billAdviceSendDetail(pid, code, prodId, spec, size, unit, quantity, quantityLeft, picAddr) 
				VALUES('${pid}', '${_initCode + k}', ${_subObj.prodId}, '${_subObj.spec}', 
				'${_subObj.size}', '${_subObj.unit}', '${_subObj.quantity}', '${_subObj.quantity}', '${_subObj.picAddr || ''}');`;
			}).join('');
		};
		let _str1 = `INSERT INTO billAdviceSend(code, dateDelivery, fromBillTypeId, fromBillNo, custId, operator, deliveryType, memo) 
		VALUES('${_initCode}', '${_obj1.dateDelivery}', '${_obj1.fromBillTypeId}', '${_obj1.fromBillNo}', '${_obj1.custId}', '${_obj1.operator}', '${_obj1.deliveryType}', '${_obj1.memo}');`;
		_resAll = await _execer(_str1);
		let _newId = _resAll.insertId;
		let _str2 = _getObj2(_newId);
		await _execer(_str2);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let putFunc = async (req, res, next) => {
	try {
		let _resAll = await reqMgr(req.body);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
let delFunc = async (req, res, next) => {
	try {
		let _id = req.query.id;
		let _str = `DELETE FROM billPickUp WHERE id = ${_id};`;
		let _resAll = await _execer(_str);
		res.apiOk(_resAll);
	} catch (err) {
		res.apiErr(err, 403);
	}
};
	
module.exports = {
	objFunc,
	listFunc,
	postFunc,
	putFunc,
	delFunc
};
