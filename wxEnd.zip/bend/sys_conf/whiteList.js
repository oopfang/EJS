module.exports = [
  "http://localhost",
  "http://localhost:8080"
];
