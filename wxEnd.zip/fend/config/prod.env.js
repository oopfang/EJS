'use strict'
module.exports = {
  // NODE_ENV: '"production"'
  NODE_ENV: '"development"'
}
