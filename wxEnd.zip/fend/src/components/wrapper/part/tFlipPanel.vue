<template>
<div class="flipWrapper" :style="getHeight" :class="{ active: flipItem || hoverItem }" @mouseenter.prevent.stop="getHover" @mouseleave.prevent.stop="outHover">
  <div class="flipCard" :style="getFlipStyle">
    <div class="flipFront" :style="getPanelStyleF">
      <slot></slot>
    </div>
    <div class="flipBack" :style="getPanelStyleB">
      <slot name="bend"></slot>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'flipPanel',
  props: {
    // 翻转切换因子
    flipItem: {
      type: Boolean,
      defalt: false
    },
    // 指定高度
    setHeight: {
      type: Number,
      default: 150
    },
    // 前端面板背景色
    bgColorF: {
      type: String,
      defalut: '#fff'
    },
    // 后端面板背景色
    bgColorB: {
      type: String,
      defalut: '#fff'
    },
    // 是否允许Hover翻转
    allowHoverFlip: {
      type: Boolean,
      defalut: false
    },
    // 是否显示阴影
    withShadow: {
      type: Boolean,
      default: true
    }
  },
  data: function () {
    return {
      hoverItem: false
    };
  },
  computed: {
    getHeight: function() {
      return {
        height: `${this.setHeight}px`,
        'box-shadow': this.withShadow ? 'rgba(112, 136, 112, 0.5) 0px 6px 20px' : 'none'
      };
    },
    getPanelStyleF: function() {
      return {
        height: `${this.setHeight}px`,
        'background-color': this.bgColorF
      };
    },
    getPanelStyleB: function() {
      return {
        height: `${this.setHeight}px`,
        'background-color': this.bgColorB
      };
    },
    getFlipStyle: function() {
      return {
        'transform-origin': `100% ${this.setHeight / 2}px`
      };
    }
  },
  methods: {
    getHover: function () {
      if (this.allowHoverFlip) {
        this.hoverItem = true;
			}
      this.$emit('flipHover');
    },
    outHover: function () {
      if (this.allowHoverFlip) {
        this.hoverItem = false;
      }
      this.$emit('flipOut');
    }
  }
};
</script>