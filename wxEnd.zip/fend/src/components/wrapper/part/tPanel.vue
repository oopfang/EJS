<template>
<div class="panelWrapper" :style="panelStlye" :class="hoverClass" @mouseover="isHover=true" @mouseout="isHover=false">
  <div class="panelHeader" :style="getHeader">
    <slot name="panelHeader"></slot>
  </div>
  <div class="panelBody" :style="{ display: hideBody ? 'none' : 'block', padding: compactBody ? '0' : '8px 0' }">
    <slot></slot>
  </div>
</div>
</template>

<script>
export default {
  name: '',
  props: {
    // 是否以flex=1方式布局
    asFlex1: {
      type: Boolean,
      default: false
    },
    // 是否显示标题栏
    showHeader: {
      type: Boolean,
      defalut: false
    },
    // 最大高度
    maxH: {
      type: Number,
      default: 0
    },
    // 最小高度
    minH: {
      type: Number,
      default: -1
    },
    // margin-top值
    topSpace: {
      type: Number,
      default: 0
    },
    // margin-left值
    leftSpace: {
      type: Number,
      default: 0
    },
    // 背景色
    bgColor: {
      type: String,
      default: 'transparent'
    },
    // 是否阴影显示
    hasShadow: {
      type: Boolean,
      default: false
    },
    // 是否采用悬浮阴影样式
    hoverShadow: {
      type: Boolean,
      default: false
    },
    hideBody: {
      type: Boolean,
      default: false
    },
    // 紧凑的body样式
    compactBody: {
      type: Boolean,
      default: false
    }
  },
  data: function() {
    return {
      isHover: false
    };
  },
  computed: {
    panelStlye: function () {
      let x = {
        'margin-top': `${this.topSpace}px`,
        'background-color': this.bgColor,
        padding: this.compactBody ? '0' : '0 16px'
      };
      if (this.leftSpace) {
        x['margin-left'] = this.leftSpace ? `${this.leftSpace}px` : '0';
      }
      if (this.asFlex1) {
        x.flex = 1;
      } else {
        x['min-height'] = this.minH === -1 ? '0' : `${this.minH}px`;
        if (this.maxH > 0) {
          x['max-height'] = `${this.maxH}px`;
        }
      }
      return x;
    },
    getHeader: function () {
      return {
        display: this.showHeader ? 'block' : 'none'
      };
    },
    hoverClass: function() {
      let x = {};
      if (this.hoverShadow) {
        if (this.hasShadow) {
          x['shadowStyle'] = !this.isHover;
        } else {
          x['shadowStyle'] = this.isHover;
        }
      } else {
        x['shadowStyle'] = this.hasShadow;
      }
      return x;
    }
  }
};
</script>

<style lang="less" scoped>
.panelWrapper {
  position: relative;
  width: 100%;
  border: .5px solid rgba(99, 100, 146, .5);
  border-radius: 0;

  .panelHeader {
    height: 42px;
    line-height: 42px;
    border-bottom: 1px solid #eee;
    font-size: 12px;
  }

  .panelHeader:first-child>div {
    display: flex;
    height: 42px;
    flex-direction: row;
    -webkit-align-items: center;
    -moz-align-items: center;
    -o-align-items: center;
    -ms-align-items: center;
    align-items: center;
    -webkit-justify-content: flex-start;
    -moz-justify-content: flex-start;
    -o-justify-content: flex-start;
    -ms-justify-content: flex-start;
    justify-content: flex-start;
  }

  .panelBody {
    padding: 8px 0;
  }
}
.shadowStyle {
  box-shadow: rgba(112, 136, 112, 0.5) 0px 6px 20px;
}
</style>
