<template>
<div class="maskBox" :style="getBoxStyle">
  <slot></slot>
  <div v-if="!isSmall" class="maskWrapper" :style="getMaskStyle">
    <div class="maskBtnRow">
      <slot name="maskBtn"></slot>
    </div>
  </div>
  <div v-else class="smallMaskWp" :style="getMaskStyle">
    <div class="maskBtnRow">
      <slot name="maskBtn"></slot>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'flipPanel',
  props: {
    // 是否采用小面板
    // 默认面板高度为 150px，小尺寸为 54px
    isSmall: {
      type: Boolean,
      default: false
    },
    // 面板背景色
    bgColor: {
      type: String,
      defalut: '#fff'
    },
    // 是否显示阴影
    withShadow: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    // 根据尺寸类型属性，获取面板高度
    getHeight: function() {
      return this.isSmall ? `${54}px` : `${150}px`;
    },
    getBoxStyle: function () {
      return {
        height: this.getHeight,
        'line-height': this.getHeight,
        'box-shadow': this.withShadow ? 'rgba(112, 136, 112, 0.5) 0px 6px 20px' : 'none',
        'background-color': this.bgColor
      };
    },
    getMaskStyle: function () {
      return {
        height: this.getHeight,
        'line-height': this.getHeight
      };
    }
  }
};
</script>