<template>
	<div class="panelWrapper" :style="preStyle">
      <div class="btnZone colLeft">
        <span :class="{ halfBtn: inEdit && allowDel, fullBtn: !inEdit || !allowDel }">{{ idNum }}</span>
        <span v-if="allowDel" v-show="inEdit" class="halfBtn" @click="$emit('removeItem', idNum)">
          <tIcon icon="h-icon-trash" :size="4" color="#fff"></tIcon>
        </span>
      </div>
      <div class="slotZone">
        <slot></slot>
      </div>
      <div v-show="allowSort" class="btnZone colRight">
        <span v-show="idNum > 0" :class="{ singleBtn: isLast, halfBtn: !isLast }" @click="$emit('setItemUp', idNum)">
          <tIcon icon="t-cheveron-up" :size="4" color="#fff"></tIcon>
        </span>
        <span v-show="!isLast" :class="{ singleBtn: (idNum === 0), halfBtn: (idNum > 0) }" @click="$emit('setItemDown', idNum)">
          <tIcon icon="t-cheveron-down" :size="4" color="#fff"></tIcon>
        </span>
      </div>
	</div>
</template>

<script>
import tIcon from '../../widge/tIcon';

export default {
  name: '',
  props: {
    // 所在数据集的位置索引
    idNum: {
      type: Number,
      default: 0
    },
    // 允许执行行删除
    allowDel: {
      type: Boolean,
      default: true
    },
    // 允许上下调整行位置
    allowSort: {
      type: Boolean,
      default: true
    },
    // 是否处于列表集合的最后一项
    isLast: {
      type: Boolean,
      default: false
    },
    // 最小高度
    minH: {
      type: Number,
      default: -1
    },
    // 页面编辑状态
    inEdit: {
      type: Boolean,
      default: true
    },
    // margin-top值
    topSpace: {
      type: Number,
      default: 18
    }
  },
  components: {
    tIcon
  },
  computed: {
    preStyle: function() {
      return {
        'min-height': this.minH === -1 ? '0' : `${this.minH}px`,
        'margin-top': `${this.topSpace}px`
      };
    }
  }
};
</script>

<style lang="less" scoped>
.panelWrapper {
  display: flex;
  flex-direction: row;
  width: 100%;
  padding: 0;
  margin: 2px 0 !important;
  border: 1px solid #6a679e;
  border-radius: 0;
  // box-shadow: rgba(112, 136, 112, 0.5) 0px 6px 20px;
  transition: all .2s ease-in-out;
  background-color: #fff;
  .btnZone {
    display: flex;
    width: 32px;
    min-height: 80px;
    flex-direction: column;
    cursor: pointer;
    span {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      color: #fff;
    }
    .singleBtn {
      min-height: 100%;
    }
    .halfBtn {
      min-height: 50%;
    }

    .fullBtn {
      min-height: 100%;
    }
  }
  .colLeft {
    span:first-child {
      background-color: #85AE7B;
    }
    span:last-child {
      background-color: #131138;
    }
    span:hover:last-child {
      background-color: #000;
    }
  }
  .colRight {
    span:first-child {
      background-color: #131138;
    }
    span:last-child {
      background-color: #85AE7B;
    }
    span:hover {
      background-color: #000;
    }
  }
  .slotZone {
    width: 100%;
    padding: 8px;
  }
}
.panelWrapper:hover {
  background-color: #EAEAEE;
}
</style>
