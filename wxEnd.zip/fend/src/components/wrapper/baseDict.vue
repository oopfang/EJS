<template>
<tBase :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
  <Row class="dictOptZone">
    <div class="h-input-group filterRow">
      <input type="text" style="border-radius: 150px; padding-left: 16px;" v-model="filterWord" placeholder="输入即查找" @keydown.prevent.13.stop="addAfterFilter" />
      <span class="h-input-addon addBtn" :class="{ btnInEdit: inEdit, btnNotInEdit: !inEdit }" v-show="!inEdit && filterWord" @click="addByBtn">新增</span>
    </div>
    <div class="flexSplit"></div><span style="min-height: 42px;">&nbsp;</span>
    <btnCrud :disableAdd="true" :disableDoc="disableDoc" :options="{ hiddenAdd: true, hiddenEdit: true, hiddenDel: true }" :inEdit="inEdit" :allowEditOption="!inEdit" :selectCount="getEditState" :allowDel="false" :allowCopy="false" :dataIsNull="getDataIsNull" @btnEditEvent="doEditByBtn" @btnDelEvent="doDel" @btnSaveEvent="doSave" @btnCancelEvent="doCancel"></btnCrud>
  </Row>

  <Row :space="18">
    <Col :width="inEdit ? 14 : 24">
      <tPanel>
        <Table ref="dictTbl" id="printPart" v-if="getColHeader.length > 0" :datas="getList" border
          :height="tblHeight" @select="onRowSelect" @trdblclick="doEditByBtn" :selectWhenClickTr="!inEdit" checkbox stripe>
          <TableItem v-for="item of define.tblHeader" :key="item.prop" :title="item.title" :prop="item.prop" :width="item.width || 100"></TableItem>
          <TableItem :width="50">
            <template slot-scope="{data}">
            <ButtonGroup size="s" v-show="!inEdit">
              <Button icon="h-icon-edit" @click.prevent.stop="doEditByBtn(data)"></Button>
              <Button icon="h-icon-trash" color="gray" @click.prevent.stop="doDelByBtn(data)"></Button>
            </ButtonGroup>
            </template>
          </TableItem>
          <div slot="empty" class="emptyZone">暂时无数据</div>
        </Table>
        <div v-show="currList.length > 0" class="tblFooter">
          <span v-if="filterWord">筛选后{{ filterCount }}  行</span>
          <div class="flexSplit"></div>
          <span v-show="currSelectCount > 0" class="bg-dark-color white-color">已选：{{ currSelectCount }}  行</span>
          <span v-show="currSelectCount > 0 && !inEdit" class="reverseBtn" @click.prevent.stop="reverseSelect">反选</span>
          <span v-for="(item, index) in footerCustom" :key="index">{{ item }}</span>
          <span>共计：{{ currList.length }}  行</span>
        </div>
      </tPanel>
    </Col>
    <Col v-if="inEdit" :width="10" :style="{ 'max-height': `${this.$parent.$el.parentElement.clientHeight - 50}px`, 'overflow-y': 'auto' }">
      <slot></slot>
    </Col>
  </Row>
</tBase>
</template>

<script>
import tBase from './base.vue';
import tPanel from './part/tPanel.vue';
import btnCrud from '../widge/bizCtrls/groupCrud';
// import btnGeneral from '../widge/bizCtrls/groupGeneral';
import tString from 'tframe-string/preString';
import dayjs from 'dayjs';
import enumObj from 'tframe-enum';

export default {
  name: 'baseDict',
  props: {
    define: {
      type: Object,
      default: function () {
        return {};
      }
    },
    // 是否处于加载中
    inLoading: {
      type: Boolean,
      default: false
    },
    currList: {
      type: Array,
      default: function () {
        return [];
      }
    },
    // 自定义的页脚文字
    footerCustom: {
      type: Array,
      default: function () {
        return [];
      }
    },
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    disableDoc: {
      type: Boolean,
      default: false
    }
  },
  components: {
    tBase,
    tPanel,
    // btnGeneral,
    btnCrud
  },
  data: function () {
    return {
      // 表格高度
      tblHeight: 400,
      // 当前已选择的行数目
      currSelectCount: 0,
      // 当前已选择的行的ID集合
      currSelectIds: [],
      // 当前输入的筛选字符
      filterWord: '',
      // 符合筛选的行数目
      filterCount: 0,
      // 是否处于编辑状态
      inEdit: false,
      // 视图中修改过的ID集合
      changeIds: [],
      // 精简视图的表头
      shortHeader: [
        { title: 'ID', prop: 'id' },
        { title: '名称', prop: 'namezh' }
      ]
    };
  },
  computed: {
    // 判断数据集是否为空
    getDataIsNull: function () {
      return this.currList.length === 0;
    },
    // 控制编辑按钮的显示逻辑
    // 如果定义中存在自定义，则不允许多编辑，否则允许
    getEditState: function () {
      if (this.define.subs) {
        return this.currSelectIds.length === 1;
      } else {
        return this.currSelectIds.length > 0 ? 1 : 0;
      }
    },
    editPanelStyle: function () {
      return {
        width: '100%',
        height: `${this.tblHeight + 40}px`,
        'overflow-x': 'hidden',
        'overflow-y': 'auto'
      };
    },
    getList: function () {
      if (this.filterWord) {
        let _arr = this.currList.filter(row => {
          return Object.keys(row).some(key => {
            return String(row[key]).includes(this.filterWord);
          });
        });
        this.filterCount = _arr.length;
        return _arr;
      } else {
        this.filterCount = 0;
        return this.currList;
      }
    },
    getColHeader() {
      if (this.define && this.define.tblHeader) {
        let _arr = this.define.tblHeader;
        return _arr;
      } else {
        return [];
      }
    }
  },
  methods: {
    // 控制表格高度
    reSizeWorkZone: function () {
      let _that = this;
      this.$nextTick(function () {
        // 尺寸计算规则：工作空间高度 - 页标题栏高度(50) - 面板标题栏高度(42) - 面板padding(上下各8 * 2) - 校准误差(20) - 表格预留footer高度(40)
        this.tblHeight =
          _that.$parent.$el.parentElement.clientHeight - 50 - 42 - 16 - 20 - 40;
      });
    },
    // 响应编辑请求
    doEditByBtn: function (item) {
      let _idx = this.getList.findIndex(v => {
        return v.code === item.code;
      });
      if (_idx > -1) {
        this.currSelectIds = this.getList[_idx].id;
        this.inEdit = true;
        this.$emit('itemEdit', [this.currSelectIds]);
      }
    },
    doSave: function () {
      let _that = this;
      let _ckbFunc = idVal => {
        if (_that.currSelectIds) {
          if (Array.isArray(_that.currSelectIds)) {
            return _that.currSelectIds.includes(idVal);
          } else {
            return _that.currSelectIds === idVal;
          }
        } else {
          return false;
        }
        // return (_that.currSelectIds || []).includes(idVal);
      }
      let x = {
        $act: enumObj.crud.act.add,
        bizIdent: this.define.intro.code,
        data: global.preReqData(this.currList.filter(v => {
          return _ckbFunc(v.id);
        }))
      };
      this.$store.dispatch(`post${this.define.intro.name}Obj`, x)
        .then(res => {
          _that.$emit('eventSaveOk');
          _that.currSelectIds = [];
          _that.$refs.dictTbl.clearSelection();
          _that.currSelectCount = 0;
          _that.inEdit = false;
          _that.filterWord = '';
        })
        .catch(err => {
          global.terr(err);
        });
    },
    doCancel: function () {
      if (this.currSelectIds.length === 1 && this.currSelectIds[0] < -1) {
        let _idx = this.currList.findIndex(v => {
          return v.id === this.currSelectIds[0];
        });
        if (_idx > -1) {
          this.currList.splice(_idx, 1);
        }
      }
      this.inEdit = false;
      this.currSelectIds = [];
      this.$refs.dictTbl.clearSelection();
      this.filterWord = '';
    },
    // 响应删除请求
    doDel: function () {
      let _idx = [];
      let ids = this.currSelectIds;
      for (let v of ids) {
        _idx.push(this.currList.findIndex(vi => {
          return vi.id === v;
        }));
      }
      _idx.sort((a, b) => {
        return a - b;
      });
      let x = {
        $act: enumObj.crud.act.del,
        bizIdent: this.define.intro.code,
        by: {
          id: ids
        }
      };
      this.$store.dispatch(`del${this.define.intro.name}Multi`, x)
        .then(res => {
          while (_idx.length > 0) {
            this.currList.splice(_idx.pop(), 1);
          }
          this.currSelectIds = [];
          this.$refs.dictTbl.clearSelection();
          this.currSelectCount = 0;
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 响应删除请求
    doDelByBtn: function (item) {
      let _idx = this.currList.findIndex(v => v.id === item.id);
      if (_idx > -1) {
        let x = {
          $act: enumObj.crud.act.del,
          bizIdent: this.define.intro.code,
          by: {
            id: item.id
          }
        };
        this.$store.dispatch(`del${this.define.intro.name}Multi`, x)
          .then(res => {
            this.currList.splice(_idx, 1);
            this.currSelectIds = [];
            this.$refs.dictTbl.clearSelection();
            this.currSelectCount = 0;
          })
          .catch(err => {
            global.terr(err);
          });
      }
    },
    onRowSelect: function (dt) {
      if (!this.inEdit) {
        this.currSelectCount = dt.length;
        this.currSelectIds = [];
        dt.forEach((v, k, arr) => {
          this.currSelectIds.push(v.id);
        });
        if (this.currSelectIds.length === 0) {
          this.inEdit = false;
        }
      }
    },
    // 反选
    reverseSelect: function () {
      let _ids = [];
      let _arr = this.currList.filter((v, k, arr) => {
        let b = !this.currSelectIds.includes(v.id);
        if (b) {
          _ids.push(v.id);
        }
        return b;
      });
      this.$refs.dictTbl.setSelection(_arr);
      this.currSelectIds = _ids;
    },
    // 从筛选框中执行新增
    addAfterFilter: function (e) {
      if (e.ctrlKey) {
        let _str = e.target.value;
        let _canAdd = false;
        let _strVaili = tString.infoOfStr(_str);
        _canAdd = (_strVaili !== enumObj.sys.aboutStr.special) && (_strVaili !== enumObj.sys.aboutStr.enOnly) && (_strVaili !== enumObj.sys.aboutStr.numOnly) && (_strVaili !== enumObj.sys.aboutStr.enOrNum);
        let _notExist = true;
        for (let v of this.currList) {
          if (v.namezh === _str) {
            _notExist = false;
            break;
          }
        }
        if (_notExist && _canAdd) {
          this.currSelectCount = 0;
          let _obj = this.define.emptyVal();
          _obj.id = (this.currList.length + 2) * -1;
          // _obj.code = tString.cn2Py(_str, true);
          _obj.code = dayjs().format('YYYYMMDDHHmmsss');
          _obj.name = tString.upFirst(_obj.code);
          _obj.namezh = e.target.value;
          this.currList.push(_obj);
          this.currSelectIds = [_obj.id];
          this.doEditByBtn(this.currSelectIds.length - 1);
        }
      }
    },
    // 从筛选框中执行新增
    addByBtn: function () {
        let _str = this.filterWord;
        let _canAdd = false;
        let _strVaili = tString.infoOfStr(_str);
        _canAdd = (_strVaili !== enumObj.sys.aboutStr.special) && (_strVaili !== enumObj.sys.aboutStr.enOnly) && (_strVaili !== enumObj.sys.aboutStr.numOnly) && (_strVaili !== enumObj.sys.aboutStr.enOrNum);
        let _notExist = true;
        for (let v of this.currList) {
          if (v.namezh === _str) {
            _notExist = false;
            break;
          }
        }
        if (_notExist && _canAdd) {
          this.currSelectCount = 0;
          let _obj = this.define.emptyVal();
          _obj.id = (this.currList.length + 2) * -1;
          // _obj.code = tString.cn2Py(_str, true);
          _obj.code = dayjs().format('YYYYMMDDHHmmsss');
          _obj.name = tString.upFirst(_obj.code);
          _obj.namezh = _str;
          this.currList.push(_obj);
          this.currSelectIds = [_obj.id];
          this.doEditByBtn(this.currSelectIds.length - 1);
          this.inEdit = true;
          this.$emit('itemEdit', _obj.id);
        }
    }
  },
  mounted() {
    let x = this.reSizeWorkZone;
    x();
    window.onresize = function () {
      x();
    };
  },
  destroyed() {
    this.currSelectIds = [];
  }
};
</script>

<style lang="less" scoped>
#printPart {
  min-height: 80vh;
}

.dictOptZone {
  display: flex;
  flex-direction: row; // justify-content: center;
  align-items: center;

  // align-items: center;
  .filterRow {
    width: 30%;
    // margin-bottom: 8px;

    input {
      width: 100%;
    }

    .addBtn {
      position: relative;
      height: 26px;
      line-height: 26px;
      padding: 0 18px;
      margin-top: 2px;
      border-radius: 150px;
      background-color: #D4C29E;
      transition:all 0.5s ease;
      cursor: pointer;
      z-index: 999;

      &:hover {
        background-color: #E2BB6D;
      }
    }

    .btnNotInEdit {
      position: relative;
      margin-left: -68px;
    }

    .btnInEdit {
      position: absolute;
      top: 0;
      left: 4px;
    }
  }

  .h-btn-group {
    margin: 2px 0;
  }
}

.emptyZone {
  height: 70vh;
  line-height: 70vh;
  padding-top: 45px;
  font-size: 12px;
  background: #fff url('/static/img//nodata.jpg') center center no-repeat;
}

.tblFooter {
  display: flex;
  width: 100%;
  height: 40px;
  flex-direction: row;
  -webkit-align-items: center;
  -moz-align-items: center;
  -o-align-items: center;
  -ms-align-items: center;
  align-items: center;
  padding-right: 16px;
  font-size: 0.8rem;
  font-weight: 100;
  text-align: right;

  span {
    padding: 0 8px;
    margin-left: 18px;
    border-radius: 2px;
  }

  .reverseBtn {
    color: #fff;
    background-color: gray;
    cursor: pointer;
  }

  .reverseBtn:hover {
    color: #000;
    background-color: orange;
  }
}
</style>
