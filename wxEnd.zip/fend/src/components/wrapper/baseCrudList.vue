<template>
<tBase :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
  <tPanel showHeader>
    <div slot="panelHeader">
      <btnCrud :allowEditOption="true" :selectCount="currSelectCount" :options="crudDef" :dataIsNull="dataIsNull" @btnAddEvent="doAdd" @btnEditEvent="doEdit" @btnDelEvent="doDel"></btnCrud>
      <div class="flexSplit"></div>
      <!-- <btnGeneral @needFilter="showFilterPanle=true" allowFilter @onImport="doImport" @onExport="doExport" @onPrint="doPrint">
        <span>帮助文档</span>
      </btnGeneral> -->
      <span style="margin-right: 18px;">单据总数： {{ getList.length }}&nbsp;&nbsp;/&nbsp;&nbsp;已完成数：{{ endCount }}</span>
      <span>帮助文档</span>
    </div>
    <div class="filterZone" :style="inShownStyle">
      <span @click.prevent.stop="showFilterPanle=false"><tIcon icon="h-icon-close" :size="4" :height="28"></tIcon></span>
      name：<input type="text" v-model="filterObj.name"/>
      <div class="flexSplit"></div>
      <div class="filterBtn" @click.prevent.stop="execFilter">查找<tIcon icon="t-search" :size="4"></tIcon></div>
    </div>
    <Table ref="billTbl" id="printPart" :columns="define.tblHeader" :datas="getList" :height="tblHeight" @select="onRowSelect" @trclick="onTrClick" @trdblclick="onTrDbClick" selectWhenClickTr checkbox stripe>
      <div slot="empty" class="emptyZone">暂时无数据</div>
    </Table>
    <div class="tblFooter">
      <div class="h-input h-input-prefix-icon" style="width: 260px;">
        <input type="text" v-model="getFilterWord" placeholder="输入即筛选..." style="background-color: transparent;" />
        <i class="h-icon-search"></i>
      </div>
      <span>共计：{{ currListCount }}  行</span>
      <span v-show="filterWord">筛选后{{ filterCount }}  行</span>
      <div class="flexSplit"></div>
      <span v-show="currSelectCount > 0" class="bg-dark-color white-color">已选：{{ currSelectCount }}  行</span>
      <span v-show="currSelectCount > 0" class="reverseBtn" @click.prevent.stop="reverseSelect">反选</span>
      <span v-for="(item, index) in footerCustom" :key="index">{{ item }}</span>
    </div>
  </tPanel>
</tBase>
</template>

<script>
import tBase from './base.vue';
import tPanel from './part/tPanel.vue';
import btnCrud from '../widge/bizCtrls/groupCrud';
import btnGeneral from '../widge/bizCtrls/groupGeneral';
import tIcon from '../widge/tIcon';
// import excel2json from '@/tModules/excel/excel2json';
// import json2excel from '@/tModules/excel/json2excel';
let excel2json = () => import(/* webpackChunkName:'excel' */'@/tModules/excel/excel2json');
let json2excel = () => import(/* webpackChunkName:'excel' */'@/tModules/excel/json2excel');

export default {
  name: 'baseCrudList',
  props: {
    // 业务定义
    define: {
      type: Object,
      default: function () {
        return {};
      }
    },
    // 增删查改按钮定义
    crudDef: {
      type: Object,
      default() {
        return {};
      }
    },
    // 单据完成数
    endCount: {
      type: Number,
      default: 0
    },
    // 是否处于加载中
    inLoading: {
      type: Boolean,
      default: false
    },
    // 自定义的页脚文字
    footerCustom: {
      type: Array,
      default: function () {
        return [];
      }
    },
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  components: {
    tBase,
    tPanel,
    btnCrud,
    btnGeneral,
    tIcon
  },
  data: function () {
    return {
      // 表格高度
      tblHeight: 400,
      // 当前已选择的行数目
      currSelectCount: 0,
      // 当前已选择的行的ID集合
      currSelectIds: [],
      // 当前输入的筛选字符
      filterWord: '',
      // 符合筛选的行数目
      filterCount: 0,
      // 当前列表数据源
      currList: [],
      // 当前列表数据源的行数
      currListCount: 0,
      // 显示查找面板
      showFilterPanle: false,
      // 多维筛选对象
      filterObj: {
        name: ''
      },
      needReFooter: false
    };
  },
  computed: {
    dataIsNull: function () {
      return this.currSelectIds.length === 0;
    },
    getFilterWord: {
      get() {
        return this.filterWord;
      },
      set(val) {
        this.needReFooter = true;
        this.filterWord = val;
      }
    },
    getList: function () {
      if (this.define && this.define.intro) {
        let _list = this.$store.getters[`get${this.define.intro.name}List`];
        if (!_list) return [];
        this.currList = _list;
        this.currListCount = this.currList.length;
        if (this.filterWord) {
          let _arr = this.currList.filter(row => {
            return Object.keys(row).some(key => {
              if (key !== '$unSave') {
                return String(row[key]).includes(this.filterWord);
              } else {
                return false;
              }
            });
          });
          this.filterCount = _arr.length;
          if (this.needReFooter) {
            this.$emit('eventFilter', _arr);
            this.needReFooter = false;
          }
          return _arr;
        } else {
          this.filterCount = 0;
          if (this.needReFooter) {
            this.$emit('eventFilter', this.currList);
            this.needReFooter = false;
          }
          return this.currList;
        }
      } else {
        return [];
      }
    },
    inShownStyle: function () {
      if (this.showFilterPanle) {
        return {
          top: 0
        };
      } else {
        return {
          top: '-240px'
        };
      }
    }
  },
  methods: {
    // 控制表格高度
    reSizeWorkZone: function () {
      let hFunc = () => {
        this.tblHeight = this.$parent.$el.parentElement.clientHeight - 50 - 42 - 16 - 20 - 40;
      };
      this.$nextTick(function () {
        // 尺寸计算规则：工作空间高度 - 页标题栏高度(50) - 面板标题栏高度(42) - 面板padding(上下各8 * 2) - 校准误差(20) - 表格预留footer高度(40)
        // _that.tblHeight =
        //   _that.$parent.$el.parentElement.clientHeight - 50 - 42 - 16 - 20 - 40;
        hFunc();
      });
    },
    // 列表行选择处理
    onRowSelect: function (dt) {
      this.currSelectIds = [];
      this.currSelectCount = dt.length;
      dt.forEach((v, k, arr) => {
        this.currSelectIds.push(v.id);
      });
    },
    // 列表行点击响应
    onTrClick: function (dt) {},
    // 列表行双击响应
    onTrDbClick: function(dt) {
      this.$router.push({
        name: `${this.define.intro.code}View`,
        params: {
          id: dt.id,
          inEdit: false
        }
      });
    },
    // 列表反选
    reverseSelect: function () {
      let _ids = [];
      let _arr = this.currList.filter((v, k, arr) => {
        let b = !this.currSelectIds.includes(v.id);
        if (b) {
          _ids.push(v.id);
        }
        return b;
      });
      this.$refs.billTbl.setSelection(_arr);
      this.currSelectIds = _ids;
    },
    // 页面新增操作响应
    doAdd: function() {
      this.$router.push({
        name: `${this.define.intro.code}Add`,
        params: {
          inEdit: true
        }
      });
    },
    // 页面编辑操作响应
    doEdit: function() {
      this.$router.push({
        name: `${this.define.intro.code}Edit`,
        params: {
          id: this.currSelectIds[0],
          inEdit: true
        }
      });
    },
    // 页面删除操作响应
    doDel: function () {
      let x = {
        $act: 'del',
        bizIdent: this.define.intro.code,
        by: {
          id: this.currSelectIds
        }
      };
      this.$store.dispatch(`del${this.define.intro.name}Multi`, x)
        .then(res => {
          global.tinfo(`已成功删除${res}行`);
          this.currSelectIds = [];
          this.inLoading = false;
        })
        .catch(err => {
          this.inLoading = false;
          global.terr(err, '删除失败');
        });
    },
    // 通过回调将导入的数据写入缓存
    importHandle: function (v) {
      if (v.successed) {
        v.jsonData.forEach(vm => {
          vm.$unSave = {};
          this.currList.push(vm);
        });
      } else {
        this.$Message.error('导入失败');
      }
    },
    // Excel 导入操作响应
    doImport: function (e) {
      excel2json(e.target.files, this.importHandle);
    },
    // Excel 导出操作响应
    doExport: function () {
      let header = Object.keys(this.currList);
      let _tStamp = new Date()
        .toLocaleString()
        .replace(new RegExp('/', 'g'), '_')
        .replace(new RegExp(':', 'g'), '_')
        .replace(new RegExp(' .*', 'g'), '');
      json2excel(`${this.define.intro.namezh}_${_tStamp}`, `export-${_tStamp}`, header, this.currList);
    },
    // 打印按钮响应
    doPrint: function () {
      let options = {
        name: '_blank',
        specs: [
          'fullscreen=yes',
          'titlebar=yes',
          'scrollbars=yes'
        ],
        styles: ['http://localhost:2019/css/print.css?v=8.0',
          'https://cdn.jsdelivr.net/npm/heyui/themes/index.css',
          'http://pi0g7yzoo.bkt.clouddn.com/ticon.8.0.min.css?v=8.0'
        ]
      };
      this.$htmlToPaper('printPart', options);
    },
    // 执行多维查找
    execFilter: function () {
      let _by = {};
      for (let v of Object.keys(this.filterObj)) {
        let _vOjb = this.filterObj[v];
        if (typeof _vOjb !== 'boolean') {
          if (_vOjb) {
            _by[v] = _vOjb;
          }
        } else {
          _by[v] = _vOjb;
        }
      }
      this.$emit('eventFind', _by);
      this.showFilterPanle = false;
    }
  },
  mounted() {
    let x = this.reSizeWorkZone;
    this.needReFooter = true;
    x();
    window.onresize = function () {
      x();
    };
  },
  beforeDestroy() {
    if (this.define && this.define.intro) {
      this.$store.commit(`set${this.define.intro.name}List`, []);
    }
  }
};
</script>

<style lang="less" scoped>
#printPart {
  min-height: 80vh;
}

.emptyZone {
  height: 70vh;
  line-height: 70vh;
  padding-top: 45px;
  font-size: 12px;
  background: #fff url('/static/img//nodata.jpg') center center no-repeat;
}

.tblFooter {
  display: flex;
  width: 100%;
  height: 40px;
  flex-direction: row;
  -webkit-align-items: center;
  -moz-align-items: center;
  -o-align-items: center;
  -ms-align-items: center;
  align-items: center;
  padding-right: 16px;
  font-size: 0.8rem;
  font-weight: 100;
  text-align: right;

  span {
    padding: 0 8px;
    margin-left: 18px;
    border-radius: 2px;
  }

  .reverseBtn {
    color: #fff;
    background-color: gray;
    cursor: pointer;
  }

  .reverseBtn:hover {
    color: #000;
    background-color: orange;
  }
}

.filterZone {
  position: absolute;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  width: 100%;
  min-height: 128px;
  padding: 18px;
  left: 0;
  z-index: 60;
  font-weight: 700;
  color: #fff;
  background-color: rgba(144, 151, 194, 0.95);
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .14), 0 3px 1px -2px rgba(0, 0, 0, .2), 0 1px 5px 0 rgba(0, 0, 0, .12);
  transition: all .5s ease-out;
  -webkit-animation-name: fadeInDown;
  animation-name: fadeInDown;

  span {
    position: absolute;
    width: 28px;
    top: 0;
    right: 0;
    text-align: center;
    background-color: #8D140D;
    cursor: pointer;
  }

  span:hover {
    color: red;
  }

  .filterBtn {
    height: 100%;
    padding: 18px;
    padding: 18px;
    cursor: pointer;
    border: 1px #888 dotted;
  }

  .filterBtn:hover {
    background-color: #3F51B5;
  }

}

@-webkit-keyframes fadeInDown {
  0% {
    opacity: 0;
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0)
  }

  to {
    opacity: 1;
    -webkit-transform: none;
    transform: none
  }
}

@keyframes fadeInDown {
  0% {
    opacity: 0;
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0)
  }

  to {
    opacity: 1;
    -webkit-transform: none;
    transform: none
  }
}

// .fadeInDown {
//   -webkit-animation-name: fadeInDown;
//   animation-name: fadeInDown
// }
</style>
