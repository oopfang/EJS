<template>
<tBase :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
  <tPanel showHeader>
    <div slot="panelHeader">
      <btnCrud :allowEditOption="!isvoid" allowDel :dataIsNull="showEditEtc"  :selectCount="1"
		      @btnAddEvent="addHandler"
		      @btnEditEvent="editHandler"
		      @btnDelEvent="delHandler"
		      @btnCopyEvent="$emit('copyEvent')">
			</btnCrud>
      <!-- <btnApprove v-show="!isvoid" @btnDisuseEvent="voidHandler"></btnApprove> -->
      <div class="flexSplit"></div>
      <btnGeneral v-show="!isvoid"></btnGeneral>
    </div>
    <span v-show="isvoid" class="voidStr">已作废</span>
    <Tabs style="rightTabs" :datas="billTabs" v-model="selected" @click="tabClick"></Tabs>
      <slot></slot>
  </tPanel>
  <div v-if="hasSubDefine">
    <Row v-show="selected === 'tab1'" class="formZone">
      <slot name="subView"></slot>
    </Row>
  </div>
  <pdf v-if="selected === 'tab2'" :src="define.intro.guidUrl" @page-loaded="pdfLoaded"></pdf>
</tBase>
</template>

<script>
import tBase from './base.vue';
import tPanel from './part/tPanel.vue';
import btnCrud from '../widge/bizCtrls/groupCrud';
// import btnGeneral from '../widge/bizCtrls/groupGeneral';
import btnApprove from '../widge/bizCtrls/groupApprove';
import pdf from 'vue-pdf';
import { mapActions } from 'vuex';

export default {
  name: 'baseCrudView',
  props: {
    // 窗体定义
    define: {
      type: Object,
      default: function() {
        return {};
      }
    },
    // 当前视图对应的业务ID
    currId: {
      type: Number,
      default: -1
    },
    // 是否处于加载中
    inLoading: {
      type: Boolean,
      default: false
    },
    // 是否处于作废状态
    isvoid: {
      type: Number,
      default: 0
    },
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  components: {
    tBase,
    tPanel,
    btnCrud,
    btnGeneral,
    // btnApprove,
    pdf
  },
  data: function() {
    return {
      billTabs: {
        tab1: '业务数据',
        tab2: '帮助'
      },
      selected: 'tab1',
      // 面板间的 marging-top值
      topSpace: 16,
      // 记录是否已经加载过PDF文件
      pdfOk: false
    };
  },
  computed: {
    // crud按钮状态置入
    showEditEtc: function() {
      return !this.currId > 0 && (this.selected === 'tab1') && !this.isvoid;
    },
    // 判断是否存在定义子集
    hasSubDefine: function() {
      return this.define && this.define.subs && Object.keys(this.define.subs).length > 0;
    }
  },
  methods: {
    ...mapActions(['voidShouhuodanObj', 'voidObj']),
    tabClick: function(e) {
      if (this.define.intro.guidUrl) {
        let _isPdf = e.key === 'tab2';
        this.$emit('onPdf', _isPdf);
        if (_isPdf && !this.pdfOk) {
          global.tloading('载入中...');
        }
      } else {
        this.$Message('本页面没有提供PDF文档');
        this.selected = 'tab1';
      }
    },
    pdfLoaded: function() {
      this.pdfOk = true;
      global.tloading();
    },
    // 新增按钮点击响应
    addHandler: function() {
      this.$router.push({
        name: `${this.define.intro.code}Add`
      });
    },
    // 编辑按钮点击响应
    editHandler: function() {
      this.$router.push({
        name: `${this.define.intro.code}Edit`,
        params: {
          id: this.currId
        }
      });
    },
    // 作废按钮点击响应
    voidHandler: function() {
      // let x = {
      //   $act: 'update',
      //   bizIdent: this.define.intro.code,
      //   data: {
      //     stopped: 1
      //   },
      //   by: {
      //     id: this.currId
      //   }
      // };
      let x = {
        bizIdent: this.define.intro.code,
        id: this.currId
      };
      this.voidObj(x)
        .then(res => {
          global.tinfo(res);
          this.$emit('eventVoid');
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 删除按钮点击响应
    delHandler: function() {
      let x = {
        $act: 'del',
        bizIdent: this.define.intro.code,
        by: {
          id: this.currId
        }
      };
      this.$store.dispatch(`del${this.define.intro.name}Multi`, x)
        .then(res => {
          global.tinfo('删除成功！');
          this.$router.push({
            name: this.define.intro.code
          });
        })
        .catch(err => {
          global.terr(err);
        });
    }
  }
};
</script>

<style scoped>
.h-tabs-default {
  border-bottom: none !important;
  text-align: right;
}
</style>
