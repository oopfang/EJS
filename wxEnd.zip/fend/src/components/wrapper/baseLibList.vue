<template>
<tBase :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
  <div class="libPage">
    <div v-if="getLayerDef.showHeader" class="panelStyle">
      <div v-if="getLayerDef.useFilter" class="libHeader">
        <slot name="headerCell"></slot>
        <span class="flexSplit"></span>
        <slot name="headerCellCenter"></slot>
        <span class="flexSplit"></span>
        <div class="h-input h-input-prefix-icon filterCell">
          <input type="text" class="iptFilter" v-model="filterWord" placeholder="输入即查找..." @input="getFilterDelay" @compositionstart="iptStart" @compositionend="iptEnd" />
          <i class="h-icon-search"></i>
        </div>
      </div>
      <template v-else class="libHeader">
        <slot name="headerCell"></slot>
      </template>
    </div>
    <div class="panel2 panelStyle">
      <div class="panelBody">
        <span v-if="getLayerDef.allowRowAdd.show" class="addBtn" @click="setClick(eventName.onItemAdd, {}, -1)">{{ getLayerDef.allowRowAdd.title }}</span>
        <div v-if="dataList">
          <ul class="listContent">
            <li class="listItemDefault" v-for="(item, index) of getList" :key="item.id">
              <p class="listItemTitleDefault">{{ item[getLayerDef.titleField] }}</p>
              <div class="listItemDetail">
                <div class="itemInfoCell">
                  <div :class="{ txtCell: itemCell.fullWidth }" :style="{ 'text-align': itemCell.align, width: itemCell.fullWidth ? '100px' : itemCell.width, ellipsis: !(getLayerDef.fullWidthInCol) }" v-for="itemCell of getLayerDef.tblHeader" :key="itemCell.key">
                    <Progress v-if="itemCell.viewType === 'progress'" :percent="item[itemCell.prop]"></Progress>
                    <img v-else-if="itemCell.viewType === 'img'" :src="itemCell.viewTypeParam ? `${itemCell.viewTypeParam}/${item[itemCell.prop]}` : item[itemCell.prop]" alt="">
                    <span v-else-if="itemCell.viewType === 'tag'" class="h-tag" :class="itemCell.viewTypeParam">{{ item[itemCell.prop] }}</span>
                    <span v-else>{{ item[itemCell.prop] }}</span>
                  </div>
                </div>
                <div class="btnCell" :style="getBtnGroupStyl">
                  <span class="btnItem" v-for="itemBtn of getLayerDef.buttons" :key="itemBtn.key" @click="setClick(itemBtn.key, item, index)">{{ itemBtn.title }}</span>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <template v-else>
          <slot></slot>
        </template>
      </div>
      <div v-if="getLayerDef.showFooter" class="panel3">
        <slot name="footerCellLeft"></slot>
        <span class="flexSplit"></span>
        <slot name="footerCellCenter"></slot>
        <span class="flexSplit"></span>
        <div>
          <slot name="footerCellRight"></slot>
          <span style="padding-left: 18px;">数据统计截至： {{ endDate }}</span>
        </div>
      </div>
    </div>
  </div>
</tBase>
</template>

<script>
import tBase from './base.vue';
import dayjs from 'dayjs';
let currTimer = null;
// 列样式的工厂函数
let _creatCell = (idx, prop, viewType, viewTypeParam, align, width, widthUnit, fullWidth, allowClickEvent, disablIdx) => {
  let _getTagStyle = () => {
    if (viewType === 'tag') {
      let _styleObj = {};
      if (viewTypeParam === undefined) {
        _styleObj['h-tag-bg-primary'] = true;
      } else {
        _styleObj[`h-tag-bg-${viewTypeParam}`] = true;
      }
      return _styleObj;
    } else {
      return viewTypeParam;
    }
  };
  let _w = width ? `${width}${widthUnit || 'px'}` : '20%';
  return {
    // 自动生成
    key: idx,
    // 该列在dataList数据源中的属性名称
    prop: prop || '',
    // 该列的显示模式：进度条、图片、tag，如果为空字符，则为默认显示模式（文本）
    viewType: viewType || 'text',
    // 该列在各个显示模式下的显示参数(如果为tag，则参数指定颜色，如果为文本，则参数指定链接跳转地址)
    viewTypeParam: _getTagStyle(),
    // 该列数据的对齐样式
    align: align || 'center',
    // 该列的宽度
    width: _w,
    // 该列宽度是否采取flex: 1的模式，如果该属性为真，则会覆盖 width 属性，默认为 FALSE
    fullWidth,
    // 该列是否支持点击事件
    allowClickEvent,
    // 指明该列的按钮组（如果有的话）中某个需要被禁用的按钮在按钮组的索引
    disablIdx: disablIdx || []
  }
}
// 根据文本参数调用列表样式工厂函数的方法
let _creatCellByString = (idx, str) => {
  return _creatCell(idx, str);
};
// 根据对象参数调用样式工厂函数的方法
let _creatCellByObj = (idx, param) => {
  let {
    prop,
    viewType,
    viewTypeParam,
    align,
    width,
    widthUnit,
    fullWidth,
    allowClickEvent,
    disablIdx
  } = param;
  let propStr = prop || param.memo || param.namezh || param.title || param.name || param.code || '';
  return _creatCell(idx, propStr, viewType, viewTypeParam, align, width, widthUnit, fullWidth, allowClickEvent, disablIdx);
};
// 组件事件集合
let _event = {
  // 页眉筛选事件
  onFilter: 'onFilter',
  // 列表行点击事件
  onItemClick: 'onItemClick',
  // 列表新增事件
  onItemAdd: 'onItemAdd',
  // 列表项编辑事件
  onItemEdit: 'onItemEdit',
  // 列表项查看事件
  onItemView: 'onItemView',
  // 列表项单笔删除事件
  onItemDel: 'onItemDel',
  // 页面批量删除事件
  onMutiDel: 'onMutiDel'
};

export default {
  name: 'baseCrudList',
  props: {
    // 是否处于加载中
    inLoading: {
      type: Boolean,
      default: false
    },
    // 业务及布局定义
    bizDefine: {
      type: Object,
      default () {
        return {};
      }
    },
    dataList: {
      type: Array,
      default () {
        return null;
      }
    },
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  components: {
    tBase
  },
  data: function () {
    return {
      // 表格高度
      tblHeight: 400,
      // 当前已选择的行数目
      currSelectCount: 0,
      // 当前已选择的行的ID集合
      currSelectIds: [],
      // 筛选锁定
      filterLock: false,
      // 筛选关键词
      filterWord: '',
      // 符合筛选的行数目
      filterCount: 0,
      // 当前列表数据源
      currList: [],
      // 当前列表数据源的行数
      currListCount: 0,
      // 显示查找面板
      showFilterPanle: false,
      // 多维筛选对象
      filterObj: {
        name: ''
      },
      // 数据截止日期
      endDate: '',
      // 事件名称集合
      eventName: _event,
      // 按钮组定义集合
      buttons: [{
        key: _event.onItemView,
          title: '详情'
      }, {
        key: _event.onItemEdit,
        title: '修改'
      }, {
        key: _event.onItemDel,
        title: '删除'
      }]
    };
  },
  computed: {
    // 获取布局定义
    getLayerDef() {
      // showHeader：是否显示页面页眉行，默认为 TRUE
      // showFooter：是否显示页面页脚行，默认为 TRUE
      // useFilter：是否启用自带输入框的页眉筛选行样式，默认为 TRUE
      // titleField：显示到列表项的标题栏的字段名
      // allowRowAdd：是否在页内区域显示行级新增按钮，如果 dataList 没有配置，则自动禁用，默认为 TRUE
      // fullText：当列表项的各个单元格的文本超出行宽时，是否折行全部显示，还是保持单行，超出部分以省略号显示。TRUE表示折行，否则省略号显示，默认为 FALSE
      // cells：页内布局默认使用数组传参形成列表布局时，各个列表行内的子列的定义
      // buttons：页内布局默认使用数组传参形成列表布局时，各个列表行操作按钮的定义
      // useDefaultCrud：是否启用默认的CRUD按钮组，默认为TRUE
      // forceBtn：如果为真，则强制在每个列表行保留按钮/组的占位，否则所有行都是依据buttons数组的元素个数动态决定是否占位，此时如果元素数为0，则不占位，默认为 FALSE
      let { intro = {}, tblHeader = [] } = this.bizDefine;
      let { showHeader, showFooter, useFilter, titleField, allowRowAdd, fullWidthInCol, buttons, useDefaultCrud, forceBtn } = intro;
      let _sH = ((showHeader === undefined) && true) || showHeader;
      let _useDftBtn = ((useDefaultCrud === undefined) && true) || useDefaultCrud;
      let _userBtns = buttons || [];
      let _obj = {
        showHeader: _sH,
        showFooter: ((showFooter === undefined) && true) || showFooter,
        useFilter: (_sH && ((useFilter === undefined) && true) || useFilter) || false,
        titleField: titleField || '',
        allowRowAdd: {},
        fullWidthInCol,
        tblHeader: [],
        buttons: _useDftBtn ? this.buttons  : []
      };
      let _hasBtn = false;
      let i = 1;
      // 如果提供了列表数据源，则创建各行的列样式定义
      if (this.dataList && Array.isArray(this.dataList)) {
        if (tblHeader) {
          let _tp = (typeof tblHeader);
          if (Array.isArray(tblHeader)) {
            for (let v of tblHeader) {
              let _tpV = (typeof v);
              if (_tpV === 'object') {
                _obj.tblHeader.push(_creatCellByObj(i, v));
              } else if (_tpV === 'string') {
                _obj.tblHeader.push(_creatCellByString(i, v));
              }
              i++;
            }
          } else if (_tp === 'object') {
            _obj.tblHeader.push(_creatCellByObj(i, tblHeader));
          } else if (_tp === 'string') {
            _obj.tblHeader.push(_creatCellByString(i, tblHeader));
          }
          i = 1;
        }

        if (_userBtns && Array.isArray(_userBtns)) {
          let _keyCheckArr = _obj.buttons.map(vBtn => vBtn.key);
          for (let vBtnCurr of _userBtns) {
            if (vBtnCurr.key && vBtnCurr.title) {
              if (!_keyCheckArr.includes(vBtnCurr.key)) {
                _obj.buttons.push({
                  key: vBtnCurr.key,
                  title: vBtnCurr.title
                });
              } else {
                terr(new Error(`There is a duplicate key name for your custom button definition as ['${vBtnCurr.key}']. You can change it with other name or add parameter 'useDefaultCrud: false' in bizDefine.`))
              }
            }
          }
        }
        _obj.forceBtn = forceBtn;
      }

      if (this.dataList) {
        _obj.allowRowAdd = {
          show: true,
          title: (allowRowAdd || {}).title || '+ 添加',
          eventName: (allowRowAdd || {}).eventName || 'rowAdd'
        };
      }

      return _obj;
    },
    // 获取列表项中，按钮组宽度的样式
    getBtnGroupStyl() {
      let _arr = this.getLayerDef.buttons || [];
      return {
        width: `${(_arr.length * 44) + 16}px`,
        display: _arr.length ? 'flex' : 'none',
        'justify-content': _arr.length ? 'center' : ''
      }
    },
    getList() {
      if (!this.dataList) {
        return null;
      } else {
        let _word = this.filterWord;
        return this.dataList.filter(v => {
          return Object.values(v).join('').includes(_word);
        });
      }
    }
  },
  methods: {
    // 延时请求处理
    delayRequest(val, i) {
      return new Promise((resolve, reject) => {
        let _that = this;
        let j = 10;
        let _clear = () => {
          clearInterval(currTimer);
        };
        if (currTimer) {
          _clear();
        }
        currTimer = setInterval(() => {
          i++;
          if (i === j) {
            _clear();
            resolve(val);
          }
        }, 100);
      });
    },
    iptStart(e) {
      this.filterLock = true;
    },
    iptEnd(e) {
      this.filterLock = false;
    },
    // 延时过滤
    async getFilterDelay(e) {
      if (!this.filterLock) {
        let _str = '';
        if (e.data) {
          _str = await this.delayRequest(this.filterWord, 0);
        } else {
          _str = e.target.value;
        }
        this.filterWord = _str;
        if (!this.dataList) {
          this.$emit(_event.onFilter, _str);
        }
      }
    },
    // 响应列表项的按钮点击事件
    setClick(evtName, item, index) {
      this.$emit('btnClick', {
        evtName,
        item,
        index
      });
    }
  },
  mounted() {
    this.endDate = dayjs().format('YYYY 年 MM 月 DD 日');
  },
  beforeDestroy() {
    clearInterval(currTimer);
    currTimer = null;
  }
};
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';

.libPage {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  width: 100%;
  height: 90vh;

  .panelStyle {
    width: 100%;
    padding: 8px;
    background-color: #fff;

    .libHeader {
      display: flex;
      flex-direction: row;
      justify-content: flex-start;
      align-items: center;
      padding: 0;

      .filterCell {
        width: 260px;

        .iptFilter {
          border-radius: 30px;
        }
      }
    }
  }

  .panel2 {
    display: flex;
    flex-direction: column;
    flex: 1;
    width: 100%;
    height: 100%;
    margin-top: 8px;

    .panelBody {
      flex: 1;
      height: 100%;
      text-align: center;
      overflow-y: auto;

      .addBtn {
        display: inline-block;
        width: 200px;
        padding: 8px;
        margin-bottom: 8px;
        font-size: 14px;
        font-weight: 700;
        text-align: center;
        border-radius: 30px;
        border: 1px #ccc dashed;
        background-color: #FAF8F1;
        transition: all .25s ease-in-out;
        cursor: pointer;

        &:hover {
          width: 100%;
          border-radius: 0;
          border: 1px #D4C29E dashed;
          background-color: #D4C29E;
        }
      }

      .listContent {
        display: block;
        width: 100%;

        .listItemDefault {
          width: 100%;
          padding: 8px;
          border-bottom: 1px #ddd dashed;
          transition: background-color .1s ease-in;

          .listItemTitleDefault {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            padding-left: 8px;
            margin: 8px 0;
            font-size: 1rem;
            font-weight: 700;
            border-left: 5px @primary-color solid;

            // .titleTxt {
            //   flex: 1;
            // }
          }

          .listItemDetail {
            display: flex;
            justify-content: center;
            align-items: center;
            max-width: 100%;

            .itemInfoCell {
              flex: 1;
              display: flex;
              justify-content: flex-start;
              align-items: center;

              .txtCell {
                width: 500px;
                flex: 1;
              }
            }

            .btnCell {
              padding: 0;
              
              .btnItem {
                padding: 4px 8px;
                border-radius: 4px;
                cursor: pointer;
                

                &:hover {
                  background-color: @primary-color;
                }
              }
            }
          }

          .goalRow {
            padding-top: 18px;

            .goalLab {
              font-size: 14px;
              font-weight: 700;
              text-align: left;
            }

            .goalTxt {
              font-size: 10px;
              font-weight: 100;
            }
          }

          .deptRow {
            padding: 8px;
            margin-top: 8px;
            text-align: center;
            border-top: 1px #D8D4CB solid;
          }

          &:hover {
            background-color: #FAF8F1;
          }
        }
      }
    }

    .panel3 {
      position: relative;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      width: 100%;
      height: 32px;
      line-height: 32px;
      padding: 0 8px;
      bottom: 0;
      font-size: 12px;
      border-top: 1px #eee solid;
    }
  }
}
</style>
