<template>
<div class="animated workZone">
  <slot></slot>{{ getLoding }}
</div>
</template>

<script>
import {
  mapMutations,
  mapActions
} from 'vuex';

export default {
  name: 'basePanel',
  props: {
    // 是否处于加载中
    inLoading: {
      type: Boolean,
      default: false
    },
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  computed: {
    // 页面加载响应
    getLoding: function() {
      if (!this.inLoading) {
        global.tloading();
      } else {
        global.tloading('');
      }
    }
  },
  methods: {
    ...mapMutations(['setCurrFooterText']),
    ...mapActions(['queryDict', 'queryMasterAsDict'])
  },
  async mounted() {
    if (this.dictKeys.length) {
      let resDict = await this.queryDict({
        keys: this.dictKeys
      });
      if (resDict.$unSave) {
        delete resDict.$unSave;
      }
      let _keys = Object.keys(resDict);
      for (let v of _keys) {
        this.$set(this.$root.$data._dict, v, resDict[v]);
      }
    }
    if (this.masterKeys.length) {
      let resMaster = await this.queryMasterAsDict({
        keys: this.masterKeys
      });
      if (resMaster.$unSave) {
        delete resMaster.$unSave;
      }
      let _keys = Object.keys(resMaster);
      for (let v of _keys) {
        this.$set(this.$root.$data._dict, v, resMaster[v]);
      }
    }
  },
  destroyed() {
    this.setCurrFooterText();
  }
};
</script>

<style lang="less" scoped>
.workZone {
  width: 100%;
  flex: 1;
  padding: 0;
  border-radius: 4px;
  background-color: transparent;
}
</style>
