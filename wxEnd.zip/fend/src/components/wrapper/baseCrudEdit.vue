<template>
<tBase id="billPage" :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
  <tPanel showHeader bgColor="#F0F0F2">
    <div slot="panelHeader">
      <btnCrud v-if="!inEdit" :allowEditOption="!isvoid" :options="crudDef" :selectCount="1" @btnAddEvent="addHandler" @btnEditEvent="editHandler" @btnDelEvent="delHandler" @btnSendEvent="$emit('sendEvent')" @btnPickOver="$emit('pickOverEvent')" @btnSendNoticeEvent="$emit('sendNoticeEvent')">
      </btnCrud>
      <!-- <btnCrud v-else inEdit :allowEditOption="!isvoid" @btnSaveEvent="$emit('saveEvnt', $event)" @btnCancelEvent="cancelHandler"></btnCrud> -->
      <btnCrud v-else inEdit :disableDoc="disableDoc" :allowEditOption="!isvoid" @btnSaveEvent="saveBill" @btnCancelEvent="cancelHandler"></btnCrud>
      <btnApprove v-show="!inEdit" :approveDef="approveDef" @execEvent="execAppro" @btnDisuseEvent="voidHandler"></btnApprove>
      <div class="flexSplit"></div>
      <div class="stepBtnRow btnGroup">
        <btnGeneral v-show="!inEdit && !isvoid">
          <span class="btnItem">帮助文档</span>
        </btnGeneral>
      </div>
    </div>
    <span v-show="!inEdit && isvoid" class="voidStr">已作废</span>
    <Row>
      <slot></slot>
      <canvas v-show="showCanvas" id="homeWork" width="500" height="500"></canvas>
    </Row>
  </tPanel>

  <tPanel v-show="!hiddeDetail" class="subPanle" :class="{ editH: inEdit, disableH: !inEdit }" compactBody :topSpace="18">
    <slot name="subPanel"></slot>
  </tPanel>
  <!-- 添加明细按钮 -->
  <div v-show="!onImgSave && inEdit && !isvoid" class="addRow" @click.prevent.stop="addNewSub"></div>
</tBase>
</template>

<script>
import tBase from './base.vue';
import tPanel from './part/tPanel.vue';
import btnCrud from '../widge/bizCtrls/groupCrud';
import btnApprove from '../widge/bizCtrls/groupApprove';
import btnGeneral from '../widge/bizCtrls/groupGeneral';
import html2canvas from 'html2canvas';
import { mapGetters } from 'vuex';
import dayjs from 'dayjs';

export default {
  name: 'baseCrudEdit',
  components: {
    tBase,
    tPanel,
    btnCrud,
    btnApprove,
    btnGeneral
  },
  props: {
    baseDefine: {
      type: Array,
      default: function () {
        return [];
      }
    },
    // 当前的审批定义
    approveDef: {
      type: Object,
      default () {
        return {
          // 审批状态下的已审级次
          currStep: 0,
          // 流程是否已经开始
          flowStart: false,
          // 流程是否已经关闭
          flowEnd: true,
          // 本单是否已作废
          stopped: false,
          // 是否具有审批权限
          hasAccess: false,
          // 是否为创建者
          isCreator: false
        }
      }
    },
    // 增删查改按钮定义
    crudDef: {
      type: Object,
      default () {
        return {};
      }
    },
    // 当前视图对应的业务ID
    currId: {
      type: Number,
      default: -1
    },
    // 页面编辑状态
    inEdit: {
      type: Boolean,
      default: true
    },
    inLoading: {
      type: Boolean,
      default: false
    },
    // 是否处于作废状态
    isvoid: {
      type: Number,
      default: 0
    },
    // 明细数量
    hiddeDetail: {
      type: Boolean,
      default: false
    },
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default () {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default () {
        return [];
      }
    },
    disableDoc: {
      type: Boolean,
      default: false
    }
  },
  data: function () {
    return {
      showCanvas: false,
      onImgSave: false,
      currStep: 0,
      // 记录是否已经加载过PDF文件
      pdfOk: false
    };
  },
  computed: {
    ...mapGetters(['getUserInfo']),
    getBizNme() {
      let _obj = this.baseDefine;
      const _nm = '请自行命名';
      if (_obj) {
        if (Array.isArray(_obj)) {
          return _obj[0].namezh || _nm;
        } else {
          return _obj.namezh || _nm;
        }
      } else {
        return _nm;
      }
    }
  },
  methods: {
    // 切换子面板
    switchSub: function (idx) {
      this.$emit('switchSub', idx);
      this.currStep = idx;
    },
    // 子视图添加记录项的响应
    addNewSub: function () {
      this.$emit('addNewSub', this.currStep - 1);
    },
    // 点击取消按钮的操作响应
    cancelHandler: function () {
      this.$router.push({
        name: this.baseDefine[0].code
      });
    },
    // 新增按钮点击响应
    addHandler: function () {
      this.$emit('onAdd');
    },
    // 编辑按钮点击响应
    editHandler: function () {
      this.$emit('onEdit');
    },
    saveAsImg(bizNamezh) {
      return new Promise((resolve, reject) => {
        let oCard = document.getElementById("billPage");
        let oContainer = document.getElementById('homeWork');
        const imgType = 'jpg';        
        let fName = `[${bizNamezh || '请自行命名'}]：[ ${dayjs().format('YYYY年MM月DD日 HH时mm分ss秒')} ]- - 提交人：[ ${this.getUserInfo.namezh} ].${imgType}`;
        html2canvas(oCard)
          .then(res => {
            oContainer.appendChild(res);
            //延迟执行确保万无一失
            setTimeout(() => {
              let type = imgType;
              let oCanvas = oContainer.getElementsByTagName("canvas")[0];
              // canvas转换为图片
              let imgData = oCanvas.toDataURL(type);
              // 加工image data，替换mime type，方便以后唤起浏览器下载
              let r = (type.toLowerCase().replace(/jpg/i, 'jpeg')).match(/png|jpeg|bmp|gif/)[0];
              let _currType = 'image/' + r;
              imgData = imgData.replace(_currType, 'image/octet-stream');
              let aLink = document.createElement('a');
              aLink.style.display = 'none';
              aLink.href = imgData;
              aLink.download = fName;
              // 触发点击-然后移除
              document.body.appendChild(aLink);
              aLink.click();
              document.body.removeChild(aLink);
              resolve();
            }, 0);
          })
          .catch(err => {
            reject(err);
          })
      });
    },
    hidenBtn() {
      let _that = this;
      return new Promise((resolve, reject) => {
        _that.onImgSave = true;
        setTimeout(() => {
          resolve();
        }, 500);
      });
    },
    // 保存按钮
    async saveBill(e) {
      try {
        await this.hidenBtn();
        await this.saveAsImg(this.getBizNme);
        this.onImgSave = false;
        this.$emit('saveEvnt');
      } catch (err) {
        terr(err);
      }
    },
    fixType(type) {
      let r = (type.toLowerCase().replace(/jpg/i, 'jpeg')).match(/png|jpeg|bmp|gif/)[0];
      return 'image/' + r;
    },
    // 提交、审批操作
    async approFunc(obj) {
      let {
        title = '审批', val
      } = obj;
      try {
        let _ident = this.baseDefine[0].ident;
        // let x = {
        //   bizIdent: _ident,
        //   id: this.currId,
        //   title,
        //   currStep: this.approveDef.currStep,
        //   val
        // };
        let x = {
          bizIdent: _ident,
          id: this.currId,
          title,
          val,
          ...JSON.parse(JSON.stringify(this.approveDef))
        }

        let _identCap = [..._ident].map((v, k) => {
          if (!k) {
            return v.toUpperCase();
          } else {
            return v;
          }
        }).join('');
        let res = await this.$store.dispatch(`post${_identCap}Appro`, x);
        this.$emit('approvEvnt', res);
        this.$Message(`${title}成功`);
      } catch (err) {
        this.$Message({
          type: 'error',
          text: `${title}失败`
        });
      }
    },
    // 表单提交操作
    execAppro(e) {
      this.approFunc(e);
    },
    // 作废按钮点击响应
    voidHandler: function () {
      let x = {
        bizIdent: this.define.intro.code,
        id: this.currId
      };
      this.voidObj(x)
        .then(res => {
          global.tinfo(res);
          this.$emit('eventVoid');
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 删除按钮点击响应
    delHandler: function () {
      let x = {
        $act: 'del',
        bizIdent: this.define.intro.code,
        by: {
          id: this.currId
        }
      };
      this.$store.dispatch(`del${this.define.intro.name}Multi`, x)
        .then(res => {
          global.tinfo('删除成功！');
          this.$router.push({
            name: this.define.intro.code
          });
        })
        .catch(err => {
          global.terr(err);
        });
    }
  }
};
</script>

<style lang="less" scoped>
@import '../../assets/less/index.less';

.stepBtnRow {
  display: flex;
  flex-direction: row;
  padding-left: 32px;
  justify-content: flex-end;
  -webkit-justify-content: flex-end;
  -moz-justify-content: flex-end;
  -o-justify-content: flex-end;
  -ms-justify-content: flex-end;

  .stepBtn {
    padding: 0 8px;
    margin: 0 4px;
    text-align: center;
    cursor: pointer;
    background-color: #eee;
  }

  .active {
    color: #fff;
    background-color: @primary-color;
  }
}

.subPanle {
  padding: 8px 12px 8px 8px;
  overflow-y: auto;
  overflow-x: hidden;
  transition: display .3s ease-in-out;

  &.editH {
    height: 48vh;
  }

  &.disableH {
    height: 64vh;
  }
}

.addRow {
  width: 100%;
  height: 24px;
  line-height: 24px;
  margin-top: 18px;
  text-align: center;
  font-size: 0.6rem;
  font-weight: 100;
  cursor: pointer;
  color: #fff;
  border-radius: 30px;
  background-color: #686780;

  &::after {
    content: '添加明细';
    letter-spacing: 8px;
    transition: all .3s ease-in;
  }
}

.addRow:hover {
  letter-spacing: 18px;
  color: #fff;
  background-color: #131138;

  &::after {
    content: '添加明细';
    letter-spacing: 18px;
  }
}
</style>
