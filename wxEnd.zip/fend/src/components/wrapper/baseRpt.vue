<template>
	<basePage :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
		<div class="rptPage">
			<div class="rptFilterRow">
				<slot name="filterRow"></slot>
			</div>
			<div class="rptWrapper" :style="getDirction">
				<slot></slot>
			</div>
		</div>
	</basePage>
</template>

<script>
import basePage from './base';

export default {
	props: {
		inLoading: {
			type: Boolean,
			default: false
		},
		dirction: {
			type: String,
			default: 'row'
		},
    // 本页面所需的主数据键值
    masterKeys: {
      type: Array,
      default() {
        return [];
      }
    },
    // 本页面所需的字典数据键值
    dictKeys: {
      type: Array,
      default() {
        return [];
      }
    }
	},
	components: {
		basePage
	},
	computed: {
		getDirction() {
			return {
				'flex-direction': this.dirction
			};
		}
	}
}
</script>

<style lang="less" scoped>
.rptPage {
	display: flex;
	flex-direction: column;
	overflow: hidden;

	.rptFilterRow {
		flex: 1;
	}
	
	.rptWrapper {
		flex: 1;
		display: flex;
		justify-content: space-between;
		align-items: center;
		flex-wrap: wrap;
		width: 100%;
		height: 90vh;
		overflow-x: hidden;
		overflow-y: auto;
	}
}
</style>