<template>
<tBase :inLoading="inLoading">
  <tPanel showHeader>
    <div slot="panelHeader">
      <btnCrud inEdit :allowEditOption="!isvoid" @btnSaveEvent="$emit('saveEvnt')" @btnCancelEvent="cancelHandler"></btnCrud>
      <div class="flexSplit"></div>
      <div class="stepBtnRow">
        <span class="stepBtn" :class="{ active: currStep === index }" v-for="(item, index) in baseDefine" :key="index" @click.prevent.stop="switchSub(index)">
          {{ item.namezh }}
        </span>
      </div>
    </div>
    <span v-show="isvoid" class="voidStr">已作废</span>
    <Row>
      <slot></slot>
    </Row>
  </tPanel>

  <Row class="subPanle">
    <slot name="subPanel"></slot>
  </Row>
  <div v-show="currStep > 0 && showAddBtn && !isvoid" class="addRow" @click.prevent.stop="addNewSub">继续添加</div>
</tBase>
</template>

<script>
import tBase from './base.vue';
import tPanel from './part/tPanel.vue';
import btnCrud from '../widge/bizCtrls/groupCrud';

export default {
  name: 'baseCrudEdit',
  components: {
    tBase,
    tPanel,
    btnCrud
  },
  props: {
    baseDefine: {
      type: Array,
      default: function () {
        return [];
      }
    },
    // 控制是否显示继续添加明细的按钮
    showAddBtn: {
      type: Boolean,
      default: true
    },
    inLoading: {
      type: Boolean,
      default: false
    },
    // 是否处于作废状态
    isvoid: {
      type: Number,
      default: 0
    }
  },
  data: function () {
    return {
      currStep: 0
    };
  },
  methods: {
    // 切换子面板
    switchSub: function (idx) {
      this.$emit('switchSub', idx);
      this.currStep = idx;
    },
    // 子视图添加记录项的响应
    addNewSub: function () {
      this.$emit('addNewSub', this.currStep - 1);
    },
    // 点击取消按钮的操作响应
    cancelHandler: function () {
      this.$router.push({
        name: this.baseDefine[0].code
      });
    }
  }
};
</script>

<style lang="less" scoped>
@import '../../assets/less/index.less';

.stepBtnRow {
  display: flex;
  flex-direction: row;
  padding-left: 32px;
  justify-content: flex-end;
  -webkit-justify-content: flex-end;
  -moz-justify-content: flex-end;
  -o-justify-content: flex-end;
  -ms-justify-content: flex-end;

  .stepBtn {
    padding: 0 8px;
    margin: 0 4px;
    text-align: center;
    cursor: pointer;
    background-color: #eee;
  }

  .active {
    color: #fff;
    background-color: @primary-color;
  }
}

.subPanle {
  padding: 8px;
}

.addRow {
  width: 100%;
  height: 30px;
  line-height: 30px;
  margin-top: 18px;
  text-align: center;
  font-size: 0.6rem;
  font-weight: 700;
  cursor: pointer;
  color: #000;
  border-radius: 5px;
  background-color: #e4e4ef;
}

.addRow:hover {
  color: #fff;
  background-color: @blue-color;
}
</style>
