<template>
	<div ref="chartPanleMap" style="width: 100%; height: 600px;"></div>
</template>

<script>
import Schart from '@/tModules/charts/sChartMapChina';
import china from '../../tModules/charts/china.json';

export default {
  props: {
    // 图表标题
    title: {
      type: String,
      default: '地图'
    },
    // 图表子标题
    subTitle: {
      type: String,
      default: ''
    },
    // 报表皮肤类型（True表示为深底白字，false表示白底深字），默认为True
    asDarkTheme: {
      type: Boolean,
      default: true
    },
    // 报表数据集
    chartData: {
      type: Array,
      default: function () {
        return [];
      }
    }
  },
  methods: {
    chartInit: function () {
      let dataList = new Schart(this.title, this.subTitle, this.chartData, this.asDarkTheme);
      /* eslint-disable no-undef */
      echarts.registerMap('china', china);
      let currChart = echarts.init(this.$refs.chartPanleMap, null, {renderer: 'svg'});
      currChart.setOption({
        // color: dataList.color,
        title: dataList.title,
				tooltip: dataList.tooltip,
				toolbox: dataList.toolbox,
				legend: dataList.legend,
				visualMap: dataList.visualMap,
				geo: dataList.geo,
        series: dataList.series
			});
		}
  },
  mounted() {
		this.chartInit();
  }
};
</script>
