<template>
<div ref="chartPanlePie" :style="getSize"></div>
</template>

<script>
import Schart from '@/tModules/charts/sChartPie';

export default {
  props: {
    // 图表配置
    optData: {
      type: Object,
      default () {
        return {};
      }
    }
  },
  data() {
    return {
      sizeW: '100px',
      sizeH: '100px'
    }
  },
  computed: {
    getSize() {
      let _minH = this.optData.minH || 300;
      return {
        width: `${this.sizeW - 36}px`,
        height: `${this.sizeH - 80}px`,
        'min-height': `${_minH}px`
      };
    },
    getOpt() {
      let { title = '', subTitle = '', chartData = [], chartLegend = [] } = this.optData;
      return {
        title,
        subTitle,
        chartLegend,
        chartData
      };
    }
  },
  methods: {
    chartInit: function (data) {
      let { title = '', subTitle = '', chartData = [], chartLegend = [] } = data;
      let dataList = new Schart(title, subTitle, chartData, chartLegend);
      /* eslint-disable no-undef */
      let currChart = echarts.init(this.$refs.chartPanlePie, null, {renderer: 'svg'});
      currChart.setOption(dataList);
    },
    update(data) {
      this.chartInit(data);
    }
  },
  mounted() {
    let _sizeFunc = () => {
      this.sizeW = this.$parent.$el.clientWidth;
      this.sizeH = this.$parent.$el.clientHeight;
    }
    _sizeFunc();
    let resizeFunc = () => {
      _sizeFunc()
    };
    window.onresize = function () {
      resizeFunc();
    };
  }
};
</script>
