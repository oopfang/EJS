<template>
	<div ref="chartPanleFunnel" style="width: 100%; height: 100%"></div>
</template>

<script>
import Schart from '@/tModules/charts/sChartFunnel';

export default {
  props: {
    // 图表标题
    title: {
      type: String,
      default: '漏斗图'
    },
    // 图表子标题
    subTitle: {
      type: String,
      default: ''
    },
    // 报表皮肤类型（True表示为深底白字，false表示白底深字），默认为True
    asDarkTheme: {
      type: Boolean,
      default: true
    },
    // 报表数据集
    chartData: {
      type: Array,
      default: function () {
        return [];
      }
    }
  },
  methods: {
    chartInit: function () {
      let dataList = new Schart(this.title, this.subTitle, this.chartData, this.asDarkTheme);
      /* eslint-disable no-undef */
      let currChart = echarts.init(this.$refs.chartPanleFunnel, null, {renderer: 'svg'});
      currChart.setOption({
        title: dataList.title,
				tooltip: dataList.tooltip,
				toolbox: dataList.toolbox,
				legend: dataList.legend,
				grid: dataList.grid,
				calculable: dataList.calculable,
        series: dataList.series
      });
    }
  },
  mounted() {
    this.chartInit();
  }
};
</script>
