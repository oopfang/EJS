<template>
<div class="treeWrapper">
  <p class="treeHeader mostBlack">
    {{ treeListData.namezh }}&nbsp;&nbsp;
    <Tooltip content="点击修改">
      <tIcon icon="t-edit-pencil" :size="12" class="handCursor"></tIcon>
    </Tooltip>
  </p>
  <p class="funcZone">
    <span v-show="!inEdit" class="funcBtn" @click.prevent.stop="changeOrg">组织调整</span>
    <span class="funcBtn" @click.prevent.stop="expandAll">{{ inExpand ? '折叠全部' : '展开全部'}}</span>
    <span v-show="inEdit" class="funcBtn" @click.prevent.stop="saveChange">保存变更</span>
    <span v-show="inEdit" class="funcBtn" @click.prevent.stop="cancelChange">取消变更</span>
  </p>
  <p v-show="inEdit" class="funcZone secondZone">
    <span v-show="currNode.id" class="funcBtn" @click.prevent.stop="addNode(true)">添加同级</span>
    <span v-show="currNode.id || treeListData.children.length === 0" class="funcBtn" @click.prevent.stop="addNode(false)">添加下级</span>
  </p>
  <Tree :data="treeListData.children" :draggable="inEdit" :droppable="inEdit" crossTree="crossTree" ref="treeList" @drop="treeListDrop" @mouseleave.native.stop="currHoverId=-1">
    <div slot-scope="{data, store}" @click="clickItem(data, store)">
      <span>{{data.namezh}}&nbsp;&nbsp;&nbsp;&nbsp;<tIcon v-show="inEdit" icon="t-edit-pencil" :size="4" :height="4" @click.native.stop="changeNodeName(data)"></tIcon></span>
      <span class="appendSpan">
        <i v-if="data.children && data.children.length > 0" :class="data.open ? 't-cheveron-down' : 't-cheveron-right'"></i>
      </span>
      <span v-show="inEdit && currHoverId===data.id" class="appendSpan delBtn">
        <Button color="red" size="xs" @click="stopOgr(data.id, data.parent.id)">注销机构</Button>
      </span>
    </div>
  </Tree>
</div>
</template>

<script>
// 申明：本组件基于 vue-draggable-nested-tree [https://github.com/phphe/vue-draggable-nested-tree]修改而来。
import Tree from './DraggableTree';
import tIcon from '@/components/widge/tIcon';
import * as th from 'tree-helper';

// 递归拆解数组
let _mapArr = obj => {
  let _arr = [];
  if (Array.isArray(obj)) {
    _arr.push(...(obj.map(v => _mapArr(v))));
    return _arr;
  } else {
    return _arr[obj];
  }
};

// 将组织对象转换为提交数组
let converRcd = obj => {
  let _arr = [];
  if (obj) {
    let {
      id,
      pid,
      namezh,
      organtypeid,
      chargemanid,
      memo,
      orderIdx,
      children
    } = obj;
    _arr.push({
      id: id,
      pid: pid,
      namezh: namezh,
      organtypeid: organtypeid,
      chargemanid: chargemanid,
      memo: memo,
      orderIndex: orderIdx
    });
    if (children && children.length > 0) {
      let _arrSub = [];
      for (let v of children) {
        let _objSub = converRcd(v);
        if (_objSub) {
          if (Array.isArray(_objSub)) {
            _arrSub.push(..._objSub);
          } else {
            _arrSub.push(_objSub);
          }
        }
      }
      _arr.push(..._arrSub);
    }
  }
  return _arr;
};

export default {
  name: 'treeList',
  components: {
    Tree,
    tIcon
  },
  props: {
    treeListData: {
      type: Object,
      default: () => {}
    },
    // 新增操作的回调值
    callBackVal: {
      type: Object,
      default: () => {}
    }
  },
  data: function () {
    return {
      currNode: {},
      // 当前hover的节点ID
      currHoverId: -1,
      // 是否处于组织调整状态
      inEdit: false,
      // 是否处于全部展开状态
      inExpand: false,
      // 组织调整前的原始数据镜像
      oldDataCache: {},
      // 新建节点是否为同级类型（同级/下级）
      isSameNode: false
    };
  },
  watch: {
    callBackVal() {
      if (this.callBackVal && this.callBackVal.id) {
        let _parant = {};
        if (this.isSameNode) {
          _parant = this.currNode.pid > 1 ? this.currNode.parent : this.treeListData;
        } else {
          _parant = this.currNode;
        }
        let _idx = _parant.children.findIndex(v => v.id === this.callBackVal.id);
        if (_idx === -1) {
          _parant.children.push(JSON.parse(JSON.stringify(this.callBackVal)));
          if (!this.isSameNode) {
            _parant.open = true;
          }
          this.currNode = _parant.children[_parant.children.length - 1];
          th.breadthFirstSearch(this.treeListData, node => {
            node.active = node.id === this.currNode.id;
          });
        }
        this.$emit('clearCallBack');
      }
    }
  },
  methods: {
    // 获取当前变动节点的父节点
    getParent(node) {
      return node.pid > 1 ? node.parent : this.treeListData;
    },
    // 拖放结束后的处理
    treeListDrop(node, targetTree, oldTree) {
      global.tlog(node);
      if (node.parent.isRoot) {
        node.pid = 1;
      } else {
        node.pid = node.parent.id;
      }
      this.getParent(node).children.forEach((v, k, arr) => {
        v.orderIdx = k;
      });
    },
    // 切换可编辑状态的公共调用
    switchEdit(isEdit) {
      this.inEdit = isEdit;
      th.breadthFirstSearch(this.treeListData, node => {
        node.draggable = isEdit;
        node.droppable = isEdit;
      });
    },
    // 响应组织调整按钮
    changeOrg() {
      this.switchEdit(true);
    },
    // 展开或折叠全部
    expandAll() {
      this.inExpand = !this.inExpand;
      th.breadthFirstSearch(this.treeListData, node => {
        node.open = this.inExpand;
      });
    },
    // 项点击时的响应（折叠展开或记录当前节点）
    clickItem(data, store) {
      this.currNode = data;
      store.toggleOpen(data);
      th.breadthFirstSearch(this.treeListData, node => {
        node.active = this.currHoverId === node.id;
        node.open = node.children.length === 0 ? false : node.open;
      });
      this.$emit('setCurrNode', {
        id: data.id,
        pid: data.pid,
        namezh: data.namezh
      });
    },
    // 添加节点
    addNode(asSameNode) {
      let _parant = {};
      this.isSameNode = asSameNode;
      if (asSameNode) {
        _parant = this.currNode.pid > 1 ? this.currNode.parent : this.treeListData;
      } else {
        _parant = this.treeListData.children.length > 0 ? this.currNode : this.treeListData;
      }
      this.$emit('setNewNode', [_parant.id, _parant.children.length]);
    },
    // 修改组织节点名称
    changeNodeName(item) {
      this.currNode = item;
      this.$emit('changeName', item);
    },
    // 修改组织节点名称后的父级回调
    reSetNode(item) {
      let { code, namezh, memo } = item;
      this.$set(this.currNode, 'code', code);
      this.$set(this.currNode, 'namezh', namezh);
      this.$set(this.currNode, 'memo', memo);
    },
    // 注销机构节点
    stopOgr(id, pid) {
      this.$emit('revokOrg', {id, pid});
    },
    // 保存调整
    saveChange() {
      let _arr = converRcd(this.treeListData);
      this.$emit('refreshData', _arr);
      this.switchEdit(false);
    },
    // 取消变更
    cancelChange() {
      this.$emit('refreshData');
      this.switchEdit(false);
    }
  },
  created() {
    this.$root.eventHub.$on('currHover', e => {
      this.currHoverId = e;
    });
  }
};
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';

.treeWrapper {
  max-height: 100%;
  color: #fff;
  overflow-y: auto;

  .treeHeader {
    padding: 24px 8px 24px 8px;
    margin: 8px 32px;
    font-size: 1.2rem;
    font-weight: 700;
    text-align: center;
    border-bottom: 1px #aaa solid;
  }

  .funcZone {
    text-align: center;
    color: #000;

    .funcBtn {
      padding: 4px 8px;
      margin: 8px;
      border-radius: 4px;
      cursor: pointer;

      &:hover {
        background-color: @second-color;
      }
    }

  }

  .secondZone {
    padding-bottom: 8px;
    margin: 18px 32px 0 32px;
    border-bottom: 1px #aaa solid;
  }

  .appendSpan {
    padding: 8px;
  }

  .delBtn {
    position: absolute;
    top: 0;
    right: 0;
  }
}
</style>
