<script>
import * as hp from 'helper-js';
import DraggableTreeNode from './DraggableTreeNode.vue';
import Tree from './Tree.vue';

const trees = [];
const dplh = {
  _id: 'draggable_tree_drag_placeHolder',
  level: null,
  draggable: false,
  droppable: false,
  isDragPlaceHolder: true,
  class: 'draggable-placeholder',
  style: {},
  innerStyle: {},
  innerClass: 'draggable-placeholder-inner',
  innerBackStyle: {},
  innerBackClass: 'draggable-placeholder-inner-back'
};

export default {
  extends: Tree,
  props: {
    getTriggerEl: {
      type: Function
    },
    draggable: {
      default: false
    },
    droppable: {
      default: false
    },
    crossTree: {},
    ondragstart: {
      type: Function
    },
    ondragend: {
      type: Function
    }
  },
  components: {
    TreeNode: DraggableTreeNode
  },
  data() {
    return {
      dplh,
      trees
    };
  },
  created() {
    trees.push(this);
  },
  beforeDestroy() {
    hp.arrayRemove(trees, this);
  }
};
</script>
