<template>
<div class="tree-node" :class="[(data.active && !data.open) ? store.activatedClass : '', data.open ? store.openedClass : '', data.class]" :style="data.style" :id="data._id">
  <div class="tree-node-inner-back" v-if="!isRoot" :style="[innerBackStyle, data.innerBackStyle]" :class="[data.innerBackClass]" @mouseenter.self.stop="$root.eventHub.$emit('currHover', data.id)">
    <div class="tree-node-inner" :style="[data.innerStyle]" :class="[data.innerClass]">
      <slot :data="data" :store="store" :vm="vm"></slot>
    </div>
  </div>
  <div class="tree-node-children" v-if="childrenVisible">
    <TreeNode v-for="child in data.children" :key="child._id" :data="child" :store="store" :level="childrenLevel">
      <template slot-scope="props">
        <slot :data="props.data" :store="props.store" :vm="props.vm"></slot>
      </template>
    </TreeNode>
  </div>
</div>
</template>

<script>
export default {
  name: 'TreeNode',
  props: {
    data: {},
    store: {},
    level: {
      default: 0
    }
  },
  data() {
    return {
      vm: this
    };
  },
  computed: {
    childrenLevel() {
      return this.level + 1;
    },
    isRoot() {
      return this.data.isRoot;
    },
    childrenVisible() {
      const {
        data
      } = this;
      /* eslint-disable no-mixed-operators */
      return this.isRoot || data.children && data.children.length && data.open;
    },
    innerBackStyle() {
      const r = {
        marginTop: `${this.store.space}px`,
        marginBottom: `${this.store.space}px`
      };
      if (!this.isRoot) {
        r.paddingLeft = `${this.level * this.store.indent}px`;
      }
      let _size = `${this.level > 4 ? 12 : (18 - this.level * 2)}px`;
      let _weight = this.level > 7 ? 100 : 700 - (this.level - 1) * 100;
      r.fontSize = _size;
      r.fontWeight = _weight;
      return r;
    }
  },
  watch: {
    data: {
      immediate: true,
      handler(data) {
        if (data) {
          data._vm = this;
          if (!data._treeNodePropertiesCompleted && !data.isRoot) {
            this.store.compeleteNode(data, this.$parent.data);
          }
        }
      }
    }
  }
};
</script>

<style lang="less" scoped>
.tree-node {
  .tree-node-inner-back {
    cursor: pointer;

    .tree-node-inner {
      position: relative;
      padding: 8px;
    }

    &:hover {
      background-color: rgba(82, 82, 82, .9);
    }
  }
}
.tree-node.active {
  background-color: #966142;
}
</style>
