<template>
  <div class="app-menu">
    <Menu ref='menu' v-width="180" accordion :datas="menus" :class-name="getClassName" className="h-menu-custom" @onclick="trigger"></Menu>
  </div>
</template>

<script>
import { mapMutations } from 'vuex';
export default {
  props: {
    menus: {
      type: Array,
      default: function() {
        return [];
      }
    },
    // 禁止点击后的导航响应，用于模拟菜单样式而不发生菜单行为的情形，例如菜单权限分配页面
    notNav: {
      type: Boolean,
      default: false
    },
    // 是否以深色背景显示
    isDark: {
      type: Boolean,
      default: false
    },
    // 自定义类名
    className: {
      type: String,
      default: ''
    }
  },
  computed: {
    getClassName: function() {
      if (this.className) {
        return this.className;
      } else {
        return !this.isDark ? 'h-menu-white' : 'h-menu-dark';
      }
    }
  },
  methods: {
    ...mapMutations(['setBreadData']),
    menuSelect() {
      if (this.$route.name) {
        this.$refs.menu.select(this.$route.name);
      }
    },
    trigger(data) {
      if (!this.notNav) {
        this.$router.push({
          name: data.key
        });
      } else {
        this.$emit('menuTo', data.id);
      }
    }
  },
  watch: {
    $route(newVal, oldVal) {
      this.menuSelect();
      let _txt = newVal.meta.title;
      if (_txt) {
        this.setBreadData({
          title: _txt,
          name: newVal.name
        });
      }
    }
  },
  mounted() {
    this.$refs.menu.select('home');
  }
};
</script>
