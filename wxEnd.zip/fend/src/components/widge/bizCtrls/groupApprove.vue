<template>
  <div class="btnGroup" v-show="!approveDef.stopped">
    <span class="btnItem"  v-show="allowSubmit" @click.prevent.stop="submitFunc">提交</span>
    <span class="btnItem" v-show="allowAppro" @click.prevent.stop="agreeFunc">同意</span>
    <span class="btnItem" v-show="allowAppro" @click.prevent.stop="disAgreeFunc">驳回</span>
  </div>
</template>

<script>
export default {
  props: {
    // 当前的审批定义
    approveDef: {
      type: Object,
      default() {
        return {
          // 审批状态下的已审级次
          currStep: 0,
          // 流程是否已经开始
          flowStart: false,
          // 流程是否已经关闭
          flowEnd: true,
          // 本单是否已作废
          stopped: false,
          // 是否具有审批权限
          hasAccess: false,
          // 是否为创建者
          isCreator: false
        }
      }
    },
    size: {
      type: String,
      // 参考 hey ui的按钮组尺寸设置，可选值为： l, s, xs
      default: 's'
    },
    // 是否以DEMO演示的方式加载，用于权限分配页面展示
    isDemo: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    // 判断是否允许操作
    allowAppro() {
      return !this.approveDef.stopped;
    },
    // 是否允许提交操作
    allowSubmit() {
      return !this.approveDef.flowStart && this.approveDef.isCreator;
    },
    // 判断是否允许审批操作
    allowAppro() {
      return this.approveDef.hasAccess && this.approveDef.flowStart && !this.approveDef.flowEnd;
    }
  },
  methods: {
    confirmDisuse: function() {
      if (!this.isDemo) {
      this.$Confirm('是否确定作废本单？该操作不可撤销！', '请确认')
        .then(() => {
          this.$emit('btnDisuseEvent');
        })
        .catch(() => {
          global.twarn('操作取消！');
        });
      }
    },
    emitFunc(obj) {
      this.$emit('execEvent', obj);
    },
    submitFunc() {
      this.emitFunc({
        title: '提交',
        val: true
      });
    },
    agreeFunc() {
      this.emitFunc({
        title: '审批',
        val: true
      });
    },
    disAgreeFunc() {
      this.emitFunc({
        title: '审批'
      });
    }
  }
};
</script>
