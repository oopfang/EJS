<template>
  <div class="btnGroup">
    <span class="btnItem active" v-if="!getOpt.hiddenAdd" v-show="getAddState" @click.prevent.stop="execAdd">新增</span>
    <span v-if="!getOpt.hiddenEdit" class="btnItem" v-show="getEditState" @click.prevent.stop="execEdit">编辑</span>
    <span v-if="getOpt.showSendNotice" class="btnItem active" @click.prevent.stop="execSendNotice">通知发货</span>
    <span  v-if="getOpt.showSendNoticeTips" class="btnTips">已通知发货</span>
    <span v-if="getOpt.showPickOver" class="btnItem active" @click.prevent.stop="execPickOver">结束拣货</span>
    <span  v-if="getOpt.showPickOverTips" class="btnTips">已拣货</span>
    <span v-if="getOpt.showSend" class="btnItem active" @click.prevent.stop="execSend">发货</span>
    <span  v-if="getOpt.showSendTips" class="btnTips">已发货</span>
    <span class="btnItem active" v-show="inEdit" @click.prevent.stop="execSave">保存</span>
    <span v-show="inEdit" class="btnItem" @click.prevent.stop="execCancel">取消</span>
    <span v-if="!getOpt.hiddenDel" class="btnItem" v-show="getDelState" @click.prevent.stop="execDel">删除</span>
    <!-- <span v-if="!getOpt.hiddenCopy" v-show="getCopyState" @click.prevent.stop="execCopy">复制</span> -->
  </div>
</template>

<script>
// 新增按钮在权限组中的绝对定位
const _addPositon = 1;
// 编辑按钮在权限组中的绝对定位
const _editPositon = 2;
// 删除按钮在权限组中的绝对定位
const _delPositon = 3;
// 复制按钮在权限组中的绝对定位
const _copyPositon = 4;
const defaultOpt = {
  // 是否强制屏蔽新增按钮
  hiddenAdd: false,
  // 是否强制屏蔽编辑按钮
  hiddenEdit: false,
  // 是否强制显示通知发货通知按钮
  showMsgSend: false,
  // 是否强制显示发货按钮
  showSend: false,
  // 是否强制屏蔽删除按钮
  hiddenDel: false,
  // 是否强制屏蔽复制按钮
  hiddenCopy: false,
  // 强制显示删除按钮
  forceDel: false
};

export default {
  props: {
    // 按钮组尺寸
    size: {
      type: String,
      // 参考 hey ui的按钮组尺寸设置，可选值为： l, s, xs
      default: 's'
    },
    // 是否以DEMO演示的方式加载，用于权限分配页面展示
    isDemo: {
      type: Boolean,
      default: false
    },
    // 数据集是否为空
    dataIsNull: {
      type: Boolean,
      default: true
    },
    // 是否处于编辑状态(用于按钮点击操作之外的强控)
    inEdit: {
      type: Boolean,
      default: false
    },
    // 对应页面的已选数据条目数量，用于控制多选状态下，可显示删除按钮，但隐藏编辑按钮
    selectCount: {
      type: Number,
      default: 1
    },
    // 当前审核的节点值
    approveStep: {
      type: Number,
      default: 0
    },
    disableDoc: {
      type: Boolean,
      default: false
    },
    // 用户权限，值说明：[有新增权限，有编辑权限，有删除权限，有复制权限]
    // 第一位不在按钮界面控制序列中，用于授权界面的“查看”操作
    userAccess: {
      type: Array,
      default: function () {
        return [1, 1, 1, 1, 1];
      }
    },
    // 特性配置
    options: {
      type: Object,
      default: function () {
        return {};
      }
    }
  },
  computed: {
    // 获取组件配置参数
    getOpt: function () {
      return Object.assign({}, defaultOpt, this.options);
    },
    // 获取新增按钮的显示状态
    getAddState: function () {
      if (this.isDemo) {
        return this.userAccess[_addPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenAdd;
      }
    },
    // 获取编辑按钮的显示状态
    getEditState: function () {
      if (this.isDemo) {
        return this.userAccess[_editPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenEdit;
      }
    },
    // 获取删除按钮的显示状态
    getDelState: function () {
      if (this.isDemo) {
        return this.userAccess[_delPositon];
      } else {
        return !this.inEdit && (this.getOpt.forceDel || !this.getOpt.hiddenDel);
      }
    },
    // 获取复制按钮的显示状态
    getCopyState: function () {
      if (this.isDemo) {
        return this.userAccess[_copyPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenCopy;
      }
    }
  },
  watch: {
    userAccess() {
      let _b = true;
      for (let v of this.userAccess) {
        if (v > 0) {
          _b = false;
          break;
        }
      }
      this.$emit('noAccess', _b);
    }
  },
  methods: {
    // 响应新增按钮的点击
    execAdd: function () {
      if (!this.isDemo) {
        this.$emit('btnAddEvent');
      }
    },
    // 响应编辑按钮的点击
    execEdit: function () {
      if (!this.isDemo) {
        this.$emit('btnEditEvent');
      }
    },
    execSendNotice: function() {
      this.$emit('btnSendNoticeEvent');
    },
    execSend: function() {
      this.$emit('btnSendEvent');
    },
    execPickOver: function() {
      this.$emit('btnPickOver');
    },
    // 响应删除按钮的点击
    execDel: function () {
      if (!this.isDemo) {
        /* eslint-disable handle-callback-err */
        this.$Confirm('是否确定删除选定数据？', '请确认')
          .then(() => {
            this.$emit('btnDelEvent', true);
          })
          .catch(err => {
            global.twarn('操作取消！', false);
          });
      }
    },
    // 响应复制按钮的点击
    execCopy: function () {
      if (!this.isDemo) {
        this.$emit('btnCopyEvent');
      }
    },
    // 响应保存按钮的点击
    execSave: function () {
      if (!this.isDemo) {
        let _that = this;
        // _that.$emit('btnSaveEvent');
        if (!this.disableDoc) {
          this.$Confirm('是否保留为电子档作业', '作业留档')
          .then(res => {
            _that.$emit('btnSaveEvent', true);
          })
          .catch(err => {
            _that.$emit('btnSaveEvent');
          })
        } else {
          this.$emit('btnSaveEvent');
        }
      }
    },
    // 响应取消按钮的点击
    execCancel: function () {
      if (!this.isDemo) {
        this.$emit('btnCancelEvent');
      }
    }
  }
};
</script>
