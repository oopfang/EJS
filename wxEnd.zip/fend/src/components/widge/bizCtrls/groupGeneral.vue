<template>
  <div class="btnGroup">
    <!-- <span v-if="!getOpt.hiddenImport" class="btnItem" v-show="getImportState"  @click.prevent.stop="fileSelect()">导入</span>
    <span v-if="!getOpt.hiddenExport" class="btnItem" v-show="getExportState" @click.prevent.stop="execExport">导出</span> -->
    <!-- <span v-if="!getOpt.hiddenPrint" v-show="getPrintState" @click.prevent.stop="execPrint">打印</span> -->
    <!-- <span v-if="!getOpt.hiddenHelp" v-show="getHelpState" @click.prevent.stop="$emit('onHelp')">帮助</span>
    <span v-if="!getOpt.hiddenIssue" v-show="getIssueState" @click.prevent.stop="$emit('onIssue')">需求</span> -->
    <template>
      <slot></slot>
    </template>
    <input ref="fileSelectCtl" type="file" style="display:none" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" multiple @change="execImport" />
  </div>
</template>

<script>
// 导入按钮在权限组中的绝对定位
const _importPositon = 0;
// 导出按钮在权限组中的绝对定位
const _exportPositon = 1;
// 打印按钮在权限组中的绝对定位
const _printPositon = 2;
// 帮助按钮在权限组中的绝对定位
const _helpPositon = 3;
// 需求按钮在权限组中的绝对定位
const _issuePositon = 4;
const defaultOpt = {
  // 是否强制屏蔽导入按钮
  hiddenImport: false,
  // 是否强制屏蔽导出按钮
  hiddenExport: false,
  // 是否强制屏蔽打印按钮
  hiddenPrint: false,
  // 是否强制屏蔽帮助按钮
  hiddenHelp: false,
  // 是否强制屏蔽需求按钮
  hiddenIssue: false
};

export default {
  props: {
    // 按钮组尺寸
    size: {
      type: String,
      // 参考 hey ui的按钮组尺寸设置，可选值为： l, s, xs
      default: 's'
    },
    // 是否以DEMO演示的方式加载，用于权限分配页面展示
    isDemo: {
      type: Boolean,
      default: false
    },
    // 数据集是否为空
    dataIsNull: {
      type: Boolean,
      default: true
    },
    // 是否处于编辑状态
    inEdit: {
      type: Boolean,
      default: false
    },
    // 用户权限，值说明：[有导入权限，有导出权限，有打印权限，有帮助权限，有需求权限]
    userAccess: {
      type: Array,
      default: function () {
        return [1, 1, 1, 1, 1];
      }
    },
    // 是否显示左边分隔线
    showLeftLine: {
      type: Boolean,
      default: true
    },
    // 特性配置
    options: {
      type: Object,
      default: function () {
        return {};
      }
    }
  },
  computed: {
    // 获取组件配置参数
    getOpt: function () {
      return Object.assign({}, defaultOpt, this.options);
    },
    // 控制是否显示左分隔线
    defaultStyle: function () {
      let _styl = {};
      if (this.showLeftLine) {
        _styl['border-left'] = '1px #ddd solid';
      }
      return _styl;
    },
    // 获取导入按钮的显示状态
    getImportState: function () {
      if (this.isDemo) {
        return this.userAccess[_importPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenImport;
      }
    },
    // 获取导出按钮的显示状态
    getExportState: function () {
      if (this.isDemo) {
        return this.userAccess[_exportPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenExport;
      }
    },
    // 获取打印按钮的显示状态
    getPrintState: function () {
      if (this.isDemo) {
        return this.userAccess[_printPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenPrint;
      }
    },
    // 获取帮助按钮的显示状态
    getHelpState: function () {
      if (this.isDemo) {
        return this.userAccess[_helpPositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenHelp;
      }
    },
    // 获取需求按钮的显示状态
    getIssueState: function () {
      if (this.isDemo) {
        return this.userAccess[_issuePositon];
      } else {
        return !this.inEdit && !this.getOpt.hiddenIssue;
      }
    }
  },
  watch: {
    userAccess() {
      let _b = true;
      for (let v of this.userAccess) {
        if (v > 0) {
          _b = false;
          break;
        }
      }
      this.$emit('noAccess', _b);
    }
  },
  methods: {
    fileSelect: function() {
      if (!this.isDemo) {
        this.$refs.fileSelectCtl.click();
      }
    },
    execImport: function(e) {
      if (!this.isDemo) {
        this.$emit('onImport', e);
      }
    },
    execExport: function() {
      if (!this.isDemo) {
        this.$emit('onExport');
      }
    },
    execPrint: function() {
      if (!this.isDemo) {
        this.$emit('onPrint');
      }
    }
  }
};
</script>
