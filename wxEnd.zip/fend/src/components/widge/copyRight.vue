<template>
<transition>
  <div v-html="getCopyRightStr" @click="$emit('closeAffir')"></div>
</transition>
</template>

<script>
import {
  mapGetters
} from 'vuex';

export default {
  name: 'copyRightPanel',
  computed: {
    ...mapGetters(['getCopyRightStr'])
  }
};
</script>
