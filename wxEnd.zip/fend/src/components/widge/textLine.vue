<template>
<div class="splitZone">
  <p class="lineText">
    <span><slot></slot></span>
  </p>
</div>
</template>

<script>
export default {
  name: 'textLine'
};
</script>

<style lang="less" scoped>
.splitZone {
  padding: 18px 0;
  margin: 0 20%;

  .lineText {
    width: 100%;
    position: relative;
    text-align: center;
    zoom: 1;

    span {
      font-weight: 700;
      text-shadow: 2px 2px 8px #ccc;
    }

    span::before {
      content: '';
      width: 44%;
      height: 40px;
      position: absolute;
      border-top: 1px #888 dashed;
      right: 0;
      top: 12px;
    }

    span:after {
      content: '';
      width: 44%;
      height: 40px;
      position: absolute;
      border-top: 1px #888 dashed;
      left: 0;
      top: 12px;
    }
  }
}
</style>
