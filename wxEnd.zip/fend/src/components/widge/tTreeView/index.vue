<template>
<li class="nodeItem" :style="levelTitle">
  <div class="itemRow" @click.self.prevent.stop="showSub=!showSub">
    <span>{{nodeData.namezh}}</span>
    <span v-if="nodeData.children.length > 0" class="arrowCell" :class="{ onOpen: showSub }"><i class="t-cheveron-right"></i></span>
  </div>
  <ul v-show="showSub" :style="levelContent">
    <treeItem v-for="child of nodeData.children" :key="child.id" :nodeData="child" :level="level+1" :pid="nodeData.id" :color="color"></treeItem>
  </ul>
</li>
</template>

<script>
import {
  mapMutations
} from 'vuex';

export default {
  name: 'treeItem',
  props: {
    nodeData: {
      type: Object,
      default: function () {
        return {};
      }
    },
    // 父级ID
    pid: {
      type: Number,
      default: -1
    },
    // item项级别
    level: {
      type: Number,
      default: 1
    },
    // 文字颜色
    color: {
      type: String,
      default: '#000'
    }
  },
  data: function () {
    return {
      currId: -1,
      // 是否显示下级
      showSub: false
    };
  },
  computed: {
    getLeveStyle: function () {
      let _size = this.level > 4 ? 9 : (12 - this.level * 2);
      let _weight = this.level > 7 ? 100 : 700 - (this.level - 1) * 100;
      return {
        size: {
          title: `${_size}px`,
          subList: `${_size - 2}px`
        },
        weight: _weight
      };
    },
    levelTitle: function () {
      let _style = this.getLeveStyle;
      return {
        color: this.color,
        'font-size': _style.size.title,
        'font-weight': _style.weight
      };
    },
    levelContent: function () {
      let _style = this.getLeveStyle;
      return {
        color: this.color,
        // 'padding-left': _style.paddingL,
        'font-size': _style.size.subList,
        'font-weight': _style.weight
      };
    }
  },
  methods: {
    ...mapMutations(['setCurrOrgNode']),
    execClick: function (node) {
      /* eslint-disable no-unused-vars */
      let {
        children,
        ...otherPart
      } = node;
      this.setCurrOrgNode(otherPart);
      this.$emit('itemClick', otherPart);
    },
    onHoverSub: function (id) {
      this.currId = id;
      this.$emit('inSub');
    },
    // 拖放移动控制
    onMove: function ({
      relatedContext,
      draggedContext
    }) {
      const relatedElement = relatedContext.element;
      const draggedElement = draggedContext.element;
      return (
        (!relatedElement || !relatedElement.fixed) && !draggedElement.fixed
      );
    }
  }
};
</script>

<style lang="less" scoped>
.nodeItem {
  display: flex;
  flex-direction: column;
  width: 100;
  padding: 0;
  cursor: pointer;

  ul {
    padding-left: 20px;
  }

  .itemRow {
    padding: 8px 0;

    .arrowCell {
      transform: translateY(-50%);
      right: 20px;

      & > i {
        transform: rotate(0deg);
      }
    }

    .arrowCell.onOpen > i {
      transition: .2s;
      transform: rotate(-90deg);
    }

    &:hover {
      color: #fff;
      background-color: rgba(85, 85, 85, .6);
    }
  }
}
</style>
