<template>
<ul class="letterRow" :style="getBgColor">
  <li v-for="(item, index) in letters" :key="index" :class="{ active: currIdx === index }" @click.prevent.stop="setActive(index)">{{ item }}</li>
  <li @click.prevent.stop="setActive(-1)">清除</li>
</ul>
</template>

<script>
export default {
  name: 'letterFilterBar',
  props: {
    bgColor: {
      type: String,
      default: 'transparent'
    }
  },
  data: function () {
    return {
      letters: [
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'
			],
			currIdx: -1
    };
  },
  computed: {
    getBgColor: function() {
      return {
        'background-color': this.bgColor
      };
    }
  },
  methods: {
		setActive: function(idx) {
      this.currIdx = idx;
      let _val = idx === -1 ? idx : (this.letters[idx]).toLowerCase();
			this.$emit('filterBy', _val);
		}
	}
};
</script>

<style lang="less" scoped>
.letterRow {
  width: 100%;
  height: 20px;
  list-style: none;
  white-space: pre-line;
  text-align: center;
  li {
    display: inline-block;
    line-height: 20px;
    padding: 0 4px;
    font-weight: 100;
    cursor: pointer;
  }
  li:hover {
    background-color: #8aa7f7;
  }
  li + .active {
    font-weight: 700;
    color: #fff;
    background-color: #454fb4;
  }
}
</style>
