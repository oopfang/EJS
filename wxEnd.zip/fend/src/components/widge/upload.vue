<template>
<div class="uploadWrapper">
  <p v-if="tips" class="tipsRow">{{ tips }}</p>
  <div class="previewRow">
    <div class="previewItem" v-for="(item, index) of actList" :key="index">
      <img :src="item.src" width="98px" height="70px">
      <span v-font="28" class="removeIco" @click="removeItem(index)">
        <i class="h-icon-trash" style="color: #fff;"></i>
        <span class="nameRow">{{ item.fileName }}</span>
      </span>
    </div>
    <form v-show="getBtnShow && !disabled" ref="loaderForm" class="uploadForm" enctype="multipart/form-data" method="post" :action="remotUrl">
      <label ref="uploadIpt" for="iptBtnId" class="lableMask">点击选择</label>
      <input :ref="refTag" id="iptBtnId" hidden type="file" :accept="allowedType" multiple="multiple" @change.prevent.stop="onChoose" class="iptBtn">
    </form>
  </div>
  <p style="margin-top: 18px; height: 32px;">
    <Button v-show="actList.length" icon="h-icon-outbox" @click="execSubmit">上传</Button>
  </p>
</div>
</template>

<script>
import {
  mapActions
} from 'vuex';
const imgIcon = {
  'application/pdf': 'pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'word',
  'application/msword': 'word',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'excel',
  'application/vnd.ms-excel': 'excel',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'ppt',
  'application/vnd.ms-powerpoint': 'ppt',
  rar: 'rar',
  other: 'file'
};

export default {
  props: {
    // 组件识别符
    refTag: {
      type: String,
      default: 'iptBtn'
    },
    // 文件/图片上传地址
    remotUrl: {
      type: String,
      default: ''
    },
    tips: {
      type: String,
      default: ''
    },
    // 文件路径归类
    pathType: {
      type: String,
      default: 'common'
    },
    // 提交方法
    submitFunc: {
      type: Function,
      default: null
    },
    // 允许上传的类型
    allowedType: {
      type: String,
      default: '.png, .jpg, .jpeg, .pdf, .doc, .xls, .ppt, .docx, .xlsx, .pptx, .txt, .rar, .zip, .7z, .txt'
    },
    // 是否允许多选
    allowMuti: {
      type: Boolean,
      default: true
    },
    // 禁用状态
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 实际文件列表
      actList: [],
      uploadList: null
    };
  },
  computed: {
    getBtnShow() {
      if (this.allowMuti) {
        return true;
      } else {
        return this.actList ? this.actList.length === 0 : true;
      }
    }
    // actList() {

    // }
  },
  methods: {
    ...mapActions(['fileUploader']),
    agentClick() {
      this.$refs[this.refTag].click();
    },
    onChoose(e) {
      // 取消默认浏览器拖拽效果
      e.preventDefault();
      // 获取文件对象
      let _currFiltList = e.currentTarget.files;
      let _urlObj = window.URL || window.webkitURL || window.mozURL;
      this.uploadList = new FormData();
      for (let v of _currFiltList) {
        // let fd = new FormData();
        this.uploadList.append(this.pathType, v, v.name);
        // this.actList.push(fd);
        if (v.type.includes('image')) {
          let _img = null;
          if (window.URL) {
            _img = window.URL.createObjectURL(v);
          } else if (window.webkitURL) {
            _img = window.webkitURL.createObjectURL(v);
          } else if (window.mozURL) {
            _img = window.mozURL.createObjectURL(v);
          }
          if (_img) {
            this.actList.push({
              fileName: v.name,
              pathType: this.pathType,
              type: 'img',
              src: _img
              // fileData: fd
            });
          }
        } else {
          let _fObj = {
            fileName: v.name,
            pathType: this.pathType,
            type: 'pdf'
            // fileData: fd
          }
          let _srcName = imgIcon[v.type];
          if (!_srcName) {
            if (v.name.endsWith('.rar') || v.name.endsWith('.7z') || v.name.endsWith('.zip')) {
              _srcName = imgIcon.rar;
            } else {
              _srcName = imgIcon.other;
            }
          }
          _fObj.src = `/static/img/fileIcon/${_srcName}.png`;
          this.actList.push(_fObj);
        }
      }
    },
    removeItem(idx) {
      if (!this.disabled) {
        this.actList.splice(idx, 1);
        this.actList.splice(idx, 1);
      } else {
        this.$Message({
          type: 'error',
          text: '正在保存数据'
        });
      }
    },
    // 提交文件/图片
    async execSubmit() {
      try {
        let x = this.uploadList;
        x.headers = {
          'Content-Type': 'multipart/form-data'
        };
        let res = await this.fileUploader(x);
        this.uploadList = null;
        this.actList.splice(0, this.actList.length);
        this.$emit('fileUpOk', res);
      } catch (err) {
        this.$Message({
          type: 'error',
          text: err.message
        });
      }
    }
  },
  mounted() {
    this.actList = [];
  }
}
</script>

<style lang="less" scoped>
@imgWidth: 100px;
@imgHeight: 80px;

.uploadWrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;

  .tipsRow {
    text-align: center;
    font-weight: 700;
    padding: 8px;
    margin-top: 8px;
  }

  .previewRow {
    width: 100%;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    min-height: @imgHeight;
    flex-wrap: wrap;
    border: 1px #ccc solid;

    .previewItem {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      width: @imgWidth;
      height: @imgHeight;
      margin: 8px 2px;
      border: 1px #ccc solid;
      text-align: center;
      cursor: pointer;

      &:hover {
        .removeIco {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
        }
      }

      img {
        position: relative;
        object-fit: scale-down;
        z-index: 0;
      }

      .removeIco {
        position: absolute;
        display: none;
        width: @imgWidth;
        height: @imgHeight;
        color: #fff;
        background-color: rgba(0, 0, 0, .5);
        z-index: 3;

        i:hover {
          color: orange;
        }

        .nameRow {
          font-size: 14px;
          font-weight: 100;
          margin-top: 12px;
        }
      }
    }

    .uploadForm {
      width: @imgWidth;
      height: @imgHeight;
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      align-items: center;
      border: 1px #ccc dotted;
      margin: 2px 18px;

      &:hover {
        border-color: #636492;
        background-color: rgb(239, 247, 255);
      }

      .lableMask {
        position: absolute;
        width: @imgWidth;
        line-height: @imgHeight;
        text-align: center;
        font-weight: 100;
        cursor: pointer;
      }

      input.iptBtn {
        position: absolute;
        display: none;
      }
    }
  }

}
</style>
