<template>
  <i :class="[iconClass, fontsizeClass, boldClass]" :style="[rotationStyle, normalStyle]"></i>
</template>

<script>
export default {
  name: 'tIcons',
  props: {
    icon: {
      type: String,
      required: true
    },
    size: {
      type: Number,
      default: 9
    },
    rotate: {
      type: Number,
      validator: function (value) {
        return value >= 0 && value <= 360;
      }
    },
    height: {
      type: Number,
      default: 30
    },
    color: String,
    bold: Boolean
  },
  computed: {
    iconClass () {
      return this.icon;
    },
    fontsizeClass () {
      return this.size;
    },
    rotationStyle () {
      return {
        transform: `rotate(${this.rotate}deg)`
      };
    },
    normalStyle () {
      let _h = `${this.height}px`;
      return {
        height: _h,
        'line-height': _h,
        'font-size': `${this.size}px`,
        color: this.color
      };
    },
    boldClass () {
      return this.bold ? 'bold' : '';
    }
  }
};
</script>
<style scoped>
i {
  font-size: 16px;
  display: inline-block;
  margin: 0 4px;
}
.small {
  font-size: 12px;
}
.large {
  font-size: 22px;
  font-weight: 600;
}
.bold {
  font-weight: 600;
}
</style>
