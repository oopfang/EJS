/* eslint-disable no-undef */
export default class OrgTree {
  constructor(option) {
    let _fontSize = 10;
    let defaultOpt = {
      width: 900,
      height: 900,
      // 影响树形横向的区域
      offsetTreeH: 200,
      // 节点rect高度
      nodeHeight: 20,
      // 默认节点宽度
      // 传参为null就按字数设置宽度
      nodeWidth: {
        _0: 160,
        _1: 160,
        _2: 130,
        _3: 110,
        _4: 160
      },
      // 挂载元素
      selector: null,
      // 设置字体大小因子
      fontNum: 1.2,
      // 字体颜色
      fontColors: {
        normal: '#fff',
        warning: '#000',
        errors: '#000'
      },
      bgColors: {
        normal: '#131138',
        warning: '#708870',
        errors: '#f00'
      },
      // 必填
      dataUrl: ''
    };

    option = Object.assign({}, defaultOpt, option);

    this.width = option.width;
    this.height = option.height;
    this.nodeHeight = option.nodeHeight;
    this.nodeWidth = option.nodeWidth;
    this.offsetTreeH = option.offsetTreeH;
    this.selector = option.selector === null ? 'body' : option.selector;
    this.fontNum = option.fontNum;
    this.fontColors = option.fontColors;
    this.bgColors = option.bgColors;
    this.dataUrl = option.dataUrl;
    this._getFontSize = function () {
      return _fontSize;
    };
  }

  init() {
    let that = this;
    let tree = d3.tree()
      .size([that.width, that.height - that.offsetTreeH])
      // 间隔函数
      .separation(function (a, b) {
        return (a.parent === b.parent ? 1 : 2) / a.depth;
      });
    this.tree = tree;
    let _oldDom = d3.select(that.selector)._groups[0][0].children;
    if (_oldDom.length > 0) {
      _oldDom.item(0).remove();
    }
    let svg = d3.select(that.selector).append('svg')
      .attr('width', that.width)
      .attr('height', that.height)
      .append('g')
      .attr('transform', 'translate(0,0)');

    if (Object.prototype.toString.call(that.dataUrl).toLowerCase() === '[object string]') {
      d3.json(that.dataUrl, function (error, root) {
        if (error) throw error;
        render(root);
      });
    } else {
      render(that.dataUrl);
    }

    function render(root) {
      let treeRoot = d3.hierarchy(root);
      tree(treeRoot);
      const nodes = treeRoot.descendants();
      const links = treeRoot.links();

      svg.selectAll('.link')
        .data(links)
        .enter()
        .append('path')
        .attr('class', 'link')
        .attr('d', function (d) {
          let lineOffsetWidth = 0;
          // nodeWidth传参为null则按照字数来自动设置宽度
          if (that.nodeWidth == null) {
            // lineOffsetWidth = (d.source.namezh.length + d.source.id.length + 2) * that._getFontSize() * that.fontNum;
            lineOffsetWidth = d.source.namezh.length * that._getFontSize() * that.fontNum;
          } else {
            lineOffsetWidth = that.nodeWidth['_' + d.source.depth];
          }

          lineOffsetWidth = lineOffsetWidth + 10;

          return 'M' + d.source.y + ' ' + d.source.x +
            'L' + (d.source.y + lineOffsetWidth) + ' ' + d.source.x +
            ' L' + (d.source.y + lineOffsetWidth) + ' ' + d.target.x + ' L' +
            d.target.y + ' ' + d.target.x;
        })
        .attr('style', function () {
          return 'stroke:#ccc;fill: none;stroke-width: 1.5px;';
        });

      let node = svg.selectAll('.node')
        .data(nodes)
        .enter()
        .append('g')
        .attr('class', 'node')
        .attr('transform', function (d) {
          return 'translate(' + d.y + ',' + (d.x - that.nodeHeight / 2) + ')';
        })
        .attr('style', function (d) {
          return 'font: ' + that._getFontSize() * that.fontNum + 'px sans-serif;';
        });

      node.append('rect')
        .attr('width', function (d) {
          return that.nodeWidth == null
            // ? (d.namezh.length + d.id.length + 2) * that._getFontSize() * that.fontNum
            ? (d.data.namezh.length + 2) * that._getFontSize() * that.fontNum
            : that.nodeWidth['_' + d.depth];
        })
        .attr('height', that.nodeHeight)
        .attr('x', 0)
        .attr('y', 0)
        .attr('style', function (d) {
          if (d.isRoot) {
            return 'fill:' + that.bgColors.warning;
          } else if (d.change) {
            return 'fill:' + that.bgColors.errors;
          } else {
            return 'fill:' + that.bgColors.normal;
          }
        })
        .on('click', setClick);

      function setClick(e) {
        global.tlog(e);
      }

      node.append('text')
        .attr('dx', function (d) {
          return that._getFontSize() * that.fontNum;
        })
        .attr('dy', (that._getFontSize() * that.fontNum + that.nodeHeight) / 2 - 2)
        .style('text-anchor', function (d) {
          return 'start';
        })
        .style('fill', '#fff')
        .text(function (d) {
          return d.data.namezh;
        });

      node.append('text')
        .attr('dx', function (d) {
          return that.nodeWidth == null
            ? (d.data.namezh.length + 2) * that._getFontSize() * that.fontNum
            : (that.nodeWidth['_' + d.depth] - 3 * that._getFontSize() * that.fontNum);
        })
        .attr('dy', (that._getFontSize() * that.fontNum + that.nodeHeight) / 2 - 2)
        .style('text-anchor', function (d) {
          return 'start';
        })
        .style('fill', '#fff');
    }
  }
}
