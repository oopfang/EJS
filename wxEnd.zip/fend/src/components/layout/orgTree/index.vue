<template>
<div id="dynamicTree"></div>
</template>

<script>
import OrgTree from './orgTree';
let tree = null;

export default {
  name: 'orgTree',
  props: {
    treeData: {
      type: Object,
      default: function () {
        return {};
      }
    }
  },
  methods: {
    refresh: function () {
      let _keys = Object.keys(this.treeData);
      if (_keys.length > 0) {
        let option = {
          dataUrl: this.treeData,
          nodeHeight: 30,
          selector: '#dynamicTree'
        };
        tree = new OrgTree(option);
        tree.init();
      }
    }
  },
  mounted() {
    tree = null;
    this.refresh();
  },
  destroyed() {
    this.$emit('clearTree');
  }
};
</script>

<style lang="less" scoped>
#dynamicTree {
  display: flex;
  width: 100%;
  justify-content: center;
  align-items: center;
}
</style>
