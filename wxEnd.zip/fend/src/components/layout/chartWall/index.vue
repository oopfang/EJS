<template>
<div class="dashboard" :style="getBackground">
  <div class="rptHeader">
    <div class="headerItem">上海深普软件有限公司</div>
    <div class="flexSplit"></div>
    <div class="headerItem" @click="signOut">
      <h-switch v-model="getIsLoop" :small="true">循环</h-switch>
    </div>
    <div class="headerItem" @click="signOut">
      <tIcon icon="t-subdirectory-right" :size="9"></tIcon>注销
    </div>
  </div>
  <div class="flex-container column">
    <div class="item one" @click="clickChart('1')" style="transform: translate(-22.4%,-33.5%) scale(0.33)">
      <slot name="chart0"></slot>
    </div>
    <div class="item two" @click="clickChart('2')" style="transform: translate(-22.4%,0.5%) scale(0.33)">
      <slot name="chart1"></slot>
    </div>
    <div class="item three" @click="clickChart('3')" style="transform: translate(-22.4%,34.5%) scale(0.33)">
      <slot name="chart2"></slot>
    </div>
    <div class="item four active" @click="clickChart('4')" style="transform: translate(43.7%, 0) scale(1)">
      <slot name="chart3"></slot>
    </div>
  </div>
  <span class="switchllBar leftBar" @click.prevent.stop="switchBg(-1)"></span>
  <span class="switchllBar rightBar" @click.prevent.stop="switchBg(1)"></span>
</div>
</template>

<script>
import tIcon from '@/components/widge/tIcon';

export default {
  name: 'reportWall',
  components: {
    tIcon
  },
  props: {
    // 是否启用图表循环
    loop: {
      type: Boolean,
      default: false
    },
    // 最多支持的背景数量
    maxBgCount: {
      type: Number,
      default: 2
    }
  },
  data: function () {
    return {
      // 是否循环展示
      isLoop: false,
      loopTag: null,
      bgImg: 'rpbg',
      currBgIndex: 1,
      items: []
    };
  },
  computed: {
    getBackground: function() {
      return {
        background: `url(/static/img/${this.bgImg}${this.currBgIndex}.jpg)`
      };
    },
    getIsLoop: {
      get() {
        return this.isLoop;
      },
      set(val) {
        this.isLoop = val;
        if (val) {
          let i = 1;
          this.loopTag = setInterval(() => {
            this.clickChart(i);
            if (i > 3) {
              i = 1;
            } else {
              i++;
            }
          }, 3000);
        } else {
          clearInterval(this.loopTag);
          this.loopTag = null;
        }
      }
    }
  },
  methods: {
    initStyle() {
      this.items = document.querySelectorAll('.flex-container .item');
      for (let i = 0; i < this.items.length; i++) {
        this.items[i].dataset.order = i + 1;
      }
    },
    clickChart(clickIndex) {
      let activeItem = document.querySelector('.flex-container .active');
      if (activeItem) {
        let activeIndex = activeItem.dataset.order;
        let clickItem = this.items[clickIndex - 1];
        if (activeIndex === clickIndex) {
          return;
        }
        activeItem.classList.remove('active');
        clickItem.classList.add('active');
        this._setStyle(clickItem, activeItem);
      }
    },
    _setStyle(el1, el2) {
      let transform1 = el1.style.transform;
      let transform2 = el2.style.transform;
      el1.style.transform = transform2;
      el2.style.transform = transform1;
    },
    switchBg(idx) {
      let _newIdx = this.currBgIndex + idx;
      if (_newIdx > this.maxBgCount) {
        _newIdx = 1;
      } else if (_newIdx < 1) {
        _newIdx = this.maxBgCount;
      }
      this.currBgIndex = _newIdx;
    },
    signOut: function () {
      this.$emit('eventSignout');
    }
  },
  mounted() {
    this.initStyle();
    this.getIsLoop = this.loop;
    let _token = this.$route.params.token;
    if (_token) {
      localStorage.setItem('signInfo', _token);
    }
  }
};
</script>

<style lang="less" scoped>
@panelHeight: calc(100vh - 96px);
@panelWidth: calc(100vw - 140px);
@barHeight: calc(100vh - 32px);

.dashboard {
  position: absolute;
  width: 100vw;
  height: 100vh;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-size: 100% 100% !important;

  .rptHeader {
    display: flex;
    flex-direction: row;
    height: 32px;
    width: 100vw;
    margin: 0;
    padding: 0;
    font-size: 12px;
    font-weight: 100;
    color: #FFF;
    background-color: rgba(32, 32, 35, 0.6);

    .headerItem {
      height: 32px;
      line-height: 32px;
      display: inline-block;
      text-align: center;
      cursor: pointer;
    }
    .headerItem:nth-child(1) {
      padding: 0 12px;
    }
    .headerItem:nth-last-child(1) {
      width: 64px;
    }
    .headerItem:hover {
      background-color: #4D4546;
    }
  }

  .flex-container.column {
    position: relative;
    width: @panelWidth;
    height: @panelHeight;
    line-height: @panelHeight;
    top: 32px;
    // left: -70px;
    text-align: center;
    overflow: hidden;
    margin: 0;
    box-sizing: content-box;

    .item {
      padding: 0px;
      margin: 0px;
      width: 68%;
      height: 100%;
      position: absolute;
      transform: scale(0.33);
      text-align: center;
      transition: all 0.8s;
      background: rgba(32, 32, 35, 0.5);
    }

    .active {
      height: 100%;
      width: 69%;
      margin-left: 10px;
      line-height: 300px;
    }
  }

  .switchllBar::before {
      position: absolute;
      display: inline-block;
      content: '';
      width: 60px;
      height: @barHeight;
      line-height: @barHeight;
      top: 32px;
      font-size: 3rem;
      font-weight: 700;
      font-variant: normal;
      -webkit-font-smoothing: antialiased;
      transition: all 1s ease-out;
      color: #fff;
      background-color: #f2f2f2;
      opacity: 0;
      cursor: pointer;
  }
  .leftBar::before {
      content: '《';
      left: 0;
      padding-right: 20px;
  }
  .rightBar::before {
      content: '》';
      right: 0;
      padding-left: 20px;
  }
  .switchllBar:hover::before {
    background-color: rgba(0, 0, 0, .5);
    opacity: 1;
  }
}
</style>
