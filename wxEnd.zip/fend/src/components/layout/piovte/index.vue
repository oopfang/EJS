<template>
<div class="container-fluid">
  <row v-if="dataSource.itemsSource" class="row">
    <Col :width="6">
    <wj-pivot-panel :items-source="getData"></wj-pivot-panel>
    </Col>
    <Col :width="18">
    <wj-pivot-grid :items-source="getData"></wj-pivot-grid>
    </Col>
  </row>
</div>
</template>

<script>
import '@grapecity/wijmo.vue2.grid';
import * as wjcOlap from '@grapecity/wijmo.olap';

export default {
	props: {
		dataSource: {
			type: Object,
			default() {
				return {};
			}
		}
	},
	computed: {
		getData() {
			let { itemsSource = [], valueFields = [], rowFields = [], showRowTotals, showColumnTotals } = this.dataSource;
			let _obj = {
				itemsSource, 
				valueFields, 
				rowFields,
			};
			if (showRowTotals) {
				_obj.showRowTotals = showRowTotals;
			}
			if (showColumnTotals) {
				_obj.showColumnTotals = showColumnTotals;
			}
			let data = new wjcOlap.PivotEngine(_obj);
			return data;
		}
	},
  mounted() {
    // this.ng.fields.getField('Amount').format = 'c0';
    // this.ng.fields.getField('Date').format = 'yyyy';
  }
};
</script>


<style lang="less" scoped>
.wj-pivotgrid {
	height: 80vh;
	box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
}

.wj-pivotpanel {
	height: 80vh !important;
}

.wj-pivotpanel table .wj-flexgrid {
	height: 8vh !important;
}
</style>