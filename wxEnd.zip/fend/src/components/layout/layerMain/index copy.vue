<template>
<div class="appWrapper">
  <smpoo v-if="getSmpoo" @closeAffir="closeSmpoo"></smpoo>
  <div class="appHeader">
    <div :style="{ '--bg-logo': getLogo }" class="logoPanel" @dblclick="showSmpooFunc3"></div>
    &nbsp;&nbsp;&nbsp;&nbsp;<Breadcrumb :datas="breadData"></Breadcrumb>
    <span class="breadStyle" v-for="item of getBreadData" :key="item.route" @click="gotoBread(item)"><i v-if="item.icon" :class="item.icon"></i>&nbsp;{{ item.title }}</span>
    <div class="flexSplit" @dblclick="showSmpooFunc2"></div>
    <div>
      <DropdownCustom trigger="hover">
        <span class="h-tag-circle h-tag-bg-primary">{{ getUserInfo.namezh[0] }}</span><span>{{ getUserInfo.code }}</span>
        <div slot="content" v-width="200">
          <div v-padding="20">
            <img :width="80" :height="80" style="border-radius:80px;float:left" :src="getUserInfo.avatar">
            <div style="height:80px;margin-left:90px;line-height:80px;" class="text-ellipsis">{{ getUserInfo.namezh }}</div>
          </div>
          <Row style="line-height:40px;border-top:1px solid #EEE;">
            <Col width=12 class="text-center" style="border-right:1px solid #EEE;" @click.native.stop="setProfile"><a>个人信息</a></Col>
            <Col width=12 class="text-center" @click.native.stop="signOutHandel"><a>注销</a></Col>
          </Row>
        </div>
      </DropdownCustom>
    </div>
  </div>
  <div class="appContent">
    <div class="menuContent">
      <div class="navPart">
        <tmenu v-show="showMenu" :menus="getMenus"></tmenu>
      </div>
      <div class="infoPart" @dblclick="showSmpooFunc1">
        <div class="small-font smallsize-font">
          <p class="rightFooter"></p>
        </div>
      </div>
    </div>
    <div id="bizContent" ref="bizContent" class="bizContent flexSplit" @scroll="wrappScroll">
      
      <transition name="tframAppTrans" enter-active-class="animated zoomIn" leave-active-class="animated bounceOutLeft" mode="out-in" :duration="{ enter: 350, leave: 200}">
        <router-view></router-view>
      </transition>
      <!-- 返回顶部 -->
      <div class="gotoTop" :class="{ hide: showGotoTop }" :style="gotoTopStyle" @click.prevent.stop="gotoTop">
        <tIcon icon="h-icon-top"></tIcon>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import tmenu from '../../widge/tmenu';
import tIcon from '../../widge/tIcon';
import preDefine from '@/tModules/utility/preDefine';
import smpoo from '@/components/widge/copyRight.vue';
import {
  mapGetters,
  mapMutations,
  mapActions
} from 'vuex';
/* eslint-disable no-unused-vars */
let copyTimmer = null;

export default {
  name: 'layermain',
  components: {
    tmenu,
    tIcon,
    smpoo
  },
  data() {
    return {
      breadData: [],
      // 是否显示菜单
      showMenu: true,
      showSmpoo: 0,
      showGotoTop: false
    };
  },
  computed: {
    ...mapGetters(['getSliderRithShown', 'getMenus', 'getUserInfo', 'getBizDefine', 'getBreadData']),
    getLogo() {
      return 'url(static/img/logo.png?v=8.0)';
    },
    gotoTopStyle: function () {
      let _str = this.showGotoTop ? 'show' : 'hide';
      return {
        visibility: this.showGotoTop ? 'visible' : 'hidden',
        animation: `ani-${_str} 0.3s linear`,
        transition: 'all 0.3s ease-in-out',
        '-webkit-transition': 'all 0.3s ease-in-out',
        '-moz-transition': 'all 0.3s ease-in-out',
        '-o-transition': 'all 0.3s ease-in-out',
        '-ms-transition': 'all 0.3s ease-in-out'
      };
    },
    getSmpoo() {
      return this.showSmpoo === 100;
    }
  },
  methods: {
    ...mapMutations(['setBizDefine']),
    ...mapActions(['signOut', 'tomorrow']),
    toggleFullScreen: function () {
      this.$refs['fsSliderR'].toggle();
    },
    fullscreenChange(fullscreen) {
      this.fullscreen = fullscreen;
    },
    setProfile: function () {
      this.$router.push({
        name: 'profile'
      });
    },
    wrappScroll: function () {
      this.showGotoTop = this.$refs.bizContent.scrollTop > 200;
    },
    gotoBread(item) {
      if (item.name) {
        this.$router.push({
          name: item.name
        });
      }
    },
    gotoTop: function () {
      this.$nextTick(() => {
        document.getElementById('bizContent').scrollTop = 0;
      });
    },
    clearFunc: function () {
      let _storeM = this.$store._mutations;
      for (let v of Object.keys(_storeM)) {
        if (v.startsWith('clearCache')) {
          _storeM[v][0]();
        }
      }
      this.setBizDefine({});
    },
    signOutHandel: function () {
      let x = {
        id: this.getUserInfo.id,
        code: this.getUserInfo.code,
        namezh: this.getUserInfo.namezh
      };
      this.signOut(x)
        .then(res => {
          global.tinfo('已退出登陆');
          this.$router.push({
            name: 'sign'
          });
        })
        .catch(err => {
          global.terr(err);
          this.$router.push({
            name: 'sign'
          });
        });
      this.clearFunc();
    },
    showSmpooFunc1(e) {
      this.showSmpoo = 30;
      let _that = this;
      copyTimmer = setTimeout(() => {
        if (_that.showSmpoo < 60) {
          _that.showSmpoo = 0;
          copyTimmer = null;
        }
      }, 3000);
    },
    showSmpooFunc2(e) {
      if (this.showSmpoo === 30) {
        this.showSmpoo = 60;
        let _that = this;
        copyTimmer = setTimeout(() => {
          if (_that.showSmpoo < 100) {
            _that.showSmpoo = 0;
          }
        }, 3000);
      }
    },
    showSmpooFunc3(e) {
      if (this.showSmpoo === 60) {
        this.showSmpoo = 100;
      }
    },
    closeSmpoo() {
      this.showSmpoo = 0;
      copyTimmer = null;
    }
  },
  created() {
    this.$root.eventHub.$on('switchMenu', e => {
      this.showMenu = e;
    });
    this.$root.eventHub.$on('gotop', e => {
      this.gotoTop();
    });
  },
  mounted() {
    let _bizDef = this.getBizDefine;
    if (!_bizDef || !Object.keys(_bizDef).length) {
      let _bizDefine = preDefine(require.context('@/define', true, /\.js$/));
      this.setBizDefine(_bizDefine);
    }
    this.tomorrow()
      .then(res => {
        global.tinfo('登陆成功');
      })
      .catch(err => {
        global.terr(err);
        this.$router.push({
          name: 'sign'
        });
      });
  },
  beforeDestroy() {
    if (!this.$route.name === 'reportWall') {
      this.clearFunc();
    }
  }
};
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';
// 除去左侧菜单栏后的工作区剩余宽度
@workZoneWidth: calc(100vw - @menuWidth);
// 除去顶部后的工作区剩余高度
@workZoneHeigh: calc(100vh - @headerHeight);
@widthSlideR: 55vw;

.appWrapper {
  position: absolute;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background-color: #fff;

  .appHeader {
    position: absolute;
    display: flex;
    right: 0;
    left: 0;
    width: 100%;
    height: @headerHeight;
    line-height: @headerHeight;
    flex-direction: row;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;

    .logoPanel {
      // width: 181px;
      width: 239px;
      height: @headerHeight;
      background: transparent var(--bg-logo) center center no-repeat;
      background-size: cover;
    }

    .breadStyle {
      margin-right: 8px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;

      &:hover {
        color: orange;
      }

      &:not(:first-child) {
        &::after {
          content: '\\';
          position: relative;
          right: 0;
          margin-left: 18px;
        }
      }
    }

    .appTitle {
      padding-left: 20px;
      height: @headerHeight;
      line-height: @headerHeight;
      font-size: 24px;
      color: @primary-color;
      text-decoration: none;
      outline: none;
      transition: color 0.2s ease;
    }
  }

  .appContent {
    display: flex;
    flex-direction: row;
    height: @workZoneHeigh;

    .menuContent {
      margin-top: @headerHeight;
      padding-top: 20px;
      height: 100%;
      // border-right: 1px #C6DBC0 solid;
      box-sizing: border-box;
      background-color: @menuBgColor;
      overflow-y: auto;
      transition: all .3s ease-in-out;
      
      z-index: 1;

      .navPart {
        width: 100%;
        height: 90%;
        padding: 0;
        overflow-y: auto;

        &::-webkit-scrollbar {
          display: none;
        }
      }

      .infoPart {
        position: absolute;
        bottom: 0;
        left: 0;
        width: @menuWidth;
        height: 60px;
        padding: 0;
        text-align: center;
        background-image: linear-gradient(30deg,
            rgba(255, 123, 48, 0.2) 25%,
            transparent 0,
            transparent 75%,
            rgba(255, 123, 48, 0.2) 0),
          linear-gradient(60deg,
            rgba(255, 123, 48, 0.2) 25%,
            transparent 0,
            transparent 75%,
            rgba(255, 123, 48, 0.2) 0);

        div {
          width: calc(@menuWidth / 0.8);
          text-align: center;

          p.rightFooter {
            padding: 0;
            margin: 10px;

            &::after {
              content: 'Power by \AtFrame v8 HAYA';
              position: relative;
              padding-top: 100px;
              white-space: pre-wrap;
              font-size: 10px;
              font-weight: 100;
              color: #fff;
              text-shadow: 4px 4px 19px orange;
            }
          }
        }
      }

      &:hover {
        box-shadow: 2px 2px 14px 0 rgb(99, 100, 146);
      }
    }

    .rightPanelShow {
      position: absolute;
      top: @headerHeight;
      width: @widthSlideR;
      height: @workZoneHeigh;
      right: 0;
      overflow: hidden;
      box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2),
        0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12) !important;
      transition: all 0.25s ease-out;
      background-color: #fff;
      z-index: 99;
    }

    .inHide {
      right: -@widthSlideR;
    }

    .bizContent {
      height: 100%;
      margin-top: 50px;
      padding: @workPanlePadding;
      overflow-x: hidden;
      overflow-y: auto;

      .gotoTop {
        position: absolute;
        width: 32px;
        height: 32px;
        line-height: 32px;
        bottom: 20px;
        right: 28px;
        text-align: center;
        cursor: pointer;
        z-index: 9999;
        border-radius: 2px;
        box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 3px;
        transition: all 0.25s ease-out;
        color: #fff;
        background-color: rgba(0, 0, 0, 0.5);
      }
    }
  }
}
</style>
