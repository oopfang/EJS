<template>
<div class="authSubContent accWrapper">
  <!-- 账号管理 -->
  <div class="h-input h-input-prefix-icon" style="width: 100%;">
    <input type="text" v-model="accFilterWord" placeholder="输入即筛选，支持账号code或账号名称" />
    <i class="h-icon-search" style="top: 16px !important;"></i>
  </div>
  <transition-group class="accList" tag="ul" enter-active-class="animated flipInx" leave-active-class="animated bounceOutRight" mode="out-in">
    <li v-for="(item, index) in getAccList" :key="item.code">
      <div class="accContent">
        <div class="cellBlock">
          <img :src="getAvatar(item.gender)" height="32" width="32">
        </div>
        <div class="flexSplit">
          <Row v-show="currAccEditId !== item.id">
            <Col :width="4">
            <span class="userNameTag mostBlack">{{ item.code }}&nbsp;&nbsp;[&nbsp;{{ item.namezh }}&nbsp;]</span>
            </Col>
            <Col :width="16">
            <p>
              <span v-for="(itemOrg, indexOrg) of getOrgName(item.oid)" :key="indexOrg" class="h-tag h-tag-gray">{{ itemOrg.namezh }}</span>
            </p>
            </Col>
            <Col :width="4">{{ $root.$data._dict.gender[item.gender].title }}</Col>
            <Col :width="24">
            <p style="border-top: 1px #ddd dashed; margin-top: 2px; padding-top: 2px;">
              <span class="roleBlock" v-for="(itemRol, indexRol) in item.roleName" :key="indexRol">{{ getRoleName(itemRol) }}</span>
            </p>
            </Col>
          </Row>
          <div v-show="currAccEditId === item.id" class="accRow">
            {{ item.namezh }}
            <div class="flexSplit">
              <ul class="roleAlready">
                <li class="roleInEdit" v-for="(itemNewRole, indexNewRole) in roleCache" :key="indexNewRole">
                  {{ itemNewRole.namezh }}&nbsp;
                  <tIcon v-show="getCanDelRole(item.code, itemNewRole.id)" icon="h-icon-close" :size="12" @click.native.stop="removeRoleItem(indexNewRole)"></tIcon>
                </li>
                <li class="addRoleBtn" @click.prevent.stop="showRoleListModal = true">
                  <tIcon icon="h-icon-plus" :size="12" :height="32"></tIcon>
                </li>
              </ul>
            </div>
            <Button color="primary" @click.prevent.stop="confirmResetRole(item.id)">确定</Button>
            <Button :no-border="true" @click.prevent.stop="changeRole(-1, -1)">取消</Button>
          </div>
        </div>
        <div class="cellBlock">
          <span v-if="!item.stopped" v-show="currAccEditId !== item.id" class="spanBtn reRoleState" @click.prevent.stop="changeRole(index, item.id)">变更角色</span>
          <span v-if="!item.stopped" v-show="currAccEditId !== item.id && (item.code !== 'admin' && item.code !== 'auth')" class="spanBtn reRoleState" @click.prevent.stop="resetUserPwd(item.id)">重置密码</span>
        </div>
        <span v-show="currAccEditId !== item.id && (item.code !== 'admin' && item.code !== 'auth')" v-if="!item.stopped" class="cellBlock spanBtn stopState" @click.prevent.stop="confirmStop(item.id, false)">封停</span>
        <span v-show="currAccEditId !== item.id && (item.code !== 'admin' && item.code !== 'auth')" v-else class="cellBlock spanBtn startState" @click.prevent.stop="confirmStop(item.id, true)">启用</span>
      </div>
    </li>
  </transition-group>
  <!-- 备选角色弹窗 -->
  <Modal v-model="showRoleListModal" :middle="true" className="roleTobeWrapper">
    <p slot="header">角色列表</p>
    <transition-group class="roleTobeList" enter-active-class="animated zoomIn" leave-active-class="animated zoomOut">
      <li v-for="item in getRoleList" :key="item.code" @click.prevent.stop="addRoleItem(item)">{{ item.namezh }}</li>
    </transition-group>
  </Modal>
</div>
</template>

<script>
import tPanel from '@/components/wrapper/part/tPanel';
import tIcon from '@/components/widge/tIcon';
import urlConfig from '@/config/config.json';
import {
  mapActions
} from 'vuex';

export default {
  name: 'accountMgr',
  components: {
    tPanel,
    tIcon
  },
  props: {
    // 账号数据集
    accountData: {
      type: Array,
      default: []
    },
    // 角色数据集
    roleList: {
      type: Array,
      default: []
    },
    orgsList: {
      type: Object,
      default: {}
    },
    orgType: {
      type: Object,
      default: {}
    }
  },
  data: function () {
    return {
      // 当前鼠标指向的的账号ID
      currAccId: {},
      // 进行账号角色变更的ID
      currAccEditId: -1,
      // 账号过滤字符
      accFilterWord: '',
      // 角色变更缓存
      roleCache: [],
      // 显示角色备选弹窗
      showRoleListModal: false,
      // 用户头像前缀地址
      baseUrl: urlConfig.ImgBaseUrl
    };
  },
  computed: {
    // 获取账号列表
    getAccList: function () {
      if (this.accFilterWord) {
        let _wd = this.accFilterWord;
        return this.accountData.filter(v => {
          return v.code.includes(_wd) || v.namezh.includes(_wd);
        });
      } else {
        return this.accountData;
      }
    },
    // 获取待选的角色列表
    getRoleList: function () {
      let _arr = this.roleCache.map(v => `${v.id}`);
      return this.roleList.filter(v => {
        let _b = _arr.includes(`${v.id}`);
        return !_b;
      });
    }
  },
  methods: {
    ...mapActions(['querAuth', 'accForbidden', 'accRePwd', 'resetRole']),
    // 获取用户头像地址
    getAvatar: function (gender) {
      return `static/img/userHeader${gender || 0}.png?v=8.0`;
    },
    // 获取组织名称
    getOrgName: function (oid) {
      let _arr = [];
      if (this.orgType && oid) {
        let _idArr = oid.split(',');
        let _that = this;
        _arr = _idArr.map(v => {
          let _currOgr = _that.orgsList[`${v}`];
          let _str1 = _currOgr.namezh;
          let _str2 = _that.orgType[`${_currOgr.organtypeid}`].namezh;
          return {
            id: v,
            namezh: `(${_str2})${_str1}`
          };
        });
      }
      return _arr;
    },
    // 获取渠道名称
    getChannelName: function (id) {
      if (this.$root.$data._dict && this.$root.$data._dict.channel) {
        return this.$root.$data._dict.channel[id].namezh;
      } else {
        return '';
      }
    },
    // 获取角色名称
    getRoleName: function (id) {
      if (id && this.roleList) {
        let _idx = this.roleList.findIndex(v => {
          return `${v.id}` === `${id}`;
        });
        if (_idx > -1) {
          return this.roleList[_idx].namezh;
        } else {
          return '';
        }
      } else {
        return '';
      }
    },
    // 获取当前角色是否可删除的标识
    getCanDelRole: function (code, id) {
      if (code === 'admin' && `${id}` === '1') {
        return false;
      } else if (code === 'auth' && `${id}` === '2') {
        return false;
      } else if (code !== 'admin' && code !== 'auth' && `${id}` === '3') {
        return false;
      } else {
        return true;
      }
    },
    // 账号封停确认
    confirmStop: function (id, result) {
      let _msg = !result ? '封停' : '启用';
      /* eslint-disable handle-callback-err */
      this.$Confirm(`是否${_msg}该账号？`, '请确认')
        .then(() => {
          let x = {
            id: id,
            isStop: result ? 0 : 1
          };
          this.accForbidden(x)
            .then(res => {
              let _idx = this.accountData.findIndex(v => v.id === id);
              this.accountData[_idx].stopped = result ? 0 : 1;
              let _obj = this.accountData[_idx];
              global.tinfo(`账号[ ${_obj.code}: ${_obj.namezh} ]被${_msg}`);
            })
            .catch(err => {
              global.terr(err);
            });
        })
        .catch(err => {
          global.twarn('操作取消！', false);
        });
    },
    // 对指定账号重置密码
    resetUserPwd: function (id) {
      let _idx = this.accountData.findIndex(v => v.id === id);
      let _obj = this.accountData[_idx];
      let _msg = `[ ${_obj.namezh} ]`;
      if (_idx > -1) {
        this.$Confirm(`是否重置账号${_msg}的密码？`, '请确认')
          .then(() => {
            let x = {
              id: id
            };
            this.accRePwd(x)
              .then(res => {
                global.tinfo(`账号${_msg}的密码成功重置为初始化`);
              })
              .catch(err => {
                global.terr(err, false);
              });
          })
          .catch(err => {
            global.terr(err);
          });
      }
    },
    // 从当前账号的角色标签中移除指定角色
    removeRoleItem: function (idx) {
      this.roleCache.splice(idx, 1);
    },
    // 对当前账号添加角色项
    addRoleItem: function (item) {
      this.roleCache.push(item);
      if (this.getRoleList.length === 0) {
        this.showRoleListModal = false;
      }
    },
    // 变更角色
    changeRole: function (idx, id) {
      this.currAccEditId = id;
      if (id > 0) {
        this.roleCache = this.accountData[idx].roleId.split(',').map(v => {
          return {
            id: v,
            namezh: this.getRoleName(v)
          };
        });
      } else {
        this.roleCache = [];
      }
    },
    // 账号角色变更执行
    confirmResetRole: function (id) {
      /* eslint-disable handle-callback-err */
      this.$Confirm('是否变更该账号的角色？', '请确认')
        .then(() => {
          let _idx = this.accountData.findIndex(v => `${v.id}` === `${id}`);
          if (_idx > -1) {
            let _obj = this.accountData[_idx];
            let _newRoleStr = this.roleCache.map(v => v.id).sort((a, b) => {
              return parseInt(a) - parseInt(b);
            }).join(',');
            let x = {
              id: _obj.id,
              roleStr: _newRoleStr
            };
            this.resetRole(x)
              .then(res => {
                this.accountData[_idx].roleId = _newRoleStr;
                this.accountData[_idx].roleName = this.roleCache.sort((a, b) => {
                  return parseInt(a) - parseInt(b);
                }).map(v => `${v.id}`);
                this.roleCache = [];
                global.tinfo(`账号 [ ${_obj.code}: ${_obj.namezh} ] 的角色修成功`);
              })
              .catch(err => {
                global.terr(err);
              });
          }
          this.currAccEditId = -1;
        })
        .catch(err => {
          global.twarn('操作取消！', false);
        });
    }
  }
};
</script>

<style lang="less" scoped>
.accWrapper {
  .accList {
    li {
      padding: 12px 18px;
      margin: 12px 0;
      font-weight: 100;
      background-color: #fff;
      cursor: pointer;

      p {
        font-weight: 700;
        text-shadow: 2px 2px 8px #ccc;

        span.timeDate {
          margin-right: 18px;
          font-weight: 100;
        }
      }

      p.noWorkFlow {
        color: #ccc;
      }
    }

    .accContent {
      display: flex;
      flex-direction: row;
      min-height: 48px;

      .accRow {
        margin-top: 7px;
        display: flex;
        justify-content: center;
        align-items: center;

        div {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }

      .cellBlock {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;

        img {
          margin-right: 32px;
          border-radius: 30px;
        }
      }

      .spanBtn {
        padding: 0 16px;
        margin: 0 4px;
        font-weight: 700;
        text-shadow: 2px 2px 8px #ccc;
        cursor: pointer;
      }

      .spanBtn:hover {
        color: #fff;
      }

      .reRoleState {
        width: 100%;
        height: 50%;
      }

      .reRoleState:hover {
        background-color: orange;
      }

      .stopState {
        background-color: orangered;
      }

      .startState {
        background-color: yellowgreen;
      }

      .roleBlock {
        margin-right: 16px;
        padding: 8px 12px;
        background: #e5e5e5;
        border-left: 3px #888 solid;
      }

      .roleAlready {
        list-style: none;
        width: 100%;
        min-width: 100%;
        padding: 0 18px;

        li {
          margin: 4px 8px;
        }

        li.roleInEdit {
          display: inline-block;
          height: 32px;
          line-height: 32px;
          padding: 0 0 0 6px;
          border-left: 3px #131138 solid;
          border-top-left-radius: 2px;
          border-bottom-left-radius: 2px;
          background-color: #cbcbda;

          i {
            padding: 0 8px;
            margin: -4px 0 0 0;
            background-color: #9696af;
          }

          i:hover {
            color: #fff;
            background-color: #131138;
          }
        }

        li.addRoleBtn {
          display: inline-block;
          padding: 0 8px;
          background-color: #9696af;
        }

        .addRoleBtn:hover {
          color: #fff;
          background-color: #131138;
        }
      }
    }
  }
}

// 备选角色列表弹窗
.roleTobeWrapper {
  width: 30%;

  p {
    padding: 8px 12px;
    text-align: center;
    font-weight: 700;
    text-shadow: 2px 2px 8px #ccc;
  }

  .roleTobeList {
    display: flex;
    flex-direction: row;
    max-width: 600px;
    list-style: none;
    padding: 18px;
    justify-content: center;

    li {
      display: inline-block;
      width: 20px;
      max-width: 20px;
      padding: 8px 18px 8px 8px;
      word-wrap: break-word;
      letter-spacing: 10px;
      text-align: center;
      font-size: 12px;
      cursor: pointer;
    }

    li:hover {
      background-color: orange;
    }
  }
}
</style>
