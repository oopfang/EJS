<template>
	<div class="demoWrapper">
		<div class="addBtn" @click="addDemo">创建基础资料演示数据</div>
		<div class="addBtn" @click="addDemoInvt">创建库存演示数据</div>
	</div>
</template>

<script>
import { mapActions } from 'vuex';

export default {
	methods: {
		...mapActions(['setDemo', 'setDemoInvt']),
		async addDemo() {
			try {
				await this.setDemo();
				this.$Message({
					text: '演示数据创建成功'
				});
			} catch (err) {
				this.$Message({
					type: 'error',
					text: '演示数据创建失败'
				});
			}
		},
		async addDemoInvt() {
			try {
				await this.setDemoInvt();
				this.$Message({
					text: '演示数据创建成功'
				});
			} catch (err) {
				this.$Message({
					type: 'error',
					text: '演示数据创建失败'
				});
			}
		}
	}
}
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';

.demoWrapper {
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 85vh;

	.addBtn {
		padding: 18px;
		border: 1px #eee solid;
		cursor: pointer;

		&:hover {
			background-color: @primary-color;
		}
	}
}
</style>