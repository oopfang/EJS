<template>
<Row class="authSubContent approWraper">
  <transition-group tag="div" enter-active-class="animated zoomIn" leave-active-class="animated zoomOut">
    <transition-group v-show="!showWorkFlowMx && !saveConfirm" class="flowRow" tag="ul" enter-active-class="animated bounceInLeft" leave-active-class="animated bounceOutRight" mode="out-in" key="appro1">
      <li key="bizFilterItem">
        <div class="h-input h-input-suffix-icon">
          <input type="text" v-model="filterWord" placeholder="输入即过滤..." style="width: 300px;"/>
          <i class="h-icon-error" @click.prevent.stop="filterWord=''"></i>
        </div>
      </li>
      <li v-for="(item, index) in getFlowMenu" :key="`sub${index}`" @click.prevent.stop="enterFlow(index)">
        <Row>
          <Col :width="4">{{ item.namezh }}</Col>
          <Col :width="4">
          <p v-if="item.seedBizCode">共分 {{ item.approAct.length }} 级审批</p>
          <p v-else class="noWorkFlow">无需审批</p>
          </Col>
          <Col :width="16" class="actRow">
          <span class="h-tag h-tag-bg-gray" v-for="(itemTag, indexTag) in item.approAct" :key="indexTag">{{ itemTag.title }}</span>
          </Col>
        </Row>
      </li>
    </transition-group>
    <div v-show="showWorkFlowMx && !saveConfirm" key="appro2">
      <tPanel showHeader class="panelEdit">
        <div slot="panelHeader">
          <Button color="gray" :circle="true" size="s">&nbsp;&nbsp;&nbsp;&nbsp;{{ getCurrBizObj.namezh }}&nbsp;&nbsp;&nbsp;&nbsp;</Button>
          <div class="flexSplit"></div>
          <Button v-show="needCommit" color="primary" @click="preSave">保存</Button>
          <Button :text="true" @click="enterFlow(-1)">关闭</Button>
        </div>
        <ul class="stepGroup">
          <li class="approBtn" @click.prevent.stop="setNodeStep(-1)">提交</li>
          <li class="approBtn" :class="{ active: currNodeIdx === index }" v-for="(item, index) in currNodes" :key="item.title" @click.prevent.stop="setNodeStep(index)">{{ item.title }}</li>
          <li class="addApproBtn flexSplit" @click.prevent.stop="addNode">添加节点</li>
          <li class="approBtn" @click.prevent.stop="setNodeStep(-1)">审毕</li>
        </ul>
      </tPanel>
      <div v-show="currNodeIdx > -1">
        <div class="stepNodeDesc">
          <span v-show="!inNodeTitleEdit" class="mostBlack">
           <span v-show="getCurrNode.roleObj.id > 0">[ {{ getCurrNode.roleObj.namezh }} ]&nbsp;&nbsp;|&nbsp;&nbsp;</span>{{ getCurrNodeTitle }}&nbsp;&nbsp;&nbsp;&nbsp;
          <tIcon icon="t-edit-pencil" :size="8" @click.native.stop="inNodeTitleEdit=true"></tIcon>
          </span>
          <div v-show="inNodeTitleEdit" class="h-input h-input-suffix-icon" style="padding-left: 18px;">
            <input type="text" v-model="getCurrNodeTitle" style="width: 300px;" @change="needCommit=true"/>
            <i class="h-icon-check" @click.prevent.stop="inNodeTitleEdit=false"></i>
          </div>
          <span class="flexSplit"></span>
          <div class="nodeCenter" v-show="!getCurrNode.showCondition">
            <Button @click="selectOrReRole">&nbsp;&nbsp;&nbsp;&nbsp;{{ getCurrNode.roleObj.id > 0 ? '更换' : '指派' }}角色&nbsp;{{ getCurrNode.roleObj.namezh ? `[ 当前：${getCurrNode.roleObj.namezh} ]` : '' }}&nbsp;&nbsp;&nbsp;&nbsp;</Button>&nbsp;&nbsp;
            <SwitchList v-show="getCurrNode.roleObj.id > 0" v-model="switchNodeType" :datas="currEnum.nodeType"></SwitchList>
          </div>
          <span class="flexSplit"></span>
          <ButtonGroup :circle="true" size="s">
            <Button v-if="getCurrNode.roleObj.id > 0 && !getCurrNode.showCondition" @click="getCurrNode.showCondition = true">&nbsp;&nbsp;查看条件&nbsp;&nbsp;</Button>
            <Button v-if="getCurrNode.roleObj.id > 0 && getCurrNode.showCondition" @click="getCurrNode.showCondition = false">&nbsp;查看审批人&nbsp;</Button>
            <Button @click="delCurrNode">&nbsp;&nbsp;删除节点&nbsp;&nbsp;</Button>
          </ButtonGroup>&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
        <!-- 为当前节点选择角色的弹窗 -->
        <Modal v-model="inRoleSelect" middle>
          <div class="mostBlack" slot="header">请为该节点选择审批角色</div>
          <ul class="roleSelectPanel" @mouseout="currHoverRoleIdx=-1">
            <li v-for="(item, index) in getRoleList" :key="item.code" @click.prevent.stop="setRole(item)" @mouseover="currHoverRoleIdx=index">
              {{ item.namezh }}
              <span class="flexSplit"></span>
              <Button v-show="currHoverRoleIdx===index" color="primary" size="s" :circle="true" @click="setRole(item)">选定</Button>
            </li>
          </ul>
          <div slot="footer"><button class="h-btn" @click="inRoleSelect=false">取消</button></div>
        </Modal>
        <transition-group v-show="currNodeIdx > -1 && getCurrNode.roleObj.id > 0 && !getCurrNode.showCondition" class="branchList" tag="ul" enter-active-class="animated bounceInLeft" leave-active-class="animated bounceOutRight" mode="out-in">
          <li v-for="(item, index) in getCurrNode.users" :key="`user${index}`" :class="{ onlyUser: getCurrNode.nodeType === 'only' && item.checked, handCursor: getCurrNode.nodeType === 'only' }" @click.prevent.stop="switchOnlyUser(index)">
            <tIcon v-show="getCurrNode.nodeType === 'only' && item.checked" icon="h-icon-check" :size="12" :height="24" color="green" bold></tIcon>
            <span>&nbsp;&nbsp;&nbsp;&nbsp;{{ item.namezh }}</span>
            <span v-show="getCurrNode.nodeType !== 'only'" class="nodeBranchCell flexSplit">第 {{ currNodeIdx + 1 }} 级，第 {{ index + 1 }} 个审批人</span>
            <span v-show="getCurrNode.nodeType === 'only' && item.checked" class="nodeBranchCell flexSplit">第 {{ currNodeIdx + 1 }} 级，<b class="mostBlack">[ {{ getCurrNode.title }} ] 节点的唯一审批人</b></span>
            <ButtonGroup v-show="getCurrNode.nodeType !== 'only'" :circle="true" size="s">
              <Button @click="delApproUser(item.id)">删除审批人</Button>
            </ButtonGroup>&nbsp;&nbsp;&nbsp;&nbsp;
          </li>
        </transition-group>
        <Row v-show="currNodeIdx > -1 && getCurrNode.roleObj.id > 0 && getCurrNode.showCondition">
          <Col :width="8">
          <ul class="branchList">
            <li class="conditionTitle">业务信息</li>
            <li v-for="item in getBizInfo" :key="item.code" @click.prevent.stop="addFieldToCondition(item)">
              {{ item.namezh }}
              <span class="flexSplit"></span>
              <Button icon="h-icon-right" @click="addFieldToCondition(item)"></Button>
            </li>
          </ul>
          </Col>
          <Col :width="16">
          <transition-group class="branchList" tag="ul" enter-active-class="animated bounceInLeft" leave-active-class="animated bounceOutRight" mode="out-in">
            <li class="conditionInfo" v-for="(item, index) in getCondition" :key="`cdt${index}`">
              {{ item.namezh }}
              <span class="flexSplit"></span>
              <Select v-model="item.symbol" :datas="symbols" :nullOption="false" style="width: 100px;" @input="needCommit=true"></Select>
              <span class="flexSplit"></span>
              <div v-if="item && item.valueTobe">
                <Select v-if="item.valueTobe.length > 0 && item.valueTobe[0].id" v-model="item.value" :datas="item.valueTobe" keyName="id" titleName="namezh" :nullOption="false" style="width: 300px;" @input="needCommit=true"></Select>
                <div v-else class="h-input h-input-suffix-icon">
                  <input type="text" v-model="item.value" style="width: 300px;" @change="needCommit=true"/>
                  <i class="h-icon-menu" @click.prevent.stop="selectValue4Biz(item.code)"></i>
                </div>
              </div>
              <span class="conditionDel handCursor" @click.prevent.stop="reSelectValue(item.code)"><i class="t-reply"></i></tIcon></span>
              <span class="conditionDel handCursor" @click.prevent.stop="delFieldToCondition(item)"><i class="h-icon-close"></i></span>
            </li>
          </transition-group>
          <!-- 为当前条件选择值的弹窗 -->
          <Modal v-model="getConditionValFormState" middle :closeOnMask="false">
            <span class="h-tag h-tag-bg-primary" slot="header">请选择值来源对象</span>
            <ul class="roleSelectPanel">
              <li><input type="text" v-model="currFilterWordByBiz" placeholder="输入即过滤..." style="width: 100%;"/></li>
              <li v-for="item in getOrmListInConditionValForm" :key="item.code" @click.prevent.stop="selectFieldBy(item.code)">
                {{ item.namezh }}
                <span class="flexSplit"></span>
              </li>
            </ul>
            <div slot="footer"><button class="h-btn" @click="getConditionValFormState=false">取消</button></div>
          </Modal>
          </Col>
        </Row>
        <!-- 为当前节点选择唯一审批人的弹窗 -->
        <Modal v-model="inOnlyUserSelect" middle :closeOnMask="false">
          <span class="h-tag h-tag-bg-red" slot="header">请为该节点选择唯一审批人</span>
          <ul class="roleSelectPanel" @mouseout="currHoverRoleIdx=-1">
            <li v-for="item in getCurrNode.users" :key="item.code" @click.prevent.stop="setUser(index)" @mouseover="currHoverRoleIdx=index">
              {{ item.namezh }}
              <span class="flexSplit"></span>
              <Button v-show="currHoverRoleIdx===index" color="primary" size="s" :circle="true" @click="setUser(index)">选定</Button>
            </li>
          </ul>
          <div slot="footer"><button class="h-btn" @click="cancelOnlyUser">取消</button></div>
        </Modal>
      </div>
    </div>
    <div v-show="saveConfirm" class="panelConfirm" key="appro3">
      <div class="infoHeader">
        <div v-show="preSaveObj.checkAll" class="infoSymbol green">
          <tIcon icon="h-icon-check" color="#fff" :size="24" :height="24" bold></tIcon>
        </div>
        <div v-show="!preSaveObj.checkAll" class="infoSymbol red">
          <tIcon icon="h-icon-close" color="#fff" :size="24" :height="24" bold></tIcon>
        </div>
      </div>
      <p class="infoTitle mostBlack">业务：[ {{ getCurrBizObj.namezh }} ] 的预定节点如下：</p>
      <ul class="infoBody">
        <li class="nodeCard" v-for="(item, index) in currNodes" :key="item.title">
          <p>
            节点<span class="indexTag">{{ index + 1 }}</span>: &nbsp;&nbsp;
            {{ item.title }}
            <span class="flexSplit"></span>
            <span v-if="preSaveObj.checkNode[index]" class="checkTag" :style="{ 'background-color': preSaveObj.checkNode[index].check ? 'green' : 'red'}"><tIcon :icon="preSaveObj.checkNode[index].check ? 'h-icon-check' : 'h-icon-close'" color="#fff" :size="18" :height="42" bold></tIcon></span>
          </p>
          <p v-if="preSaveObj.checkNode[index] && !preSaveObj.checkNode[index].msg['1']"><span class="mostBlack">授予角色：</span>{{ item.roleObj.namezh }}&nbsp;&nbsp;[ {{ currEnum.nodeType[item.nodeType] }} ]模式</p>
          <p v-else-if="preSaveObj.checkNode[index] && preSaveObj.checkNode[index].msg['1']">
            <span class="errMsgTxt">{{ preSaveObj.checkNode[index].msg['1'] }}</span>
            &nbsp;&nbsp;[ {{ currEnum.nodeType[item.nodeType] }} ]模式
          </p>
          <p class="mostBlack">有效审批人包括：</p>
          <p v-if="preSaveObj.checkNode[index] && (preSaveObj.checkNode[index].msg['2'] || preSaveObj.checkNode[index].msg['3'])">
            <span v-if="!preSaveObj.checkNode[index].msg['2']">{{ preSaveObj.checkNode[index].msg['2'] }}</span>
            <span v-if="!preSaveObj.checkNode[index].msg['3']">{{ preSaveObj.checkNode[index].msg['3'] }}</span>
          </p>
          <ul v-else class="approUserList">
            <li v-for="(itemUser, indexUser) in item.users" :key="indexUser">{{ itemUser.namezh }}</li>
          </ul>
          <p class="mostBlack">节点触发条件为：</p>
          <ul class="approConditionList">
            <li v-for="(itemCdt, indexCdt) in getConditionArr(item.actCondition)" :key="indexCdt">
              {{ itemCdt.namezh }}&nbsp;&nbsp;{{ symbols[itemCdt.symbol] }}&nbsp;&nbsp;
              <span v-if="preSaveObj.checkNode[index] && !preSaveObj.checkNode[index].msg['4']">{{ (itemCdt.valueFrom && itemCdt.valueFrom.length > 0) ? itemCdt.valueTobe.find(v => v.id === itemCdt.value).namezh : itemCdt.value }}</span>
              <span v-else-if="preSaveObj.checkNode[index] && preSaveObj.checkNode[index].msg['4']" class="errMsgTxt">{{ preSaveObj.checkNode[index].msg['4'] }}</span>
            </li>
          </ul>
        </li>
      </ul>
      <p class="infoTitle">
        <Button v-show="preSaveObj.checkAll" color="primary" @click="saveFlow">保存</Button>
        <Button :text="true" @click="enterFlow(-1)">放弃</Button>
        <Button color="red" @click="saveConfirm=false">取消</Button>
      </p>
    </div>
  </transition-group>
</Row>
</template>

<script>
import tIcon from '@/components/widge/tIcon';
import tPanel from '@/components/wrapper/part/tPanel';
import tEnum from 'tframe-enum/enum/sys';
import {
  mapActions
} from 'vuex';
// 自定义审批条件时的过滤字段列表
let outFields = ['id', 'memo', 'stopped', 'deleted', 'createId', 'createby', 'changeby', 'byid', 'orderIndex', 'tLeft', 'tRight', 'approStep'];
let _defaultNode = () => {
  return {
    key: '',
    title: '',
    roleObj: {
      id: -1,
      namezh: ''
    },
    users: [],
    nodeType: 'any',
    actCondition: {},
    showCondition: false
  };
};
// 预定义检查报告的错误提示信息
const errMsg = {
  '1': '未指派角色',
  '2': '未选择审批人',
  '3': '“仅限”模式有且仅有一个选定审批人',
  '4': '未指定节点条件的值'
};

export default {
  name: 'flowMgr',
  components: {
    tIcon,
    tPanel
  },
  props: {
    ormData: {
      type: Object,
      default: {}
    },
    flowMenu: {
      type: Array,
      default: []
    },
    // 角色列表
    roleList: {
      type: Array,
      default: []
    },
    // 账号数据集
    accountData: {
      type: Array,
      default: []
    },
    // db中已存储的所有角色的菜单项
    roleMenuAll: {
      type: Object,
      default: function () {
        return {};
      }
    }
  },
  data: function () {
    return {
      // 页面列表筛选值
      filterWord: '',
      // 页面所需的权限枚举
      currEnum: tEnum,
      // 当前选择的菜单项在列表中的索引
      currMenuIdx: -1,
      // 当前页面的流程菜单集合
      currFlowMenu: [],
      // 当前进行编辑的节点集合
      currNodes: [],
      // 当前编辑的节点索引
      currNodeIdx: -1,
      // 当前选择的分支索引
      selectBranchIdx: -1,
      // 是否处于节点标题编辑模式
      inNodeTitleEdit: false,
      // 是否显示角色选择弹窗
      inRoleSelect: false,
      // 是否为仅限模式的当前节点显示选择弹窗
      inOnlyUserSelect: false,
      // 是否显示条件设值的弹窗
      inValSelectForm: false,
      // 条件选择窗中，过滤显示的值
      currFilterWordByBiz: '',
      // 条件选择窗中点击选定的业务对象的code
      currSelectCodeByBiz: '',
      // 当前节点条件项的正在编辑中的code值
      currCodeOfConditionInNode: '',
      // 当前hover的角色行
      currHoverRoleIdx: -1,
      // 需要保存的标志
      needCommit: false,
      // 是否显示保存前的确认
      saveConfirm: false,
      // 审批条件的有效符号
      symbols: {
        $eq: '等于',
        $lt: '小于',
        $lte: '小于等于',
        $gt: '大于',
        $gte: '大于等于'
      },
      // 流程预保存的结果集
      preSaveObj: {
        checkAll: true,
        checkNode: []
      }
    };
  },
  computed: {
    // 获取流程引擎可分配的菜单集
    getFlowMenu: function () {
      this.currFlowMenu = [];
      // 通过角色ID获取角色简要信息
      let _getRoleById = id => {
        let _emptyObj = {
          id: -1,
          namezh: ''
        };
        if (id) {
          let _obj = this.roleList.find(v => `${v.id}` === `${id}`);
          if (_obj) {
            return {
              id: id,
              namezh: _obj.namezh
            };
          } else {
            return _emptyObj;
          }
        } else {
          return _emptyObj;
        }
      };
      let _getConditionObj = item => {
        // let item = this.ormData[bizCode];
        return {
          code: item.code,
          namezh: item.namezh,
          symbol: item.symbol,
          valueFrom: item.valueFrom,
          value: item.value,
          valueTobe: item.valueTobe
        };
      };
      for (let v of this.flowMenu) {
        let _currV = null;
        if (this.filterWord) {
          if (v.namezh.includes(this.filterWord)) {
            _currV = v;
          }
        } else {
          _currV = v;
        }
        if (_currV) {
          _currV.approAct = [];
          if (_currV.seedBizCode) {
            let _arrKey = _currV.seedBizCode ? _currV.seedBizCode.split(',') : [];
            let _arrTitle = _currV.seedBizTitle ? _currV.seedBizTitle.split(',') : [];
            let _arrRoles = _currV.nodeRoles ? _currV.nodeRoles.split(',') : [];
            let _arrTypes = _currV.nodeTypes ? _currV.nodeTypes.split(',') : [];
            let _arrUsers = [];
            if (_currV.nodeUsers) {
              let _userL1 = _currV.nodeUsers.split('|');
              for (let vUser of _userL1) {
                if (vUser) {
                  let _userL2 = vUser.split(',');
                  _arrUsers.push(this.getUserInfoByid(_userL2));
                } else {
                  _arrUsers.push([]);
                }
              }
            }
            let _arrCondition = [];
            if (_currV.nodeConditions) {
              _currV.nodeConditions.split('@|@').forEach(vC => {
                if (vC) {
                  let _vcObj = {};
                  let _jsVc = JSON.parse(vC);
                  _vcObj[_jsVc.code] = _getConditionObj(_jsVc);
                  _arrCondition.push(_vcObj);
                }
              });
            }
            _arrKey.forEach((vCode, kCode, arrCode) => {
              let _node = _defaultNode();
              _node.key = vCode;
              _node.title = _arrTitle[kCode];
              _node.roleObj = _getRoleById(_arrRoles[kCode]);
              let _currUsers = _arrUsers[kCode] || [];
              _node.users = _currUsers;
              let _currType = _arrTypes[kCode];
              if (_currUsers) {
                if (_currType === 'only' && _currUsers.length === 1) {
                  _currUsers[0].checked = true;
                } else {
                  _currUsers.forEach(vCheck => {
                    vCheck.checked = false;
                  });
                }
              }
              _node.nodeType = _currType || 'any';
              _node.actCondition = _arrCondition[kCode] || {};
              _node.showCondition = false;
              _currV.approAct.push(_node);
            });
          }
          this.currFlowMenu.push(_currV);
        }
      }
      return this.currFlowMenu;
    },
    // 是否显示工作流定义细节面板
    showWorkFlowMx: {
      get() {
        return this.currMenuIdx > -1;
      },
      set(val) {
        this.currMenuIdx = val;
      }
    },
    // 获取当前要编辑工作流细节的业务对象
    getCurrBizObj: function () {
      if (this.currMenuIdx > -1) {
        let _obj = this.currFlowMenu[this.currMenuIdx];
        this.currNodes = _obj.approAct;
        return _obj;
      } else {
        return {
          namezh: '',
          approAct: []
        };
      }
    },
    // 获取当前编辑中的工作流节点信息
    getCurrNode: function () {
      if (this.currNodes.length > 0 && this.currNodeIdx > -1) {
        return this.currNodes[this.currNodeIdx];
      } else {
        return _defaultNode();
      }
    },
    // 获取或设置当前编辑中的工作流节点的标题
    getCurrNodeTitle: {
      get() {
        return this.getCurrNode.title;
      },
      set(val) {
        if (this.getCurrNode.title !== val) {
          this.getCurrNode.title = val;
          this.computed = true;
        }
      }
    },
    // 提供节点模式的绑定数据源
    switchNodeType: {
      get() {
        return this.getCurrNode.nodeType;
      },
      set(val) {
        if (val === 'only') {
          this.inOnlyUserSelect = true;
        } else {
          for (let v of this.getCurrNode.users) {
            v.checked = false;
          }
          this.getCurrNode.nodeType = val;
        }
        this.needCommit = true;
      }
    },
    // 获取可用的角色列表
    getRoleList: function () {
      // let _flMeuu = this.getFlowMenu;
      // let _allowMx = this.showWorkFlowMx;
      // let _roleAll = this.roleMenuAll;
      // let _currIdx = this.currMenuIdx;
      // let getRoleFilter = (roleId) => {
      //   if (_allowMx && _currIdx > -1) {
      //     let _ormObj = _flMeuu[_currIdx];
      //     if (_ormObj && _ormObj.id) {
      //       let _roleM = _roleAll[`role${roleId}`].rights[`r${_ormObj.id}`];
      //       return _roleM && _roleM.crudVal > 0;
      //     } else {
      //       return true;
      //     }
      //   } else {
      //     return true;
      //   }
      // };
      //  && getRoleFilter(v.id)
      return this.roleList.filter(v => v.code !== 'adminGroup' && v.code !== 'authKeeperGroup' && v.code !== 'userLimitGroup');
    },
    // 获取可用的用户列表
    getUserList: function () {
      let _arr = [];
      for (let v of this.accountData) {
        if (v.code !== 'admin' && v.code !== 'auth') {
          if (v.roleId) {
            v.roleIdList = v.roleId.split(',');
          } else {
            v.roleIdList = [];
          }
          v.checked = false;
          _arr.push(v);
        }
      }
      return _arr;
    },
    // 为当业务获取可设定条件的业务信息
    getBizInfo: function () {
      let _obj = this.ormData[this.getCurrBizObj.code];
      let _arr = (_obj && _obj.columns) || [];
      return _arr.filter(v => {
        return v.namezh && !outFields.includes(v.code);
      });
    },
    // 获取当前节点的可用执行条件
    getCondition: function () {
      let _obj = this.getCurrNode.actCondition;
      let _arr = [];
      if (_obj) {
        let _keys = Object.keys(_obj);
        for (let v of _keys) {
          _arr.push(_obj[v]);
        }
      }
      return _arr;
    },
    // 在条件设置的值选择弹窗中获取ORM对象集合
    getOrmListInConditionValForm: function () {
      let _arr = [];
      if (this.getConditionValFormState) {
        let _objArr = Object.keys(this.ormData);
        let _currCode = this.getCurrBizObj.code;
        for (let v of _objArr) {
          let _vObj = this.ormData[v];
          if (v === _currCode || this.currFilterWordByBiz) {
            _vObj = null;
          }
          if (_vObj) {
            _arr.push({
              code: v,
              ..._vObj
            });
          }
        }
      }
      return _arr;
    },
    // 为值选择弹窗绑定显示或隐藏状态
    getConditionValFormState: {
      get() {
        return this.inValSelectForm;
      },
      set(val) {
        // 关闭弹窗，或首次弹出置零
        if (!val || (!this.inValSelectForm && val)) {
          this.currSelectCodeByBiz = '';
        }
        this.inValSelectForm = val;
      }
    }
  },
  methods: {
    ...mapActions(['getRecordAsValue', 'setFlow']),
    selectOrReRole() {
      /* eslint-disable no-unused-vars */
      let x = this.getRoleList;
      this.inRoleSelect = true;
    },
    // 进入或退出流程细节设定面板
    enterFlow: function (idx) {
      this.currMenuIdx = idx;
      if (idx === -1) {
        this.currNodes = [];
        this.needCommit = false;
        this.currNodeIdx = -1;
        this.saveConfirm = false;
      }
      this.$emit('changeMenu', (idx === -1));
    },
    // 对当前业务添加流程节点
    addNode: function () {
      let _len = this.currNodes.length;
      let _node = _defaultNode();
      _node.key = `appro${_len}`;
      _node.title = `审批${_len}`;
      this.currNodes.push(_node);
      this.needCommit = true;
    },
    // 删除当前节点
    delCurrNode: function () {
      this.currNodes.splice(this.currNodeIdx, 1);
      this.currNodeIdx = -1;
      this.needCommit = true;
    },
    // 响应箭头流程节点点击事件
    setNodeStep: function (idx) {
      this.inNodeTitleEdit = false;
      this.currNodeIdx = idx;
      this.inValSelectForm = false;
      this.currFilterWordByBiz = '';
      this.currSelectCodeByBiz = '';
      this.currCodeOfConditionInNode = '';
    },
    // 根据角色 id 获取简要用户集合
    getUserInfoByRoleId: function (id) {
      return this.getUserList.filter(v => {
        return v.roleIdList.includes(`${id}`);
      }).map(v => {
        return {
          id: v.id,
          code: v.code,
          name: v.name,
          namezh: v.namezh,
          avatar: v.avatar,
          organid: v.organid,
          roleId: v.roleId,
          channelid: v.channelid,
          accountType: v.accountType
        };
      });
    },
    // 根据用户 id 获取简要用户信息
    getUserInfoByid: function (id) {
      if (Array.isArray(id)) {
        return this.getUserList.filter(v => id.includes(`${v.id}`)).map(_obj => {
          return {
            id: _obj.id,
            code: _obj.code,
            name: _obj.name,
            namezh: _obj.namezh,
            avatar: _obj.avatar,
            organid: _obj.organid,
            roleId: _obj.roleId,
            channelid: _obj.channelid,
            accountType: _obj.accountType
          };
        });
      } else {
        let _obj = (this.getUserList.filter(v => `${v.id}` === id))[0];
        if (_obj) {
          return {
            id: _obj.id,
            code: _obj.code,
            name: _obj.name,
            namezh: _obj.namezh,
            avatar: _obj.avatar,
            organid: _obj.organid,
            roleId: _obj.roleId,
            channelid: _obj.channelid,
            accountType: _obj.accountType
          };
        } else {
          return null;
        }
      }
    },
    // 选定指派的角色
    setRole: function (item) {
      this.inRoleSelect = false;
      this.getCurrNode.roleObj = {
        id: item.id,
        namezh: item.namezh
      };
      this.getCurrNode.users = this.getUserInfoByRoleId(item.id);
      this.needCommit = true;
    },
    // 为仅限模式的当前节点选定用户
    setUser: function (idx) {
      this.getCurrNode.users.forEach((v, k, arr) => {
        v.checked = (idx === k);
      });
      this.getCurrNode.nodeType = 'only';
      this.inOnlyUserSelect = false;
    },
    // 在仅限模式下切换仅有用户
    switchOnlyUser: function (idx) {
      let _obj = this.currNodes[this.currNodeIdx];
      if (_obj.nodeType === 'only') {
        _obj.users.forEach((v, k, arr) => {
          v.checked = (k === idx);
          let _b = k === idx;
          v.checked = _b;
          if (v.checked !== _b) {
            this.needCommit = true;
          }
          v.checked = _b;
        });
        this.$set(this.currNodes, this.currNodeIdx, _obj);
      }
    },
    // 仅限模式下的用户选定弹窗点击了取消后的响应
    cancelOnlyUser: function () {
      this.getCurrNode.nodeType = 'any';
      this.inOnlyUserSelect = false;
    },
    // 响应删除审批人操作
    delApproUser: function (id) {
      if (id && id > 0) {
        let _obj = this.getCurrNode;
        let _idx = _obj.users.findIndex(v => v.id === id);
        _obj.users.splice(_idx, 1);
        if (_obj.users.length === 0) {
          let _newNode = _defaultNode();
          _newNode.key = _obj.key;
          _newNode.title = _obj.title;
          _newNode.actCondition = _obj.actCondition;
          this.$set(this.currNodes, this.currNodeIdx, _newNode);
        }
        this.needCommit = true;
      }
    },
    // 将选定的字段添加到当前节点的条件项
    addFieldToCondition: function (item) {
      if (item && item.code && item.namezh) {
        let _obj = this.getCurrNode.actCondition;
        if (!_obj[item.code]) {
          let _x = {
            code: item.code,
            namezh: item.namezh,
            symbol: '$eq',
            valueFrom: '',
            value: null,
            valueTobe: []
          };
          this.currCodeOfConditionInNode = item.code;
          this.$set(_obj, item.code, _x);
          this.needCommit = true;
        }
      }
    },
    // 从当前节点中已设定的条件项中移除指定条件
    delFieldToCondition: function (item) {
      if (item && item.code && item.namezh) {
        let _obj = this.getCurrNode.actCondition;
        let _newObj = {};
        let _objArr = Object.keys(_obj);
        for (let v of _objArr) {
          if (v !== item.code) {
            _newObj[v] = _obj[v];
          }
        }
        this.$set(this.getCurrNode, 'actCondition', _newObj);
        this.needCommit = true;
      }
    },
    // 在条件的值设定弹窗中，点击了业务项的响应
    selectFieldBy: async function (code) {
      if (code) {
        this.currSelectCodeByBiz = code;
        let _x = {
          tblName: code
        };
        let _res = await this.getRecordAsValue(_x);
        if (Array.isArray(_res) && _res.length > 0) {
          this.$set(this.getCurrNode.actCondition[this.currCodeOfConditionInNode], 'valueFrom', code);
          this.$set(this.getCurrNode.actCondition[this.currCodeOfConditionInNode], 'valueTobe', _res);
          this.$set(this.getCurrNode.actCondition[this.currCodeOfConditionInNode], 'value', _res[0].id);
        } else {
          this.$Modal({
            title: '数据为空',
            middle: true,
            content: '选择的数据源没有任何数据，请手工输入值，或选择其他数据源'
          });
        }
        this.needCommit = true;
        this.getConditionValFormState = false;
      }
    },
    // 对指定的业务重新选择值源
    reSelectValue: function (code) {
      if (code) {
        this.$set(this.getCurrNode.actCondition[code], 'valueFrom', '');
        this.$set(this.getCurrNode.actCondition[code], 'valueTobe', []);
        this.$set(this.getCurrNode.actCondition[code], 'value', '');
        this.needCommit = true;
      }
    },
    // 为指定的条件打开业务选择弹窗
    selectValue4Biz: function (code) {
      if (code) {
        this.currCodeOfConditionInNode = code;
        this.getConditionValFormState = true;
      }
    },
    // 在检查报告中，将审批条件对象转换为数组
    getConditionArr: function (item) {
      return Object.keys(item).map(v => item[v]);
    },
    // 工作流保存前的有效性校验
    checkFlow: function (item) {
      let _rObj = () => {
        return {
          check: true,
          msg: {}
        };
      };
      let _result = {
        checkAll: true,
        checkNode: []
      };
      item.forEach((v, k, arr) => {
        let _node = _rObj();
        // '1': '未指派角色',
        if (!v.roleObj.id || v.roleObj.id < 0) {
          _node.check = false;
          _node.msg['1'] = errMsg['1'];
          _result.checkAll = false;
        }
        // '2': '未选择审批人',
        if (!v.users || v.users.length === 0) {
          _node.check = false;
          _node.msg['2'] = errMsg['2'];
          _result.checkAll = false;
        }
        // '3': '“仅限”模式有且仅有一个选定审批人',
        if (v.nodeType === 'only') {
          let _b = false;
          let i = 0;
          for (let vUser of v.users) {
            if (vUser.checked) {
              _b = true;
              i++;
            }
          }
          if (!_b || i !== 1) {
            _node.check = false;
            _node['3'] = errMsg['3'];
            _result.checkAll = false;
          }
        }
        // '4': '未指定节点条件的值'
        for (let vCdt of this.getConditionArr(v.actCondition)) {
          /* eslint-disable no-undefined */
          if (vCdt.value === null || String(vCdt.value) === '' || vCdt === undefined) {
            _node.check = false;
            _node.msg['4'] = errMsg['4'];
            _result.checkAll = false;
          }
        }
        _result.checkNode.push(_node);
      });
      return _result;
    },
    // 流程预保存
    preSave: function () {
      this.preSaveObj = this.checkFlow(this.currNodes);
      this.saveConfirm = true;
    },
    // 保存工作流
    saveFlow: function () {
      // 分解当前ORM信息，生成插入菜单记录的值
      let _keys = [];
      let _titles = [];
      let _roles = [];
      let _types = [];
      let _users = [];
      let _cdts = [];
      for (let v of this.currNodes) {
        _keys.push(v.key);
        _titles.push(v.title);
        _roles.push(v.roleObj.id);
        _types.push(v.nodeType);
        _users.push(v.users.map(vUser => vUser.id));
        let _cdtArr = Object.keys(v.actCondition);
        if (_cdtArr.length > 0) {
          _cdts.push(v.actCondition);
        } else {
          _cdts.push({});
        }
      }
      let _x = {
        code: this.getCurrBizObj.code,
        keys: _keys,
        titles: _titles,
        roles: _roles,
        types: _types,
        users: _users,
        cdts: _cdts
      };
      this.setFlow(_x)
        .then(res => {
          this.$emit('reSetFlowMenu', res[0]);
          this.enterFlow(-1);
          this.saveConfirm = false;
        })
        .catch(err => {
          global.terr(err);
          this.saveConfirm = false;
        });
    }
  }
};
</script>

<style lang="less" scoped>
@import '../../../assets/less/index.less';
@last-color: #666;

// 审核规则
.approWraper {
  position: relative;
  padding: 8px 0px;
  margin: 8px 36px;

  // 审批流程箭头组
  .stepGroup {
    display: flex;
    list-style: none;
    height: 30px;
    line-height: 30px;
    background-color: #fff;

    .approBtn {
      position: relative;
      display: inline-block;
      padding: 0 40px;
      margin-left: -6px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      font-weight: 100;
      color: #fff;
      background: @primary-color;
      cursor: pointer;

      &::before {
        position: absolute;
        display: block;
        left: 0px;
        top: 0;
        content: '';
        border-top: 15px solid @primary-color;
        border-bottom: 15px solid @primary-color;
        border-left: 15px solid #fff;
        z-index: 90;
      }

      &::after {
        display: block;
        position: absolute;
        right: 0;
        top: 0;
        content: '';
        border-top: 15px solid #fff;
        border-bottom: 15px solid #fff;
        border-left: 15px solid @primary-color;
        z-index: 100;
      }

      &:first-child {
        border-radius: 4px 0 0 4px;
        padding-left: 25px;
        margin-left: 0;

        &:first-child:before {
          display: none;
        }
      }

      &:last-child {
        border-radius: 0px 4px 4px 0px;
        padding-right: 25px;
        background-color: @last-color;

        &::before {
          border-top: 15px solid @last-color;
          border-bottom: 15px solid @last-color;
        }

        &::after {
          display: none;
        }
      }

      &:not(:first-child):not(:last-child):hover {
        background-color: @second-color;

        &::before {
          border-top: 15px solid @second-color;
          border-bottom: 15px solid @second-color;
        }

        &::after {
          border-left: 15px solid @second-color;
        }
      }
    }

    .active {
      width: 220px;
      text-align: center;
      padding-left: 30px;
      transition: all 0.25s ease-out;
      font-weight: 700;
      color: #fff;
      background-color: #666;

      &::before {
        transition: all 0.25s ease-out;
        border-top-color: #666;
        border-bottom-color: #666;
      }

      &::after {
        transition: all 0.25s ease-out;
        border-left-color: #666;
      }

      &:hover::before {
        border-top-color: #666;
        border-bottom-color: #666;
      }

      &:hover::after {
        transition: all 0.25s ease-out;
        border-left-color: #666;
      }
    }

    .addApproBtn {
      position: relative;
      display: inline-block;
      font-weight: 400;
      text-align: center;
      color: orange;
      background: -webkit-linear-gradient(left, @primary-color, #CCCCFF);
      background: -moz-linear-gradient(left, @primary-color, #CCCCFF);
      background: -ms-linear-gradient(left, @primary-color, #CCCCFF);
      background: -o-linear-gradient(left, @primary-color, #CCCCFF);
      background: linear-gradient(left, @primary-color, #CCCCFF);
      cursor: pointer;

      &::before {
        position: absolute;
        display: block;
        left: 0px;
        top: 0;
        content: '';
        border-top: 15px solid @primary-color;
        border-bottom: 15px solid @primary-color;
        border-left: 15px solid #fff;
        z-index: 90;
      }

      &::after {
        display: block;
        position: absolute;
        right: 0;
        top: 0;
        content: '';
        border-top: 15px solid #fff;
        border-bottom: 15px solid #fff;
        border-left: 15px solid #CCCCFF;
        z-index: 100;
      }

      &:hover {
        color: #fff;
        background: #666;

        &::before {
          border-top: 15px solid #666;
          border-bottom: 15px solid #666;
        }

        &::after {
          border-left: 15px solid #666;
        }
      }
    }
  }

  .flowRow {
    position: absolute;
    width: 100%;
    top: 40px;
    z-index: 900;

    li {
      padding: 12px 18px;
      margin: 12px 0;
      font-weight: 100;
      background-color: #fff;
      cursor: pointer;

      p {
        font-weight: 700;
        text-shadow: 2px 2px 8px #ccc;

        span.timeDate {
          margin-right: 18px;
          font-weight: 100;
        }
      }

      p.noWorkFlow {
        color: #ccc;
      }

      &:hover {
        background-color: #ccc;

        p.noWorkFlow {
          color: #333;
        }
      }

      .actRow {
        text-align: center;

        span {
          margin-right: 18px;
        }
      }
    }
  }

  .panelEdit {
    position: absolute;
    top: 0;
    z-index: 800;
  }

  .panelConfirm {
    position: absolute;
    top: 0;
    left: -54px;
    width: 100vw;
    min-height: 60vh;
    text-align: center;
    z-index: 900;

    .infoHeader {
      display: flex;
      width: 100%;
      margin-bottom: 18px;
      justify-content: center;
      text-align: center;

      .infoSymbol {
        width: 48px;
        height: 48px;
        padding: 12px;
        border-radius: 30px;
        cursor: pointer;

        &.green {
          background-color: green;
        }

        &.red {
          background-color: red;
        }
      }
    }

    .infoTitle {
      padding: 4px;
      margin: 0 64px;
      border-bottom: 1px #ccc dashed;
    }

    .infoBody {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;

      .nodeCard {
        width: 300px;
        padding: 0;
        margin: 18px;
        border: 1px #ccc dashed;
        cursor: pointer;
        background-color: #fff;

        p {
          padding: 8px;
          margin: 0 8px;
          border-bottom: 1px #f2f2f2 dotted;

          &:first-child {
            display: flex;
            height: 42px;
            line-height: 42px;
            padding: 0;
            margin: 0 0 18px 0;
            color: #fff;
            background-color: @primary-color;

            .indexTag {
              position: relative;
              top: 8px;
              height: 24px;
              line-height: 24px;
              padding: 0 8px;
              margin: 0 4px;
              border-radius: 4px;
              background-color: gray;
            }

            .checkTag {
              width: 42px;
            }
          }
        }

        .approUserList {
          list-style: none;

          li {
            display: inline-block;
            padding: 4px 8px;
            margin: 4px;
            border-radius: 4px;
            background-color: #eee;
          }
        }

        .approConditionList {
          li {
            padding: 8px;
            font-weight: 100;
          }
        }

        &:hover {
          background-color: @second-color;
        }

        .errMsgTxt {
          color: red;
        }
      }
    }
  }

  .stepNodeDesc {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    top: 82px;
    padding: 18px 0;
    background-color: @second-color;

    span {
      padding: 0 18px;
    }

    i {
      font-weight: 700;
      cursor: pointer;

      &:hover {
        color: #0781F4;
      }
    }

    .nodeCenter {
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }

  .branchList {
    position: relative;
    top: 120px;
    padding: 0 80px;

    li {
      display: flex;
      align-items: center;
      padding: 8px;
      margin-bottom: 12px;
      font-weight: 700;
      border-left: 5px @primary-color solid;
      background-color: #fff;

      .nodeBranchCell {
        padding: 0 18px;
        font-weight: 100;
        font-size: 12px;
        color: #666;
      }

      .titleWidge {
        margin-right: 32px;
      }

      &::before {
        background-color: red;
      }

      &:hover {
        background-color: #ccc;
      }
    }

    li.conditionTitle {
      justify-content: center;
      border: none;
      background-color: @second-color;
    }

    li.conditionInfo {
      padding: 0;

      .conditionDel {
        padding: 8px 10px;
        margin-left: 18px;

        i {
          font-weight: 700;
        }

        &:hover {
          background-color: red;

          i {
            color: #fff;
          }
        }
      }
    }

    li.onlyUser {
      background-color: @second-color;
    }

    li.addConditionBtn {
      justify-content: center;
      border: none;
      border-radius: 30px;
      background-color: @second-color;
    }
  }
}

.roleSelectPanel {
  min-height: 300px;
  max-height: 300px;
  overflow-y: auto;

  li {
    display: flex;
    align-items: center;
    padding: 8px 0;
    min-height: 41px;
    cursor: pointer;

    &:hover {
      background-color: @second-color;
    }
  }
}
</style>
