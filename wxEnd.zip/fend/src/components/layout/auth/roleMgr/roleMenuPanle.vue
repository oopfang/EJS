<template>
<!-- 菜单权限 -->
<Row class="roleEditContent">
  <Col :width="5">&nbsp;</Col>
  <Col :width="6" class="menuBlockLeft">
    <p class="roleMenuTitle mostBlack">已授予的菜单</p>
    <tmenu :menus="currRoleMenusYes" notNav @menuTo="delMenuFromRole"></tmenu>
  </Col>
  <Col :width="2" class="saveZone flexSplie">
    <!-- <span class="saveBtn defaultHover handCursor" @click.prevent.stop="saveRoleMenu">保存</span> -->
  </Col>
  <Col :width="6" class="menuBlockRight">
  <p class="roleMenuTitle mostBlack">未授予</p>
  <tmenu :menus="getMenuNotInCurrRole" notNav className="menuInAuth" @menuTo="addMenuFromRole"></tmenu>
  </Col>
  <Col :width="5">&nbsp;</Col>
</Row>
</template>

<script>
import tmenu from '@/components/widge/tmenu';
import { mapActions } from 'vuex';

export default {
  name: '',
  components: {
    tmenu
  },
  props: {
    // 该组件的父级组件的标签切换ID
    currStep: {
      type: Number,
      default: 0
    },
    // 当前编辑的角色对象
    currRoleEditObj: {
      type: Object,
      default: {}
    },
    // 当前的角色菜单分配总集
    roleMenuAll: {
      type: Object,
      default: {}
    },
    // 菜单总集的扁平数据
    menuFlatList: {
      type: Array,
      default: []
    },
    // 当前角色已有权限的菜单
    rightMenu: {
      type: Array,
      default: []
    }
  },
  data: function () {
    return {
      // 当前角色已分配的菜单项
      currRoleMenusYes: [],
      // 当前角色未分配的菜单项
      currRoleMenusNo: []
    };
  },
  computed: {
    // 获取未分配给当前角色的菜单列表
    getMenuNotInCurrRole: function () {
      if (this.currStep === 1) {
        let _obj = this.roleMenuAll[`role${this.currRoleEditObj.id}`];
        if (_obj) {
          this.currRoleMenusNo = _obj.noMenu;
          let _arr = this.currRoleMenusNo.filter(v => {
            return !v.children || v.children.length > 0;
          }).sort((a, b) => {
            return a.pid - b.pid || a.orderIndex - b.orderIndex;
          });
          for (let v of _arr) {
            if (v.children) {
              v.children.sort((a, b) => {
                return a.pid - b.pid || a.orderIndex - b.orderIndex;
              });
            }
          }
          if (this.rightMenu.length > 0 && this.currRoleMenusYes.length === 0) {
            this.currRoleMenusYes = this.rightMenu;
          }
          return _arr;
        } else {
          return [];
        }
      } else {
        return [];
      }
    }
  },
  methods: {
    ...mapActions(['resetRoleMenu']),
    // 从当前角色的未授权菜单中添加指定项给该角色
    addMenuFromRole: function (id) {
      this.resetMenuOfRole(id, true);
    },
    // 从当前角色的已授权菜单中移除指定项
    delMenuFromRole: function (id) {
      this.resetMenuOfRole(id);
    },
    // 在已授权和未授权的菜单列表中进行平移
    // @id：要平移的菜单ID，
    // @isAdd：是否为添加模式，否则则表示从已授权中移除
    resetMenuOfRole: function (id, isAdd) {
      let listOut = isAdd ? this.currRoleMenusNo : this.currRoleMenusYes;
      let listIn = isAdd ? this.currRoleMenusYes : this.currRoleMenusNo;
      let _tagObj = this.menuFlatList.find(v => v.id === id);
      let _idx = [];
      if (_tagObj.pid === -1) {
        _idx[0] = listOut.findIndex(v => v.id === id);
      } else {
        _idx[0] = listOut.findIndex(v => v.id === _tagObj.pid);
        _idx[1] = listOut[_idx[0]].children.findIndex(v => v.id === id);
      }
      if (_idx[0] > -1) {
        if (_idx.length === 1) {
          let _objOut = listOut.splice(_idx[0], 1)[0];
          listIn.push(_objOut);
        } else {
          if (_idx[1] > -1) {
            let _pobj = listOut[_idx[0]];
            let _objOutSub = listOut[_idx[0]].children.splice(_idx[1], 1)[0];
            let _idxInTarget = listIn.findIndex(v => v.id === _pobj.id);
            if (_idxInTarget === -1) {
              /* eslint-disable no-unused-vars */
              let {
                children,
                ...otherPart
              } = _pobj;
              let _newObjPara = JSON.parse(JSON.stringify(otherPart));
              _newObjPara.children = [_objOutSub];
              listIn.push(_newObjPara);
            } else {
              listIn[_idxInTarget].children.push(_objOutSub);
            }
            if (_objOutSub.pid > -1) {
              let _pIdx = listOut.findIndex(v => v.id === _objOutSub.pid);
              if (listOut[_pIdx].children.length === 0) {
                listOut.splice(_pIdx, 1);
              }
            }
          }
        }
        this.$emit('setComit', true);
      }
    },
    // 保存当前角色的菜单定义
    saveRoleMenu: function () {
      let _arr = [];
      let _roleId = this.currRoleEditObj.id;
      this.currRoleMenusYes.forEach(v => {
        if (v.children) {
          if (v.children.length > 0) {
            _arr.push({
              pid: _roleId,
              menuId: v.id
            });
            v.children.forEach(vSub => {
              _arr.push({
                pid: _roleId,
                menuId: vSub.id
              });
            });
          }
        } else {
          _arr.push({
            pid: _roleId,
            menuId: v.id
          });
        }
      });
      this.resetRoleMenu(_arr)
        .then(res => {
          this.$emit('reRole', res);
          global.tinfo(`角色[ ${this.currRoleEditObj.namezh} ]的菜单授权完成`);
        })
        .catch(err => {
          global.terr(err);
        });
      // this.$emit('saveMenu', _arr);
    }
  }
};
</script>

<style lang="less" scoped>
@import './index.less';
</style>
