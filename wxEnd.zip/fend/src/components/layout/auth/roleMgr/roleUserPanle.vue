<template>
<div class="roleEditContent">
  <div class="h-input h-input-prefix-icon" style="width: 100%;">
    <input type="text" v-model="accFilterWord" placeholder="输入即筛选，支持账号code或账号名称" />
    <i class="h-icon-search" style="top: 16px !important;"></i>
  </div>
  <transition-group class="roleUserWrapper" tag="div" enter-active-class="animated bounceInRight" leave-active-class="animated fadeOutRight">
    <transition-group class="flexSplit roleUserList" tag="ul" enter-active-class="animated zoomIn" leave-active-class="animated fadeOutRight" key="roleUser1">
      <li v-for="(item, index) in getUserListOfRole" :key="`uList${index}`" v-tooltip placement="top-start" :content="getHoverStrInRoleUser(item.id, item.code) ? '不允许删除' : '点击删除'" @click.prevent.stop="delUserFromRole(item.id, item.code)">{{ item.code }} [ {{ item.namezh }} ]</li>
      <li v-show="!needSelectUserInRoleEdit" :key="currUserListOfRole.length" @click.prevent.stop="needSelectUserInRoleEdit=true">
        <tIcon icon="h-icon-plus" :size="12" :height="12"></tIcon>
      </li>
      <li v-show="needSelectUserInRoleEdit" class="closeButtonInRoleUsser" :key="currUserListOfRole.length + 1" @click.prevent.stop="needSelectUserInRoleEdit=false">完成</li>
    </transition-group>
    <transition-group class="roleUserList" v-show="needSelectUserInRoleEdit" tag="ul" enter-active-class="animated zoomIn" leave-active-class="animated bounceOutLeft" key="roleUser2">
      <li v-for="(item, index) in getUserListOfRoleNot" :key="`uRole${index}`" @click.prevent.stop="addUserToRole(item.id)">{{ item.code }} [ {{ item.namezh }} ]</li>
    </transition-group>
  </transition-group>
</div>
</template>

<script>
import tIcon from '@/components/widge/tIcon';
import { mapActions } from 'vuex';

export default {
  name: '',
  components: {
    tIcon
  },
  props: {
    // 该组件的父级组件的标签切换ID
    currStep: {
      type: Number,
      default: 0
    },
    // 当前编辑的角色对象
    currRoleEditObj: {
      type: Object,
      default: {}
    },
    // 所有角色的账号列表
    accountData: {
      type: Array,
      default: []
    }
  },
  data: function () {
    return {
      // 账号过滤字符
      accFilterWord: '',
      // 是否需要在角色编辑页面中显示用户选择的面板
      needSelectUserInRoleEdit: false,
      // 当前编辑的角色所拥有的用户
      currUserListOfRole: [],
      // 不属于当前编辑角色的用户
      currUserListOfRoleNot: []
    };
  },
  computed: {
    // 获取当前编辑的角色所拥有用户的列表
    getUserListOfRole: function () {
      if (this.currStep === 0) {
        this.preUserInRoleEdit();
        let _fStr = this.accFilterWord;
        if (_fStr) {
          return this.currUserListOfRole.filter(v => {
            return v.code.includes(_fStr) || v.namezh.includes(_fStr);
          });
        } else {
          return this.currUserListOfRole;
        }
      } else {
        return [];
      }
    },
    // 获取不属于当前编辑的角色的用户列表
    getUserListOfRoleNot: function () {
      if (this.currStep === 0) {
        let _fStr = this.accFilterWord;
        if (_fStr) {
          return this.currUserListOfRoleNot.filter(v => {
            return v.code.includes(_fStr) || v.namezh.includes(_fStr);
          });
        } else {
          return this.currUserListOfRoleNot;
        }
      } else {
        return [];
      }
    }
  },
  methods: {
    ...mapActions(['resetRole']),
    // 预准备进入角色编辑后的用户列表
    preUserInRoleEdit: function () {
      this.accFilterWord = '';
      let _id = this.currRoleEditObj.id;
      this.currUserListOfRole = [];
      this.currUserListOfRoleNot = [];
      this.accountData.forEach(v => {
        if (v.roleName.includes(`${_id}`)) {
          this.currUserListOfRole.push(v);
        } else {
          this.currUserListOfRoleNot.push(v);
        }
      });
    },
    // 在角色编辑页面的已有用户列表中获取hover文字提示
    getHoverStrInRoleUser: function (id, code) {
      return (this.currRoleEditObj.code === 'adminGroup' && code === 'admin') || (this.currRoleEditObj.code === 'authKeeperGroup' && code === 'auth');
    },
    // 将不属于当前编辑角色的账号添加到当前角色中
    addUserToRole: function (id) {
      let _idx = this.currUserListOfRoleNot.findIndex(v => v.id === id);
      if (_idx > -1) {
        let _obj = this.currUserListOfRoleNot[_idx];
        let _roleNameArr = JSON.parse(JSON.stringify(_obj.roleName));
        _roleNameArr.push(`${this.currRoleEditObj.id}`);
        let _roleStr = _roleNameArr.sort((a, b) => {
          return parseInt(a) - parseInt(b);
        }).join(',');
        let x = {
          id: _obj.id,
          roleStr: _roleStr
        };
        this.resetRole(x)
          .then(res => {
            let _idx2 = this.accountData.findIndex(v => v.id === id);
            if (_idx2 > -1) {
              let _objOld = this.currUserListOfRoleNot.splice(_idx, 1)[0];
              let _roleNameNew = _roleStr.split(',').map(v => `${v}`);
              _objOld.roleId = _roleStr;
              _objOld.roleName = _roleNameNew;
              this.currUserListOfRole.push(_objOld);
              this.accountData[_idx2].roleId = _roleStr;
              this.accountData[_idx2].roleName = _roleNameNew;
              global.tinfo(`账号 [ ${_obj.code}: ${_obj.namezh} ] 已加入角色组： ${this.currRoleEditObj.namezh}`);
            }
          })
          .catch(err => {
            global.terr(err);
          });
      }
    },
    // 在角色编辑页面的已有用户列表中移除用户
    delUserFromRole: function (id, code) {
      if (!this.getHoverStrInRoleUser(id, code)) {
        let _idx = this.currUserListOfRole.findIndex(v => v.id === id);
        if (_idx > -1) {
          let _obj = this.currUserListOfRole[_idx];
          let _msg = `${_obj.namezh}`;
          this.$Confirm(`是否从该角色中移除账号 [ ${_msg} ] ？`, '请确认')
            .then(res => {
              let _idx2 = this.accountData.findIndex(v => v.id === id);
              if (_idx2 > -1) {
                let _obj = this.accountData[_idx2];
                let _newRoleStr = _obj.roleId.split(',');
                let _currRoleId = this.currRoleEditObj.id;
                let _removeIdx = _newRoleStr.findIndex(v => v === `${_currRoleId}`);
                if (_removeIdx > -1) {
                  _newRoleStr.splice(_removeIdx, 1);
                  let _saveRoleStr = _newRoleStr.sort((a, b) => {
                    return parseInt(a) - parseInt(b);
                  }).join(',');
                  let x = {
                    id: _obj.id,
                    roleStr: _saveRoleStr
                  };
                  this.resetRole(x)
                    .then(res => {
                      this.currUserListOfRoleNot.push(this.currUserListOfRole.splice(_idx, 1)[0]);
                      this.accountData[_idx2].roleId = _saveRoleStr;
                      this.accountData[_idx2].roleName = _saveRoleStr.split(',').map(v => `${v}`);
                      global.tinfo(`账号 [ ${_msg} ] 已从该角色移除`);
                    })
                    .catch(err => {
                      global.terr(err);
                    });
                }
              }
            })
            .catch(err => {
              global.terr(err);
            });
        }
      }
    }
  }
};
</script>

<style lang="less" scoped>
@import './index.less';
</style>
