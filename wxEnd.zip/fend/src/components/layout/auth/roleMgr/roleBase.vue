<template>
<div class="authSubContent roleWrapper">
  <!-- 角色规划 -->
  <transition-group tag="div" enter-active-class="animated zoomInDown" leave-active-class="animated fadeOutDown">
    <!-- 角色列表面板 -->
    <tPanel v-show="!inRoleEdit" showHeader bgColor="#F3F2F7" class="panelList" key="rolePanel1">
      <div slot="panelHeader">
        <Button icon="h-icon-plus" color="primary" @click="enterRoleAdd">创建角色</Button>
      </div>
      <transition-group class="listRow" tag="ul" enter-active-class="animated bounceInLeft" leave-active-class="animated bounceOutRight">
        <li v-show="currRoleEditId === -1 || currRoleEditId === item.id" class="roleRow" v-for="(item, index) in getRoleList" :key="item.code" @mouseover="currHoverRoleIdx=index" @mouseout="currHoverRoleIdx=-1" @click.prevent.stop="enterRoleEdit(item.id)">
          <div class="flexSplit hoverPart">
            <span class="roleTitle">{{ item.namezh }}</span>
            <span>{{ item.memo }}</span>
          </div>
          <span v-show="item.code !== 'adminGroup' && item.code !== 'authKeeperGroup' && item.code !== 'userLimitGroup' && currHoverRoleIdx===index" class="delBtnInRow" @click.prevent.stop="delRole(item.id, item.namezh)">删除</span>
        </li>
      </transition-group>
    </tPanel>
    <!-- 角色权限分配面板 -->
    <tPanel v-show="inRoleEdit" showHeader class="panelEdit" key="rolePanel2">
      <div slot="panelHeader">
        <ul class="rightTypeList">
          <li v-show="(currRoleEditObj.code !== 'adminGroup' && currRoleEditObj.code !== 'authKeeperGroup') || index === 0" :class="{ active: currRoleRightStep === index }" v-for="(item, index) in roleRightType" :key="item.code" @click.prevent.stop="switchRoleType(index)">{{ item }}</li>
        </ul>
        <div class="flexSplit"></div>
        [ 当前角色( ID: {{ currRoleEditObj.id }} ) ]&nbsp;&nbsp;<span class="h-tag h-tag-gray">{{ currRoleEditObj.namezh }}</span>
        <div class="flexSplit"></div>
        <div class="rolePanelBtn">
          <Button v-show="needCommitRole && currRoleRightStep > 0" color="primary" @click="saveRoleEdit">保存</Button>
          <Button :no-border="true" @click="exitRoleEdit">关闭</Button>
        </div>
      </div>
      <div style="height: 65vh;">
        <!-- <keep-alive> -->
        <transition-group class="roleEditWrapper" tag="div" enter-active-class="animated bounceInRight" leave-active-class="animated fadeOutLeft">
          <!-- 用户列表 -->
          <roleUserPanle v-show="currRoleRightStep === 0" :currStep="currRoleRightStep" :currRoleEditObj="currRoleEditObj" :accountData="accountData" key="roleRightSet0"></roleUserPanle>
          <!-- 菜单权限 -->
          <roleMenuPanle ref="roleMenu" v-show="currRoleRightStep === 1" :currStep="currRoleRightStep" :currRoleEditObj="currRoleEditObj" :roleMenuAll="roleMenuAll" :menuFlatList="menuFlatList" :rightMenu="getMenuInCurrRole" @setComit="setComit" @reRole="setRoleRespon" key="roleRightSet1"></roleMenuPanle>
          <!-- 操作权限 -->
          <roleOperatPanle ref="roleOpt" v-show="currRoleRightStep === 2" :currStep="currRoleRightStep" :ormData="ormData" :currRoleEditObj="currRoleEditObj" :roleMenuAll="roleMenuAll" :rightMenu="getMenuInCurrRole" :needCommitRole="needCommitRole" @reRole="setRoleRespon" @setComit="setComit" key="roleRightSet2"></roleOperatPanle>
          <!-- 数据权限 -->
          <roleDataPanle v-show="currRoleRightStep === 3" :currStep="currRoleRightStep" :currRoleEditObj="currRoleEditObj" @setComit="setComit" key="roleRightSet3"></roleDataPanle>
        </transition-group>
      </div>
    </tPanel>
  </transition-group>
  <!-- 创建角色弹窗 -->
  <Modal v-model="showNewRoleModal" className="roleTobeWrapper">
    <p slot="header">创建角色：{{ currNewRole.namezh }}</p>
    <p><span>角色代码：</span><input type="text" v-model="currNewRole.code" style="width: 300px;"/></p>
      <p><span>角色名称：</span><input type="text" v-model="currNewRole.namezh" style="width: 300px;"/></p>
        <p><textarea v-model="currNewRole.memo" placeholder="请输入备注信息" style="width: 100%;"></textarea></p>
        <div slot="footer">
          <Button v-show="currNewRole.code && currNewRole.namezh && currNewRole.memo" color="primary" @click="addNewRole">保存</Button>
          <Button :no-border="true" @click="showNewRoleModal=false">取消</Button>
        </div>
  </Modal>
</div>
</template>

<script>
import tPanel from '@/components/wrapper/part/tPanel';
import {
  mapActions
} from 'vuex';
let roleUserPanle = () => import(/* webpackChunkName:'authRole' */'./roleUserPanle');
let roleMenuPanle = () => import(/* webpackChunkName:'authRole' */'./roleMenuPanle');
let roleOperatPanle = () => import(/* webpackChunkName:'authRole' */'./roleOperatPanle');
let roleDataPanle = () => import(/* webpackChunkName:'authRole' */'./roleDataPanle');

export default {
  name: 'roleMgr',
  components: {
    tPanel,
    roleUserPanle,
    roleMenuPanle,
    roleOperatPanle,
    roleDataPanle
  },
  props: {
    // Orms数据集
    ormData: {
      type: Object,
      default: {}
    },
    // 角色列表
    roleList: {
      type: Array,
      default: []
    },
    // 用户列表
    accountData: {
      type: Array,
      default: []
    },
    // 扁平菜单数据集
    menuFlatList: {
      type: Array,
      default: []
    },
    // db中已存储的所有角色的菜单项
    roleMenuAll: {
      type: Object,
      default: {}
    }
  },
  data: function () {
    return {
      // 当前hover的角色行索引
      currHoverRoleIdx: -1,
      // 是否显示创建角色的弹窗
      showNewRoleModal: false,
      // 新角色的缓存数据
      currNewRole: {
        code: '',
        namezh: '',
        memo: ''
      },
      // 角色权限类别
      roleRightType: ['用户列表', '菜单权限', '操作权限', '数据权限'],
      // 当前角色授权面板的执行步骤
      currRoleRightStep: 0,
      // 当前编辑的角色ID
      currRoleEditId: -1,
      // 当前编辑的角色对象
      currRoleEditObj: {},
      // 是否需要对角色编辑面板显示保存按钮
      needCommitRole: false,
      // 是否处于角色编辑页面
      inRoleEdit: false,
      // 当前角色已分配的菜单项
      currRoleMenus: [],
      // 当前角色未分配的菜单项
      currRoleMenusLeft: [],
      // 当前编辑的CRUD权限标题列表
      currCrudTitleList: [],
      // Crud按钮组的权限值列表
      currCrudValList: [0, 0, 0, 0, 0],
      // 当前编辑的 Extend 权限列表
      currExtendTitleList: [],
      // 当前编辑的  Biz 权限列表
      currBizTitleList: [],
      // 当前编辑的实例的隐藏字段列表
      currHiddenList: [],
      currShowFieldList: [],
      currHiddenFieldList: [],
      // 操作权限页面中，当前字段的hover序列值
      currFieldIdx: -1,
      // 当前角色编辑操作权限时选定的业务实体
      currOrmInRoleEdit: {},
      // CRUD按钮组没有任何权限
      currCrudIsNull: false
    };
  },
  computed: {
    // 获取当前角色已具备的菜单列表
    getMenuInCurrRole: function () {
      if (this.currRoleRightStep === 1 || this.currRoleRightStep === 2) {
        let _obj = this.roleMenuAll[`role${this.currRoleEditId}`];
        if (_obj) {
          this.currRoleMenus = _obj.hasMenu;
          let _arr = this.currRoleMenus.filter(v => {
            return !v.children || v.children.length > 0;
          }).sort((a, b) => {
            return a.pid - b.pid || a.orderIndex - b.orderIndex;
          });
          for (let v of _arr) {
            if (v.children) {
              v.children.sort((a, b) => {
                return a.pid - b.pid || a.orderIndex - b.orderIndex;
              });
            }
          }
          return _arr;
        } else {
          return [];
        }
      } else {
        return [];
      }
    },
    getRoleList() {
      return this.roleList.filter(v => {
        return v.code !== 'userLimitGroup';
      });
    }
  },
  methods: {
    ...mapActions(['createRole', 'deleletRole']),
    // 进入角色创建弹窗
    enterRoleAdd: function () {
      this.currNewRole = {
        code: '',
        namezh: '',
        memo: ''
      };
      this.showNewRoleModal = true;
    },
    // 创建角色成功后，不继续的回调执行
    subFuncOnCreate() {
      this.showNewRoleModal = false;
    },
    // 创建角色
    addNewRole: function () {
      let _a = this.showNewRoleModal;
      this.createRole(this.currNewRole)
        .then(res => {
          this.roleList.push(res);
          this.currNewRole = {
            code: '',
            namezh: '',
            memo: ''
          };
          let _b = _a;
          // 成功后的回调
          this.$Modal({
            title: '角色创建成功',
            content: '继续创建新角色吗？',
            buttons: [{
              type: 'ok',
              name: '继续',
              color: 'primary'
            }, {
              type: 'cancel',
              name: '关闭'
            }],
            events: {
              $init: modal => {},
              cancel: modal => {
                this.subFuncOnCreate();
                modal.close();
              },
              ok: modal => {
                modal.close();
              }
            }
          });
          this.showNewRoleModal = _b;
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 删除指定角色
    delRole: function (id, roleNamezh) {
      this.$Confirm(`是否删除该角色 [ ${roleNamezh} ] ？`, '请确认')
        .then(() => {
          let _idx = this.roleList.findIndex(v => v.id === id);
          if (_idx > -1) {
            let x = {
              id: id
            };
            /* eslint-disable handle-callback-err */
            this.deleletRole(x)
              .then(res => {
                let _obj = this.roleList.splice(_idx, 1)[0];
                this.$emit('reAcc', res);
                global.tinfo(`角色[ ${id}: ${_obj.namezh} ] 删除成功！`);
              })
              .catch(err => {
                global.terr(err);
              });
          }
        })
        .catch(err => {
          global.twarn('操作取消！', false);
        });
    },
    // 进入角色编辑页面
    enterRoleEdit: function (id) {
      let _idx = this.roleList.findIndex(v => v.id === id);
      if (_idx > -1) {
        let _obj = this.roleList[_idx];
        if (_obj.code !== 'userLimitGroup') {
          this.currRoleEditId = id;
          this.currRoleEditObj = this.roleList[_idx];
          this.currCrudTitleList = [];
          this.currExtendTitleList = [];
          this.currBizTitleList = [];
          this.currHiddenList = [];
          this.needCommitRole = false;
          setTimeout(() => {
            this.$emit('changeMenu', false);
            this.inRoleEdit = true;
          }, 300);
        } else {
          global.twarn(`不允许编辑${_obj.namezh}`, false);
        }
      }
    },
    // 在角色编辑页面切换标签
    switchRoleType: function (idx) {
      this.needCommitRole = false;
      this.currCrudTitleList = [];
      this.currExtendTitleList = [];
      this.currBizTitleList = [];
      this.currHiddenList = [];
      this.currRoleRightStep = idx;
    },
    // 响应授权子组件的保存成功事件
    setRoleRespon: function (e) {
      this.$emit('reRole', e);
      this.needCommitRole = false;
    },
    // 保存当前角色编辑页面的数据
    saveRoleEdit: function () {
      if (this.currRoleRightStep === 1) {
        this.$refs.roleMenu.saveRoleMenu();
      } else if (this.currRoleRightStep === 2) {
        this.$refs.roleOpt.saveRoleOperat();
      }
    },
    // 退出角色编辑页面
    exitRoleEdit: function () {
      this.currRoleRightStep = 0;
      this.$emit('changeMenu', true);
      this.currRoleRightStep = -1;
      this.inRoleEdit = false;
      this.currRoleEditId = -1;
      this.currRoleEditObj = {};
      this.currUserListOfRole = [];
      this.needCommitRole = false;
      this.currCrudTitleList = [];
      this.currExtendTitleList = [];
      this.currHoverRoleIdx = [];
    },
    // 响应子组件的保存按钮状态提交事件
    setComit: function(e) {
      this.needCommitRole = e;
    }
  }
};
</script>

<style lang="less" scoped>
@import '../../../../assets/less/index.less';

.roleWrapper {
  position: relative;
  padding: 8px 0px;

  .panelList {
    position: absolute;
    top: 0;
    z-index: 900;

    .listRow {
      li {
        padding: 12px 18px;
        margin: 12px 0;
        font-weight: 100;
        background-color: #fff;
        cursor: pointer;

        p {
          font-weight: 700;
          text-shadow: 2px 2px 8px #ccc;

          span.timeDate {
            margin-right: 18px;
            font-weight: 100;
          }
        }

        p.noWorkFlow {
          color: #ccc;
        }
      }

      .roleRow {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 0;

        .hoverPart {
          padding: 8px 0;

          .roleTitle {
            padding: 8px 12px;
            margin-right: 18px;
            font-weight: 700;
            color: #fff;
            background-color: #131138
          }
        }

        .delBtnInRow {
          padding: 8px 12px;
          color: #000;
          background-color: orangered;
        }

        .delBtnInRow:hover {
          font-weight: 700;
          color: #fff;
        }

      }

      .roleRow:hover {
        background-color: #ddd;
      }
    }
  }

  .panelEdit {
    position: absolute;
    top: 0;
    z-index: 800;

    .rightTypeList {
      list-style: none;

      li {
        display: inline-block;
        padding: 0 8px;
        margin: 0;
        background-color: #ccc;
        cursor: pointer;
      }

      li:hover {
        background-color: #eee;
      }

      li.active {
        color: #fff;
        background-color: @primary-color;
      }
    }

    .rightTypeList::after {
      position: relative;
      content: '';
      width: 0;
      height: 0;
      top: -46px;
      right: 0;
      border-color: #4A4C52 transparent;
      border-width: 0 6px 8px 0;
      border-style: solid;
    }

    .rolePanelBtn {
      width: 130px;
      text-align: right;
    }
    .roleEditWrapper {
      position: relative;
      padding: 8px 18px;
      height: 65vh;
    }
  }
}

// 备选角色列表弹窗
.roleTobeWrapper {
  width: 30%;

  p {
    padding: 8px 12px;
    text-align: center;
    font-weight: 700;
    text-shadow: 2px 2px 8px #ccc;
  }

  .roleTobeList {
    display: flex;
    flex-direction: row;
    max-width: 600px;
    list-style: none;
    padding: 18px;
    justify-content: center;

    li {
      display: inline-block;
      width: 20px;
      max-width: 20px;
      padding: 8px 18px 8px 8px;
      word-wrap: break-word;
      letter-spacing: 10px;
      text-align: center;
      font-size: 12px;
      cursor: pointer;

      &:hover {
        background-color: orange;
      }
    }
  }
}
</style>
