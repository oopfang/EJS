<template>
<!-- 操作权限 -->
<Row class="roleEditContent">
  <Col :width="4" class="optionRightWrapper">
  <span v-if="currRoleEditObj"></span>
  <p class="headerTxt mostBlack">业务类型</p>
  <ul class="opRightList" :class="{ opRightListCanHover: !needCommitRole }">
    <li :class="{ currOparterItem: currOrmInRoleEdit.tblName === item.tblName }" v-for="item in getOrmsByRole" :key="item.code" @click.prevent.stop="selectOrm(item)">
      {{ item.namezh }}
    </li>
  </ul>
  </Col>
  <Col v-show="currOrmInRoleEdit.tblName" :width="8" class="optionRightWrapper">
    <p class="headerTxt mostBlack">常规操作</p>
    <p class="headerTxt">
      <btnCrud isDemo :userAccess="valListCrud" @noAccess="setNoAccessCrud"></btnCrud>
      <span class="noRights atAll" v-show="!valListCrud[0]"></span>
      <span class="noRights viewOnly" v-show="readOnlyVal"></span>
    </p>
    <p class="headerTxt">
      <Checkbox v-model="getCheckValCrud" :datas="seeds.crud"></Checkbox>
    </p>
    <div class="viewRange asCrud" @mouseout="currFieldIdx=-1" style="margin: 8px 36px;">
      <p v-show="fieldListHide.length > 0" class="headerTxt"><span class="mostBlack">已隐藏字段</span>&nbsp;[点击取消]</p>
      <ul v-show="fieldListHide.length > 0" class="hUl hideRange">
        <li class="defaultHover" v-for="item in fieldListHide" :key="item.code" @click.prevent.stop="showHideField(item.code)">{{ item.namezh }}</li>
      </ul>
      <p class="headerTxt mostBlack">显示中的字段</p>
      <p class="headerTxt fieldRow" v-for="(item, index) in getFieldlistShow" :key="item.code" @mouseover="currFieldIdx=index">
        {{ item.namezh }}
        <span v-show="currFieldIdx===index" @click.prevent.stop="hideField(item.code)">隐藏</span>
      </p>
    </div>
  </Col>
  <Col v-show="currOrmInRoleEdit.tblName" :width="6" class="optionRightWrapper">
    <p class="headerTxt mostBlack">扩展功能</p>
    <p class="headerTxt">
      <btnExtend isDemo :userAccess="valListExtend" @noAccess="setNoAccessExtend"></btnExtend>
      <span class="noRights atAll" v-show="extendIsNull"></span>
    </p>
    <p class="headerTxt">
      <Checkbox v-model="getCheckValExtend" :datas="seeds.extend"></Checkbox>
    </p>
  </Col>
  <Col v-show="currOrmInRoleEdit.tblName" :width="6" class="optionRightWrapper">
    <p class="headerTxt mostBlack">审批操作</p>
    <p class="headerTxt">
      <btnAppro @noAccess="bizIsNull=true"></btnAppro>
    </p>
    <p class="headerTxt">
      <Checkbox disabled v-model="getCheckValBiz" :datas="seeds[currOrmInRoleEdit.tblName]"></Checkbox>
    </p>
    <div class="viewRange">
      <div class="approTips">
      </div>
    </div>
  </Col>
</Row>
</template>

<script>
import btnCrud from '@/components/widge/bizCtrls/groupCrud';
import btnAppro from '@/components/widge/bizCtrls/groupApprove';
import btnExtend from '@/components/widge/bizCtrls/groupGeneral';
import {
  mapActions
} from 'vuex';
// 不受权限控制显示与否的字段集
let ourRange = ['deleted', 'createby', 'changeby'];

export default {
  name: '',
  components: {
    btnCrud,
    btnAppro,
    btnExtend
  },
  props: {
    // 该组件的父级组件的标签切换ID
    currStep: {
      type: Number,
      default: 0
    },
    // 当前编辑的角色对象
    currRoleEditObj: {
      type: Object,
      default: {}
    },
    // Orms数据集
    ormData: {
      type: Object,
      default: {}
    },
    // 当前的角色菜单分配总集
    roleMenuAll: {
      type: Object,
      default: {}
    },
    // 同步父组件的保存按钮显示状态
    needCommitRole: {
      type: Boolean,
      default: false
    },
    // 当前角色已有权限的菜单
    rightMenu: {
      type: Array,
      default: []
    }
  },
  data: function () {
    return {
      // 当前角色编辑操作权限时选定的业务实体
      currOrmInRoleEdit: {},
      // 权限种子
      seeds: {
        crud: [],
        extend: []
      },
      // 当前ORM的 Crud 权限Key集合
      titleListCrud: [],
      // 当前ORM的 Extend 权限key集合
      titleListExtend: [],
      // 当前ORM的  Biz 权限key集合
      titleListBiz: [],
      // 当前ORM的 Crud 按钮组的权限值列表
      valListCrud: [],
      // 当前ORM的 Extend 按钮组的权限值列表
      valListExtend: [],
      // 当前ORM的 biz 按钮组的权限值列表
      valListBiz: [],
      // 当前ORM的显示字段列表
      fieldlistShow: [],
      // 当前编辑的实例的隐藏字段列表
      fieldListHide: [],
      // 操作权限页面中，当前字段的hover序列值
      currFieldIdx: -1,
      // 当前 CRUD 权限值是否为空
      crudIsNull: true,
      // 当前 CRUD 权限是否仅允许查看
      readOnlyVal: false,
      // 当前 Extend 权限值是否为空
      extendIsNull: true,
      // 当前 Biz 权限值是否为空
      bizIsNull: true
    };
  },
  computed: {
    // 根据当前角色的菜单权限定义获取可分配的业务实体集合
    getOrmsByRole: function () {
      let _arr = [];
      if (this.currStep === 2 && this.currRoleEditObj.id > 0) {
        for (let v of this.rightMenu) {
          if (v.children && v.children.length > 0) {
            for (let vSub of v.children) {
              let _obj = this.ormData[`${vSub.key}`];
              if (_obj) {
                _obj.menuId = vSub.id;

                _arr.push(_obj);
              }
            }
          } else {
            let _obj2 = this.ormData[`${v.key}`];
            if (_obj2) {
              _obj2.menuId = v.id;
              _arr.push(_obj2);
            }
          }
        }
      }
      return _arr;
    },
    getFieldlistShow() {
      return this.fieldlistShow.filter(v => {
        return item.namezh;
      });
    },
    // 获取 CRUD 复选框的值
    getCheckValCrud: {
      get() {
        return this.titleListCrud;
      },
      set(val) {
        let _changeVal = '';
        let _oldList = this.titleListCrud;
        for (let v of val) {
          if (!_oldList.includes(v)) {
            _changeVal = v;
            break;
          }
        }
        let isAdd = Boolean(_changeVal);
        if (!isAdd) {
          for (let v of _oldList) {
            if (!val.includes(v)) {
              _changeVal = v;
              break;
            }
          }
        }
        if (isAdd) {
          if (_changeVal !== 'read' && !val.includes('read')) {
            val.push('read');
          }
          if (_changeVal === 'add') {
            if (!val.includes('edit')) {
              val.push('edit');
            }
            if (!val.includes('copy')) {
              val.push('copy');
            }
          } else if (_changeVal === 'copy' && !val.includes('add')) {
            val.push('add');
          }
        } else {
          if (_changeVal === 'read') {
            val = [];
          } else if (_changeVal === 'add') {
            let _idxCopy = val.findIndex(v => v === 'copy');
            if (_idxCopy > -1) {
              val.splice(_idxCopy, 1);
            }
          }
        }
        this.valListCrud = this.getValListByKeyList('crud', val);
        this.titleListCrud = val;
        this.readOnlyVal = val.length === 1 && val[0] === 'read';
        this.$emit('setComit', true);
      }
    },
    // 获取 Extend 复选框的值
    getCheckValExtend: {
      get() {
        return this.titleListExtend;
      },
      set(val) {
        this.valListExtend = this.getValListByKeyList('extend', val);
        this.titleListExtend = val;
        this.$emit('setComit', true);
      }
    },
    // 获取 Biz 复选框的值
    getCheckValBiz: {
      get() {
        return this.titleListBiz;
      },
      set(val) {
        let _idt = this.currOrmInRoleEdit.tblName;
        this.valListBiz = this.getValListByKeyList(_idt, val);
        this.titleListBiz = val;
        this.$emit('setComit', true);
      }
    }
  },
  methods: {
    ...mapActions(['resetRoleOperatRight']),
    // 通过权限的键序列获取完整的值序列
    getValListByKeyList: function(type, keyList) {
      if (type) {
        let _obj = this.$root.rights[type] || this.$root.rights[`$${type}`];
        if (_obj.maxStep) {
          let _rVal = _obj.handler.createValue(keyList);
          return _obj.handler.getValList(_rVal);
        } else {
          let _rVal = _obj.createValue(keyList);
          return _obj.getValList(_rVal);
        }
      } else {
        throw new Error('参数不正确');
      }
    },
    // 通过业务的 MenuId 值获取已设定的权限定义对象
    getRightByMenu: function (menuId) {
      let _obj = this.roleMenuAll[`role${this.currRoleEditObj.id}`];
      if (_obj) {
        return _obj.rights[`r${menuId}`];
      } else {
        return null;
      }
    },
    // 通过权限值获取权限的key集合
    getKeyList: function(val, type) {
      if (val && type) {
        let _rightHandler = this.$root.rights[type] || this.$root.rights[`$${type}`];
        if (_rightHandler.maxStep) {
          return _rightHandler.handler.getKeyList(val);
        } else {
          return _rightHandler.getKeyList(val);
        }
      } else {
        return [];
      }
    },
    // 对当前角色选定的业务实体进行操作权限设置
    selectOrm: function (item) {
      let _that = this;
      let setInit = () => {
        _that.currOrmInRoleEdit = item;
        let _obj = _that.getRightByMenu(item.menuId);
        if (_obj) {
          _that.crudIsNull = _obj.crudVal === 0;
          _that.extendIsNull = _obj.extendVal === 0;
          _that.bizIsNull = _obj.bizVal === 0;
          _that.titleListCrud = _that.getKeyList(_obj.crudVal, 'crud');
          _that.titleListExtend = _that.getKeyList(_obj.extendVal, 'extend');
          _that.titleListBiz = _that.getKeyList(_obj.bizVal, item.tblName);
          _that.fieldListHide = _obj.disFieldRange;
          _that.fieldListHide = [];
          _that.fieldlistShow = [];
          for (let v of _that.currOrmInRoleEdit.columns) {
            if (!ourRange.includes(v.code)) {
              if (_obj.disFieldRange.includes(v.code)) {
                _that.fieldListHide.push(v);
              } else {
                _that.fieldlistShow.push(v);
              }
            }
          }
          _that.valListCrud = _that.$root.rights.$crud.getValList(_obj.crudVal);
          _that.valListExtend = _that.$root.rights.$extend.getValList(_obj.extendVal);
          _that.valListBiz = _that.$root.rights[_that.currOrmInRoleEdit.tblName].handler.getValList(_obj.bizVal);
        } else {
          _that.titleListCrud = [];
          _that.titleListExtend = [];
          _that.titleListBiz = [];
          _that.fieldListHide = [];
        }
      };
      if (_that.needCommitRole && _that.currOrmInRoleEdit.tblName !== item.tblName) {
        _that.$Modal({
          title: '需要保存',
          content: `刚才的编辑未保存，是否先保存，再切换到 [ ${item.namezh} ]`,
          middle: true,
          buttons: [{
            type: 'ok',
            name: '保存并切换',
            color: 'primary'
          }, {
            type: 'delete',
            name: '放弃更改'
          }, {
            type: 'cancel',
            name: '返回'
          }],
          events: {
            // 保存并切换
            ok: async modal => {
              modal.close();
              try {
                await _that.saveRoleOperat();
                setInit();
              } catch (err) {
                global.terr(err);
              }
            },
            // 放弃更改
            delete: modal => {
              setInit();
              _that.$emit('setComit', false);
              modal.close();
            },
            // 取消
            cancel: modal => {
              modal.close();
            }
          }
        });
      } else {
        setInit();
      }
    },
    // 从当前显示的字段列表中隐藏被点击项
    hideField: function (code) {
      let _idx = this.fieldlistShow.findIndex(v => v.code === code);
      if (_idx > -1) {
        let x = this.fieldlistShow.splice(_idx, 1)[0];
        this.fieldListHide.push(x);
        this.$emit('setComit', true);
      }
    },
    // 从当前的隐藏字段列表中恢复被点击项的显示
    showHideField: function (code) {
      let _idx = this.fieldListHide.findIndex(v => v.code === code);
      if (_idx > -1) {
        let x = this.fieldListHide.splice(_idx, 1)[0];
        this.fieldlistShow.push(x);
        this.$emit('setComit', true);
      }
    },
    // 响应 CRUD 按钮组的 noAccess 事件
    setNoAccessCrud: function(e) {
      this.crudIsNull = e;
    },
    // 响应 Extend 按钮组的 noAccess 事件
    setNoAccessExtend: function(e) {
      this.extendIsNull = e;
    },
    // 响应 biz 按钮组的 noAccess 事件
    setNoAccessBiz: function(e) {
      this.bizIsNull = e;
    },
    // 保存当前角色的操作定义
    saveRoleOperat: function () {
      let _roleId = this.currRoleEditObj.id;
      let _rootRight = this.$root.rights;
      let x = {
        roleId: _roleId,
        menuId: this.currOrmInRoleEdit.menuId,
        crudVal: _rootRight.$crud.createValue(this.titleListCrud),
        extendVal: _rootRight.$extend.createValue(this.titleListExtend),
        bizVal: _rootRight[this.currOrmInRoleEdit.tblName].handler.createValue(this.titleListBiz),
        disRange: this.fieldListHide.map(v => v.code).join(',')
      };
      this.resetRoleOperatRight(x)
        .then(res => {
          this.$emit('reRole', res);
          global.tinfo(`角色[ ${this.currRoleEditObj.namezh} ]的操作授权完成`);
        })
        .catch(err => {
          global.terr(err);
        });
    }
  },
  mounted() {
    // 初始化种子
    let {
      $crud,
      $extend,
      ...otherBiz
    } = this.$root.rights;
    let _keysCrud = $crud.getKeys();
    let _titleCrud = $crud.getTitles();
    let i = 0;
    for (let v of _keysCrud) {
      this.seeds.crud.push({
        key: v,
        title: _titleCrud[i]
      });
      i++;
    }
    i = 0;
    let _keysExtend = $extend.getKeys();
    let _titleExtend = $extend.getTitles();
    for (let v of _keysExtend) {
      this.seeds.extend.push({
        key: v,
        title: _titleExtend[i]
      });
      i++;
    }
    for (let vBiz of Object.keys(otherBiz)) {
      let _objBiz = {};
      let _keys = otherBiz[vBiz].handler.getKeys();
      let _titles = otherBiz[vBiz].handler.getTitles();
      let i = 0;
      for (let vKey of _keys) {
        _objBiz[vKey] = _titles[i];
        i++;
      }
      this.seeds[vBiz] = _objBiz;
    }
  }
};
</script>

<style lang="less" scoped>
@import './index.less';
</style>
