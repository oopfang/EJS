<template>
<!-- 数据权限 -->
<div class="roleEditContent">
  <br />数据权限
  <br />待考虑：
  <br />组织级别权限
  <br />渠道权限
  <br />主数据权限
  <br />审批代理
  <br />上溯级别（如销售助理可以代销售总监审批），不以数字表示，而用界面选择代理人
  </div>
</template>

<script>
export default {
  name: '',
  components: {},
  props: {
    // 该组件的父级组件的标签切换ID
    currStep: {
      type: Number,
      default: 0
    }
  },
  data: function () {
    return {
      test: 1
    };
  },
  computed: {},
  methods: {}
};
</script>

<style lang="less" scoped>
</style>
