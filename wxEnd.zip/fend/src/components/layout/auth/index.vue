<template>
<basePage class="rightPage">
  <h3 class="pageTitle">系统授权中心</h3>
  <div class="rightWapper">
    <ul v-show="showLeftMenu" class="rightMneu">
      <li :class="{ active: currRightType === index }" v-for="(item, index) in rightTypes" :key="item" @click.prevent="switchLeft(index)">{{ item }}</li>
    </ul>
    <accMgr v-show="currRightType===0" :accountData="accountData" :roleList="role" :orgsList="orgs" :orgType="orgType"></accMgr>
    <roleMgr v-show="currRightType===1" :accountData="accountData" :roleList="role" :menuFlatList="menuFlat" :roleMenuAll="roleMenuAll" :ormData="ormData" @reAcc="refreshAccountData" @reRole="initRoleMenus" @changeMenu="setMenu"></roleMgr>
    <flowMgr v-show="currRightType===2" :ormData="ormData" :flowMenu="flowMenu" :roleList="role" :accountData="accountData" :roleMenuAll="roleMenuAll" @changeMenu="setMenu" @reSetFlowMenu="reSetFlowMenu"></flowMgr>
    <demoCenter v-show="currRightType===3"></demoCenter>
  </div>
</basePage>
</template>

<script>
import basePage from '../../wrapper/base';
import {
  mapActions
} from 'vuex';
let accMgr = () => import(/* webpackChunkName:'auth' */ './accMgr');
let roleMgr = () => import(/* webpackChunkName:'auth' */ './roleMgr/roleBase.vue');
let flowMgr = () => import(/* webpackChunkName:'auth' */ './flowMgr');
let demoCenter = () => import(/* webpackChunkName:'auth' */ './demoCenter');

export default {
  name: '',
  components: {
    basePage,
    accMgr,
    roleMgr,
    flowMgr,
    demoCenter
  },
  data: function () {
    return {
      // 隐藏左侧导航
      showLeftMenu: true,
      // 授权操作类别
      rightTypes: ['账号管理', '角色规划', '流程引擎', '演示数据', '退出'],
      // 当前的授权操作类别
      currRightType: 0,
      // Orms数据集
      ormData: {},
      // 账号数据集
      accountData: [],
      // 角色数据集
      role: [],
      // db中已存储的所有角色的菜单项
      roleMenuAll: {},
      // 菜单数据集
      menus: [],
      // 菜单数据集的扁平集合
      menuFlat: [],
      // 工作流设计中的有效菜单集
      flowMenu: [],
      // 组织数据集
      orgs: {},
      // 组织类型
      orgType: {}
    };
  },
  methods: {
    // ...mapActions(['querAuth', 'accForbidden', 'accRePwd', 'resetRole', 'createRole', 'deleletRole', 'resetRoleMenu', 'resetRoleOperatRight']),
    ...mapActions(['querAuth']),
    // 控制左侧导航的显示隐藏
    setMenu: function (e) {
      this.showLeftMenu = e;
    },
    // 从左侧纵向TAB标签切换授权操作类别的响应
    switchLeft: function (idx) {
      if (idx === this.rightTypes.length - 1) {
        this.$router.push({
          name: 'home'
        });
      } else {
        this.currRightType = idx;
      }
    },
    // 按照角色分组初始化每个角色所拥有菜单项的映射数据
    initRoleMenus: function (roleMenuArr) {
      let _that = this;
      // 对已有的角色列表中每项，添加 hasMenu 和 noMenu 空数组
      for (let vRole of _that.role) {
        if (vRole.code !== 'authKeeperGroup' && vRole.code !== 'userLimitGroup') {
          _that.roleMenuAll[`role${vRole.id}`] = {
            hasMenu: [],
            noMenu: []
          };
        }
      }
      // 遍历现有的角色列表
      for (let _vRm of Object.keys(_that.roleMenuAll)) {
        let _currRoleMenuObj = _that.roleMenuAll[_vRm];
        let _arrMenu = {};
        let _arrRight = {};
        let _currV = _vRm;
        // 从传入的参数中过滤属于当前角色的菜单项
        roleMenuArr.filter(vSub => {
          return `role${vSub.pid}` === _currV;
        }).forEach((vmap, kmap, arrmap) => {
          _arrMenu[`m${vmap.menuId}`] = 1;
          let _str = `r${vmap.menuId}`;
          _arrRight[_str] = {
            crudVal: vmap.crudVal,
            extendVal: vmap.extendVal,
            bizVal: vmap.bizVal
          };
          if (vmap.disFieldRange) {
            _arrRight[_str].disFieldRange = vmap.disFieldRange.split(',');
          } else {
            _arrRight[_str].disFieldRange = [];
          }
        });
        // 遍历所有一级菜单项，并将菜单的详细信息填充到该角色的每个菜单ID中
        for (let vmen of _that.menus) {
          // if (vmen.key !== 'auth') {
          // 如果该菜单ID存在于该角色的已分配菜单映射表中
          if (_arrMenu[`m${vmen.id}`]) {
            /* eslint-disable no-unused-vars */
            let {
              children,
              ...otherMenu
            } = vmen;
            // 该一级菜单包含子菜单
            if (children) {
              if (children.length > 0) {
                // 有 children 且数量不为零
                otherMenu.children = [];
                // 遍历子菜单
                for (let vChild of children) {
                  // 该子菜单已在注册列表中登记
                  if (_arrMenu[`m${vChild.id}`]) {
                    // 判断子菜单的父级是否已经在注册列表中登记
                    let _idxHas = _currRoleMenuObj.hasMenu.findIndex(vHas => vHas.id === otherMenu.id);
                    if (_idxHas === -1) {
                      otherMenu.children.push(vChild);
                      _currRoleMenuObj.hasMenu.push(otherMenu);
                    } else {
                      _currRoleMenuObj.hasMenu[_idxHas].children.push(vChild);
                    }
                  } else {
                    // 子菜单未在注册列表中登记
                    let _idxNo = _currRoleMenuObj.noMenu.findIndex(vNo => vNo.id === otherMenu.id);
                    if (_idxNo === -1) {
                      let _noMenu = JSON.parse(JSON.stringify(otherMenu));
                      _noMenu.children = [];
                      _noMenu.children.push(vChild);
                      _currRoleMenuObj.noMenu.push(_noMenu);
                    } else {
                      _currRoleMenuObj.noMenu[_idxNo].children.push(vChild);
                    }
                  }
                }
              } else {
                // 有 children，但子集数量为0
                _currRoleMenuObj.noMenu.push(vmen);
              }
            } else {
              // 一级菜单，但不包含子集（直接添加）
              _currRoleMenuObj.hasMenu.push(otherMenu);
            }
          } else {
            // 未在注册列表中登记（直接拒绝）
            _currRoleMenuObj.noMenu.push(vmen);
          }
          // }
        }
        _currRoleMenuObj.rights = _arrRight;
        _currRoleMenuObj.hasMenu.sort((a, b) => {
          return a.pid - b.pid || a.orderIndex - b.orderIndex;
        });
        _currRoleMenuObj.noMenu.sort((a, b) => {
          return a.pid - b.pid || a.orderIndex - b.orderIndex;
        });
      }
      this.roleMenuAll = _that.roleMenuAll;
    },
    // 刷新 accountData 数据
    refreshAccountData: function (acc) {
      if (acc && Array.isArray(acc)) {
        this.accountData = acc.map(v => {
          v.roleName = v.roleId.split(',');
          v.$unSave = {};
          return v;
        });
      }
    },
    // 刷新 flowMenu 数据
    reSetFlowMenu: function(e) {
      let _idx = this.flowMenu.findIndex(v => v.code === e.code);
      this.$set(this.flowMenu, _idx, e);
    }
  },
  mounted() {
    this.$root.eventHub.$emit('switchMenu', false);
    this.querAuth()
      .then(res => {
        this.ormData = res.orms;
        this.refreshAccountData(res.account);
        this.role = res.role;
        this.menus = res.menus;
        this.menuFlat = res.menuFlat;
        this.flowMenu = res.flowMenu;
        this.orgs = res.orgs;
        this.orgType = res.orgType;
        this.initRoleMenus(res.roleMenu);
      })
      .catch(err => {
        global.terr(err);
      });
  },
  destroyed() {
    this.$root.eventHub.$emit('switchMenu', true);
  }
};
</script>

<style lang="less" scoped>
@import '../../../assets/less/index.less';

.rightPage {
  .pageTitle {
    text-align: center;
    padding: 8px 50px;
    margin-bottom: 18px;
    font-weight: 700;
    border-bottom: 1px #aaa dotted;
    text-shadow: 2px 2px 8px #ccc;
  }

  .rightWapper {
    display: flex;
    flex-direction: row;
    width: 100%;
    height: 100%;

    .rightMneu {
      display: inline-block;
      width: 120px;
      line-height: 1;
      font-size: 15px;

      li {
        padding: 8px;
        text-align: center;
        cursor: pointer;
      }

      li:hover {
        background-color: rgba(0, 0, 0, .3);
      }

      li.active {
        border-right: 5px blue solid;
        background-color: #ccc;
      }
    }
  }
}
</style>
