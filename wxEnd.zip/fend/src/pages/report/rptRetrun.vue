<template>
<baseRpt :masterKeys="masterKeys" :dictKeys="dictKeys">
  <tPanel showHeader>
    <div slot="panelHeader" class="btnGroup">
      <span class="btnItem active">退货统计</span>
      <span class="flexSplit"></span>
      <span class="btnItem" :class="{ active: currType === item.key }" v-for="item of typeArr" :key="item.key" @click.prevent.stop="setFilter(item.key)">{{ item.title }}</span>
    </div>
    <div>
      <Table :datas="dataList" border  stripe :loading="loading">
        <TableItem title="序号" prop="$serial" v-if="serial"></TableItem>
        <TableItem title="产品" prop="prodName"></TableItem>
        <TableItem title="规格" prop="specName"></TableItem>
        <TableItem title="型号" prop="sizeName"></TableItem>
        <TableItem title="数量" prop="quantity" sort="auto"></TableItem>
        <TableItem title="单价" prop="price" sort="auto"></TableItem>
        <TableItem title="金额" prop="cost" sort="auto"></TableItem>
        <TableItem title="状态" prop="checkTypeName" sort="auto"></TableItem>
        <div slot="empty">暂无退货数据</div>
      </Table>
    </div>
  </tPanel>
</baseRpt>
</template>

<script>
import baseRpt from '@/components/wrapper/baseRpt';
import tPanel from '@/components/wrapper/part/tPanel';
import { mapActions } from 'vuex';

export default {
  components: {
    baseRpt,
    tPanel
  },
	data() {
		return {
      dictKeys: ['returnQualityType'],
      masterKeys: [],
      typeArr: [],
      currType: -1,
			dataList: [
        { id: 5, name: '测试5', age: 12, address: '上海' },
        { id: 6, name: '测试6', age: 13, address: '上海' },
        { id: 7, name: '测试7', age: 14, address: '上海' },
        { id: 5, name: '测试5', age: 15, address: '上海' },
        { id: 6, name: '测试6', age: 16, address: '上海' },
        { id: 7, name: '测试7', age: 17, address: '上海' }
      ]
		}
  },
  methods: {
    ...mapActions(['querRptByProd']),
    async queryData(typeId) {
      this.dataList = await this.querRptByProd({
        typeId: typeId
      });
    },
    setFilter(tId) {
      this.currType = tId;
      this.queryData(tId);
    }
  },
  mounted() {
    this.queryData();
    this.typeArr = this.$root.$data._dict.returnQualityType;
    this.typeArr.unshift({
      key: -1,
      title: '全部'
    });
  }
};
</script>
