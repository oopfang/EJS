<template>
<baseRpt>
  <div class="rptCell cellItm">
    <!-- 今日流水分拣分析 -->
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">今日流水分拣分析</span>
      </div>
      <div>
        <bar ref="anysWarterFllow"></bar>
      </div>
    </tPanel>
    <!-- 今日货物占比 -->
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">今日货物占比</span>
      </div>
      <div>
        <pie ref="goodsProp"></pie>
      </div>
    </tPanel>
  </div>
  <div class="rptCell cellItm">
    <!-- 今日退货情况 -->
    <tPanel showHeader>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">今日退货情况</span>
      </div>
      <div class="cellBlog">
        <div class="infoItem redStr">
          <span class="val">2000</span>
          <span class="title">退货数量</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem mainStr">
          <span class="val">1800</span>
          <span class="title">平均退货数量</span>
        </div>
      </div>
    </tPanel>
    <!-- 今日流水压力分析 -->
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">今日流水压力分析</span>
      </div>
      <div>
        <bar ref="anysWarterPressure"></bar>
      </div>
    </tPanel>
  </div>
  <!-- 产品退货情况排名 -->
  <div class="rptCell cellItm">
    <!-- 今日今日已分拣实时数据 -->
    <tPanel showHeader>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">今日今日已分拣实时数据</span>
      </div>
      <div class="cellBlog">
        <div class="infoItem redStr">
          <span class="val">23</span>
          <span class="title">破损</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem mainStr">
          <span class="val">5000</span>
          <span class="title">临保</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem greenStr">
          <span class="val">5</span>
          <span class="title">三方检测</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem mainStr">
          <span class="val">300</span>
          <span class="title">再销售</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem redStr">
          <span class="val">30</span>
          <span class="title">报废</span>
        </div>
      </div>
    </tPanel>
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">产品退货情况排名</span>
      </div>
      <div>
        <bar ref="prodBackRank"></bar>
      </div>
    </tPanel>
  </div>
</baseRpt>
</template>

<script>
import baseRpt from '@/components/wrapper/baseRpt';
import tPanel from '@/components/wrapper/part/tPanel';
import bar from '@/components/charts/bar';
import pie from '@/components/charts/pie';
let _getChartOpt = (title = '报表', subTitle = '', chartData, chartLegend) => {
  return {
    title: title,
    subTitle: subTitle,
    chartLegend: chartLegend,
    chartData: chartData
  };
};

export default {
  components: {
    baseRpt,
    tPanel,
    bar,
    pie
  },
  methods: {
    // 今日流水分拣分析
    onAnysWarterFllow(val) {
      let _anysWarterFllow = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.anysWarterFllow.update(_anysWarterFllow);
      this.$refs.anysWarterFllow.resize({
        height: '200px'
      });
    },
    // 今日货物占比
    onGoodsProp(val) {
      let _goodsProp = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.goodsProp.update(_goodsProp);
		},
		// 今日流水压力分析
		onAnysWarterPressure(val) {
      let _anysWarterPressure = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.anysWarterPressure.update(_anysWarterPressure);
		},
		// 产品退货情况排名
		onProdBackRank(val) {
      let _prodBackRank = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.prodBackRank.update(_prodBackRank, true);
      this.$refs.prodBackRank.resize({
        height: '500px'
      });
		}
  },
  mounted() {
    this.onAnysWarterFllow([{
      id: 1,
      name: '今日货量',
      value: 300
    }, {
      id: 2,
      name: '历史平均货量',
      value: 400
    }, {
      id: 3,
      name: '已分拣',
      value: 450
    }]);
    this.onGoodsProp([{
      id: 1,
      name: '报废',
      value: 300
    }, {
      id: 2,
      name: '再销售',
      value: 400
    }, {
      id: 3,
      name: '临保',
      value: 410
    }, {
      id: 4,
      name: '返厂检测',
      value: 330
    }, {
      id: 5,
      name: '破损',
      value: 500
		}]);
    this.onAnysWarterPressure([{
      id: 1,
      name: '破损',
      value: 300
    }, {
      id: 2,
      name: '临保',
      value: 400
    }, {
      id: 3,
      name: '三方检测',
      value: 410
    }, {
      id: 4,
      name: '再销售',
      value: 330
    }, {
      id: 5,
      name: '报废',
      value: 500
		}]);
    this.onProdBackRank([{
      id: 1,
      name: '产品3',
      value: 50
    }, {
      id: 2,
      name: '产品2',
      value: 100
    }, {
      id: 3,
      name: '产品5',
      value: 180
    }, {
      id: 4,
      name: '产品7',
      value: 230
    }, {
      id: 5,
      name: '产品1',
      value: 300
		}, {
      id: 6,
      name: '产品4',
      value: 380
		}, {
      id: 7,
      name: '产品9',
      value: 430
		}, {
      id: 8,
      name: '产品8',
      value: 600
		}, {
      id: 9,
      name: '产品6',
      value: 650
		}]);
  }
}
</script>
