<template>
<baseRpt>
  <div class="rptCell cellItm">
    <!-- 年度营业额分析 -->
    <tPanel showHeader asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">年度营业额分析</span>
      </div>
      <div>
        <bar ref="anysYearSales"></bar>
      </div>
    </tPanel>
    <!-- 各类产品营业额占比 -->
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">各类产品营业额占比</span>
      </div>
      <div>
        <pieNormal ref="goodsTypeRank"></pieNormal>
      </div>
    </tPanel>
  </div>
  <div class="rptCell cellItm">
		<!-- 本周退货产品状况实时数据 -->
    <tPanel showHeader asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">本周退货产品状况实时数据</span>
      </div>
      <div>
        <pie ref="anayWeekGoodsBack"></pie>
      </div>
    </tPanel>
		<!-- 年度退货产品状况实时数据 -->
    <tPanel showHeader :topSpace="8">
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">年度退货产品状况实时数据</span>
      </div>
      <div class="cellBlog">
        <div class="infoItem redStr">
          <span class="val">23</span>
          <span class="title">破损</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem mainStr">
          <span class="val">5000</span>
          <span class="title">临保</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem greenStr">
          <span class="val">5</span>
          <span class="title">三方检测</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem mainStr">
          <span class="val">300</span>
          <span class="title">再销售</span>
        </div>
        <div class="splitLine"></div>
        <div class="infoItem redStr">
          <span class="val">30</span>
          <span class="title">报废</span>
        </div>
      </div>
    </tPanel>
  </div>
  <div class="rptCell cellItm">
		<!-- 年度产品销售情况排名一览 -->
    <tPanel showHeader asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">年度产品销售情况排名一览</span>
      </div>
      <div>
        <bar ref="prodSalesRank"></bar>
      </div>
    </tPanel>
  </div>
</baseRpt>
</template>

<script>
import baseRpt from '@/components/wrapper/baseRpt';
import tPanel from '@/components/wrapper/part/tPanel';
import bar from '@/components/charts/bar';
import pie from '@/components/charts/pie';
import pieNormal from '@/components/charts/pieNormal';
let _getChartOpt = (title = '报表', subTitle = '', chartData, chartLegend) => {
  return {
    title: title,
    subTitle: subTitle,
    chartLegend: chartLegend,
    chartData: chartData
  };
};

export default {
  components: {
    baseRpt,
		tPanel,
		bar,
		pie,
		pieNormal
	},
	methods: {
		// 年度营业额分析
		onAnysYearSales(val) {
      let _anysYearSales = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.anysYearSales.update(_anysYearSales);
		},
		// 各类产品营业额占比
		ongoodsTypeRank(val) {
      let _goodsTypeRank = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.goodsTypeRank.update(_goodsTypeRank);
		},
		// 本周退货产品状况实时数据
		onAnayWeekGoodsBack(val) {
      let _anayWeekGoodsBack = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.anayWeekGoodsBack.update(_anayWeekGoodsBack);
		},
		// 年度产品销售情况排名一览
		onProdSalesRank(val) {
      let _prodSalesRank = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.prodSalesRank.update(_prodSalesRank, true);
      this.$refs.prodSalesRank.resize({
        height: '600px'
      });
		}
	},
	mounted() {
    this.onAnysYearSales([{
      id: 1,
      name: '2016年',
      value: 300
    }, {
      id: 2,
      name: '2017年',
      value: 400
    }, {
      id: 3,
      name: '2018年',
      value: 450
    }, {
      id: 4,
      name: '2019年',
      value: 350
    }]);
    this.ongoodsTypeRank([{
      id: 1,
      name: '再销售',
      value: 300
    }, {
      id: 2,
      name: '销量',
      value: 400
		}]);
    this.onAnayWeekGoodsBack([{
      id: 1,
      name: '2月9号',
      value: 50
    }, {
      id: 2,
      name: '2月10号',
      value: 400
    }, {
      id: 3,
      name: '2月11号',
      value: 230
    }, {
      id: 4,
      name: '2月12号',
      value: 350
    }, {
      id: 5,
      name: '2月13号',
      value: 150
    }, {
      id: 6,
      name: '2月14号',
      value: 80
    }]);
    this.onProdSalesRank([{
      id: 1,
      name: '产品3',
      value: 50
    }, {
      id: 2,
      name: '产品2',
      value: 100
    }, {
      id: 3,
      name: '产品5',
      value: 180
    }, {
      id: 4,
      name: '产品7',
      value: 230
    }, {
      id: 5,
      name: '产品1',
      value: 300
		}, {
      id: 6,
      name: '产品4',
      value: 380
		}, {
      id: 7,
      name: '产品9',
      value: 430
		}, {
      id: 8,
      name: '产品8',
      value: 600
		}, {
      id: 9,
      name: '产品6',
      value: 650
		}]);
	}
}
</script>
