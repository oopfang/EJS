<template>
<baseRpt>
	<div slot="filterRow" class="filterZone">
    <div class="h-input-group">
			<span class="h-input-addon">退货日期范围：</span>
			<DateRangePicker v-model="dateStart" :format="fmtStr"></DateRangePicker>
    </div>
    <div class="h-input-group">
			<span class="h-input-addon">商品编码</span>
    	<input type="text" v-width="300" v-model="proudCode" placeholder="支持商品代码或商品名称的模糊查询" />
    </div>
    <div class="h-input-group">
			<span class="h-input-addon">规格</span>
    	<input type="text" v-width="300" v-model="spec" placeholder="支持规格的代码或规格名称的模糊查询" />
    </div>
	</div>
  <div class="rptCell cellItm">
    <!-- 退货类型（按数量统计） -->
    <tPanel showHeader asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">退货类型（按数量统计）</span>
      </div>
      <div>
        <pieNormal ref="backTypeByNum"></pieNormal>
      </div>
    </tPanel>
    <!-- 退货原因（按数量统计） -->
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">退货原因（按数量统计）</span>
      </div>
      <div>
        <pieNormal ref="backReasonByNum"></pieNormal>
      </div>
    </tPanel>
  </div>
  <div class="rptCell cellItm">
		<!-- 退货类型（按金额统计） -->
    <tPanel showHeader asFlex1>
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">退货类型（按金额统计）</span>
      </div>
      <div>
        <pieNormal ref="backTypeByAmount"></pieNormal>
      </div>
    </tPanel>
		<!-- 退货原因（按金额统计） -->
    <tPanel showHeader :topSpace="8">
      <div slot="panelHeader">
        <span class="h-tag h-tag-bg-primary">退货原因（按金额统计）</span>
      </div>
      <div>
        <pieNormal ref="backReasonByAmount"></pieNormal>
      </div>
    </tPanel>
  </div>
</baseRpt>
</template>

<script>
import baseRpt from '@/components/wrapper/baseRpt';
import tPanel from '@/components/wrapper/part/tPanel';
import pieNormal from '@/components/charts/pieNormal';
let _getChartOpt = (title = '报表', subTitle = '', chartData, chartLegend) => {
  return {
    title: title,
    subTitle: subTitle,
    chartLegend: chartLegend,
    chartData: chartData
  };
};

export default {
  components: {
    baseRpt,
		tPanel,
		pieNormal,
	},
	data() {
		return {
			// 日期控件格式化字符串
			fmtStr: 'YYYY-MM-DD',
			// 退货查询日期范围
			dateStart: {},
			// 查询商品
			proudCode: '',
			// 查询规格
			spec: ''

		};
	},
	methods: {
		// 退货类型（按数量统计）
		onBackTypeByNum(val) {
      let _backTypeByNum = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.backTypeByNum.update(_backTypeByNum);
		},
		// 退货类型（按金额统计）
		onBackTypeByAmount(val) {
      let _backTypeByAmount = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.backTypeByAmount.update(_backTypeByAmount);
		},
		// 退货原因（按数量统计）
		onBackReasonByNum(val) {
      let _backReasonByNum = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.backReasonByNum.update(_backReasonByNum);
		},
		// 退货原因（按金额统计）
		onBackReasonByAmount(val) {
      let _backReasonByAmount = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.backReasonByAmount.update(_backReasonByAmount);
		},
	},
	mounted() {
    this.onBackTypeByNum([{
      id: 1,
      name: '商业退回',
      value: 300
    }, {
      id: 2,
      name: '商业退货',
      value: 400
    }, {
      id: 3,
      name: '厂家退货',
      value: 450
    }]);
    this.onBackTypeByAmount([{
      id: 1,
      name: '商业退回',
      value: 33970.23
    }, {
      id: 2,
      name: '商业退货',
      value: 52372.78
    }, {
      id: 3,
      name: '厂家退货',
      value: 12302
    }]);
    this.onBackReasonByNum([{
      id: 1,
      name: '近效期',
      value: 300
    }, {
      id: 2,
      name: '过保质期',
      value: 400
    }, {
      id: 3,
      name: '监管部门责令召回',
      value: 250
    }, {
      id: 4,
      name: '包装损坏',
      value: 600
    }, {
      id: 5,
      name: '强制性退货',
      value: 510
    }, {
      id: 6,
      name: '不在质保范围',
      value: 490
		}]);
    this.onBackReasonByAmount([{
      id: 1,
      name: '近效期',
      value: 3000
    }, {
      id: 2,
      name: '过保质期',
      value: 8000
    }, {
      id: 3,
      name: '监管部门责令召回',
      value: 2050
    }, {
      id: 4,
      name: '包装损坏',
      value: 1000
    }, {
      id: 5,
      name: '强制性退货',
      value: 5010
    }, {
      id: 6,
      name: '不在质保范围',
      value: 4090
		}]);
	}
}
</script>

<style lang="less" scoped>
.filterZone {
	display: flex;
	justify-content: flex-start;
	align-items: center;
	width: 100%;
	height: 50px;
	margin: 0 8px;
	border-bottom: 1px #ccc solid;
}
</style>