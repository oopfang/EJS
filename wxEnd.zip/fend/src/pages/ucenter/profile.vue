<template>
<tBase>
  <Row :space="10">
    <Col width="18">
    <Row :space="10">
      <Col width="4" style="text-align: center;">
      <t-panel>
        <img :width="120" :height="120" style="border-radius:80px; padding: 20px;" :src="`${getUserInfo.avatar}?v=8.0`">
        <p class="editAvaterTxt">
          修改头像<tIcon icon="t-edit-pencil" :size="4"></tIcon>
        </p>
      </t-panel>
      </Col>
      <Col width="20">
      <tPanel showHeader :minH="176" :maxH="176">
        <span slot="panelHeader">个人资料</span> 个人资料
      </tPanel>
      </Col>
      <Col width="24">
      <tPanel showHeader :minH="185">
        <span slot="panelHeader">公司信息</span>
      </tPanel>
      </Col>
    </Row>
    </Col>
    <Col width="6">
    <tPanel showHeader :minH="372" :maxH="372">
      <span slot="panelHeader">修改密码</span>
      <Form ref="pwdForm" style="margin-top: 30px;" :label-width="150" :rules="rules" :model="pwdData">
        <FormItem label="旧密码" prop="oldPwd">
          <input type="password" v-model="pwdData.oldPwd" />
        </FormItem>
          <FormItem label="新密码" prop="newPwd1">
            <input type="password" v-model="pwdData.newPwd1" />
        </FormItem>
            <FormItem label="再次输入新密码" prop="newPwd2">
              <input type="password" v-model="pwdData.newPwd2" />
        </FormItem>
              <FormItem>
                <Button color="primary" @click="resetPwd">提交</Button>&nbsp;&nbsp;&nbsp;
                <Button @click="cancelResetPwd">取消</Button>
              </FormItem>
      </Form>
    </tPanel>
    </Col>
  </Row>
</tBase>
</template>

<script>
import tBase from '@/components/wrapper/base';
import tPanel from '@/components/wrapper/part/tPanel';
import tIcon from '@/components/widge/tIcon';
import {
  mapGetters,
  mapMutations,
  mapActions
} from 'vuex';

export default {
  name: 'profile',
  components: {
    tBase,
    tPanel,
    tIcon
  },
  data: function () {
    return {
      pwdData: {
        oldPwd: '',
        newPwd1: '',
        newPwd2: ''
      },
      rules: {
        required: ['oldPwd', 'newPwd1', 'newPwd2'],
        combineRules: [{
          refs: ['newPwd1', 'newPwd2'],
          valid: {
            valid: 'equal',
            message: '两次输入的密码不一致'
          }
        }]
      }
    };
  },
  computed: {
    ...mapGetters(['getUserInfo'])
  },
  methods: {
    ...mapMutations(['setInLoading']),
    ...mapActions(['changePwd']),
    resetPwd: function () {
      let validResult = this.$refs.pwdForm.valid();
      if (validResult.result) {
        /* eslint-disable no-undef */
        let x = {
          id: this.getUserInfo.id,
          code: this.getUserInfo.code,
          namezh: this.getUserInfo.namezh,
          oldPwd: sha1(this.pwdData.oldPwd),
          newPwd: sha1(this.pwdData.newPwd1)
        };
        this.changePwd(x)
          .then(res => {
            global.tinfo(res);
            this.$router.push({
              name: 'sign'
            });
          })
          .catch(err => {
            global.terr(err);
          });
      } else {
        let _errArr = validResult.messages.map(v => {
          return `${v.label}${v.message}`;
        });
        global.terr(_errArr);
      }
    },
    cancelResetPwd: function () {
      this.pwdData.oldPwd = '';
      this.pwdData.newPwd1 = '';
      this.pwdData.newPwd2 = '';
    }
  }
};
</script>

<style lang="less" scoped>
.editAvaterTxt {
  height: 34px;
  line-height: 34px;
  font-size: 12px;
  font-weight: 100;
  cursor: pointer;
}
</style>
