<template>
<baseCrudEdit :masterKeys="masterKeys" :dictKeys="dictKeys" :baseDefine="baseDefine" :inLoading="inLoading" :crudDef="crudDef" :currId="currId" :inEdit="inEdit" @pickOverEvent="onPickOverEvent" @saveEvnt="saveHandler">
  <Row v-if="dataset" :space="18">
    <Col :xl="6" :lg="6" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">通知日期</span>
    <span class="billItemData">{{dataset.dateDelivery}}</span>
    </Col>
    <Col :xl="6" :lg="6" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">通知单号</span>
    <span class="billItemData">{{dataset.fromBillNo}}</span>
    </Col>
    <Col :xl="6" :lg="6" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">拣货日期</span>
    <span class="billItemData">{{dataset.dateStorePick}}</span>
    </Col>
    <Col :xl="6" :lg="6" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">通知数量</span>
    <span class="billItemData">{{dataset.quantityDeliv}}</span>
    </Col>
  </Row>
  
  <div slot="subPanel" style="overflow: hidden;">
    <div class="itemRow asHeader">
      <div class="itemCell w1">序号</div>
      <div class="itemCell w6">商品</div>
      <div class="itemCell w3">规格</div>
      <div class="itemCell w3">型号</div>
      <div class="itemCell w4">架位号</div>
      <div class="itemCell w24">唯一码</div>
      <div class="itemCell w2">通知数量</div>
      <div class="itemCell w1">单位</div>
      <div class="itemCell w1">已拣</div>
    </div>
    <div class="detailWrapper">
      <div class="itemRow" v-for="(item, index) of dataset1" :key="item.id">
        <div class="itemCell w1">{{ index }}</div>
        <div class="itemCell w6">{{ item.prodId | localDict($root, 'produc') }}</div>
        <div class="itemCell w3">{{ item.spec | localDict($root, 'groupColor') }}</div>
        <div class="itemCell w3">{{ item.size | localDict($root, 'groupSize') }}</div>
        <div class="itemCell w4">{{ item.cellCode || '无' }}</div>
        <div class="itemCell w24">{{ item.uuCodePub }}-{{ item.uuCodePrive }}</div>
        <div class="itemCell w2">1</div>
        <div class="itemCell w1">{{ item.unit }}</div>
        <div class="itemCell w1">
          <i v-if="item.quantityPick" class="h-icon-complete" style="color: green; font-weight: 700;"></i>
          <i v-else class="h-icon-close" style="color: red; font-weight: 700;"></i>
        </div>
      </div>
    </div>
  </div>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billPick';

export default {
  name: 'billPickEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      masterKeys: ['customer', 'produc', 'groupColor', 'groupSize', 'hr'],
      dictKeys: [],
      crudDef: {
        hiddenAdd: true,
        hiddenEdit: true,
        hiddenDel: true,
        showPickOver: false,
        showPickOverTips: false
      },
      currStep: 0,
      inLoading: false,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {},
      dataset1: []
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillPickObj', 'getUserInfo'])
  },
  methods: {
    ...mapActions(['queryBillPickObj', 'putBillPickObj', 'postBillPickObj', 'putPickOver']),
    // 保存操作的响应
    async saveHandler() {
      try {
        let _func = this.isAdd ? this.postBillPickObj : this.putBillPickObj;
        let x = {};
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset, this.dataset.id)]
          }
        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };
        }
        let res = await _func(x);
        this.inEdit = false;
        x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: res
          }
        }];
        let resObj = await this.queryBillPickObj(x);
        this.dataset = resObj[0];
      } catch (err) {
        terr(err);
      }
    },
    async onPickOverEvent() {
      try {
        let x = {
          id: this.dataset.id,
          pid: this.dataset.pid,
          state: 1,
          inPc: true
        };
        let res = await this.putPickOver(x);
        this.$set(this.crudDef, 'showPickOver', res.done === 1 ? false : true);
        this.$set(this.crudDef, 'showPickOverTips', res.done === 1);
      } catch (err) {
        terr(err);
      }
    }
  },
  async mounted() {
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        if (id && id > 0) {
          this.isAdd = false;
          let x = {
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          };
          let [a, b] = await this.queryBillPickObj(x);
          this.dataset = a;
          this.dataset1 = b;
          this.inLoading = false;
          this.$set(this.crudDef, 'showPickOver', (a && (a.alreadyDone === 1)) ? false : true);
          this.$set(this.crudDef, 'showPickOverTips', (a && (a.alreadyDone === 1)));
        }
      }
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>

<style lang="less" scoped>
.detailWrapper {
  height: 75vh;
  overflow-x: hidden;
  overflow-y: auto;
}
.itemRow {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 32px;
  padding: 0;
  border-bottom: 1px #aaa solid;
}

.asHeader {
  background-color: #F0F0F2;
}

.itemCell {
  padding: 6px 0;
  text-align: center;
  border-right: 1px #AAA solid;
}

.w1 {
  width: 40px;
}

.w2 {
  width: 80px;
}

.w3 {
  width: 120px;
}

.w4 {
  width: 160px;
}

.w6 {
  width: 240px;
}

.w24 {
  flex: 1;
}
</style>