<template>
<baseCrudEdit :masterKeys="masterKeys" :dictKeys="dictKeys" :baseDefine="baseDefine" :inLoading="inLoading" :crudDef="crudDef" :currId="currId" :inEdit="inEdit" @onAdd="onAdd" @onEdit="onEdit" @saveEvnt="saveHandler">
  <Row v-if="dataset" :space="18">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">入库日期</span>
      <DatePicker v-if="inEdit" v-model="dataset.dateStroeIn" format="YYYY-MM-DD"></DatePicker>
      <span v-else class="billItemData">{{dataset.dateStroeIn || '未入库'}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">入库来源单号</span>
      <input v-if="inEdit" type="text" v-model="dataset.fromBillNo" />
      <span v-else class="billItemData">{{dataset.fromBillNo}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">仓库</span>
      <Select v-model="dataset.wHouseId" :datas="$root.$data._dict.warehouse" disabled :nullOption="false"></Select>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">入库类型</span>
      <Select v-model="dataset.stroeInTypeId" :datas="$root.$data._dict.storeInType" disabled :nullOption="false"></Select>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">收货员</span>
      <span class="billItemData">{{dataset.operator | localDict($root, 'hr')}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="infoTips">
      <span v-if="dataset.recived" class="tagRecived already">收货完毕</span>
      <span v-else class="tagRecived unRecived">未收货</span>
      <span>申请数量: {{ dataset.quantity }}</span>
      <span :style="{ color: dataset.quantity === dataset.quantityAct ? '#000' : 'red' }">实收数量： {{ dataset.quantityAct }}</span>
    </Col>
      <Col :width="24" class="h-input-group">
        <span class="h-input-addon">备注</span>
      </Col>
      <Col :width="24" class="h-input-group">
        <textarea rows="1" v-autosize v-model="dataset.memo" readonly></textarea>
      </Col>
  </Row>

  <Row slot="subPanel" :space="8">
    <p class="switchPanel">
      <span class="switchTag" :class="{ active: showUnrecive === index }" v-for="(item, index) of detailTypeList" :key="index" @click.prevent.stop="showUnrecive=index">{{ item }}</span>
    </p>
      <tCrudPanel v-for="(itemSub1, indexSub1) in getDetailList" :key="indexSub1" :idNum="indexSub1" :isLast="indexSub1 === dataset1.length - 1" :topSpace="18" :allowDel="false" :allowSort="false">
        <Row :space="18">
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">商品</span>
          <Select v-model="itemSub1.prodId" :datas="$root.$data._dict.produc" :disabled="!inEdit" :nullOption="false"></Select>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">规格</span>
          <Select v-model="itemSub1.spec" :datas="$root.$data._dict.groupColor" :disabled="!inEdit" :nullOption="false"></Select>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">型号</span>
          <Select v-model="itemSub1.size" :datas="$root.$data._dict.groupSize" :disabled="!inEdit" :nullOption="false"></Select>
          </Col>
          <Col :xl="4" :lg="4" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">单位</span>
          <input v-if="inEdit" type="text" v-model="itemSub1.unit" />
          <span v-else class="billItemData">{{itemSub1.unit}}</span>
          </Col>
          <Col :xl="6" :lg="6" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">申请数量</span>
          <span class="billItemData">{{itemSub1.quantity}}</span>
          <i v-show="!showUnrecive" class="h-icon-right iconBtn" @click.prevent.stop="fillQuantity(itemSub1, itemSub1.quantity)"></i>
          </Col>
          <Col :xl="6" :lg="6" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">实收数量</span>
          <input v-if="!showUnrecive" v-model="itemSub1.quantityAct" />
          <span v-else class="billItemData" :style="{ color: itemSub1.quantity === itemSub1.quantityAct ? '#000' : 'red', 'font-weight': '700' }">{{itemSub1.quantityAct}}</span>
          </Col>
          <Col v-show="!showUnrecive" :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="reviveBtnRow">
          <button class="checkBtn" @click="checkItem(itemSub1)">收货&nbsp;&nbsp;<i class="h-icon-check"></i></button>
          <button class="closeBtn" @click="closeItem(itemSub1)">无此项&nbsp;&nbsp;<i class="h-icon-close"></i></button>
          </Col>
        </Row>
      </tCrudPanel>
  </Row>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import tPanel from '@/components/wrapper/part/tPanel'
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billStockIn';

export default {
  name: 'billStockInEdit',
  components: {
    baseCrudEdit,
    tCrudPanel,
    tPanel
  },
  data: function () {
    return {
      bizDefine: {},
      crudDef: {
        hiddenAdd: true,
        hiddenEdit: true,
        hiddenDel: true
      },
      masterKeys: ['customer', 'produc', 'groupColor', 'groupSize', 'ruleVerify', 'hr'],
      dictKeys: [],
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {},
      dataset1: [],
      // 明细显示类型：0-未收货，1-已收货
      showUnrecive: 0,
      detailTypeList: ['未收货', '已收货']
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillStockInObj', 'getUserInfo']),
    getDetailList() {
      let _val = this.showUnrecive;
      return this.dataset1.filter(v => {
        return v.recived === _val;
      });
    }
  },
  methods: {
    ...mapActions(['queryBillStockInObj', 'putBillStockInObj', 'postBillStockInObj', 'postBillStockInRecive']),
    fillQuantity(item, val) {
      let _idx = this.dataset1.findIndex(v => {
        return v.code === item.code;
      });
      if (_idx > -1) {
        this.$set(this.dataset1[_idx], 'quantityAct', val);
      }
    },
    // 保存操作的响应
    async saveHandler() {
      try {
        let _func = this.isAdd ? this.postBillStockInObj : this.putBillStockInObj;
        let x = {};
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset, this.dataset.id)]
          }
        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };
        }
        let res = await _func(x);
        this.inEdit = false;
        x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: res
          }
        }];
        let resObj = await this.queryBillStockInObj(x);
        this.dataset = resObj[0];
      } catch (err) {
        terr(err);
      }
    },
    onAdd() {
      this.inEdit = true;
      this.dataset = this.bizDefine.emptyVal();
    },
    onEdit() {
      this.inEdit = true;
    },
    switchDetailType(e) {
      this.$Message.info(`切换到${showUnrecive}`, 1000);
    },
    async reciveOpt(obj, code, title) {
      try {
        let _idx = this.dataset1.findIndex(v => {
          return v.code === code;
        });
        if (_idx > -1) {
          obj.pid = this.dataset.id;
          let res = await this.postBillStockInRecive(obj);
          this.$set(this.dataset1[_idx], 'recived', 1);
          let _rcvVal = this.dataset1.reduce((pre, curr) => {
            return pre + parseInt(curr.recived);
          }, 0);
          if (_rcvVal === this.dataset1.length) {
            this.$set(this.dataset, 'recived', 1);
          }
          this.$Message(`${title}成功！`);
          this.$set(this.dataset, 'quantityAct', _rcvVal);
        } else {
          this.$Message({
            type: 'warn',
            text: '无效的项，请重新检查'
          });
        }
      } catch (err) {
        this.$Message({
          type: 'error',
          text: `${title}失败`
        })
      }
    },
    async checkItem(item) {
      if (!item.quantityAct) {
        this.$Message({
          type: 'warn',
          text: '收货数量必填，或者选择“无此项”按钮'
        });
      } else {
        let x = {
          id: item.id,
          val: item.quantityAct
        };
        this.reciveOpt(x, item.code, '收货');
      }
    },
    closeItem(item) {
      let x = {
        id: item.id,
        val: item.quantityAct
      };
      this.reciveOpt(x, item.code, '拒收');
    }
  },
  async mounted() {    
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      if (this.bizDefine.subs) {
        this.subCount = Object.keys(this.bizDefine.subs).length;
      }
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        // let _param = this.$route.params;
        let _subDefine = this.bizDefine.subs;
        if (id && id > 0) {
          this.isAdd = false;
          this.currId = id;
          let x = [{
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          }, {
            $act: enumObj.crud.act.read,
            bizIdent: _subDefine.billStockInDetail.intro.code,
            by: {
              pid: id
            }
          }];
          let [a, b, c] = await this.queryBillStockInObj(x);
          this.dataset = a;
          this.dataset1 = b;
          this.inLoading = false;
          if (!inEdit) {
            this.approveDef = c || {
              currStep: 0,
              flowStart: false,
              flowEnd: true,
              stopped: false,
              hasAccess: false,
              isCreator: false
            };
          }
        } else {
          this.isAdd = true;
          this.dataset = this.bizDefine.emptyVal();
          this.$set(this.dataset, 'operator', this.getUserInfo.id);
          this.$set(this.dataset, 'dateAsk', dayjs().format('YYYY-MM-DD'));
        }
      }
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>

<style lang="less" scoped>
.infoTips {
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.iconBtn {
  height: 30px;
  line-height: 30px;
  padding: 0 8px;
  background-color: orange;
  cursor: pointer;

  &:hover {
    color: #fff;
    background-color: #131138;
  }
}

.reviveBtnRow {
  display: flex;

  button {
    flex: 1;
    height: 28px;
    line-height: 28px;
    margin: 0 8px;
    box-sizing: border-box;
    border: 1px #131138 solid;
    border-radius: 30px;
    color: #131138;
    cursor: pointer;

    i {
      font-weight: 700;
    }
  }

  .checkBtn {
    background-color: #F0F0F2;

    i {
      color: green;
    }

    &:hover {
      border: none;
      color: #fff;
      background-color: #131138;
    }
  }

  .closeBtn {
    background-color: #686780;

    i {
      color: red;
    }

    &:hover {
      border: none;
      color: #fff;
      background-color: red;

      i {
        color: #fff;
      }
    }
  }
}

.switchPanel {
  padding: 10px 0 18px 0;
  border: none;

  .switchTag {
    padding: 8px;
    margin: 0 8px;
    box-sizing: border-box;
    transition: border .1s ease;
    cursor: pointer;

    &:hover {
      color: orange;
    }

    &.active {
      color: #131138;
      border-bottom: 3px #131138 solid;
    }
  }
}

.tagRecived {
  height: 20px;
  line-height: 20px;
  padding: 0 18px;
  font-size: 12px;
  font-weight: 700;
  border: none;
  border-radius: 30px;
}

.already {
  color: #fff;
  background-color: orange;
}

.unRecived {
  color: #fff;
  background-color: red;
}
</style>