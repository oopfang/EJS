<template>
<baseCrudEdit :masterKeys="masterKeys" :dictKeys="dictKeys" :baseDefine="baseDefine" :approveDef="approveDef" :canAppro="getCanAppro" :inLoading="inLoading" :currId="currId" :inEdit="inEdit" :hiddeDetail="!dataset1.length" @onAdd="onAdd" @onEdit="onEdit" :showAddBtn="setAddBtnShow" @switchSub="switchSub" @addNewSub="addNewSub" @saveEvnt="saveHandler" @approvEvnt="onAppro">
  <Row v-if="dataset" :space="18" v-show="currStep===0">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">申请日期</span>
    <DatePicker v-if="inEdit" v-model="dataset.dateAsk" format="YYYY-MM-DD"></DatePicker>
    <span v-else class="billItemData">{{dataset.dateAsk}}</span>
    </Col>
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">客户</span>
    <Select v-model="dataset.custId" :datas="$root.$data._dict.customer" filterable :disabled="!inEdit" :nullOption="false" @change="setCustInfo"></Select>
    </Col>
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">退货类型</span>
    <Select v-model="dataset.returnTypeId" :datas="$root.$data._dict.returnType" :disabled="!inEdit" :nullOption="false"></Select>
    </Col>
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">原始凭据号</span>
    <input v-if="inEdit" type="text" v-model="dataset.billOriginalNo" />
    <span v-else class="billItemData">{{dataset.billOriginalNo}}</span>
    </Col>
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">经办客服</span>
    <span class="billItemData">{{dataset.operator | localDict($root, 'hr')}}</span>
    </Col>
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
    <span class="h-input-addon">申请状态</span>
    <span class="billItemData">{{ dataset.askStateId | localDict($root, 'requestType') }}</span>
    </Col>
    <Col :width="24" class="h-input-group">
    <span class="h-input-addon">备注</span>
    <textarea v-if="inEdit" rows="5" v-autosize v-model="dataset.memo" :readonly="!inEdit"></textarea>
    </Col>
  </Row>
  <div slot="subPanel">
    <Row v-if="dataset1" :space="8">
      <tCrudPanel v-for="(itemSub1, indexSub1) in dataset1" :key="indexSub1" :idNum="indexSub1" :isLast="indexSub1 === dataset1.length - 1" :topSpace="18" :allowSort="itemSub1.id < -1" @setItemUp="setItemUp" @setItemDown="setItemDown" @removeItem="removeSubItem">
        <Row :space="18">
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">商品</span>
          <Select v-model="itemSub1.prodId" :datas="$root.$data._dict.produc" filterable :disabled="!inEdit" :nullOption="false" @change="filterSpecSize"></Select>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">规格</span>
          <Select v-model="itemSub1.spec" :datas="specList" filterable :disabled="!inEdit" :nullOption="false"></Select>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">型号</span>
          <Select v-model="itemSub1.size" :datas="sizeList" filterable :disabled="!inEdit" :nullOption="false"></Select>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">单位</span>
          <input v-if="inEdit" type="text" v-model="itemSub1.unit" />
          <span v-else class="billItemData">{{itemSub1.unit}}</span>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">申请数量</span>
          <NumberInput v-if="inEdit" v-model="itemSub1.quantityAsk" :useOperate="true"></NumberInput>
          <span v-else class="billItemData">{{itemSub1.quantityAsk}}</span>
          </Col>
          <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
          <span class="h-input-addon">退货原因</span>
          <Select v-model="itemSub1.reason" :datas="$root.$data._dict.ruleVerify" :disabled="!inEdit" :nullOption="false"></Select>
          </Col>
        </Row>
      </tCrudPanel>
    </Row>
  </div>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import {
  swapItems
} from 'tframe-utility/preArr';
import {
  mapGetters,
  mapActions
} from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billReturenAsk';

export default {
  name: 'billReturenAskEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      masterKeys: ['customer', 'produc', 'groupColor', 'groupSize', 'ruleVerify', 'hr'],
      dictKeys: [],
      approveDef: {
        // 审批状态下的已审级次
        approStep: 0,
        // 最大审批索引
        maxStep: 1,
        // 本单是否已作废
        stopped: false,
        // 是否具有审批权限
        hasAccess: true
      },
      currStep: 0,
      inLoading: false,
      // 规格列表
      specList: [],
      // 型号列表
      sizeList: [],
      // 明细对象的数量
      subCount: 0,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {},
      dataset1: [],
      datasetDel1: [],
      currProvince: '',
      currCity: ''
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillReturenAskObj', 'getUserInfo']),
    // 判断是否允许审批操作
    getCanAppro() {
      return parseInt(this.dataset.askStateId) > 1;
    },
    // 控制子面板添加按钮的显示
    setAddBtnShow: function () {
      let _currArr = this[`dataset${this.currStep}`];
      let _b = true;
      if (_currArr) {
        for (let v of _currArr) {
          if (!v.code) {
            _b = false;
            break;
          }
        }
      }
      return _b;
    },
    getBillState() {
      let _obj = this.$root.$data._dict.requestType;
      if (_obj) {
        return _obj.title;
      } else {
        return '';
      }
    }
  },
  methods: {
    ...mapActions(['queryBillReturenAskObj', 'putBillReturenAskObj', 'postBillReturenAskObj']),
    // 删除子面板中的数据行
    removeSubItem: function (itemIdx) {
      let _currArr = this.dataset1;
      let _delItemId = _currArr.splice(itemIdx, 1)[0].id;
      if (_delItemId || _delItemId > 0) {
        this.datasetDel1.push(_delItemId);
      }
    },
    // 上移指定行
    setItemUp: function (itemIdx) {
      let _currArr = this[`dataset${this.currStep}`];
      swapItems(_currArr, itemIdx, itemIdx - 1);
      _currArr.forEach((v, k, arr) => {
        v.orderIndex = k;
      });
    },
    // 下移指定行
    setItemDown: function (itemIdx) {
      let _currArr = this[`dataset${this.currStep}`];
      swapItems(_currArr, itemIdx, itemIdx + 1);
      _currArr.forEach((v, k, arr) => {
        v.orderIndex = k;
      });
    },
    setCustInfo(e) {
      this.currProvince = e.province;
      this.currCity = e.city;
    },
    filterSpecSize(e) {
      this.specList = this.$root.$data._dict.groupColor.filter(v => (v.prodTypeId === e.groupFitId) || (v.prodTypeId === -1));
      this.sizeList = this.$root.$data._dict.groupSize.filter(v => (v.prodTypeId === e.groupFitId) || (v.prodTypeId === -1));
    },
    // 切换主从面板
    switchSub: function (idx) {
      this.currStep = idx;
    },
    // 添加新数据
    addNewSub: function (idx) {
      let _currArr = this.dataset1;
      // let _currArr = this[`dataset${this.currStep}`];
      // let _val = this.bizDefine.subs[this.baseDefine[this.currStep].ident].intro.emptyVal;
      let _val = this.bizDefine.subs[this.baseDefine[1].ident].intro.emptyVal;
      let _currVal = JSON.parse(JSON.stringify(_val));
      _currVal.id = (_currArr.length + 2) * -1;
      _currVal.code = Date.getCode();
      _currVal.province = this.currProvince;
      _currVal.city = this.currCity;
      _currArr.push(_currVal);
    },
    // 保存操作的响应
    async saveHandler(e) {
      tlog(e);
      try {
        let x = {};
        let y = [];
        let _func = this.isAdd ? this.postBillReturenAskObj : this.putBillReturenAskObj;
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }

          for (let v of this.dataset1) {
            if (!v.code) {
              _initCode++;
              v.code = `${_initCode}${this.getUserInfo.id}`;
            }
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset)],
            $after: global.preReqData(this.dataset1)
          };
          await _func(x);
          this.$router.push({
            name: `${this.bizDefine.intro.code}`
          });

        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };

          if (this.subCount > 0) {
            let _reqSub = [];
            for (let i = 0; i < this.subCount; i++) {
              let _idx = i + 1;
              let _dt = this[`dataset${_idx}`];
              let _dtDel = this[`datasetDel${_idx}`];
              let _ident = this.baseDefine[_idx].ident;
              // 处理当前混合了修改、新增的明细数据
              if (_dt.length > 0) {
                _reqSub[i] = {
                  $act: enumObj.crud.act.add,
                  bizIdent: _ident,
                  data: global.preReqData(_dt, this.dataset.id)
                };
              }
              // 处理删除的明细数据
              if (_dtDel.length > 0) {
                y.push({
                  $act: enumObj.crud.act.del,
                  bizIdent: _ident,
                  by: {
                    id: _dtDel
                  }
                });
              }
            }
            x.$after = _reqSub;
          }
          let _currReq = {};
          if (y.length > 0) {
            _currReq.$before = y;
            _currReq.$after = x;
          } else {
            _currReq = x;
          }

          let res = await _func(_currReq);
          this.$router.push({
            name: `${this.bizDefine.intro.code}`
          });
        }
      } catch (err) {
        terr(err);
      }
    },
    onAdd() {
      this.inEdit = true;
      this.dataset = this.bizDefine.emptyVal();
      this.dataset1 = [];
      this.datasetDel1 = [];
      this.$set(this.dataset, 'operator', this.getUserInfo.id);
      this.$set(this.dataset, 'dateAsk', dayjs().format('YYYY-MM-DD'));
    },
    onEdit() {
      this.inEdit = true;
    },
    onAppro(e) {
      this.approveDef = e;
    }
  },
  async mounted() {
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      if (this.bizDefine.subs) {
        this.subCount = Object.keys(this.bizDefine.subs).length;
      }
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        // let _param = this.$route.params;
        let _subDefine = this.bizDefine.subs;
        if (id && id > 0) {
          this.isAdd = false;
          this.currId = id;
          let x = [{
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          }, {
            $act: enumObj.crud.act.read,
            bizIdent: _subDefine.returenAskDetail.intro.code,
            by: {
              pid: id
            }
          }];
          let [a, b, c] = await this.queryBillReturenAskObj(x);
          this.dataset = a;
          this.dataset1 = b;
          this.inLoading = false;
          if (!inEdit) {
            this.approveDef = c || {
              currStep: 0,
              flowStart: false,
              flowEnd: true,
              stopped: false,
              hasAccess: false,
              isCreator: false
            };
          }
        } else {
          this.isAdd = true;
          this.dataset = this.bizDefine.emptyVal();
          this.$set(this.dataset, 'operator', this.getUserInfo.id);
          this.$set(this.dataset, 'dateAsk', dayjs().format('YYYY-MM-DD'));
        }
      }
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>
