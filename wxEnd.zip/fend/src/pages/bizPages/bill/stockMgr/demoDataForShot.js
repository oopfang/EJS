// 发射点数组
export default [
  [
    [{
      name: '上海'
    }, {
      name: '上海'
    }],
    [{
      name: '福州'
    }, {
      name: '上海'
    }],
    [{
      name: '吕梁'
    }, {
      name: '上海'
    }],
    [{
      name: '长春'
    }, {
      name: '上海'
    }],
    [{
      name: '汉中'
    }, {
      name: '上海'
    }],
    [{
      name: '那曲'
    }, {
      name: '上海'
    }],
    [{
      name: '广州'
    }, {
      name: '上海'
    }],
    [{
      name: '常州'
    }, {
      name: '上海'
    }],
    [{
      name: '北京'
    }, {
      name: '上海'
    }],
    [{
      name: '南宁'
    }, {
      name: '上海'
    }],
    [{
      name: '昆明'
    }, {
      name: '上海'
    }],
    [{
      name: '呼和浩特'
    }, {
      name: '上海'
    }],
    [{
      name: '西宁'
    }, {
      name: '上海'
    }],
    [{
      name: '呼伦贝尔'
    }, {
      name: '上海'
    }],
    [{
      name: '嘉峪关'
    }, {
      name: '上海'
    }],
    [{
      name: '成都'
    }, {
      name: '上海'
    }],
    [{
      name: '伊春'
    }, {
      name: '上海'
    }],
    [{
      name: '海口'
    }, {
      name: '上海'
    }]
  ],
  [
    [{
      name: '昆明'
    }, {
      name: '昆明'
    }],
    [{
      name: '福州'
    }, {
      name: '昆明'
    }],
    [{
      name: '吕梁'
    }, {
      name: '昆明'
    }],
    [{
      name: '长春'
    }, {
      name: '昆明'
    }],
    [{
      name: '汉中'
    }, {
      name: '昆明'
    }],
    [{
      name: '那曲'
    }, {
      name: '昆明'
    }],
    [{
      name: '广州'
    }, {
      name: '昆明'
    }],
    [{
      name: '常州'
    }, {
      name: '昆明'
    }],
    [{
      name: '北京'
    }, {
      name: '昆明'
    }],
    [{
      name: '北海'
    }, {
      name: '昆明'
    }],
    [{
      name: '西宁'
    }, {
      name: '昆明'
    }],
    [{
      name: '上海'
    }, {
      name: '昆明'
    }],
    [{
      name: '海口'
    }, {
      name: '昆明'
    }]
  ],
  [
    [{
      name: '西安'
    }, {
      name: '西安'
    }],
    [{
      name: '福州'
    }, {
      name: '西安'
    }],
    [{
      name: '吕梁'
    }, {
      name: '西安'
    }],
    [{
      name: '长春'
    }, {
      name: '西安'
    }],
    [{
      name: '那曲'
    }, {
      name: '西安'
    }],
    [{
      name: '广州'
    }, {
      name: '西安'
    }],
    [{
      name: '常州'
    }, {
      name: '西安'
    }],
    [{
      name: '北京'
    }, {
      name: '西安'
    }],
    [{
      name: '北海'
    }, {
      name: '西安'
    }],
    [{
      name: '呼和浩特'
    }, {
      name: '西安'
    }],
    [{
      name: '西宁'
    }, {
      name: '西安'
    }],
    [{
      name: '上海'
    }, {
      name: '西安'
    }],
    [{
      name: '昆明'
    }, {
      name: '西安'
    }],
    [{
      name: '海口'
    }, {
      name: '西安'
    }]
  ]
];
