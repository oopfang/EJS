<template>
<div>
  <div id="myChartChina" :style="mapSize"></div>
</div>
</template>

<script>
import china from '../../../../tModules/charts/china.json';
// import china from '../../../../tModules/charts/chinaCity.json';
let getHeatData = data => {
  let _arr = [];
  for (let v of data) {

  }
};

export default {
  props: {
    // 图表标题
    title: {
      type: String,
      default: '地图'
    },
    // 图表子标题
    subTitle: {
      type: String,
      default: ''
    },
    // 图表尺寸
    mapSize: {
      type: Object,
      default: {
        width: '100%',
        height: '500px'
      }
    },
    // 报表皮肤类型（True表示为深底白字，false表示白底深字），默认为True
    asDarkTheme: {
      type: Boolean,
      default: true
    },
    // 最高预警线
    maxWarnValue: {
      type: Number | String,
      default: 50
    },
    // 报表数据集
    chartData: {
      type: Array,
      default: function () {
        return [];
      }
    }
  },
  methods: {
    drawMap() {
      let _obj = {};
      for (let v of this.chartData) {
        _obj[v.name] = v.value;
      }
      // 基于准备好的dom，初始化echarts实例
      let myChartContainer = document.getElementById('myChartChina');
      let resizeMyChartContainer = function () {
        // 宽度
        myChartContainer.style.width = (document.body.offsetWidth * .8) + 'px';
        // 高度
        myChartContainer.style.height = (document.body.offsetHeight - 200) + 'px';
      }
      resizeMyChartContainer();
      /* eslint-disable no-undef */
      echarts.registerMap('china', china);
      let myChartChina = echarts.init(myChartContainer);

      // 绘制图表
      let optionMap = {
        tooltip: {},
        animation: true,
        progressiveThreshold: 3,
        legend: {
          orient: 'vertical',
          left: 'left',
          data: ['']
        },
        visualMap: {
          min: 0,
          max: parseInt(this.maxWarnValue),
          left: '10%',
          top: 'bottom',
          text: ['高', '低'],
		      seriesIndex: 0,
          calculable: true,
          inRange: {
            type: 'heatmap',
            color: ['red', 'orange', 'yellow', '#8BC808'].reverse(),
          }
        },
        selectedMode: 'single',
        geo: {
          map: 'china',
          //'center': [0, 12],
          aspectScale: 0.8,
          roam: false,
          scaleLimit: {
            min: 1.2,
            max: 15
          },
          zoom: 1.2,
          label: {
            normal: {
              show: true,
              fontSize: '12',
              color: '#000',
              fontFamily: 'Microsoft YaHei'
            },
            emphasis: {
              show: true,
              fontSize: '16',
              color: '#000'
            }
          },
          itemStyle: {
            normal: {
              areaColor: 'transparent',
              borderColor: '#fff',
              // shadowColor: 'rgba(0, 0, 0, .2)',
              shadowBlur: '1',
              borderWidth: '.2'
            },
            'emphasis': {
              areaColor: 'rgba(0, 0, 255, .1)',
              borderWidth: '.2',
              borderColor: '#eee'
            }
          }
        },
        series: [{
          name: '',
          type: 'heatmap',
          coordinateSystem: 'geo',
          // mapType: 'china',
          // 是否开启鼠标缩放和平移漫游。默认不开启。如果只想要开启缩放或者平移，可以设置成 'scale' 或者 'move'。设置成 true 为都开启
          roam: true,
          // 是否在鼠标移到节点上的时候突出显示节点以及节点的边和邻接节点。
          focusNodeAdjacency: true,
          itemStyle: {
            normal: {
              borderColor: 'rgba(0, 0, 0, 0.2)'
            },
            emphasis: {
              shadowOffsetX: 0,
              shadowOffsetY: 3,
              shadowBlur: 16,
              borderWidth: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          },
          showLegendSymbol: true,
          label: {
            normal: {
              show: true,
              // 标签的字体样式
              textStyle: {
                // 字体颜色
                color: "#000",
                // 文字字体的风格 'normal'标准 'italic'斜体 'oblique' 倾斜
                fontStyle: "normal",
                // 'normal'标准'bold'粗的'bolder'更粗的'lighter'更细的或100 | 200 | 300 | 400...
                fontWeight: "bolder",
                // 文字的字体系列
                fontFamily: "sans-serif",
                // 字体大小
                fontSize: 12
              }
            },
            emphasis: {
              show: true,
              // 标签的字体样式
              textStyle: {
                // 字体颜色
                color: "#000",
                // 文字字体的风格 'normal'标准 'italic'斜体 'oblique' 倾斜
                fontStyle: "normal",
                // 'normal'标准'bold'粗的'bolder'更粗的'lighter'更细的或100 | 200 | 300 | 400...
                fontWeight: "bolder",
                // 文字的字体系列
                fontFamily: "sans-serif",
                // 字体大小
                fontSize: 12
              }
            }
          },
          emphasis: {
            label: {
              show: true
            }
          },
          data: this.chartData
        }]
      }

      myChartChina.setOption(optionMap);
      window.onresize = function () {
        resizeMyChartContainer();
        myChartChina.resize();
      }
    }
  },
  mounted() {
    this.drawMap();
  }
}
</script>
