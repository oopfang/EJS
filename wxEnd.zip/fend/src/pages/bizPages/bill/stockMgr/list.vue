<template>
<basePage :masterKeys="masterKeys" :dictKeys="dictKeys">
  <div class="storeWrapper">
    <div class="storeHeader">
      <p class="filterRow btnGroup">
        <span>库存报表</span>
        <span class="flexSplit"></span>
        <span v-show="viewType===2" style="margin-right: 8px;">热力预警上限值</span>
        <input v-show="viewType===2" type="number" v-model="warnMax" placeholder="输入热力预警上限值" v-width="100" @blur="resetWarn" />
        <span v-show="viewType===3" style="margin-right: 8px;">退货接收城市</span>
        <Select v-show="viewType===3" v-model="currShotCityKey" :datas="cityList" :nullOption="false" v-width="100" @change="setShot" />
        <span class="btnItem" @click.prevent.stop="switchView(0)">表格</span>
        <span class="btnItem" @click.prevent.stop="switchView(1)">分析</span>
        <span class="btnItem" @click.prevent.stop="switchView(2)">热力</span>
        <!-- <span class="btnItem" @click.prevent.stop="switchView(3)">迁移</span> -->
        <span class="btnItem" @click.prevent.stop="export2excel">导出</span>
      </p>
    </div>
    <Table v-if="viewType===0" :datas="invtList" :height="600" border stripe :loading="onLoading" @trdblclick="showProdInfo">
      <TableItem title="序号" :width="100" prop="$serial" sort="auto"></TableItem>
      <TableItem title="商品" prop="prodNamezh" sort="auto"></TableItem>
      <TableItem title="规格" :width="100" prop="specNamezh" sort="auto"></TableItem>
      <TableItem title="型号" :width="100" prop="sizeNamezh" sort="auto"></TableItem>
      <TableItem title="数量" :width="100" prop="quantity" sort="auto"></TableItem>
      <TableItem title="状态" :width="100" prop="checkType" sort="auto"></TableItem>
      <TableItem title="货架号" :width="150" prop="cellCode" sort="auto"></TableItem>
      <TableItem title="过期时间" :width="100" prop="diffDay" sort="auto"></TableItem>
      <TableItem title="退货原因" :width="100" prop="returnFor" sort="auto"></TableItem>
      <TableItem title="退货客户类型" :width="150" prop="custBuildType" sort="auto"></TableItem>
      <!-- <TableItem title="退货来自省份" :width="150" prop="province" sort="auto"></TableItem> -->
      <TableItem title="退货来自城市" :width="150" prop="city" sort="auto"></TableItem>
      <div slot="empty">暂时无数据</div>
    </Table>
    <poivte v-else-if="viewType===1" :dataSource="pivotData"></poivte>

    <div v-else>
      <mapChina ref="chinaMap" :chartData="mapData" :mapSize="mapSize" :maxWarnValue="warnMax"></mapChina>
    </div>

    <!-- <div v-else :style="getMoveWarpper">
      <div ref="fullWrapper" class="fullScreeItem">
        <mapChinaDot ref="chinaMapDot" :chartData="mapData" :mapSize="mapSize" :maxWarnValue="warnMax" :cityShotList="cityShotList"></mapChinaDot>
      </div>
    </div> -->
  </div>
  <Modal v-model="onProdShow" middle>
    <div slot="header" class="btnGroup marginTop">
      <span class="btnItem" @click="currProdViewIdx=0">商品详情</span>
      <span class="btnItem" @click="currProdViewIdx=1">质检图片</span>
    </div>
    <div v-show="currProdViewIdx===0" class="billOrderWrapper">
      <div class="imgCell">
        <img :src="currProdObj.imgAddr" width="64" height="64">
      </div>
      <div class="flexSplit">
        <Row :space="18">
          <Col :width="24" class="h-input-group">
            <span class="billItemData">商品名称：{{ currProdObj.prodNamezh }}</span>
          </Col>
          <Col :width="12" class="h-input-group">
            <span class="billItemData">规格：{{ currProdObj.specNamezh }}</span>
          </Col>
          <Col :width="12" class="h-input-group">
            <span class="billItemData">型号：{{ currProdObj.sizeNamezh }}</span>
          </Col>
          <Col :width="12" class="h-input-group">
            <span class="billItemData">状态：{{ currProdObj.returnFor }}</span>
          </Col>
          <Col :width="12" class="h-input-group">
            <span class="billItemData">至过期时间：{{ currProdObj.diffDay }}天</span>
          </Col>
          <Col :width="12" class="h-input-group">
            <span class="billItemData">退货原因：{{ currProdObj.checkType }}</span>
          </Col>
          <Col :width="24" class="h-input-group">
            <span class="billItemData">退货客户：{{ currProdObj.custNamezh }}</span>
          </Col>
        </Row>
      </div>
    </div>
    <div v-show="currProdViewIdx===1" class="billOrderWrapper scrollX">
      <img src="/static/img/imgCheck/01.jpg" height="200">
      <img src="/static/img/imgCheck/02.jpg" height="200">
      <img src="/static/img/imgCheck/03.jpg" height="200">
      <img src="/static/img/imgCheck/04.jpg" height="200">
      <!-- <ul class="imgList">
        <li>
          <img src="/static/img/imgCheck/01.jpg">
        </li>
        <li>
          <img src="/static/img/imgCheck/02.jpg" alt="">
        </li>
        <li>
          <img src="/static/img/imgCheck/03.jpg" alt="">
        </li>
        <li>
          <img src="/static/img/imgCheck/04.jpg" alt="">
        </li>
      </ul> -->
    </div>
  </Modal>

  <Modal v-model="onStockOut" middle :closeOnMask="false">
    <div slot="header">库存再销售</div>
    <div class="billOrderWrapper">
      <div class="h-input-group iptRow">
        <span class="h-input-addon">订单日期</span>
        <DatePicker v-model="orderObj.dateDelivery" format="YYYY-MM-DD"></DatePicker>
      </div>
      <div class="h-input-group iptRow">
        <span class="h-input-addon">收货客户</span>
        <Select v-model="orderObj.custId" :datas="$root.$data._dict.customer" :nullOption="false" nullOptionText="请选择客户"></Select>
      </div>
      <div class="h-input-group iptRow">
        <span class="h-input-addon">商品：{{orderDetail.prodNamezh}}-{{orderDetail.specNamezh || '通用规格'}}-{{orderDetail.sizeNamezh || '通用型号'}}</span>
      </div>
      <div class="h-input-group iptRow">
        <span class="h-input-addon">销售数量</span>
        <input type="number" v-model="orderDetail.salesNum" />
      </div>
      <div class="h-input-group iptRow">
        <span class="h-input-addon">备注</span>
        <textarea v-model="orderObj.memo"></textarea>
      </div>
    </div>
    <div slot="footer">
      <button class="h-btn" @click="cancelOrder">取消</button>
      <span class="flexSplit"></span>
      <button class="h-btn" @click="submitOrder">订货</button>
    </div>
  </Modal>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import dayjs from 'dayjs';
import poivte from '../../../../components/layout/piovte';
import mapChina from './chinaHeat';
import mapChinaDot from './chinaDot';
let _getChartOpt = (title = '报表', subTitle = '', chartData, chartLegend) => {
  return {
    title: title,
    subTitle: subTitle,
    chartLegend: chartLegend,
    chartData: chartData
  };
};

import {
  mapActions
} from 'vuex';

export default {
  components: {
    basePage,
    mapChina,
    mapChinaDot,
    poivte
  },
  data() {
    return {
      onProdShow: false,
      // 当前查看的商品
      currProdObj: {},
      // 当前查看的产品信息索引
      currProdViewIdx: 0,
      // 热力预警最大值
      warnMax: 60,
      // 发射点备选城市
      cityList: [],
      tblHeight: 600,
      currShotCityKey: 0,
      currShotCityName: '',
      // 已选择的发射点城市
      currShotCity: {},
      // 城市迁移图表发射点数据
      cityShotList: [],
      pivotData: {},
      onStockOut: false,
      masterKeys: ['customer', 'warehouse'],
      onLoading: false,
      dictKeys: [],
      invtList: [],
      poviteList: [],
      currByIdx: -1,
      orderObj: {},
      orderDetail: {},
      viewType: 0,
      mapSize: {},
      mapData: []
    }
  },
  computed: {
    // 迁移图表容器样式
    getMoveWarpper() {
      return {
        ...this.mapSize
      };
    },
    // 获取仓库
    getWarehouse() {
      // return this.stroeObj[this.currIdxW] || {};
      if (!this.$root.$data || !this.$root.$data._dict || !this.$root.$data._dict.warehouse) {
        return [];
      } else {
        return this.$root.$data._dict.warehouse.filter(v => v.storeUnitType === '1');
      }
    },
    // 获取库区
    getZone() {
      // return this.stroeObj[this.currIdxW] || {};
      if (!this.$root.$data || !this.$root.$data._dict || !this.$root.$data._dict.warehouse) {
        return [];
      } else {
        return this.$root.$data._dict.warehouse.filter(v => v.storeUnitType === '2');
      }
    },
    // 获取货架
    getShelves() {
      // return this.getZone[this.currIdxZ] || {};
      if (!this.$root.$data || !this.$root.$data._dict || !this.$root.$data._dict.warehouse) {
        return [];
      } else {
        return this.$root.$data._dict.warehouse.filter(v => v.storeUnitType === '3');
      }
    },
    // 获取货架层
    getLevel() {
      return this.getShelves[this.currIdxD] || {};
    },
    // 获取单元格
    getCell() {
      return this.getLevel[this.currIdxL] || {};
    },
    // 获取库区列表
    getZoneList() {
      return Object.keys(this.getZone);
    },
    // 获取货架列表
    getShelvesList() {
      return Object.keys(this.getShelves);
    },
    // 获取货架层列表
    getLevelList() {
      return Object.keys(this.getLevel);
    },
    // 获取单元格列表
    getCellList() {
      return Object.keys(this.getCell);
    },
    getInvtList() {
      let _objW = this.stroeObj[this.currIdxW];
      if (!_objW) return [];
      let _objZ = _objW[this.currIdxZ];
      if (!_objZ) return [];
      let _objD = _objZ[this.currIdxD];
      if (!_objD) return [];
      let _objL = _objD[this.currIdxL];
      if (!_objL) return [];
      return _objL;
    },
    // 获取透视表数据源
    getPivote() {
      return new wjcOlap.PivotEngine(this.pivotData);
    }
  },
  methods: {
    ...mapActions(['queryStockListByCell', 'postBillAdviceSendByInvt']),
    // 获取容器空间尺寸
    getWorkSize() {
      let _that = this;
      return new Promise((resolve, reject) => {
        this.$nextTick(() => {
          // 尺寸计算规则：工作空间高度 - 页标题栏高度(50) - 面板标题栏高度(42) - 面板padding(上下各8 * 2) - 校准误差(20) - 表格预留footer高度(40)
          let _obj = _that.$el.children[0];
          let _h = _obj.clientHeight;
          this.tblHeight = _h;
          resolve({
            display: 'flex',
            'justify-content': 'center',
            'align-items': 'center',
            width: `${_obj.clientWidth}px`,
            height: `${_h - 100}px`
          });
        });
      })
    },
    // 变更热力预警上限值
    resetWarn() {
      this.$refs.chinaMap.drawMap();
    },
    // 切换迁移图表发射点
    setShot(e) {
      this.currShotCity = e;
      let _ct = JSON.parse(JSON.stringify(this.cityList));
      let [_shotObj] = _ct.splice(this.currShotCity.key, 1);
      let _shotName = _shotObj.title || '上海';
      let _arrShot = [
        [{
          name: _shotName
        }, {
          name: _shotName
        }]
      ];
      _arrShot = _ct.map(v => {
        return [{
          name: _shotName
        }, {
          name: v.title
        }];
      });
      this.cityShotList = _arrShot;
      this.$refs.chinaMapDot.drawMap();
    },
    storckOut(item, strC, idx) {
      this.orderObj = {
        dateDelivery: dayjs().format('YYYY-MM-DD'),
        custId: -1,
        deliveryType: 4,
        memo: ''
      };
      this.orderDetail = {
        ...item,
        salesNum: item.quantity
      };
      this.currIdxC = strC;
      this.currByIdx = idx;
      this.onStockOut = true;
    },
    // 显示双击商品的详情
    showProdInfo(e) {
      this.currProdViewIdx = 0;
      this.onProdShow = true;
      this.currProdObj = e;
      let _imgType = e.prodNamezh.endsWith('皂') ? 'zhao' : 'shuang';
      // /static/img/produc/shuang/00.jpg
      let _idx = (e.id % 7) + 1;
      this.$set(this.currProdObj, 'imgAddr', `/static/img/produc/${_imgType}/0${_idx}.jpg`);
      console.log(e);
    },
    cancelOrder() {
      this.currIdxC = '';
      this.currByIdx = -1;
      this.orderObj = {};
      this.orderDetail = {};
      this.onStockOut = false;
    },
    checkData() {
      let _errMsg = [];
      if (!this.orderObj.dateDelivery) _errMsg.push('订单日期不能为空');
      if (this.orderObj.custId < 1) _errMsg.push('收货客户必选');
      if (!this.orderDetail.salesNum || this.orderDetail.salesNum < 0) _errMsg.push('订货数量必须大于0')
      if (this.orderDetail.salesNum > this.orderDetail.quantity) _errMsg.push('订货数不能超出库存数');
      if (_errMsg.length) {
        for (let v of _errMsg) {
          this.$Message({
            type: 'error',
            text: v
          });
        }
        return false;
      } else {
        return true;
      }
    },
    async submitOrder() {
      try {
        if (this.checkData()) {
          let x = {
            data: this.orderObj,
            detail: this.orderDetail
          };
          let _that = this;
          await this.postBillAdviceSendByInvt(x);
          let _w = _that.currIdxW;
          let _z = _that.currIdxZ;
          let _d = _that.currIdxD;
          let _l = _that.currIdxL;
          let _c = _that.currIdxC;
          let _arr = _that.stroeObj[_w][_z][_d][_l][_c];
          if (_that.currByIdx > -1) {
            let _newVal = _that.orderDetail.quantity - parseInt(_that.orderDetail.salesNum);
            _that.$set(_that.stroeObj[_w][_z][_d][_l][_c][_that.currByIdx], 'quantity', _newVal);
          }
          _that.cancelOrder();
        }
      } catch (err) {
        terr(err);
      }
    },
    export2excel() {
      let jsonData = this.poviteList;
      //导出前要将json转成table格式
      //列标题
      let str = '<tr><td>省份</td><td>城市</td><td>产品名称</td><td>规格</td><td>型号</td><td>客户类型</td><td>质检分类</td><td>过期天数</td><td>退货理由</td><td>数量</td></tr>';
      //具体数值 遍历
      for (let i = 0; i < jsonData.length; i++) {
        str += '<tr>';
        for (let item in jsonData[i]) {
          let cellvalue = jsonData[i][item];
          //不让表格显示科学计数法或者其他格式 
          //方法1 tr里面加 style="mso-number-format:'\@';" 方法2 是改为 = 'XXXX'格式 
          //如果纯数字且超过15位
          /*let reg = /^[0-9]+.?[0-9]*$/;
          if ((cellvalue.length>15) && (reg.test(cellvalue))){
          //cellvalue = '="' + cellvalue + '"';
          }*/
          //此处用`取代'，具体用法搜索模板字符串 ES6特性
          str += `<td style="mso-number-format:'\@';">${cellvalue}</td>`;
          // str+=`<td>${cellvalue}</td>`; 
        }
        str += '</tr>';
      }
      let worksheet = '导出结果'
      let uri = 'data:application/vnd.ms-excel;base64,';
      //下载的表格模板数据
      let template = `<html xmlns:o="urn:schemas-microsoft-com:office:office" 
        xmlns:x="urn:schemas-microsoft-com:office:excel" 
        xmlns="http://www.w3.org/TR/REC-html40">
        <head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>
        <x:Name>${worksheet}</x:Name>
        <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>
        </x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
        </head><body><table>${str}</table></body></html>`;
      //下载模板
      function base64(s) {
        return window.btoa(unescape(encodeURIComponent(s)))
      }
      window.location.href = uri + base64(template);
    },
    chinaMapProp(val) {
      let _chinaMap = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.chinaMap.update(_chinaMap);
    },
    switchView(typeId) {
      this.viewType = typeId;
      if ((typeId === 2 || typeId === 3) && this.invtList.length && !this.mapData.length) {
        let _obj = {};
        // let _arr = [];
        // let i = 0;
        let x = this.$root.$data.loglat;
        for (let v of this.invtList) {
          // let _tag = v.province;
          // if (!_obj[_tag]) {
          //   // _obj[_tag] = parseInt(v.quantity);
          //   _obj[_tag] = i;
          //   _arr.push({
          //     name: _tag,
          //     value: parseInt(v.quantity)
          //   });
          //   i++;
          // } else {
          //   // _obj[_tag] = parseInt(v.quantity) + _obj[_tag];
          //   _arr[_obj[_tag]] = {
          //     name: _tag,
          //     value: parseInt(v.quantity) + _arr[_obj[_tag]].value
          //   };
          // }
          let loglatArr = x[v.city];
          if (loglatArr) {
            if (_obj[v.city]) {
              // let [a, b] = loglatArr;
              let [a, b, c] = _obj[v.city];
              _obj[v.city] = [a, b, c + parseInt(v.quantity)];
            } else {
              let [a, b] = loglatArr;
              _obj[v.city] = [a, b, parseInt(v.quantity)];
            }
          }
        }
        this.mapData = Object.values(_obj);
        _obj = {};
      }
    }
  },
  async mounted() {
    let _that = this;
    this.mapSize = await this.getWorkSize();
    this.onLoading = true;
    this.invtList = await this.queryStockListByCell();
    this.poviteList = this.invtList.map(v => {
      return {
        // 省份: v.province,
        城市: v.city,
        产品名称: v.prodNamezh,
        退货客户: v.custNamezh,
        规格: v.specNamezh,
        型号: v.sizeNamezh,
        客户类型: v.custBuildType,
        质检分类: v.checkType,
        过期天数: v.diffDay,
        退货理由: v.returnFor,
        数量: 1
      };
    });
    let _arr = [];
    let _obj = {};
    let i = 0;
    for (let v of _that.invtList) {
      let _tag = v.cityOrigan;
      if (!_obj[_tag]) {
        _obj[_tag] = _tag;
        _that.cityList.push({
          key: i,
          title: _tag
        });
        i++;
      }
    }
    let idx = _that.invtList.findIndex(v => v.title === '上海');
    _that.currShotCityName = idx > -1 ? _that.invtList[idx].title : '上海';
    _that.currShotCity = _that.cityList[0] || {
      key: 1,
      title: '上海'
    };
    this.pivotData = {
      itemsSource: this.poviteList,
      valueFields: ['数量'],
      rowFields: ['城市']
    };
    this.onLoading = false;
  }
}
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';

.storeWrapper {
  display: flex;
  flex-direction: column;
  width: 98%;
  height: 90vh;
  margin: 18px;
  border: 1px #eee solid;
  overflow: hidden;

  .storeHeader {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    align-items: center;

    .filterRow {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      height: 40px;
      line-height: 40px;
      padding: 0 18px;
      margin-bottom: 8px;
      box-sizing: border-box;
      border: 1px #eee solid;

      .filterWrapper {
        width: 20%;

        .filterItem {
          margin: 4px 18px;
          padding: 2px 64px;
          border: 1px #eee solid;
          border-radius: 20px;
          color: #666;
          background-color: rgb(230, 238, 223);
          cursor: pointer;

          &:hover {
            background-color: rgb(185, 216, 158);
          }

          &.active {
            font-weight: 700;
            color: #000;
            background-color: @primary-color;
          }
        }
      }
    }
  }

  .storeBody {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    overflow-y: auto;

    .storeCell {
      display: flex;
      flex-direction: column;
      width: 100%;
      justify-content: flex-start;
      align-items: flex-start;

      .cellTitle {
        width: 100%;
        padding: 18px 0;
        font-weight: 700;
        color: #000;
        background-color: #eee;
      }

      .cellBody {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        width: 100%;
        flex-wrap: wrap;

        .prodCell {
          // display: flex;
          // flex-direction: column;
          // justify-content: center;
          // align-items: center;
          min-width: 200px;
          height: 140px;
          margin: 8px;
          border: 1px #ddd solid;

          &:hover {
            background-color: rgb(223, 230, 216);
          }

          .prodInfoRow {
            width: 100%;
            height: 38px;
            line-height: 38px;
            padding: 8px;

            &.btnRow {
              height: 38px;
              line-height: 38px;
              padding: 0;
              text-align: center;
              color: #000;
              background-color: @primary-color;
              cursor: pointer;
            }
          }

          .prodCountRow {
            width: 100%;
            height: 64px;
            line-height: 64px;
            text-align: center;
            font-size: 1.2rem;
          }
        }
      }
    }

    &.emptyDat {
      position: relative;
      width: 100%;
      height: 70vh;
      line-height: 70vh;
      align-items: center;
      color: #888;

      &::after {
        position: absolute;
        width: 100%;
        height: 100%;
        content: '';
        bottom: 124px;
        background: transparent url(/static/img/nodata.jpg) center center no-repeat;
        background-size: 104px 104px;
      }
    }
  }
}

.billOrderWrapper {
  width: 30vw;
  height: 228px;
  display: flex;
  justify-content: flex-start;
  align-items: center;

  .imgCell {
    width: 80px;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
  }

  .iptRow {
    width: 360px;
    margin-bottom: 18px;
  }

  .imgList {
    flex: 1;
    overflow-x: auto;
    overflow-y: hidden;
    list-style: none;
    height: 80%;


    li {
      display: inline-block;
      height: 80%;
    }
  }
}

.marginTop {
  margin-top: 18px;
}

.scrollX {
  overflow-x: auto;
  overflow-y: hidden;
}
</style>
