<template>
<baseCrudView :masterKeys="masterKeys" :dictKeys="dictKeys" :define="bizDefine" :inLoading="inLoading" :currId="getBillVrifyObj[0] ? getBillVrifyObj[0].id : -1" 
    :isvoid="getBillVrifyObj[0] && getBillVrifyObj[0].id && getBillVrifyObj[0].stopped"
    @eventVoid="voidBill"
    @onPdf="onPdf">
  <Row v-if="getBillVrifyObj[0]" v-show="!isPdf" :space="18">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">ID</span>
      <span class="billItemData">{{ getBillVrifyObj[0].id }}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">父级ID</span>
      <span class="billItemData">{{ getBillVrifyObj[0].pid }}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">代码</span>
      <span class="billItemData">{{ getBillVrifyObj[0].code }}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">英文名称</span>
      <span class="billItemData">{{ getBillVrifyObj[0].name }}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">鉴验日期</span>
      <span class="billItemData">{{ getBillVrifyObj[0].dateCheck }}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">名称</span>
      <span class="billItemData">{{ getBillVrifyObj[0].namezh }}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">检验员</span>
      <span class="billItemData">{{ getBillVrifyObj[0].operator }}</span>
    </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">退货申请单ID</span>
      <span class="billItemData">{{ getBillVrifyObj[0].billReturnAskId }}</span>
    </Col>
  </Row>
</baseCrudView>
</template>

<script>
import baseCrudView from '@/components/wrapper/baseCrudView';
import tPanel from '@/components/wrapper/part/tPanel';
import enumObj from 'tframe-enum';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billVrify';

export default {
  name: 'billVrifyView',
  components: {
    baseCrudView,
    tPanel
  },
  data: function () {
    return {
      bizDefine: {},
      masterKeys: [],
      dictKeys: [],
      // 控制页面显示加载状态遮罩
      inLoading: false,
      isPdf: false
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillVrifyObj'])
  },
  methods: {
    ...mapActions(['queryBillVrifyObj']),
    voidBill: function() {
      if (this.getBillVrifyObj[0].id > 0) {
        this.getBillVrifyObj[0].stopped = 1;
      }
    },
    onPdf: function(e) {
      this.isPdf = e;
    }
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    let _param = this.$route.params;
    if (_param) {
      let _id = _param.id;
      if (_id && _id > 0) {
        let x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: _id
          }
        }];
        this.queryBillVrifyObj(x)
          .then(res => {
            this.inLoading = false;
          })
          .catch(err => {
          this.inLoading = false;
            global.terr(err);
          });
      }
    }
  }
};
</script>
