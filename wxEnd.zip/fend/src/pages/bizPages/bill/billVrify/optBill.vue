<template>
<basePage :inLoading="inLoading">
  <tPanel showHeader>
    <div slot="panelHeader">
      <span class="panelTips" :titleStr='`当前日期：${currDate}`'></span>
      <span class="flexSplit"></span>
      <span class="panelTips" v-show="currStep === 0" :titleStr='`${stepList[currStep]} ( ${custTobeList.length}家 )`'></span>
      <span class="panelTips" v-show="currStep === 1" :titleStr='`${stepList[currStep]} ( ${getProdList.length}件 )`'></span>
      <span class="panelTips" v-show="currStep === 2" :titleStr='`${stepList[currStep]} ( ${currCust.custNamezh} )`'></span>
      <span class="flexSplit"></span>
      <span v-show="currStep" class="panelTips backBtn" @click="backStep"></span>
    </div>
    <div v-show="currStep === 0" class="workPanel">
      <p class="workItem asHeader">
        <span class="cell" :class="item.width" v-for="item of headerCust" :key="item.key">{{ item.title }}</span>
      </p>
      <div class="workDetail">
        <p class="workItem asDetail" v-for="(item, index) of custTobeList" :key="index" @click="setCust(item, index)">
          <span class="cell" :class="headerCust[0].width">{{ index + 1 }}</span>
          <span class="cell" :class="headerCust[1].width">单据编号</span>
          <span class="cell" :class="headerCust[2].width">{{ item.custNamezh }}</span>
          <span class="cell" :class="headerCust[3].width">{{ item.quantityAct }}</span>
          <span class="cell" :class="headerCust[4].width">{{ item.quantityCkb }}</span>
          <span class="cell" :class="headerCust[5].width">{{ item.quantityAct - item.quantityCkb }}</span>
          <span class="cell" :class="headerCust[6].width">
            <span v-if="item.quantityCkb === 0">未检</span>
            <span v-else class="txtYellow">鉴验中</span>
          </span>
          <span class="cell" :class="headerCust[7].width">{{ item.dateStroeIn }}</span>
          <span class="cell x1" :class="Object.assign(headerCust[8].width, { txtRed: item.diff > 3 })">{{ item.diff }}</span>
        </p>
      </div>
    </div>
    <div v-show="currStep === 1" class="workPanel itemWrapper">
      <div class="prodItem" v-for="(item, index) of getProdList" :key="index" @click="setProd(item, index)">
        <p>商品：{{ item.prodNamezh }}</p>
        <p>待检数：{{ item.quantityAct }}&nbsp;(&nbsp;{{ item.unit }}&nbsp;)</p>
        <p>已检数：{{ item.quantityCkb }}&nbsp;(&nbsp;{{ item.unit }}&nbsp;)</p>
        <p>剩余量：{{ item.quantityAct - item.quantityCkb }}&nbsp;(&nbsp;{{ item.unit }}&nbsp;)</p>
      </div>
    </div>
    <div v-show="currStep === 2" class="workPanel itemWrapper">
      <div class="vrifyPanel">
        <p class="vrifyTipRow">
          <span class="photoTip">留证时，请拍取三张照片</span>
          <span class="infoTip">当前商品：{{ currProd.prodNamezh }}</span>
        </p>
        <div class="optWrapper">
          <div class="photoWrapper videoContent">
            <div class="photoMaskUp" :class="{ onHidden: onCamera }">
              <span class="startBtn" @click.prevent.stop="startPhoto"></span>
            </div>
            <div class="photoMaskDown" :class="{ onHidden: onCamera }"></div>
            <video ref="videoItem" class="videoContener itemVdo" :width="imgSize" :height="imgSize"></video>
            <canvas ref="cvsItem" class="videoContener itemCanvas" :width="imgSize" :height="imgSize"></canvas>
            <div v-show="onCamera" class="itemBtns">
              <div class="photoBtn" @click.prevent.stop="takePhoto"></div>
            </div>
          </div>
          <div class="msgWrapper">
            <p class="codeItem">入库日期：{{ currProd.dateStroeIn }}</p>
            <p class="codeItem">
              <span class="itemCell flexSplit">检验员：{{ getUserInfo.namezh }}</span>
              <!-- <span class="itemCell flexSplit">检验员：{{ getUserInfo.namezh }}</span> -->
            </p>
            <p class="codeItem">鉴验日期：{{ currItemDateCkb }}</p>
            <p class="codeItem">商品编码：{{ currProd.code }}</p>
            <p class="codeItem">
              <span>规格：</span>
              <SwitchList v-model="currItemSpec" :datas="currProd.arrSpec"></SwitchList>
            </p>
            <p class="codeItem">
              <span>型号：</span>
              <SwitchList v-model="currItemSize" :datas="currProd.arrSize"></SwitchList>
            </p>
            <p class="codeItem">
              <span>鉴验类型：</span>
              <SwitchList v-model="currItemCkbState" :datas="$root.$data._dict.returnQualityType"></SwitchList>
            </p>
            <p class="codeItem">
              <span class="itemCell flexSplit">唯一码：{{ getUuCode || '----------------------------------------' }}</span>
            </p>
            <div class="codeItem h-input-addon">
              <DatePicker v-model="currItemDateProduct" format="YYYY-MM-DD" placeholder="请选择生产日期"></DatePicker>
              <span class="h-input-addon" style="margin-left: 32px;">保质期：</span>
              <input type="text" style="width: 50px; margin-right: 16px; text-align: center;" v-model="currItemValidityVal" @focus="setIptFcs" />
              <SwitchList v-model="currItemValidityUnit" :datas="typeValidity"></SwitchList>
            </div>
            <div class="codeItem">
              <span class="itemCell flexSplit">临效日期：{{ getDateValidity }}</span>
            </div>
            <textarea rows="2" v-model="currItemMemo" class="memoArear" placeholder="鉴验备注说明"></textarea>
          </div>
        </div>
        <div class="imgRow">
          <div class="photoList">
            <span class="photoImg" v-for="(item, index) of photoList" :key="index" @click.prevent.stop="removeImg(index)">
              <img :src="item" width="60" height="60">
            </span>
          </div>
        </div>
        <p class="vrifyFooter">
          <span class="errMsgItem" v-for="(item, index) of getCheckMsg" :key="index">{{ item }}</span>
        </p>
        <p class="vrifyBtnGroup">
          <span class="btnItem btnVrifyCancle" @click.prevent.stop="cancleVrify">取消</span>
          <span class="btnItem btnVrifySubmit" @click.prevent.stop="submitVrify">确认</span>
        </p>
      </div>
      <div class="vrifySlide">
        <canvas ref="qrCell" class="qrCell"></canvas>
        <img id="prtImgCell" ref="prtImg" :src="currQr" width="128" height="128">
        <p class="optBtnRow">
          <button @click="execPrint">打印</button>&nbsp;&nbsp;&nbsp;&nbsp;
          <button @click="currQr=null">取消</button>
        </p>
      </div>
    </div>
  </tPanel>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import tPanel from '@/components/wrapper/part/tPanel';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import vueCountUp from 'vue-countupjs';
import dayjs from 'dayjs';
import {
  mapGetters,
  mapActions
} from 'vuex';
import UudCode from '@/tModules/utility/getUud';
import camer from '@/tModules/utility/camer';
import QRCode from 'qrcode';
// 定义本视图业务标识
const bizIdent = 'billVrify';
const Tdate = globalThis.smpoo.Tdate;

export default {
  name: 'billVrifyEdit',
  components: {
    basePage,
    tPanel,
    vueCountUp,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      inLoading: false,
      currDate: '',
      stepList: ['待检客户列表', '待检商品列表', '当前客户：'],
      currStep: 0,
      headerCust: [{
        key: 0,
        title: '序号',
        width: {
          x1: true
        }
      }, {
        key: 1,
        title: '单据编号',
        width: {
          x3: true
        }
      }, {
        key: 2,
        title: '客户',
        width: {
          flexSplit: true
        }
      }, {
        key: 3,
        title: '任务数量',
        width: {
          x2: true
        }
      }, {
        key: 4,
        title: '已检数量',
        width: {
          x2: true
        }
      }, {
        key: 5,
        title: '待检数量',
        width: {
          x2: true
        }
      }, {
        key: 6,
        title: '状态',
        width: {
          x1: true
        }
      }, {
        key: 7,
        title: '入库日期',
        width: {
          x2: true
        }
      }, {
        key: 8,
        title: '滞留天数',
        width: {
          x1: true
        }
      }],
      // 有效期类型
      typeValidity: [{
          key: 0,
          title: '天',
          dateEnd: (dataStart, val) => {
            return (new Tdate((new Date(dataStart)).getTime() + (val * 24 * 60 * 60 * 1000))).toString();
          }
        },
        {
          key: 1,
          title: '月',
          dateEnd: (dataStart, val) => {
            return (new Tdate((new Date(dataStart)).getTime() + (val * 30 * 24 * 60 * 60 * 1000))).toString();
          }
        },
        {
          key: 2,
          title: '年',
          dateEnd: (dataStart, val) => {
            return (new Tdate((new Date(dataStart)).getTime() + (val * 365 * 24 * 60 * 60 * 1000))).toString();
          }
        }
      ],
      // 待检品的从属客户列表
      custTobeList: [],
      // 当前所选的鉴验客户
      currCust: {},
      // 当前所选的鉴验商品
      currProd: {},
      // 拍照列表
      photoList: [],
      // 是否显示相机面板
      onCamera: false,
      // 视频和相片尺寸
      imgSize: 460,
      // 当前条目的荷载
      currItemSpec: -1,
      currItemSize: -1,
      // 当前条目的鉴验状态
      currItemCkbState: 1,
      // 当前条目的鉴验日期
      currItemDateCkb: '',
      // 生产日期
      currItemDataProd: '',
      // 生产日期
      currItemDateProduct: '',
      // 有效期单位
      currItemValidityUnit: 0,
      // 有效期数值
      currItemValidityVal: 1,
      // 有效期
      currItemDateValidityEnd: '',
      currItemMemo: '',
      // 二维码侧边栏的数据源属性
      currQr: null
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillVrifyObj', 'getUserInfo']),
    getProdList() {
      if (this.currCust.id) {
        let _obj = {};
        let lenProd = this.currCust.detail.length;
        let m = 0;
        for (let i = 0; i < lenProd; i++) {
          let v = this.currCust.detail[i];
          let _tag = `p${v.prodId}`;
          if (v.quantityCkb < v.quantityAct) {
            let _arrSpec = {};
            let _arrSize = {};
            if (_obj[_tag]) {
              _obj[_tag].quantityAct += v.quantityAct;
              _obj[_tag].quantityCkb += v.quantityCkb;
              let idxSpec = _obj[_tag].arrSpec.findIndex(vSpec => vSpec.key === v.spec);
              if (idxSpec === -1) {
                _obj[_tag].arrSpec.push({
                  key: v.spec,
                  title: v.specNamezh
                });
              }
              let idxSize = _obj[_tag].arrSize.findIndex(vSize => vSize.key === v.size);
              if (idxSize === -1) {
                _obj[_tag].arrSize.push({
                  key: v.size,
                  title: v.sizeNamezh
                });
              }
            } else {
              _obj[_tag] = {
                idx: i,
                pid: v.pid,
                prodId: v.prodId,
                code: v.code,
                prodNamezh: v.prodNamezh,
                quantityAct: v.quantityAct,
                quantityCkb: v.quantityCkb,
                unit: v.unit,
                arrSpec: [{
                  key: v.spec,
                  title: v.specNamezh
                }],
                arrSize: [{
                  key: v.size,
                  title: v.sizeNamezh
                }]
              };
            }
          }
        }
        return Object.values(_obj);
      } else {
        return [];
      }
    },
    // 获取数据有效性提示
    getCheckMsg() {
      let _msgArr = [];
      if (this.currStep === 2) {
        if (this.currItemSpec < 0) {
          _msgArr.push['产品规格未选择'];
        }
        if (this.currItemSize < 0) {
          _msgArr.push('产品型号未选择');
        }
        if (!this.getDateValidity) {
          _msgArr.push('产品临效期未指定');
        }
      }
      return _msgArr;
    },
    // 获取临效期
    getDateValidity() {
      if (this.currStep === 2) {
        let _dtType = this.currItemValidityUnit;
        let idx = this.typeValidity.findIndex(v => v.key === _dtType);
        if (idx > -1 && this.currItemDateProduct) {
          return this.typeValidity[idx].dateEnd(this.currItemDateProduct, this.currItemValidityVal);
        } else {
          return '';
        }
      }
    },
    // 获取唯一码
    getUuCode() {
      if (this.currStep === 2 && this.currItemSpec > -1 && this.currItemSize > -1 && this.currItemDateCkb) {
        let _uCodeStr = UudCode.getUud({
          fromCustId: this.currCust.id,
          prodId: this.currProd.prodId,
          spec: this.currItemSpec,
          size: this.currItemSize,
          dateCheck: new Tdate(this.currItemDateCkb).toString('cn', true, true),
          opteratorId: this.getUserInfo.id,
          state: this.currItemCkbState
        });
        this.getQr(_uCodeStr);
        return _uCodeStr;
      } else {
        return '';
      }
    }
  },
  methods: {
    ...mapActions(['queryBillVrifyObj', 'putBillVrifyObj', 'queryBillVrifyListTobe', 'putBillVrifyCheck', 'postBillVrifyObj']),
    // 选择当前客户
    setCust(item, idx) {
      this.currStep = 1;
      this.currCust = item;
    },
    // 选择当前商品
    setProd(item, idx) {
      this.currStep = 2;
      this.currProd = item;
      this.currItemDateCkb = new Tdate(new Date()).toString('cn', true, true);
      if (this.currProd.arrSpec.length === 1) {
        this.currItemSpec = this.currProd.arrSpec[0].key;
      } else {
        this.currItemSpec = -1;
      }
      if (this.currProd.arrSize.length === 1) {
        this.currItemSize = this.currProd.arrSize[0].key;
      } else {
        this.currItemSize = -1;
      }
    },
    // 返回上一步骤
    backStep() {
      if (!this.currStep) {
        this.currCust = {};
      } else if (this.currStep === 2) {
        this.currProd = {};
        this.initItemPayload();
      }
      this.currStep--;
    },
    // 还原当前操作条目的载荷为初始值
    initItemPayload() {
      this.currItemSpec = -1;
      this.currItemSize = -1;
      // 当前条目的鉴验状态
      this.currItemCkbState = 1;
      // 当前条目的鉴验日期
      this.currItemDateCkb = '';
      // 生产日期
      this.currItemDataProd = '';
      // 生产日期
      this.currItemDateProduct = '';
      // 有效期单位
      this.currItemValidityUnit = 0;
      // 有效期数值
      this.currItemValidityVal = 1;
      // 有效期
      this.currItemDateValidityEnd = '';
      this.currItemMemo = '';
      this.photoList = [];
      this.onCamera = false;
    },
    // 设置焦点并选择文字
    setIptFcs(e) {
      e.currentTarget.select();
    },
    // 创建二维码
    getQr(str) {
      let canvas = this.$refs.qrCell;
      QRCode.toCanvas(canvas, str, err => {
        if (err) console.error(err)
        console.log('success!');
      });
      let cvs = this.$refs.qrCell;
      this.currQr = cvs.toDataURL("image/jpeg");
    },
    execPrint() {
      printJS({
        printable: 'prtImgCell',
        type: 'html',
        css: '/static/css/currPrint.css',
        scanStyles: false
      });
    },
    // 开始留证操作
    startPhoto() {
      if (!this.getCheckMsg.length) {
        this.onCamera = true;
        camer.start(this.$refs.videoItem, {
          width: this.imgSize,
          height: this.imgSize
        });
      }
    },
    // 拍照操作
    takePhoto() {
      if (!this.getCheckMsg.length) {
        let cvs = this.$refs.cvsItem;
        cvs.getContext('2d').drawImage(this.$refs.videoItem, 0, 0, this.imgSize, this.imgSize);
        this.photoList.push(cvs.toDataURL("image/jpeg"));
      }
    },
    removeImg(idx) {
      this.photoList.splice(idx, 1);
    },
    // 取消鉴验
    cancleVrify() {
      this.initItemPayload();
      this.backStep();
    },
    // 确认鉴验结果
    async submitVrify() {
      let x = {
        pid: this.currProd.pid,
        prodId: this.currProd.prodId,
        spec: this.currItemSpec,
        size: this.currItemSize,
        quantity: 1,
        unit: this.currProd.unit,
        imgData: '',
        dateStroeIn: this.currCust.dateStroeIn,
        // 鉴验状态
        state: this.currItemCkbState,
        // 鉴验日期
        dateCkb: this.currItemDateCkb,
        // 有效期
        dateValidityEnd: this.getDateValidity,
        // 唯一码
        uuCode: this.getUuCode,
        memo: this.currItemMemo,
        operator: this.getUserInfo.id
      };
      let {
        detail,
        ...otherBill
      } = this.currCust;
      let res = await this.postBillVrifyObj({
        billObj: otherBill,
        prodItem: x
      });
      let _idx = detail.findIndex(v => {
        return v.prodId === x.prodId && v.spec === x.spec && v.size === x.size;
      });
      if (_idx > -1) {
        this.$set(detail[_idx], 'quantityCkb', detail[_idx].quantityCkb + 1)
      }
      this.cancleVrify();
    }
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    this.baseDefine = global.getBaseDefine(this.bizDefine);
    let _dt = new Date();
    this.currDate = new Tdate(_dt).toString('cn');
    let _that = this;
    this.queryBillVrifyListTobe({})
      .then(res => {
        let _diffNow = _dt.getTime();
        _that.custTobeList = res.map(v => {
          // 换算从入库开始的时间差
          v.diff = ((_diffNow - (new Date(v.dateStroeIn)).getTime()) / 1000 / 60 / 60 / 24).toFixed(1);
          return v;
        });
        _that.inLoading = false;
      })
      .catch(err => {
        _that.inLoading = false;
        global.terr(err);
      });
  }
};
</script>

<style lang="less" scoped>
@detailWrapperHeight: calc(84vh - 48px);
@sizeVal: 460px;
@pothoItemSize: 60px;

.txtRed {
  color: orangered;
}

.txtYellow {
  color: orange;
}

.workItem {
  display: flex;
  justify-content: center;
  align-items: center;

  .cell {
    margin: 0 2px;
    text-align: center;

    .tipsTag {
      position: relative;
      width: 100%;
      height: 100%;
      padding: 2px 8px;
      border-radius: 10px;
    }

    &.x1 {
      width: 80px;
    }

    &.x2 {
      width: 160px;
    }

    &.x3 {
      width: 240px;
    }
  }
}

.panelTips {
  &::after {
    content: attr(titleStr);
    font-size: 14px;
    font-weight: 700;
  }

  &.backBtn {
    padding: 0 18px;
    font-family: heyui !important;
    transition: all .3s ease-in-out;
    cursor: pointer;

    &:hover {
      color: #fff;
      background-color: #131138;
    }

    &::after {
      content: '\8FD4\56DE \e920';
    }
  }
}

.workPanel {
  width: 100%;
  height: 84vh;
  overflow-x: hidden;
  overflow-y: auto;

  .asHeader {
    padding: 8px 0;
    font-weight: 700;
    background-color: #f2f2f2;
    cursor: default;
  }

  .asDetail {
    padding: 18px 0;
    border-bottom: 1px #eee solid;
    cursor: pointer;

    &:hover {
      background-color: rgba(206, 205, 224, 0.3);
    }
  }

  .workDetail {
    height: @detailWrapperHeight;
    overflow-x: hidden;
    overflow-y: auto;
  }

  &.itemWrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;

    .prodItem {
      display: flex;
      flex-direction: column;
      justify-content: space-evenly;
      align-items: center;
      margin-right: 18px;
      width: 160px;
      height: 160px;
      border: 1px #ddd solid;
      background-color: rgba(100, 149, 237, .2);
      ;
      transition: background-color .3s ease-in-out,
        color .3s ease-in-out,
        box-shadow .3s ease-in-out;
      cursor: pointer;

      &:hover {
        border: none;
        border-radius: 10px;
        color: #fff;
        background-color: #131138;
        box-shadow: 2px 2px 14px 0 #131138;
      }
    }
  }

  .vrifyPanel {
    width: 958px;
    padding: 8px;
    border: 1px #eee solid;
    transition: all 1s ease-in-out;

    &:hover {
      box-shadow: 2px 2px 14px 0 #131138;
    }

    .vrifyTipRow {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      padding: 8px;

      .photoTip {
        flex: 1;
        text-align: center;
        color: #aaa;
      }

      .infoTip {
        flex: 1;
        text-align: center;
      }
    }

    .optWrapper {
      position: relative;
      display: flex;
      width: 946px;
      height: @sizeVal;

      .photoWrapper {
        position: absolute;
        width: @sizeVal;
        height: @sizeVal;
        line-height: @sizeVal;
        text-align: center;
        overflow: hidden;
        transition: all .3s ease-in-out;

        &.videoContent {
          z-index: 990;
        }

        .photoMaskUp {
          position: absolute;
          display: flex;
          justify-content: center;
          align-items: flex-end;
          width: @sizeVal;
          height: 50%;
          left: 0;
          top: 0;
          text-align: center;
          background-color: #000;
          z-index: 998;
          transition: visibility 1s linear;

          &.onHidden {
            animation: hiddenUp 1s;
            visibility: hidden;
          }

          .startBtn {
            position: absolute;
            width: @pothoItemSize;
            height: @pothoItemSize;
            line-height: @pothoItemSize;
            bottom: -30px;
            border-radius: 50%;
            color: #fff;
            background: #aaa url(/static/img/camera.png) center center no-repeat;
            background-size: 32px 32px;
            z-index: 999;
            cursor: pointer;
          }
        }

        .photoMaskDown {
          position: absolute;
          width: @sizeVal;
          height: 50%;
          top: 50%;
          left: 0;
          background-color: #000;
          transition: visibility 1s linear;
          z-index: 996;

          &.onHidden {
            animation: hiddenDown 1s;
            visibility: hidden;
          }
        }

        @keyframes hiddenUp {
          from {
            top: 0;
            background-color: rgba(0, 0, 0, 0.5);
          }

          to {
            top: -50%;
            display: none;
            background-color: transparent;
            z-index: 800;
          }
        }

        @keyframes hiddenDown {
          from {
            top: 50%;
            background-color: rgba(0, 0, 0, 0.5);
          }

          to {
            top: 100%;
            display: none;
            background-color: transparent;
            z-index: 800;
          }
        }

        .videoContener {
          position: absolute;
          width: @sizeVal;
          height: @sizeVal;
          left: 0;
          top: 0;

          &.itemVdo {
            z-index: 90;
          }

          &.itemCanvas {
            // display: none;
            line-height: @sizeVal;
          }
        }

        .itemBtns {
          position: absolute;
          display: flex;
          justify-content: center;
          align-items: center;
          width: @sizeVal;
          height: 48px;
          bottom: 0;
          background-color: rgba(0, 0, 0, 0.5);
          animation: showCameraBtn .3s;
          z-index: 9999;

          .photoBtn {
            width: 32px;
            height: 32px;
            line-height: 32px;
            border: none;
            border-radius: 50%;
            background: #aaa url(/static/img/camera.png) center center no-repeat;
            background-size: 16px 16px;
            transition: background .2s ease-in-out;
            outline: none;
            cursor: pointer;

            &:hover {
              background-color: orange;
            }
          }

          @keyframes showCameraBtn {
            from {
              bottom: -48px;
            }

            to {
              bottom: 0;
            }
          }
        }
      }

      .msgWrapper {
        position: absolute;
        flex: 1;
        display: flex;
        flex-direction: column;
        width: @sizeVal;
        height: @sizeVal;
        margin-left: 480px;

        .memoArear {
          width: 100%;
        }

        .codeItem {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          padding: 8px 0;
          border-bottom: 1px #aaa solid;

          .itemCell {
            text-align: left;
          }
        }
      }
    }

    .imgRow {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      max-width: 946px;
      height: 80px;
      margin-top: 4px;

      .photoList {
        display: flex;
        justify-content: flex-start;
        align-items: flex-start;
        max-width: 946px;
        height: 80px;
        flex: 1;
        overflow-x: auto;
        overflow-y: hidden;

        .photoImg {
          position: relative;
          width: @pothoItemSize;
          height: @pothoItemSize;
          line-height: @pothoItemSize;
          margin: 4px 4px 0 0;
          border: 1px #eee solid;
          text-align: center;
          font-size: .6rem;
          background-color: #ccc;
          transition: all 1s ease-in-out;
          cursor: pointer;

          &:hover {
            font-family: heyui !important;

            &::after {
              content: '\e918';
              position: absolute;
              width: @pothoItemSize;
              height: @pothoItemSize;
              left: 0;
              top: 0;
              font-size: 18px;
              color: #fff;
              background-color: rgba(0, 0, 0, 0.5);
            }
          }
        }
      }
    }

    .vrifyFooter {
      display: flex;
      justify-content: center;
      align-items: center;
      max-width: 946px;
      height: 32px;
      color: orangered;

      .errMsgItem {
        margin: 0 8px;
      }
    }

    .vrifyBtnGroup {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      max-width: 946px;
      height: 32px;

      .btnItem {
        padding: 4px 18px;
        margin-left: 18px;
        border: 1px #131138 solid;
        border-radius: 50px;
        cursor: pointer;
      }

      .btnVrifyCancle {
        background-color: transparent;
      }

      .btnVrifySubmit {
        color: #fff;
        background-color: #131138;
      }
    }
  }

  .vrifySlide {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 256px;
    height: 662px;
    margin-left: 18px;
    border: 1px #eee solid;
    transition: all .5s ease-in-out;

    .qrCell {
      width: 80px;
      height: 80px;
      margin-right: 16px;
      cursor: pointer;
    }

    #prtImgCell {
      display: none;
    }

    .optBtnRow {
      width: 100%;
      text-align: center;
    }
  }
}

@media print{
  .qrCell {
    display: none;
  }

  #prtImgCell {
    display: block;
  }
}
</style>
