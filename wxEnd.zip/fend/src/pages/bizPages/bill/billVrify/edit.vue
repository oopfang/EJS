<template>
<baseCrudEdit :masterKeys="masterKeys" :dictKeys="dictKeys" :baseDefine="baseDefine" :inLoading="inLoading" @saveEvnt="saveHandler">
  <Row :space="18">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">ID</span>
      <span>{{dataset.id}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">父级ID</span>
      <NumberInput v-model="dataset.pid" :useOperate="true"></NumberInput>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">代码</span>
      <input type="text" v-model="dataset.code" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">英文名称</span>
      <input type="text" v-model="dataset.name" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">鉴验日期</span>
      <input type="text" v-model="dataset.dateCheck" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">名称</span>
      <input type="text" v-model="dataset.namezh" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">检验员</span>
      <input type="text" v-model="dataset.operator" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">退货申请单ID</span>
      <input type="text" v-model="dataset.billReturnAskId" />
    </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">全部可再销</span>
      <input type="text" v-model="dataset.allGood" />
    </Col>
  </Row>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billVrify';

export default {
  name: 'billVrifyEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      masterKeys: [],
      dictKeys: [],
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      dataset: {}
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillVrifyObj'])
  },
  methods: {
    ...mapActions(['queryBillVrifyObj', 'putBillVrifyObj']),
    // 保存操作的响应
    saveHandler: function () {
      let x = {
        $act: enumObj.crud.act.edit,
        bizIdent: this.bizDefine.intro.code,
        data: global.preReqData(this.dataset),
        by: {
          id: this.dataset.id
        }
      };
      this.putBillVrifyObj(x)
        .then(res => {
          global.tinfo(res);
          this.$router.push({
            name: `${this.bizDefine.intro.code}View`,
            params: {
              id: this.dataset.id
            }
          });
        })
        .catch(err => {
          global.terr(err);
        });
    }
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    this.baseDefine = global.getBaseDefine(this.bizDefine);
    let _param = this.$route.params;
    if (_param) {
      let _id = _param.id;
      if (_id && _id > 0) {
        let x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: _id
          }
        }];
        this.queryBillVrifyObj(x)
          .then(res => {
            this.dataset = this.getBillVrifyObj[0];
            this.inLoading = false;
          })
          .catch(err => {
            this.inLoading = false;
            global.terr(err);
          });
      }
    }
  }
};
</script>
