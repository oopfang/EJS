<template>
<baseCrudAdd :masterKeys="masterKeys" :dictKeys="dictKeys" :baseDefine="baseDefine" :inLoading="inLoading" @saveEvnt="saveHandler">
  <Row :space="18" v-show="currStep===0">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">ID</span>
      <span>{{dataset.id}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">父级ID</span>
      <NumberInput v-model="dataset.pid" :useOperate="true"></NumberInput>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">代码</span>
      <input type="text" v-model="dataset.code" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">英文名称</span>
      <input type="text" v-model="dataset.name" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">鉴验日期</span>
      <input type="text" v-model="dataset.dateCheck" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">名称</span>
      <input type="text" v-model="dataset.namezh" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">检验员</span>
      <input type="text" v-model="dataset.operator" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">退货申请单ID</span>
      <input type="text" v-model="dataset.billReturnAskId" />
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">全部可再销</span>
      <input type="text" v-model="dataset.allGood" />
    </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">备注</span>
      <textarea rows="5" v-autosize v-model="dataset.memo"></textarea>
    </Col>
  </Row>
</baseCrudAdd>
</template>

<script>
import baseCrudAdd from '@/components/wrapper/baseCrudAdd';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billVrify';

export default {
  name: 'billVrifyAdd',
  components: {
    baseCrudAdd,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      masterKeys: [],
      dictKeys: [],
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      dataset: {}
    };
  },
  computed: {
    ...mapGetters(['getBizDefine'])
  },
  methods: {
    ...mapActions(['postBillVrifyObj']),
    // 保存操作的响应
    saveHandler: function () {
      let x = {
        $act: enumObj.crud.act.add,
        bizIdent: this.bizDefine.intro.code,
        data: [global.preReqData(this.dataset, this.dataset.id)]
      };
      this.postBillVrifyObj(x)
        .then(res => {
          global.tinfo('新增成功');
          this.$router.push({
            name: `${this.bizDefine.intro.code}View`,
            params: {
              id: res
            }
          });
        })
        .catch(err => {
          global.terr(err);
        });
    }
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    if (this.bizDefine) {
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      this.dataset = this.bizDefine.emptyVal();
    }
  }
};
</script>
