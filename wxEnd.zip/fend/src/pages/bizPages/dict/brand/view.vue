<template>
<baseDict :masterKeys="masterKeys" :dictKeys="dictKeys" :disableDoc="true" :define="bizDefine" :currList="dataset" @itemEdit="editHandler" @eventSaveOk="queryData">
  <tPanel showHeader :topSpace="index > 0 ? 18 : 0" v-for="(item, index) in editList" :key="index">
    <div slot="panelHeader"><span class="inEditTag">{{ item.namezh }}</span>[编辑中...]</div>
    <Row :space="18">
      <Col :width="12" class="h-input-group">
      <span class="h-input-addon">品牌代码</span>
      <input type="text" v-model="item.code" />
      </Col>
      <Col :width="12" class="h-input-group">
      <span class="h-input-addon">品牌名称</span>
      <input type="text" v-model="item.namezh" />
      </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">备注</span>
      <textarea rows="5" v-autosize v-model="item.memo"></textarea>
      </Col>
    </Row>
  </tPanel>
</baseDict>
</template>

<script>
import baseDict from '@/components/wrapper/baseDict';
import tPanel from '@/components/wrapper/part/tPanel.vue';
import enumObj from 'tframe-enum';
import {
  mapGetters,
  mapActions
} from 'vuex';
// 定义本视图业务标识
const bizIdent = 'brand';

export default {
  name: 'brandDictView',
  components: {
    baseDict,
    tPanel
  },
  data: function () {
    return {
      bizDefine: {},
      inLoading: false,
      dataset: [],
      masterKeys: [],
      dictKeys: [],
      // 进行编辑的列表集合
      editList: []
    };
  },
  computed: {
    ...mapGetters(['getBizDefine'])
  },
  methods: {
    ...mapActions(['queryBrandList']),
    setDictName(code, idx) {
      let _obj = this.$preCode(code);
      this.$set(this.editList[idx], 'code', _obj.code);
      this.$set(this.editList[idx], 'name', _obj.name);
    },
    editHandler: function (ids) {
      this.editList = this.dataset.filter(v => {
        // return ids.includes(v.id);
        return Array.isArray(ids) ? ids.includes(v.id) : ids === v.id;
      });
    },
    // 查询数据
    queryData: function () {
      let x = [{
        $act: enumObj.crud.act.read,
        bizIdent: bizIdent
      }];
      this.queryBrandList(x)
        .then(res => {
          this.dataset = res;
        })
        .catch(err => {
          global.terr(err);
        });
    }
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    this.queryData();
  },
  destroyed() {
    this.dataset = [];
    this.editList = [];
    this.bizDefine = {};
  }
};
</script>
