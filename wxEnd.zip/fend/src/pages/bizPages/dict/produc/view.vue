<template>
<baseDict :masterKeys="masterKeys" :dictKeys="dictKeys" :disableDoc="true" :define="bizDefine" :currList="dataset" @itemEdit="editHandler" @eventSaveOk="queryData">
  <tPanel showHeader :topSpace="index > 0 ? 18 : 0" v-for="(item, index) in editList" :key="index">
    <div slot="panelHeader"><span class="inEditTag">{{ item.namezh }}</span>[编辑中...]</div>
    <Row :space="18" class="dictDetailSlider">
      <Col :width="12" class="h-input-group">
      <span class="h-input-addon">代码</span>
      <input type="text" v-model="item.code" />
      </Col>
      <Col :width="12" class="h-input-group">
      <span class="h-input-addon">名称</span>
      <input type="text" v-model="item.namezh" />
      </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">价格</span>
      <input type="number" v-model="item.price" />
      <span class="h-input-addon">元</span>
      </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">所属品牌</span>
      <Select v-model="item.brandId" :datas="$root.$data._dict.brand" :nullOption="false"></Select>
      </Col>
      <Col :width="24" class="groupTips">可选规格</Col>
      <Col :width="24" class="h-input-group">
      <Select v-model="item.spec" :datas="$root.$data._dict.groupColor" :nullOption="false" multiple></Select>
      <!-- <TagInput v-model="item.spec" type="string" split=","></TagInput> -->
      </Col>
      <Col :width="24" class="groupTips">可选型号</Col>
      <Col :width="24" class="h-input-group">
      <Select v-model="item.size" :datas="$root.$data._dict.groupSize" :nullOption="false" multiple></Select>
      <!-- <TagInput v-model="item.size" type="string" split=","></TagInput> -->
      </Col>
      <Col :width="12" class="h-input-group">
      <span class="h-input-addon">碳减排量</span>
      <input type="number" v-model="item.co2" />
      <span class="h-input-addon">克</span>
      </Col>
      <Col :width="12" class="h-input-group">
      <span class="h-input-addon">象币兑换比例</span>
      <input type="number" v-model="item.scale" />
      </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">备注</span>
      <textarea rows="5" v-autosize v-model="item.memo"></textarea>
      </Col>
      <Col :width="24" class="h-input-group">
      <span class="h-input-addon">附件</span>
      </Col>
      <Col :width="24" class="h-input-group">
      <fUpload ref="loaderAskMeasure" :submitFunc="fileUploader" :allowedType="allowedType" :pathType="pathType" @fileUpOk="item.picAddr=$event"></fUpload>
      </Col>
    </Row>
  </tPanel>
</baseDict>
</template>

<script>
import baseDict from '@/components/wrapper/baseDict';
import tPanel from '@/components/wrapper/part/tPanel.vue';
import fUpload from '@/components/widge/upload';
import enumObj from 'tframe-enum';
import {
  mapGetters,
  mapActions
} from 'vuex';
// 定义本视图业务标识
const bizIdent = 'produc';

export default {
  name: 'producDictView',
  components: {
    baseDict,
    fUpload,
    tPanel
  },
  data: function () {
    return {
      bizDefine: {},
      inLoading: false,
      dataset: [],
      masterKeys: ['brand', 'groupColor', 'groupSize'],
      dictKeys: [],
      // 附件上传的允许类型
      allowedType: '.png, .jpg, .jpeg, .png',
      // 进行编辑的列表集合
      editList: [],
      // 文件路径归类
      pathType: 'prod'
    };
  },
  computed: {
    ...mapGetters(['getBizDefine'])
  },
  methods: {
    ...mapActions(['fileUploader', 'queryProducList', 'putProducImg']),
    setDictName(code, idx) {
      let _obj = this.$preCode(code);
      this.$set(this.editList[idx], 'code', _obj.code);
      this.$set(this.editList[idx], 'name', _obj.name);
    },
    editHandler: function (ids) {
      this.editList = this.dataset.filter(v => {
        // return ids.includes(v.id);
        return Array.isArray(ids) ? ids.includes(v.id) : ids === v.id;
      });
    },
    // 查询数据
    queryData: function () {
      let x = [{
        $act: enumObj.crud.act.read,
        bizIdent: bizIdent
      }];
      this.queryProducList(x)
        .then(res => {
          this.dataset = res;
        })
        .catch(err => {
          global.terr(err);
        });
    },
    fileUpOk(e) {
      tlog(e);
    }
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    this.queryData();
  },
  destroyed() {
    this.dataset = [];
    this.editList = [];
    this.bizDefine = {};
  }
};
</script>
