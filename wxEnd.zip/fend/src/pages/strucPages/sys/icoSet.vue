<template>
<basePage>
  <keep-alive>
    <ul class="fullPage">
      <li v-for="(item, index) in currList" :key="index" @click.prevent.stop="execCopy(item, index)">
        <p>
          <tIcon :icon="item" :size="24" :height="32"></tIcon>
        </p>
        <p>{{ item }}</p>
      </li>
    </ul>
  </keep-alive>
  <input class="copyCtrl" type="text" id='ipt'/>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import tIcon from '@/components/widge/tIcon';
import iconList from '_static/js/tIconList';

export default {
  name: 'lock',
  components: {
    basePage,
    tIcon
  },
  data: function () {
    return {
      currList: []
    };
  },
  methods: {
    execCopy: function (txt, idx) {
      let _setVal = val => {
        let ipt = document.getElementById('ipt');
        ipt.value = val;
        ipt.select();
        document.execCommand('copy');
        this.$Message(`已复制：${val}`);
      };
      _setVal(txt);
    }
  },
  mounted() {
    this.currList = iconList.sort((a, b) => {
      a.localeCompare(b);
    });
  }
};
</script>

<style lang="less" scoped>
.fullPage {
  list-style: none;
  height: 99vh;
  padding: 36px;

  li {
    display: inline-flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 150px;
    height: 150px;
    padding: 20px 8px;
    margin: 8px;
    border: 1px solid #eee;
    border-radius: 3px;
    text-align: center;
    font-size: 15px;
    white-space: nowrap;
    overflow: hidden;
    background-color: #fff;

    &:hover {
      background-color: #eee;
    }
  }
}

input.copyCtrl {
  position: absolute;
  top: 0;
}
</style>
