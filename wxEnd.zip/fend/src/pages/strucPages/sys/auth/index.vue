<template>
  <basePage></basePage>
</template>

<script>
  import basePage from '@/components/layout/auth';

  export default {
    name: '',
    components: {
      basePage
    },
    data: function() {
      return {
        data: []
      };
    },
    computed: {},
    methods: {}
  };
</script>
