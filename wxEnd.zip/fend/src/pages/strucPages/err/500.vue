<template>
<div class="page500">
  <p>500错误</p>
  <p>服务器异常</p>
  <hr />
  <p>如果遇到这个页面，请练习 系统管理员 </p>
</div>
</template>

<script>
  export default {
    name: ''
  };
</script>

<style lang="less" scoped>
.page500 {
  width: 100vw;
  height: 100vh;
  overflow: hidden;

  p:nth-child(1) {
    background-color: red;
  }
}
</style>