<template>
<div class="error403">
  <div class="error403-title">
    <span class="error403-title-icon">
      <tIcon :size="80" icon="t-lock-closed"></tIcon>
      <tIcon :size="140" icon="t-block" color="#3B91FF"></tIcon>
    </span>
  </div>
  <p class="error403-message"></p>
  <div class="error403-btn">
    <Button noBorder text-color="blue" @click="goHome">返回</Button>
  </div>
</div>
</template>

<script>
import tIcon from '@/components/widge/tIcon';

export default {
  name: 'Error403',
  components: {
    tIcon
  },
  methods: {
    backPage() {
      this.$router.go(-1);
    },
    goHome() {
      this.$router.push({
        path: 'sign'
      });
    }
  }
};
</script>

<style lang="less" scoped>
@keyframes error403animation {
  0% {
    transform: rotateZ(0deg);
  }

  40% {
    transform: rotateZ(-20deg);
  }

  45% {
    transform: rotateZ(-15deg);
  }

  50% {
    transform: rotateZ(-20deg);
  }

  55% {
    transform: rotateZ(-15deg);
  }

  60% {
    transform: rotateZ(-20deg);
  }

  100% {
    transform: rotateZ(0deg);
  }
}

@offset: -150px;

.txt(left, @txt) {
  content: @txt;
  left: @offset;
}

.txt(right, @txt) {
  content: @txt;
  right: @offset;
}

.txt(@_, @txt) {
  position: absolute;
  top: -60px;
}

.error403 {
  width: 700px;
  height: 500px;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);

  &-title {
    text-align: center;
    font-size: 240px;
    font-weight: 700;
    color: #aaa;
    height: 260px;
    line-height: 260px;
    margin-top: 40px;

    &-icon {
      display: inline-block;
      position: relative;
      width: 170px;
      height: 170px;
      color: #ed3f14;
      margin-right: 10px;

      i {
        display: inline-block;
        font-size: 120px;
        position: absolute;
        left: 50%;
        top: 50%;

        &:first-child {
          top: 90px;
          font-size: 120px;
          transform: translate(-50%, -50%);
        }
        &:last-child {
          font-size: 190px;
          left: 20px;
          transform: translate(-50%, -60%);
          transform-origin: center bottom;
          animation: error403animation 2.8s ease 0s infinite;
        }

      }

      &::before {
        .txt(left, '4');
      }

      &::after {
        .txt(right, '3');
      }
    }
  }

  &-message {
    display: block;
    text-align: center;
    font-size: 30px;
    font-weight: 500;
    letter-spacing: 4px;
    color: #dddde2;
    &::before {
      content: '操作受限，请联系管理员';
    }
  }

  &-btn {
    text-align: center;
    padding: 20px 0;
    margin-bottom: 40px;
  }
}

&-btn {
  text-align: center;
  padding: 20px 0;
  margin-bottom: 40px;
}
</style>
