<template>
  <div class="error404">
    <div class="error404-title">
      <tIcon icon="t-search" :size="94"></tIcon>
    </div>
    <p class="error404-message"></p>
    <div class="error404-btn">
      <Button noBorder text-color="blue" @click="backPage">返回</Button>
    </div>
  </div>
</template>

<script>
import tIcon from '@/components/widge/tIcon';

export default {
  name: 'Error404',
  components: {
    tIcon
  },
  methods: {
    backPage() {
      this.$router.go(-1);
    }
  }
};
</script>

<style lang="less" scoped>
@keyframes error404animation {
  0% {
    transform: rotateZ(0deg);
  }

  20% {
    transform: rotateZ(-60deg);
  }

  40% {
    transform: rotateZ(-10deg);
  }

  60% {
    transform: rotateZ(50deg);
  }

  80% {
    transform: rotateZ(-20deg);
  }

  100% {
    transform: rotateZ(0deg);
  }
}

  .error404 {
    width: 700px;
    height: 500px;
    position: absolute;
    left: 50%;
    top: 50%;
    background-color: #fff;
    transform: translate(-50%, -50%);

    @offset: 150px;
    .txt(left) {
      left: @offset;
    }

    .txt(right) {
      right: @offset;
    }

    .txt(@_) {
      content: '4';
      position: absolute;
    }
    &-title {
      text-align: center;
      font-size: 168px;
      font-weight: 700;
      color: #aaa;
      height: 260px;
      line-height: 260px;
      margin-top: 40px;

      i {
        display: inline-block;
        top: 33%;
        left: 43%;
        color: #131138;
        font-size: 10rem;
        animation: error404animation 3s ease 0s infinite alternate;
      }

      &::before {
        .txt(left);
      }

      &::after {
        .txt(right);
      }
    }

    &-message {
      display: block;
      text-align: center;
      font-size: 30px;
      font-weight: 500;
      letter-spacing: 12px;
      color: #dddde2;

      &::before {
        content: '访问的地址有误';
      }
    }

    &-btn {
      text-align: center;
      padding: 20px 0;
      margin-bottom: 40px;
    }
  }


</style>
