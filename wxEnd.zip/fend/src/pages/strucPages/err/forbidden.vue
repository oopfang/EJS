<template>
<div class="errorForbidden">
  <div class="errorForbidden-body-con">
    <div class="errorForbidden-body-con-title">
      <tIcon icon="t-lock-closed" :size="48" color="#aaa"></tIcon>
    </div>
    <p class="errorForbidden-body-con-message"></p>
    <div class="errorForbidden-btn-con">
      <Button noBorder text-color="blue" @click="gotoLogin">返回</Button>
    </div>
  </div>
</div>
</template>

<script>
import tIcon from '@/components/widge/tIcon';

export default {
  components: {
    tIcon
  },
  methods: {
    gotoLogin() {
      this.$router.push({
        path: 'sign'
      });
    }
  }
};
</script>

<style lang="less" scoped>
@keyframes errorForbiddenanimation {
  0% {
    transform: rotateZ(0deg);
  }

  40% {
    transform: rotateZ(-20deg);
  }

  45% {
    transform: rotateZ(-15deg);
  }

  50% {
    transform: rotateZ(-20deg);
  }

  55% {
    transform: rotateZ(-15deg);
  }

  60% {
    transform: rotateZ(-20deg);
  }

  100% {
    transform: rotateZ(0deg);
  }
}

.errorForbidden {
  &-body-con {
    width: 700px;
    height: 500px;
    position: absolute;
    left: 50%;
    top: 40%;
    transform: translate(-50%, -50%);

    &-title {
      text-align: center;
      font-size: 240px;
      font-weight: 700;
      color: #2d8cf0;
      height: 260px;
      line-height: 260px;
      margin-top: 40px;

      i {
        display: inline-block;
        font-size: 3rem;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
      }
    }

    &-message {
      display: block;
      text-align: center;
      font-size: 24px;
      font-weight: 500;
      letter-spacing: 4px;
      color: #dddde2;
      &::before {
        content: '该账号已被禁用';
      }
    }
  }

  &-btn-con {
    text-align: center;
    padding: 20px 0;
    margin-bottom: 40px;
  }
}
</style>
