<template>
<!-- 正式版 inout.vue 文件 -->
<Row class="container">
  <div class="slogan"><p></p><span></span></div>
  <Row class="content">
    <Row class="appLogo">
      <img src="http://pcqrmgax6.bkt.clouddn.com/img/slogan_white.png">
    </Row>

      <Form :label-width="110" :model="sign" :rules="validationRules" ref="form">
        <FormItem label="用户名" prop="input">
          <input type="text" v-model="sign.uName" placeholder="用户名..." autofocus @keydown.enter.prevent.stop="nextStep"/>
      </FormItem>
          <FormItem label="密码" prop="input">
            <input ref="uPwd" :type="getPwdType" v-model="sign.uPwd" placeholder="输入并回车" @focus="inFocus=true"  @keydown.enter.prevent.stop="getSignIn" />
      </FormItem>
      </Form>
    </Row>
    <div class="loginFooter">
      {{ getCpStr1 }}
      <br /> {{ getCpStr2 }}
    </div>
  </Row>
</template>

<script>
import Tright from 'tframe-rights';
import tEnumRight from 'tframe-enum/enum/sys';
import {
  mapGetters,
  mapActions
} from 'vuex';

export default {
  name: 'signin',
  comments: {},
  data: function () {
    return {
      sign: {
        uName: '',
        uPwd: ''
      },
      inFocus: false,
      validationRules: {
        required: [
          'uName',
          'uPwd'
        ]
      }
    };
  },
  computed: {
    ...mapGetters(['getCpStr1', 'getCpStr2']),
    getPwdType: function () {
      if (this.sign.uName === 'test' || this.sign.uName === 'demo') {
        return 'password';
      } else {
        return this.sign.uPwd ? 'password' : 'text';
      }
    }
  },
  methods: {
    ...mapActions(['signIn']),
    nextStep: function () {
      if (this.sign.uPwd) {
        this.getSignIn();
      } else {
        this.$refs.uPwd.focus();
      }
    },
    getSignIn: function () {
      let validResult = this.$refs.form.valid();
      if (validResult.result) {
        /* eslint-disable no-undef */
        let x = {
          by: {
            code: this.sign.uName,
            uPwd: sha1(this.sign.uPwd)
          }
        };
        let _setRoot = (key, val) => {
          this.$root.$data[key] = val;
        };
        let _setRouter = pathObj => {
          this.$router.push(pathObj);
        };
        this.signIn(x).then(res => {
          if (res.isStopped) {
            _setRouter({
              path: 'forbidden'
            });
          } else if (!res.hasRight > 0) {
            _setRouter({
              path: '403'
            });
          } else {
            _setRoot('_dict', res.dict);
            let _bizObj = {
              $crud: new Tright(tEnumRight.seed.crud),
              $extend: new Tright(tEnumRight.seed.extend)
            };
            for (let v of Object.keys(res.bizRight)) {
              _bizObj[v] = new Tright(res.bizRight[v]);
            }
            _setRoot('rights', _bizObj);
            _setRouter('/');
          }
        }).catch(err => {
          terr(err);
        });
      } else {
        terr('输入不正确');
      }
    }
  }
};
</script>

<style lang="less" scoped>
input:-webkit-autofill {
  box-shadow: 0 0 0px 1000px #9189a7 inset !important;
  -webkit-box-shadow: 0 0 0px 1000px #9189a7 inset !important;
  -webkit-text-fill-color: #333 !important;
  border: none !important;
  border-radius: 0;
}

.container {
  width: 100vw;
  height: 100vh;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  background: url(../../../../static/img/bg.jpg) no-repeat center;
  background-position: center top;
  background-size: cover;

  .slogan {
    position: absolute;
    width: 100vw;
    top: 10vh;
    left: 30vw;
    text-align: center;
    color: #fff;
    font-size: 1.8rem;
    z-index: 99;
    p::after {
      content: 'HAYA';
    }
    span {
      position: absolute;
      padding-left: 6px;
      margin-top: 0;
      font-size: 0.8rem;
      color: orange;
      z-index: 100;
      &::after {
        content: '@2018';
      }
    }
  }

  .content {
    width: 400px;
    height: 200px;
    border-radius: 6px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.6);
    overflow: hidden;
    z-index: 2;
    padding: 50px;
    box-sizing: border-box;

    .appLogo {
      width: 10%;
      height: 10%;
      margin-bottom: 1rem;

      img {
        width: 6vw;
        margin-left: -50px;
        margin-top: -10px;
      }
    }

    .inputRow {
      min-height: 30px;
      margin: 0.5rem 0;
      background-color: transparent;
      border-bottom: 1px #000 solid;

      .inputItem {
        min-width: 100%;
        min-height: 30px;
        /* 设置line-height与父级元素的height相等 */
        line-height: 30px;
        /* 设置文本水平居中 */
        text-align: center;
        /* 防止内容超出容器或者产生自动换行 */
        overflow: hidden;
        color: #000;
        font-weight: 100;
        border: 0px;
        outline: none;
      }
    }
  }

  .loginFooter {
    position: absolute;
    padding: 0;
    margin: 0;
    width: 100vw;
    height: 20px;
    line-height: 20px;
    bottom: 20%;
    text-align: center;
    font-size: 0.6rem;
    font-weight: 300;
    color: #777;
  }
}
</style>
