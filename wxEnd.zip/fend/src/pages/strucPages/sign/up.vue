<template>
	<div>注册</div>
</template>

<script>
export default {
  name: 'signup',
  comments: {},
  computed: {},
  methods: {}
};
</script>
