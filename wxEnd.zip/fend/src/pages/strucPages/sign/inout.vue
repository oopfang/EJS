<template>
<basePage :masterKeys="masterKeys" :dictKeys="dictKeys" :inLoading="inLoading">
  <div class="container">
    <div class="contentLeft">
      <img class="cellLogo" src="/static/img/logo.png">
    </div>
    <Row class="content">
      <div class="slogan">
        <p></p><span></span>
      </div>
      <div class="signBlock">
        <div class="h-input-addon iptRow">
          <div class="h-input-addon labelBlock">用户名：</div>
          <input style="flex: 1;" type="text" class="iptCtrl" v-model="sign.uName" placeholder="用户名..." autofocus @keydown.enter.prevent.stop="nextStep" />
        </div>
        <div class="h-input-addon iptRow">
          <div class="h-input-addon labelBlock">密码：</div>
          <input style="flex: 1;" ref="uPwd" type="password" class="iptCtrl" v-model="sign.uPwd" placeholder="输入并回车" @keydown.enter.prevent.stop="getSignIn" />
        </div>
        <div class="h-input-addon iptRow">
          <div class="h-input-addon labelBlock">角色：</div>
          <Select :disabled="!sign.uName || sign.uName === 'admin' || sign.uName === 'auth'" style="flex: 1;" v-model="sign.roleId" :datas="getRoleList" :nullOption="false" nullOptionText="请选择角色"></Select>
        </div>
        <p class="signBtnRow">
          <button class="h-btn h-btn-text-yellow h-btn-transparent" @click="getSignIn">登录</button>
        </p>
      </div>
    </Row>
  </div>
  <div class="loginFooter">
    {{ getCpStr1 }}
    <br /> {{ getCpStr2 }}
  </div>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import Tright from 'tframe-rights';
import tEnumRight from 'tframe-enum/enum/sys';
import {
  mapGetters,
  mapActions
} from 'vuex';

export default {
  name: 'signin',
  components: {
    basePage
  },
  data: function () {
    return {
      masterKeys: ['role'],
      dictKeys: [],
      inLoading: false,
      sign: {
        uName: '',
        uPwd: '',
        roleId: 1
      },

      validationRules: {
        required: [
          'uName',
          'uPwd'
        ]
      }
    };
  },
  computed: {
    ...mapGetters(['getCpStr1', 'getCpStr2', 'getSlogan']),
    getRoleList() {
      return ((((this.$root || {}).$data || {})._dict || {}).role || []).filter(v => {
        return v.key !== 2 && v.key !== 3;
      });
    }
  },
  methods: {
    ...mapActions(['signIn']),
    nextStep: function () {
      if (this.sign.uPwd) {
        this.getSignIn();
      } else {
        this.$refs.uPwd.focus();
      }
    },
    validResult() {
      return this.sign.uName && this.sign.uPwd;
    },
    getSignIn: function () {
      // let validResult = this.$refs.form.valid();
      if (this.validResult) {
        /* eslint-disable no-undef */
        let x = {
          by: {
            code: this.sign.uName,
            uPwd: sha1(this.sign.uPwd),
            roleId: this.sign.roleId
          }
        };
        let _setRoot = (key, val) => {
          this.$root.$data[key] = val;
        };
        let _setRouter = pathObj => {
          this.$router.push(pathObj);
        };
        this.signIn(x).then(res => {
          if (res.isStopped) {
            _setRouter({
              path: 'forbidden'
            });
          } else if (!res.hasRight > 0) {
            _setRouter({
              path: '403'
            });
          } else {
            _setRoot('_dict', res.dict);
            let _bizObj = {
              $crud: new Tright(tEnumRight.seed.crud),
              $extend: new Tright(tEnumRight.seed.extend)
            };
            for (let v of Object.keys(res.bizRight)) {
              _bizObj[v] = new Tright(res.bizRight[v]);
            }
            _setRoot('rights', _bizObj);
            _setRouter('/');
          }
        }).catch(err => {
          terr(err);
        });
      } else {
        terr('输入不正确');
      }
    }
  }
};
</script>

<style lang="less" scoped>
// .h-form-item-label {
//   color: #fff !important;
// }

input:-webkit-autofill {
  box-shadow: 0 0 0px 1000px #ebeee6 inset !important;
  -webkit-box-shadow: 0 0 0px 1000px #ebeee6 inset !important;
  -webkit-text-fill-color: #333 !important;
}

.container {
  width: 100vw;
  height: 100vh;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;

  .slogan {
    position: absolute;
    width: 100vw;
    top: 10vh;
    right: 5vw;
    text-align: right;
    color: #fff;
    font-size: 1.8rem;
    z-index: 99;

    p::after {
      color: #000;
      font-size: 18px;
      font-weight: 700;
      content: '\4E0A\6D77\7B2C\4E8C\5DE5\4E1A\5927\5B66\A\9006\5411\7269\6D41\7BA1\7406\7CFB\7EDF';
      white-space: pre;
    }

    span {
      position: absolute;
      width: 300px;
      padding-left: 6px;
      margin-top: 0;
      margin-left: -10vw;
      font-size: 0.8rem;
      text-align: left;
      color: orange;
      z-index: 100;

      &::after {
        font-size: 12px;
        content: 'Base on HAYA ( tFrame v8.0 )';
      }
    }
  }

  .contentLeft {
    position: relative;
    flex: 1;
    height: 100vh;
    background: transparent url(/static/img/bg.jpg) left bottom no-repeat;
    background-size: cover;
    // filter: saturate(0.5);

    .cellLogo {
      position: fixed;
      left: 0;
      top: 50px;
      filter: drop-shadow(2px 4px 6px black);
    }
  }

  .content {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 30vw;
    height: 100vh;
    // border-radius: 6px;
    // box-shadow: 0 10px 20px rgba(0, 0, 0, 0.6);
    overflow: hidden;
    // z-index: 2;
    padding: 30px 10px;
    box-sizing: border-box;
    background-color: rgba(0, 255, 0, 0.1);

    .inputRow {
      min-height: 30px;
      margin: 0.5rem 0;
      background-color: transparent;
      border-bottom: 1px #000 solid;

      .inputItem {
        min-width: 100%;
        min-height: 30px;
        /* 设置line-height与父级元素的height相等 */
        line-height: 30px;
        /* 设置文本水平居中 */
        text-align: center;
        /* 防止内容超出容器或者产生自动换行 */
        overflow: hidden;
        color: #000;
        font-weight: 100;
        border: 0px;
        outline: none;
      }
    }

    .signBlock {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;
      height: 100%;
      margin-top: 20px;

      .signBtnRow {
        width: 100%;
        margin-top: 8px;
        text-align: center;
      }

      .iptRow {
        display: flex;
        flex-direction: row;
        width: 20vw;
        padding: 8px;

        .labelBlock {
          width: 80px;
          height: 30px;
          line-height: 30px;
          margin-right: 18px;
          text-align: right;
          font-weight: 700;

          input.iptCtrl {
            flex: 1 !important;
            font-size: 16px !important;
            letter-spacing: 2px !important;
            padding: 8px !important;
            color: #000 !important;
            border-radius: 50px !important;
          }
        }
      }
    }
  }

  .loginFooter {
    position: fixed;
    padding: 0;
    margin: 0;
    width: 100vw;
    height: 20px;
    line-height: 20px;
    bottom: 20%;
    text-align: center;
    font-size: 0.6rem;
    font-weight: 300;
    color: #888;
    z-index: 99999;
  }
}
</style>
