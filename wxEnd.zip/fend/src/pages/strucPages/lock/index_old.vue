<template>
	<div>锁屏</div>
</template>

<script>
export default {
  name: 'lock',
  components: {},
  computed: {},
  methods: {}
};
</script>
