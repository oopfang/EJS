<template>
	<ul class="fullPage">
    <li v-for="(item, index) in iconList" :key="index">
      <tIcon :icon="item" :size="24" :height="32"></tIcon>
      {{ item }}
    </li>
  </ul>
</template>

<script>
import iconList from '_static/js/tIconList';
import tIcon from '@/components/widge/tIcon';

export default {
  name: 'lock',
  components: {
    tIcon
  },
  data: function() {
    return {
      iconList
    };
  },
  methods: {}
};
</script>

<style lang="less" scoped>
  .fullPage {
    list-style: none;
    height: 99vh;
    overflow-y: auto;
    li {
      display: inline-block;
      width: 320px;
      height: 48px;
      line-height: 48px;
      padding: 8px;
      margin: 16px;
      border: 1px #888 solid;
    }
  }
</style>
