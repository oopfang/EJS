<template>
<basePage @eventSignout="signoutHandler" loop :maxBgCount="25">
  <div slot="chart0" class="rptBlock">
    <chartBar useDemo></chartBar>
  </div>
  <div slot="chart1" class="rptBlock">
    <chartLine useDemo></chartLine>
  </div>
  <div slot="chart2" class="rptBlock">
    <chartPie useDemo></chartPie>
  </div>
  <div slot="chart3" class="rptBlock">
    <chartRadar useDemo></chartRadar>
  </div>
</basePage>
</template>

<script>
import basePage from '@/components/layout/chartWall';
import chartBar from '@/components/charts/bar';
import chartLine from '@/components/charts/lineNormal';
import chartPie from '@/components/charts/pie';
// import chartPie from '@/components/charts/pieNormal';
import chartRadar from '@/components/charts/radar';
// import chartMap from '@/components/charts/mapChina';
import { mapGetters, mapMutations, mapActions } from 'vuex';

export default {
  name: '',
  components: {
    basePage,
    chartLine,
    chartPie,
    chartBar,
    chartRadar
  },
  computed: {
    ...mapGetters(['getUserInfo'])
  },
  data: function () {
    return {
      currDataLine: [],
      currDataPie: [],
      currDataBar: [],
      currDataMapChina: []
    };
  },
  methods: {
    ...mapMutations(['setBizDefine']),
    ...mapActions(['signOut']),
    // 退出时的清理
    clearFunc: function () {
      let _storeM = this.$store._mutations;
      for (let v of Object.keys(_storeM)) {
        if (v.startsWith('clearCache')) {
          _storeM[v][0]();
        }
      }
      this.setBizDefine({});
    },
    // 响应注销操作
    signoutHandler: function() {
      let x = {
        id: this.getUserInfo.id,
        code: this.getUserInfo.code,
        namezh: this.getUserInfo.namezh
      };
      this.signOut(x)
        .then(res => {
          global.tinfo('已退出登陆');
          this.$router.push({
            name: 'sign'
          });
        })
        .catch(err => {
          global.terr(err);
          this.$router.push({
            name: 'sign'
          });
        });
      this.clearFunc();
    }
  }
};
</script>

<style lang="less" scoped>
.rptBlock {
  height: 100%;
  width: 100%;
}
</style>
