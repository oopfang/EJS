<template>
  <div>职务设置</div>
</template>

<script>
  export default {
    name: 'duty',
    components: {},
    data: function() {
      return {
        id: 1
      };
    },
    computed: {},
    methods: {}
  };
</script>

<style lang="less" scoped>
</style>