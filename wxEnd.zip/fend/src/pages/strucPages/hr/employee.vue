<template>
<basePage>
  <Row :space="18" class="employeeWrapper">
    <input id="copyInput" v-model="copyStr" />
    <Col v-show="employeeList.length > 0" :width="6" class="panelLeft">
    <transition-group tag="ul" enter-active-class="animated bounceOutRight" leave-active-class="animated bounceOutLeft" mode="out-in" :duration="300">
      <li key="fliterItem">
        <p class="mostBlack">职员列表（在职：{{ employeeCount }}人）</p>
        <Tooltip content="支持中英文姓名、登陆账号、工号模糊匹配" style="width: 100%;">
          <input type="text" v-model="currFilterWord" placeholder="输入即筛选..." />
        </Tooltip>
      </li>
      <li v-for="item of getEmployeeList" :key="item.id" @click.prevent.stop="setCurrEmployee(item)">
        <div class="itemRow">
          <img :src="item.avatar" width="24px" height="24px" />
          <div class="flexSplit">
            <p>{{ item.namezh }}</p>
            <p>英文名：{{ item.name || '' }}</p>
          </div>
        </div>
      </li>
    </transition-group>
    </Col>
    <Col :width="employeeList.length > 0 ? 18 : 24" class="panelRight">
    <transition-group tag="div" enter-active-class="animated zoomIn" leave-active-class="animated zoomOut" mode="out-in">
      <div v-show="currEmployee.id > 0 && !showDetail" class="viewPanel viewPanelOffset" key="keyView">
        <div class="card" @mouseenter="inHover=true" @mouseleave="inHover=false">
          <p v-if="currEmployee.name" class="titleRow" @click.prevent.stop="clickCopy(currEmployee.name, '英文名')">{{ currEmployee.name }}</p>
          <p v-else class="titleRow" @click.prevent.stop="clickCopy(currEmployee.namezh, '姓名')">{{ currEmployee.namezh }}</p>
          <p v-if="currEmployee.name" @click.prevent.stop="clickCopy(currEmployee.namezh, '姓名')"><span class="mostBlack">姓名：</span>{{ currEmployee.namezh }}</p>
          <div class="quoteRow">
            <p>
              <tIcon icon="t-tag" color="#131138" bold></tIcon>&nbsp;&nbsp;
              <span class="mostBlacck">工号：</span>
              <span @click.prevent.stop="clickCopy(currEmployee.jobNo, '工号')">{{ currEmployee.jobNo }}</span>
              <span class="spaceSpan"></span>
              <tIcon icon="t-user-solid-circle" :color="currEmployee.gender ? '#131138' : '#DC78CF'" bold></tIcon>&nbsp;&nbsp;
              <span class="mostBlacck">性别：</span>
              <span>{{ currEmployee.gender }}</span>
            </p>
            <p>
              <tIcon icon="t-phone" color="#131138" bold></tIcon>&nbsp;&nbsp;
              <span class="mostBlacck">工作电话：</span>
              <span class="minWidth" @click.prevent.stop="clickCopy(currEmployee.phoneWork, '工作电话')">{{ currEmployee.phoneWork || '&nbsp;' }}</span>
              <span class="mostBlacck">私人电话：</span>
              <span class="minWidth" @click.prevent.stop="clickCopy(currEmployee.phonePrivate, '私人电话')">{{ currEmployee.phonePrivate || '&nbsp;' }}</span>
            </p>
            <p>
              <tIcon icon="t-envelope" color="#131138" bold></tIcon>&nbsp;&nbsp;
              <span class="mostBlacck">邮箱：</span>
              <span @click.prevent.stop="clickCopy(currEmployee.email, '邮箱')">{{ currEmployee.email || '&nbsp;' }}</span>
            </p>
            <p>
              <tIcon icon="t-home" color="#131138" bold></tIcon>&nbsp;&nbsp;<span class="mostBlacck">机构/岗位：</span><span>{{ currEmployee.phoneWork }}</span>
            </p>
            <p>
              <span class="orgTag" v-for="item of getCurrEmployeeOrgList" :key="item.id">
                {{ item.fullPath }}
                <a v-if="item.chargemanid === currEmployee.id" class="chargTag">[负责人]</a>
              </span>
            </p>
            <p>
              <tIcon icon="t-load-balancer" color="#131138" bold></tIcon>&nbsp;&nbsp;<span class="mostBlacck">所属渠道：</span>
            </p>
            <p>
              <span class="orgTag" v-for="item of getCurrEmployeeChannelList" :key="item.id">
                {{ item.fullPath }}
                <a v-if="item.chargemanid === currEmployee.id" class="chargTag">[负责人]</a>
              </span>
            </p>
          </div>
          <transition tag="div" enter-active-class="animated bounceInRight" leave-active-class="animated fadeOutRight">
            <div v-show="inHover" class="optCol">
              <p @click.prevent.stop="changeEmployeeInfo">管理</p>
              <p @click.prevent.stop="stopEmployeeInfo">停职</p>
              <p @click.prevent.stop="fireConfrim=true">解聘</p>
              <p @click.prevent.stop="createEmployee">添加</p>
            </div>
          </transition>
        </div>
      </div>
      <tPanel v-show="showDetail" :topSpace="8" showHeader key="keyPanel">
        <div slot="panelHeader">
          <span style="display: inline-block; min-width: 120px"></span>
          <groupCrud :options="crudBtnOption" :inEdit="inEdit" @btnAddEvent="createEmployee" @btnEditEvent="inEdit=true" @btnSaveEvent="onSave" @btnCancelEvent="onCancel"></groupCrud>&nbsp;&nbsp;&nbsp;&nbsp;
          <span class="flexSplit"></span>
          <span v-show="!inEdit" class="bizBtn" @click.prevent.stop="stopEmployeeInfo">停职</span>
          <span v-show="!inEdit" class="bizBtn" @click.prevent.stop="fireConfrim=true">解聘</span>
          <span v-show="!inEdit" class="closeBtn" @click.prevent.stop="showDetail=false">关闭</span>
        </div>
        <div class="resumeWrapper">
          <div class="leftCol">
            <div class="userHeader">
              <img :src="currEmployee.avatar" width="81" height="81" />
            </div>
            <!-- 基本信息 -->
            <p @click.prevent.stop="currStep=0"></p>
            <!-- 履历表
            <p @click.prevent.stop="currStep=1"></p>
            职业技能
            <p @click.prevent.stop="currStep=2"></p>
            奖项资历
            <p @click.prevent.stop="currStep=3"></p>
            培训记录
            <p @click.prevent.stop="currStep=4"></p>
            奖惩历史
            <p @click.prevent.stop="currStep=5"></p>
            考勤管理
            <p @click.prevent.stop="currStep=6"></p>
            岗位异动
            <p @click.prevent.stop="currStep=7"></p>
            薪资管理
            <p @click.prevent.stop="currStep=8"></p>
            合同管理
            <p @click.prevent.stop="currStep=9"></p>
            绩效评估
            <p @click.prevent.stop="currStep=10"></p>
            背景推荐
            <p @click.prevent.stop="currStep=11"></p> -->
          </div>
          <transition-group class="rightCol flexSplit" tag="div" enter-active-class="animated bounceInRight" leave-active-class="animated bounceOutRight" mode="out-in">
            <div class="infoPanel" v-show="currStep===0" key="info0">
              <Row :space="18">
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">姓名</span>
                  <input type="text" v-model="getEmployeeNamezh" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.namezh, '姓名')"><span class="mostBlack">姓名：</span>{{ currEmployee.namezh }}</p>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">英文名称</span>
                  <input type="text" v-model="currEmployee.name" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.name, '英文姓名')"><span class="mostBlack">英文名称：</span>{{ currEmployee.name }}</p>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">登陆账号</span>
                  <input type="text" v-model="currEmployee.code" :disabled="!isNew" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.code, '登陆账号')"><span class="mostBlack">登陆账号：</span>{{ currEmployee.code }}</p>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">工号</span>
                  <input type="text" v-model="currEmployee.jobNo" placeholder="若未提供，则由系统自动创建" :disabled="!isNew" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.jobNo, '工号')"><span class="mostBlack">工号：</span>{{ currEmployee.jobNo }}</p>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">性别</span>
                  <Select v-model="currEmployee.gender" :datas="$root.$data._dict.gender" :nullOption="false"></Select>
                </div>
                <p v-show="!inEdit && !isNew"><span class="mostBlack">性别：</span>{{ currEmployee.gender }}</p>
                </Col>
                <Col :width="8">
                <div class="h-input-group" style="visibility: hidden;">
                  <span class="h-input-addon"></span>
                </div>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">工作电话</span>
                  <input type="text" v-model="currEmployee.phoneWork" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.phoneWork, '工作电话')"><span class="mostBlack">工作电话：</span>{{ currEmployee.phoneWork }}</p>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">私人电话</span>
                  <input type="text" v-model="currEmployee.phonePrivate" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.phonePrivate, '私人电话')"><span class="mostBlack">私人电话：</span>{{ currEmployee.phonePrivate }}</p>
                </Col>
                <Col :width="8">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">邮箱</span>
                  <input type="text" v-model="currEmployee.email" />
                </div>
                <p v-show="!inEdit && !isNew" @click.prevent.stop="clickCopy(currEmployee.email, '邮箱')"><span class="mostBlack">邮箱：</span>{{ currEmployee.email }}</p>
                </Col>
                <Col :width="12" class="orgPanel">
                <p class="mostBlack infoTitle">所属组织/岗位：</p>
                <ul>
                  <li v-for="(item, index) of getCurrEmployeeOrgList" :key="index">
                    <span class="flexSplit">{{ item.fullPath }}</span>
                    <span v-show="item.incharge" class="inChargeStle" :class="{ editAbleHover: inEdit || isNew }" @click.prevent.stop="setInChargeOrg(index, false)">
                      负责人&nbsp;
                    </span>
                    <tIcon v-show="item.incharge" icon="t-checkmark" color="green" :size="12" :height="24"></tIcon>
                    <div v-show="inEdit || isNew" class="orgFunc">
                      <span v-show="!item.incharge" class="h-tag h-tag-bg-primary" @click.prevent.stop="setInChargeOrg(index, true)">设为负责人</span>
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      <span @click.prevent.stop="delOrgItem(index)">
                        <tIcon icon="h-icon-close"></tIcon>
                      </span>
                    </div>
                  </li>
                  <li v-show="inEdit || isNew">
                    <span>点击右边添加&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <span class="flexSplit">
                      <Category v-model="getCurrEmployeeOrgList" multiple :option="categoryOptOrg" type="list" @change="addOrgItem"></Category>
                    </span>
                  </li>
                </ul>
                </Col>
                <Col :width="12" class="orgPanel">
                <p class="mostBlack infoTitle">所属渠道：</p>
                <ul>
                  <li v-for="(item, index) of currEmployee.channelList" :key="index">
                    <span class="flexSplit">{{ item.fullPath }}</span>
                    <span v-show="item.incharge" class="inChargeStle" :class="{ editAbleHover: inEdit || isNew }" @click.prevent.stop="setInChargeChannel(index, false)">
                      负责人&nbsp;
                    </span>
                    <tIcon v-show="item.incharge" icon="t-checkmark" color="green" :size="12" :height="24"></tIcon>
                    <div v-show="inEdit || isNew" class="orgFunc">
                      <span v-show="!item.incharge" class="h-tag h-tag-bg-primary" @click.prevent.stop="setInChargeChannel(index, true)">设为负责人</span>
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      <span @click.prevent.stop="delChannelItem(index)">
                        <tIcon icon="h-icon-close"></tIcon>
                      </span>
                    </div>
                  </li>
                  <li v-show="inEdit || isNew">
                    <span>点击右边添加&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <span class="flexSplit">
                      <Category v-model="getCurrEmployeeChannelList" multiple :option="categoryOptChannel" type="list" @change="addChannelItem"></Category>
                    </span>
                  </li>
                </ul>
                </Col>
              </Row>
            </div>
            <div class="infoPanel limitRight" v-show="currStep>0" key="info1">
            </div>
          </transition-group>
        </div>
      </tPanel>
      <p v-show="!currEmployee.id || (currEmployee.id === -1 && !showDetail)" class="newEmployeeZone" key="keyBtn"><span @click.prevent.stop="createEmployee"></span></p>
    </transition-group>
    <Modal v-model="fireConfrim" middle>
      <div slot="header">是否确认解聘雇员：<span class="h-tag h-tag-bg-primary">{{ currEmployee.namezh }}</span></div>
      <div>
        <p>解聘后，该雇员的账号在《职员管理》中不再出现，但仍保留在人力资源池中</p>
        <p>同时，该操作意味着该雇员信息的以下变化：</p>
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1、系统登陆权限被清除;</p>
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2、不再从属任何授权角色，意味着没有任何业务权限;</p>
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3、不再属于任何机构和渠道;</p>
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4、不再担任任何机构/渠道的负责人(如果以前是的话);</p>
      </div>
      <div slot="footer">
        <button class="h-btn h-btn-primary" @click="delEmployeeInfo">确定</button>
        <button class="h-btn" @click="fireConfrim=false">取消</button>
      </div>
    </Modal>
    </Col>
  </Row>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import tPanel from '@/components/wrapper/part/tPanel';
import groupCrud from '@/components/widge/bizCtrls/groupCrud';
import tIcon from '@/components/widge/tIcon';
import urlConfig from '@/config/config.json';
import tString from 'tframe-string/preString';
import {
  mapActions
} from 'vuex';
let emptyEmployee = () => {
  return {
    id: -1,
    pid: -1,
    code: '',
    name: '',
    namezh: '',
    gender: '1',
    phoneWork: '',
    phonePrivate: '',
    email: '',
    orgList: [],
    channelList: []
  };
};
let phoneNoFmt = num => {
  return num ? `${num.slice(0, 3)}-${num.slice(3, 7)}-${num.slice(7, num.length)}` : '';
};
let autoCode = val => {
  let _str = (tString.cn2Py(val));
  if (_str.length > 20) {
    return _str.slice(0, 20);
  } else {
    return _str;
  }
};
// 单词首字母大写
let titleCase = str => {
  return str.replace(/( |^)[a-z]/g, (L) => L.toUpperCase());
};

export default {
  name: 'employee',
  components: {
    basePage,
    tPanel,
    groupCrud,
    tIcon
  },
  data: function () {
    return {
      // 用于拷贝的变量
      copyStr: '',
      // 雇员列表
      employeeList: [],
      // 员工人数统计
      employeeCount: 0,
      // 机构列表
      orgList: [],
      // 机构速查表
      orgFlat: {},
      // 渠道速查表
      channelFlat: {},
      // 职员筛选关键词
      currFilterWord: '',
      // 当前选择的职员
      currEmployee: {},
      // 是否显示雇员信息详情
      showDetail: false,
      // 是否处于新增状态
      isNew: false,
      // 解聘雇员前的弹窗状态
      fireConfrim: false,
      // 当前显示的子面板索引
      currStep: 0,
      // 是否处于编辑状态
      inEdit: false,
      // 是否处于卡片hover状态
      inHover: false,
      // CRUD按钮组配置参数
      crudBtnOption: {
        hiddenCopy: true,
        hiddenDel: true
      },
      // 用户头像前缀地址
      baseUrl: urlConfig.ImgBaseUrl,
      // 机构选择面板配置参数
      categoryOptOrg: {
        keyName: 'id',
        parentName: 'pid',
        titleName: 'namezh',
        dataMode: 'list',
        datas: []
      },
      // 渠道选择面板配置参数
      categoryOptChannel: {
        keyName: 'id',
        parentName: 'pid',
        titleName: 'namezh',
        dataMode: 'list',
        datas: []
      }
    };
  },
  computed: {
    // 获取职员列表信息的动态加载
    getEmployeeList: function () {
      let _fw = this.currFilterWord;
      if (_fw) {
        return this.employeeList.filter(v => {
          return v.code.includes(_fw) || (v.name && v.name.includes(_fw)) || (v.namezh && v.namezh.includes(_fw)) || (v.jobNo && v.jobNo.includes(_fw));
        });
      } else {
        return this.employeeList;
      }
    },
    // 新建模式下绑定的雇员姓名
    getEmployeeNamezh: {
      get() {
        return this.currEmployee.namezh;
      },
      set(val) {
        if (this.isNew) {
          let _word = autoCode(val);
          this.currEmployee.code = _word;
          this.currEmployee.name = titleCase(_word).substr(0, 20);
        }
        this.currEmployee.namezh = val;
      }
    },
    getCurrEmployeeOrgList: {
      get() {
        let _that = this;
        return (this.currEmployee.orgList || []).filter(v => {
          return v && v.id && _that.categoryOptOrg.datas && _that.categoryOptOrg.datas.length > 0;
        });
      },
      set(val) {
        this.$set(this.currEmployee, 'orgList', val);
      }
    },
    getCurrEmployeeChannelList: {
      get() {
        let _that = this;
        return (this.currEmployee.channelList || []).filter(v => {
          return v && v.id && _that.categoryOptChannel.datas && _that.categoryOptChannel.datas.length > 0;
        });
      },
      set(val) {
        this.$set(this.currEmployee, 'channelList', val);
      }
    }
  },
  methods: {
    ...mapActions(['queryEmployee', 'addEmployee', 'editEmployee', 'stopEmployee', 'delEmployee']),
    // 设为当前雇员
    setCurrEmployee(item) {
      this.currEmployee = item;
      this.showDetail = false;
      this.isNew = false;
      this.inEdit = false;
      this.currStep = 0;
      this.$root.eventHub.$emit('gotop');
      setTimeout(() => {
        this.inHover = true;
      }, 500);
    },
    // 创建雇员
    createEmployee() {
      this.inEdit = true;
      this.isNew = true;
      this.showDetail = true;
      this.currEmployee = emptyEmployee();
      this.currEmployee.avatar = `/static/img/userHeader${this.currEmployee.gender|| 0}.png?v=8.0`;
    },
    // 修改雇员资料
    changeEmployeeInfo() {
      // this.inEdit = true;
      this.showDetail = true;
    },
    // 清除编辑状态
    clearState() {
      this.inEdit = false;
      this.isNew = false;
      this.showDetail = this.currEmployee.id && this.currEmployee.id > 0;
      this.currStep = 0;
    },
    // 对当前雇员的所选组织设为负责人
    setInChargeOrg(idx, tag) {
      if (this.inEdit || this.isNew) {
        let _item = this.getCurrEmployeeOrgList[idx];
        _item.incharge = tag;
        this.$set(this.currEmployee.orgList, idx, _item);
      }
    },
    // 对当前雇员的所选渠道设为负责人
    setInChargeChannel(idx, tag) {
      if (this.inEdit || this.isNew) {
        let _item = this.currEmployee.channelList[idx];
        _item.incharge = tag;
        this.$set(this.currEmployee.channelList, idx, _item);
      }
    },
    // 对当前雇员添加组织项
    addOrgItem(obj) {
      for (let v of obj) {
        let _obj = v.value;
        let _objIn = this.getCurrEmployeeOrgList.find(vf => vf.id === _obj.id);
        if (!_objIn) {
          this.currEmployee.orgList.push({
            id: _obj.id,
            pid: _obj.pid,
            namezh: _obj.namezh,
            fullPath: _obj.fullPath,
            incharge: false
          });
        }
      }
    },
    // 对当前雇员添加渠道项
    addChannelItem(obj) {
      for (let v of obj) {
        let _obj = v.value;
        let _objIn = this.currEmployee.channelList.find(vf => vf.id === _obj.id);
        if (!_objIn) {
          this.currEmployee.channelList.push({
            id: _obj.id,
            pid: _obj.pid,
            namezh: _obj.namezh,
            fullPath: _obj.fullPath,
            incharge: false
          });
        }
      }
    },
    // 删除当前雇员的所选组织项
    delOrgItem(idx) {
      this.currEmployee.orgList.splice(idx, 1);
    },
    // 删除当前雇员的所选渠道项
    delChannelItem(idx) {
      this.currEmployee.channelList.splice(idx, 1);
    },
    onSave() {
      let _msg = {
        code: '必须为员工提供登陆账号',
        namezh: '姓名必填',
        org: '必须为员工指定所属组织'
      };
      if (!this.currEmployee.namezh) {
        global.terr(_msg.namezh);
      } else if (!this.currEmployee.code) {
        global.terr(_msg.code);
      } else if (this.currEmployee.orgList.length === 0) {
        global.terr(_msg.org);
      } else {
        let _func = this.isNew ? this.addEmployee : this.editEmployee;
        let { id, pid, code, name, namezh, gender, avatar, phoneWork, phonePrivate, email } = this.currEmployee;
        let x = { id, pid, code, name, namezh, avatar, phoneWork, phonePrivate, email };
        x.genderVal = gender || 0;
        x.orgs = this.currEmployee.orgList.map(v => {
          return {
            id: v.id,
            incharge: v.incharge
          };
        });
        x.channel = this.currEmployee.channelList.map(v => {
          return {
            id: v.id,
            incharge: v.incharge
          };
        });
        _func(x)
          .then(res => {
            if (this.isNew) {
              this.employeeList.push(this.initEmployee(res));
            } else {
              let _idx = this.employeeList.findIndex(v => v.id === res.id);
              this.$set(this.employeeList, _idx, res);
            }
            this.clearState();
          })
          .catch(err => {
            global.terr(err);
            this.clearState();
          });
      }
    },
    onCancel() {
      this.clearState();
    },
    // 对雇员停职
    stopEmployeeInfo() {
      let _idx = this.employeeList.findIndex(v => v.id === this.currEmployee.id);
      this.stopEmployee({
          id: this.currEmployee.id
        })
        .then(res => {
          let _curr = this.employeeList[_idx];
          _curr.stopped = 1;
          this.$set(this.employeeList, _idx, _curr);
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 解聘雇员
    delEmployeeInfo() {
      let _curr = this.currEmployee;
      let _idx = this.employeeList.findIndex(v => v.id === _curr.id);
      this.delEmployee({
          id: _curr.id
        })
        .then(res => {
          this.employeeList.splice(_idx, 1);
          if (this.employeeList.length > 0) {
            this.currEmployee = this.employeeList[0];
          } else {
            this.currEmployee = emptyEmployee();
          }
          this.fireConfrim = false;
          this.isNew = false;
          this.inEdit = false;
          this.showDetail = false;
        })
        .catch(err => {
          this.fireConfrim = false;
          global.terr(err);
        });
    },
    // 复制到剪贴板
    clickCopy(txt, type) {
      if (txt) {
        let _setVal = val => {
          let _val = val.replace(/-/g, '').replace(/\s+/g, '');
          this.copyStr = _val;
          let ipt = document.getElementById('copyInput');
          ipt.value = _val;
          ipt.select();
          document.execCommand('copy');
          this.$Message(`${type}  ${_val}  已复制到剪贴板`);
        };
        _setVal(txt);
      }
    },
    initEmployee(item) {
      // item.avatar = `${this.baseUrl}img/${item.avatar}.jpg`;
      item.avatar = `/static/img/userHeader${item.gender || 0}.png?v=8.0`;
      item.phonePrivate = phoneNoFmt(item.phonePrivate);
      item.orgList = [];
      let _that = this;
      if (item.oid) {
        item.oid.split(',').forEach(vO => {
          let _orgItem = JSON.parse(JSON.stringify(_that.orgFlat[`o${vO}`]));
          _orgItem.incharge = (`${_orgItem.chargemanid}` === `${item.id}`);
          item.orgList.push(_orgItem);
        });
      }
      item.channelList = [];
      if (item.cid) {
        item.cid.split(',').forEach(vC => {
          let _channelItem = JSON.parse(JSON.stringify(_that.channelFlat[`c${vC}`]));
          _channelItem.incharge = (`${_channelItem.chargemanid}` === `${item.id}`);
          item.channelList.push(_channelItem);
        });
      }
      return item;
    }
  },
  mounted() {
    let _that = this;
    this.queryEmployee()
      .then(res => {
        for (let v of res.orgList) {
          _that.orgFlat[`o${v.id}`] = v;
        }
        for (let v of res.channelList) {
          _that.channelFlat[`c${v.id}`] = v;
        }
        _that.employeeCount = res.employeeList.length;
        _that.employeeList = res.employeeList.map(v => {
          return _that.initEmployee(v);
        });
        _that.orgList = res.orgList;
        _that.channelList = res.channelList;
        _that.$set(_that.categoryOptOrg, 'datas', res.orgList);
        _that.$set(_that.categoryOptChannel, 'datas', res.channelList);
      })
      .catch(err => {
        global.terr(err);
      });
  }
};
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';

#copyInput {
  position: absolute;
  top: -100px;
}

.employeeWrapper {
  .panelLeft {
    padding: 0 8px;

    li {
      padding: 8px;
      margin: 8px;
      background-color: #fff;
      cursor: pointer;

      .itemRow {
        display: flex;
        align-items: center;

        img {
          margin: 0 8px;
          border-radius: 50%;
        }
      }

      &:hover {
        background-color: @second-color;
      }

      &:first-child {
        text-align: center;

        .h-tooltip-show {
          input {
            width: 80%;
            margin: 8px 16px;
          }
        }
      }
    }
  }

  .panelRight {
    position: relative;

    .viewPanel {
      position: absolute;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;

      .card {
        position: relative;
        width: 654px;
        height: 400px;
        padding: 32px;
        background-image: url('../../../../static/img/code.png');
        background-repeat: repeat;
        border-radius: 10px;
        box-shadow: 5px 5px 110px rgba(0, 0, 0, 0.3);
        transition: .2s;

        .titleRow {
          font-size: 2rem;
          color: #757575;
        }

        .quoteRow {
          display: flex;
          flex-direction: column;
          padding-left: 18px;
          margin-top: 24px;
          border-left: 2px #D3D3D3 solid;

          .spaceSpan {
            display: inline-block;
            min-width: 62px;
          }

          .minWidth {
            display: inline-block;
            min-width: 130px;
          }

          .orgTag {
            padding: 0;
            height: 48px;
            line-height: 48px;
            margin: 0 16px;
            color: #4e4f74;
            background: #cfcfdd;

            .chargTag {
              padding: 1px 8px;
              margin-left: 8px;
              font-size: 4px;
              color: #fff;
              background-color: #333366;
            }
          }
        }

        .optCol {
          position: absolute;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: 128px;
          height: 100%;
          right: 0;
          top: 0;
          color: #fff;
          border-top-right-radius: 10px;
          border-bottom-right-radius: 10px;
          background-color: rgba(0, 0, 0, 0.6);

          p {
            width: 100%;
            padding: 18px 0;
            text-align: center;
            cursor: pointer;

            &:hover {
              background-color: rgba(34, 32, 32, 0.6);
            }
          }
        }
      }
    }

    .viewPanelOffset {
      margin-top: 5%;
      margin-left: 5%;
    }

    @media (min-width: 1800px) {
      .viewPanelOffset {
        margin-top: 20%;
        margin-left: 20%;
      }
    }

    @media (min-width: 1200px) and (max-width: 1800px) {
      .viewPanelOffset {
        margin-top: 10%;
        margin-left: 10%;
      }
    }

    @media (min-width: 992px) and (max-width: 1200px) {
      .viewPanelOffset {
        margin-top: 5%;
        margin-left: 5%;
      }
    }

    @media (min-width: 768px) and (max-width: 992px) {
      .viewPanelOffset {
        margin-top: 5%;
        margin-left: 5%;
      }
    }

    .newEmployeeZone {
      width: 100%;
      height: 80vh;
      line-height: 80vh;
      text-align: center;

      span {
        padding: 25px 30px;
        border: 1px #ccc dashed;
        cursor: pointer;
        transition: all .2s ease-in-out;

        &::before {
          content: '添加职员';
          font-weight: 700;
        }

        &:hover {
          box-shadow: 0 1px 6px rgba(0, 0, 0, .2);
          border-color: #eee;
        }
      }
    }

    .resumeWrapper {
      display: flex;
      height: 50vh;

      .leftCol {
        width: 84px;
        padding: 0;
        border-right: 1px #ccc solid;

        .userHeader {
          position: relative;
          top: -50px;
          left: -16px;
          padding: 8px;
          margin-bottom: 60px;
          border: 1px #ccc solid;
          width: 100px;
          background-color: #fff;
        }

        p {
          padding: 8px;
          text-align: right;
          border-bottom: 1px #ccc solid;
          cursor: pointer;

          &:hover {
            background-color: @second-color;
          }

          &:nth-child(2) {
            margin-top: -100px;
          }

          &:nth-child(2)::before {
            content: '基本信息'
          }

          &:nth-child(3)::before {
            content: '履历表'
          }

          &:nth-child(4)::before {
            content: '职业技能'
          }

          &:nth-child(5)::before {
            content: '奖项资历'
          }

          &:nth-child(6)::before {
            content: '培训记录'
          }

          &:nth-child(7)::before {
            content: '奖惩历史'
          }

          &:nth-child(8)::before {
            content: '考勤管理'
          }

          &:nth-child(9)::before {
            content: '岗位异动'
          }

          &:nth-child(10)::before {
            content: '薪资管理'
          }

          &:nth-child(11)::before {
            content: '合同管理'
          }

          &:nth-child(12)::before {
            content: '绩效评估'
          }

          &:nth-child(13)::before {
            content: '背景推荐'
          }
        }
      }

      .rightCol {
        position: relative;

        .infoPanel {
          position: absolute;
          width: 100%;
          height: 100%;
          padding: 34px;

          .orgPanel {
            .infoTitle {
              padding: 8px;
              text-align: center;
              background-color: #f2f2f2;
            }

            ul {
              li {
                display: flex;
                min-height: 30px;
                flex-direction: row;
                justify-content: center;
                align-items: center;
                border-bottom: 1px #f2f2f2 dashed;

                &:not(:last-child) {
                  margin-top: 8px;

                  .orgFunc {
                    visibility: hidden;

                    span {
                      cursor: pointer;

                      &:last-child {
                        padding: 8px;
                      }
                    }
                  }

                  &:hover {
                    background-color: @second-color;

                    .orgFunc {
                      visibility: visible;

                      span:last-child {
                        color: #fff;
                        background-color: orangered;
                      }
                    }
                  }
                }

                &:last-child {
                  padding: 8px 0;
                }

                .inChargeStle {
                  cursor: pointer;

                }

                .editAbleHover {
                  &:hover::before {
                    content: '取消';
                  }
                }
              }
            }
          }
        }

        .limitRight {
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;
          width: 100%;
          height: 100%;
          line-height: 100%;
          margin-left: 18px;
          background-color: rgba(0, 0, 0, 0.6);

          &::before {
            position: absolute;
            padding: 36px;
            content: '基础人事版不提供此功能';
            font-size: 1.2rem;
            font-weight: 700;
            // border: 2px #444 dashed;
            color: #aaa;
            background-color: #fff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, .1);
          }
        }
      }
    }
  }
}
</style>
