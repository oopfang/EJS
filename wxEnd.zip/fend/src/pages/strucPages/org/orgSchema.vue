<template>
<basePage style="padding: 0;">
  <tPanel showHeader>
    <div slot="panelHeader">
      <span class="headerTop flexSplit"></span>
      <span class="closeBtn" @click.prevent.stop="close">关闭</span>
    </div>
    <div v-if="currOrgObj && currOrgObj.id" class="baseWrapper">
      <div class="leftList">
        <treeList ref="leftTree" :treeListData="currOrgObj" :callBackVal="callBackVal" @refreshData="getInit" @setCurrNode="setCurrNode" @setNewNode="setNewNode" @clearCallBack="callBackVal={}" @changeName="changeName" @revokOrg="confirmStop"></treeList>
        <Modal v-model="inNewOrg" :middle="true">
          <div slot="header"><span class="h-tag h-tag-bg-gray">{{ inChange ? '修改' : '新建' }}组织节点</span></div>
          <Row :space="18">
            <Col :width="4">组织名称：</Col>
            <Col :width="20"><input class="newOrgItem" type="text" v-model="currNewNamezh" placeholder="请输入组织名称" /></Col>
            <Col :width="4">组织代码：</Col>
            <Col :width="20"><input class="newOrgItem" type="text" v-model="newCode" placeholder="请为组织建立代码" /></Col>
            <Col :width="4">备注：</Col>
            <Col :width="20"><textarea class="newOrgItem" v-model="newMemo" rows=4 placeholder="请输入描述信息"></textarea></Col>
          </Row>
          <div slot="footer">
            <Button color="primary" @click="saveNew">保存</Button>
            <Button :text="true" @click="cancelNew">取消</Button>
          </div>
        </Modal>
        <Modal v-model="inStopConfirm" :middle="true">
          <div slot="header">
            <tIcon icon="t-exclamation-solid" color="red"></tIcon>&nbsp;&nbsp;警告！ / 须知
          </div>
          <div>
            <p>注销该节点，同时也会注销该节点的所有下级节点</p>
            <p>要避免该情况，请先将不属于注销范围的下级节点移动到注销范围之外。</p>
            <br />
            <p>该节点注销后，属于该节点（及其子节点）的所有员工会被默认禁用，需要手工调整</p>
            <p>同时这些员工之前的权限会被清空，需要重新分配。</p>
          </div>
          <div slot="footer">
            <Button color="primary" @click="execOrgStop">确认</Button>
            <Button class="h-btn" @click="inStopConfirm=false">取消</Button>
          </div>
        </Modal>
      </div>
      <transition-group class="rightPanel flexSplit" tag="div" enter-active-class="animated zoomInDown" leave-active-class="animated zoomOutRight" mode="out-in">
        <treeChart v-show="userTobe.length === 0" ref="treeChart" :treeData="currOrgObj" key="rightPane3"></treeChart>
        <ul v-show="userTobe.length > 0" class="tipRow" key="rightPane1">
          <li></li>
          <li></li>
          <li></li>
        </ul>
        <p class="finishZone" v-show="getUserChageOk" key="changeOk">
          <span @click.prevent.stop="setUserFinish"></span>
        </p>
        <p v-show="userTobe.length > 0 && currNodeInfo.namezh && !getUserChageOk" key="rightPane2">&nbsp;&nbsp;&nbsp;&nbsp;
          <Button color="primary" @click="setUserAll">全部转入&nbsp;&nbsp;{{ currNodeInfo.namezh }}</Button>
        </p>
        <transition-group v-show="userTobe.length > 0" class="userContaint" tag="ul" key="rightPane4" enter-active-class="animated bounceOutRight" leave-active-class="animated bounceOutLeft" mode="out-in" :duration="260">
          <li v-show="item.newOrgId === -1" v-for="item of userTobe" :key="item.id">
            <img :src="getAvatar(item.avatar)" width="24px" height="24px" />{{ item.namezh }}
            <Row class="flexSplit">
              <Col :width="12" class="oldOrgTitle">[原属组织]：</Col>
              <Col :width="12" class="oldOrgBody">
              <span v-for="itemOrg of item.oldOrg" :key="itemOrg.oid">{{ itemOrg.fullPath }}</span>
              </Col>
            </Row>
            <Button v-show="currNodeInfo.namezh" color="primary" @click="setUser(item)">转入&nbsp;&nbsp;{{ currNodeInfo.namezh }}</Button>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <Button color="red">解聘通知</Button>
          </li>
        </transition-group>
      </transition-group>
    </div>
  </tPanel>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import tIcon from '@/components/widge/tIcon';
import treeList from '@/components/widge/treeList';
import tPanel from '@/components/wrapper/part/tPanel';
import treeChart from '@/components/layout/orgTree';
import tString from 'tframe-string/preString';
import urlConfig from '@/config/config.json';
import {
  mapActions
} from 'vuex';

export default {
  name: 'orgSchema',
  components: {
    basePage,
    tIcon,
    treeChart,
    treeList,
    tPanel
  },
  data: function () {
    return {
      currOrgObj: {},
      // 当前选中的节点信息
      currNodeInfo: {},
      // 是否打开新建节点弹窗
      inNewOrg: false,
      // 是否处于节点修改状态
      inChange: false,
      // 新建组织节点的名称
      newNamezh: '',
      // 新建组织节点的代码
      newCode: '',
      // 新建组织节点的备注
      newMemo: '',
      // 组件传入的新建参数
      newParam: [1, -1],
      // 新建节点的回调值
      callBackVal: null,
      // 是否打开节点注销确认面板
      inStopConfirm: false,
      // 待注销的节点ID
      orgTobeStop: {
        id: -1,
        pid: -1
      },
      // 组织节点注销后待处理的员工列表
      userTobe: [],
      // 用户头像前缀地址
      baseUrl: urlConfig.ImgBaseUrl
    };
  },
  computed: {
    currNewNamezh: {
      get() {
        return this.newNamezh;
      },
      set(val) {
        this.newCode = tString.cn2Py(val, true).slice(0, 20);
        this.newNamezh = val;
      }
    },
    // 获取是否已经完成组织注销后的用户迁移操作的标志
    getUserChageOk: function () {
      let _b = this.userTobe.length > 0 && true;
      for (let v of this.userTobe) {
        if (v.newOrgId === -1) {
          _b = false;
          break;
        }
      }
      return _b;
    }
  },
  methods: {
    ...mapActions(['queryOrgs', 'resetOrgs', 'setNewOrgs', 'stopOrg', 'resetUserOgr', 'changeOrgsInfo']),
    // 获取初始化数据
    getInit(queryOption) {
      let _func = queryOption ? this.resetOrgs : this.queryOrgs;
      let refreshFunc = () => {
        this.$refs.treeChart.refresh();
      };
      if (queryOption) {
        queryOption.forEach((v, k, arr) => {
          if (!v.orderIndex) {
            v.orderIndex = k;
          }
        });
      }
      _func(queryOption || {})
        .then(res => {
          this.currOrgObj = res;
          refreshFunc();
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 获取用户头像地址
    getAvatar: function (avatar) {
      return `${this.baseUrl}img/${avatar}_lite.jpg`;
    },
    // 响应当前节点的设置事件
    setCurrNode(e) {
      this.currNodeInfo = e;
    },
    // 响应创建新节点的事件
    setNewNode(e) {
      this.newParam = e;
      this.inNewOrg = true;
    },
    // 保存组织节点的新建
    saveNew() {
      if (this.inChange) {
        let x = {
          id: this.currNodeInfo.id,
          code: this.newCode,
          namezh: this.newNamezh,
          memo: this.newMemo
        };
        let _elm = this.$refs.leftTree;
        this.changeOrgsInfo(x)
          .then(res => {
            _elm.reSetNode({
              code: this.newCode,
              namezh: this.newNamezh,
              memo: this.newMemo
            });
            this.newNamezh = '';
            this.newCode = '';
            this.newMemo = '';
            this.inChange = false;
            this.inNewOrg = false;
          })
          .catch(err => {
            global.terr(err);
          });
      } else {
        let x = {
          pid: this.newParam[0],
          code: this.newCode,
          namezh: this.newNamezh,
          organtypeid: 1,
          chargemanid: 1,
          memo: this.newMemo,
          subCount: this.newParam[1]
        };
        let _clearCache = (id) => {
          if (id) {
            x.id = id;
            x.children = [];
          }
          this.currNewNamezh = '';
          this.newMemo = '';
          this.newParam = [1, -1];
          this.inNewOrg = false;
          this.callBackVal = x;
        };
        this.setNewOrgs(x)
          .then(res => {
            _clearCache(res);
          })
          .catch(err => {
            global.terr(err);
            _clearCache(false);
          });
      }
    },
    // 取消组织节点的新建
    cancelNew() {
      this.newNamezh = '';
      this.newCode = '';
      this.newMemo = '';
      this.newNodeParam = {};
      this.inNewOrg = false;
    },
    // 修改组织节点名称
    changeName(e) {
      this.currNodeInfo = e;
      this.inChange = true;
      this.newNamezh = e.namezh;
      this.newCode = e.code;
      this.newMemo = e.memo;
      this.inNewOrg = true;
    },
    // 注销弹窗确认
    confirmStop(e) {
      if (this.currOrgObj.children.length > 1) {
        this.orgTobeStop = e;
        this.inStopConfirm = true;
      } else {
        global.twarn('不能删除唯一机构！');
      }
    },
    // 取消注销操作
    cancelStop() {
      this.orgTobeStop = {
        id: -1,
        pid: -1
      };
      this.inStopConfirm = false;
    },
    // 注销指定机构
    execOrgStop() {
      let refresh = (org, users) => {
        this.currOrgObj = org;
        this.userTobe = users;
        this.currNodeInfo = {};
        this.cancelStop();
      };
      this.stopOrg(this.orgTobeStop)
        .then(res => {
          refresh(res.newOrg, res.userSet);
        })
        .catch(err => {
          this.inStopConfirm = false;
          global.terr(err);
        });
    },
    // 机构注销后迁移用户
    setUser(item) {
      if (this.currNodeInfo.id) {
        item.newOrgId = this.currNodeInfo.id;
      }
    },
    // 全部迁移到指定机构
    setUserAll() {
      for (let v of this.userTobe) {
        if (v.newOrgId === -1) {
          v.newOrgId = this.currNodeInfo.id;
        }
      }
    },
    // 完成机构注销后的用户迁移操作
    setUserFinish() {
      let _arr = this.userTobe.map(v => {
        return {
          id: v.id,
          newOrgId: v.newOrgId
        };
      });
      this.resetUserOgr(_arr)
        .then(res => {
          this.userTobe = [];
        })
        .catch(err => {
          global.terr(err);
        });
    },
    close: function () {
      this.$router.push({
        name: 'home'
      });
    }
  },
  mounted() {
    this.$root.eventHub.$emit('switchMenu', false);
    this.getInit();
  },
  destroyed() {
    this.$root.eventHub.$emit('switchMenu', true);
  }
};
</script>

<style lang="less" scoped>
@import "~@/assets/less/index.less";
@leftWidth: 300px;
@topRowHeight: 40px;

.headerTop {
  height: @topRowHeight;
  line-height: @topRowHeight;
  text-align: right;
  border-bottom: 1px #ccc solid;

  &::before {
    position: relative;
    width: 40%;
    padding: 8px 36px;
    content: @orgName;
    font-size: 1rem;
    font-weight: 700;
    text-shadow: 2px 2px 8px #ccc;
  }
}

.baseWrapper {
  display: flex;

  .leftList {
    width: @leftWidth;
    background-color: @primary-color;
  }

  .rightPanel {
    min-height: 80vh;

    .tipRow {
      padding: 8px;
      text-align: center;

      li {
        &:nth-child(1) {
          &::before {
            content: '本页面仅显示一次';
            font-size: 1rem;
            font-weight: 700;
          }
        }

        &:nth-child(2) {
          &::before {
            content: '本页面仅显示一次';
            font-size: .8rem;
            font-weight: 400;
          }
        }

        &:nth-child(3) {
          &::before {
            content: '[操作]：请先选择目标组织，然后点击员工即可将该员工移入所选的组织';
            font-size: .8rem;
            font-weight: 100;
          }
        }
      }
    }

    .userContaint {
      li {
        display: flex;
        align-items: center;
        min-height: 48px;
        padding: 0;
        margin: 18px;
        background-color: #fff;
        cursor: pointer;

        &:hover {
          background-color: @second-color;
        }

        img {
          margin: 0 18px 0 8px;
          border-radius: 50%;
        }

        .oldOrgTitle {
          display: flex;
          justify-content: flex-end;
          align-items: center;
        }

        .oldOrgBody {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: flex-start;
        }
      }
    }

    .finishZone {
      height: 300px;
      line-height: 300px;
      text-align: center;
      background-color: transparent;
      cursor: default;

      span {
        padding: 25px 30px;
        border: 2px #ccc dashed;
        cursor: pointer;

        &::before {
          content: '点击完成';
          font-weight: 700;
        }

        &:hover {
          background-color: @second-color;
        }
      }
    }
  }
}

.newOrgItem {
  width: 100%;
}
</style>
