<template>
<basePage>
  <tPanel showHeader>
    <div slot="panelHeader">
      <groupCrud :options="getCrudBtnOpt" :inEdit="inEdit" @btnAddEvent="execAdd" @btnEditEvent="execEdit" @btnDelEvent="execDel" @btnSaveEvent="execSave" @btnCancelEvent="execCancel"></groupCrud>
      <span class="flexSplit"></span>
      <groupGeneral :options="generalBtnOption" :inEdit="inEdit"></groupGeneral>
    </div>
    <div class="infoWrapper">
      <div class="leftZone">
        <Menu :datas="channelArr" className="h-menu-custom" :option="menuOpt" v-width="250" @click="execClick"></Menu>
      </div>
      <div v-show="currNode.id" class="flexSplit rightZone">
        <div class="editCard">
          <tPanel showHeader bgColor="transparent">
            <div slot="panelHeader">
              <span class="rightTitle mostBlack">当前所属渠道：{{ currNode.namezh }}</span>
            </div>
            <div>
              <Row v-if="isNew || inEdit" :space="18">
                <Col :width="24" class="itemRow">
                <div v-show="inEdit || isNew" class="h-input-group">
                  <span class="h-input-addon mostBlack">渠道名称</span>
                  <input type="text" v-model="currNodeNew.namezh" />
                  </div>
                  </Col>
                  <Col :width="12" class="itemRow">
                  <div v-show="inEdit || isNew" class="h-input-group">
                    <span class="h-input-addon mostBlack">渠道代码</span>
                    <input type="text" v-model="currNodeNew.code" />
                  </div>
                    </Col>
                    <Col :width="12" class="itemRow handCursor" @click.native.stop="openUserSelect">
                    <div v-show="inEdit || isNew" class="h-input-group">
                      <span class="h-input-addon mostBlack">渠道负责人：{{ getUserName }}</span>
                    </div>
                    </Col>
                    <Col :width="24" class="itemRow">
                    <div v-show="inEdit || isNew" class="h-input-group">
                      <span class="h-input-addon mostBlack">上级渠道：{{ getPnode }}</span>
                    </div>
                    </Col>
              </Row>
              <Row v-else :space="18">
                <Col :width="24" class="itemRow">
                <p v-show="!inEdit && !isNew"><span class="mostBlack">渠道名称：</span>{{ currNode.namezh }}</p>
                </Col>
                <Col :width="24" class="itemRow">
                <p v-show="!inEdit && !isNew"><span class="mostBlack">渠道代码：</span>{{ currNode.code }}</p>
                </Col>
                <Col :width="24" class="itemRow">
                <p v-show="!inEdit && !isNew"><span class="mostBlack">渠道负责人：</span>{{ getUserName }}</p>
                </Col>
                <Col :width="24" class="itemRow">
                <p v-show="!inEdit && !isNew"><span class="mostBlack">上级渠道：</span>{{ getPnode }}</p>
                </Col>
              </Row>
            </div>
          </tPanel>
          <Modal v-model="inUserSelect" middle>
            <div slot="header">请选择负责人</div>
            <input type="text" v-model="currFilterWord" v-width="310"/>
            <ul class="userPanel">
              <li v-for="(itemUser, indexUser) of getUsers" :key="itemUser.id" @click.prevent.stop="selectCharge(itemUser.id)">{{ itemUser.namezh }}</li>
            </ul>
            <div slot="footer"><button class="h-btn" @click="inUserSelect=false">取消</button></div>
          </Modal>
        </div>
      </div>
    </div>
  </tPanel>

</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base';
import tPanel from '@/components/wrapper/part/tPanel';
import groupCrud from '@/components/widge/bizCtrls/groupCrud';
import groupGeneral from '@/components/widge/bizCtrls/groupGeneral';
import tString from 'tframe-string/preString';
import tEnum from 'tframe-enum';
import {
  mapActions
} from 'vuex';
let _getNewNode = () => {
  return {
    id: -1,
    pid: 1,
    code: '',
    namezh: '',
    chargemanid: -1,
    fullPath: ''
  };
};

export default {
  name: 'channel',
  components: {
    basePage,
    tPanel,
    groupCrud,
    groupGeneral
  },
  data: function () {
    return {
      // 渠道数据总树
      channelArr: [],
      // 渠道全集的扁平数据集
      channelFlat: {},
      // 职员列表
      users: [],
      // 当前负责人选择面板的已选项的ID
      currUserId: -1,
      // 当前选择的渠道节点
      currNode: {},
      // 当前新增的渠道对象
      currNodeNew: {},
      // 是否处于新增状态
      isNew: false,
      // 是否处于编辑状态
      inEdit: false,
      // 是否弹出用户选择面板
      inUserSelect: false,
      // 用户选择面板的过滤词
      currFilterWord: '',
      // 渠道树组件配置
      menuOpt: {
        titleName: 'namezh',
        keyName: 'id',
        childrenName: 'children'
      },
      // CRUD按钮组配置参数
      crudBtnOption: {
        hiddenCopy: true
      },
      // CRUD按钮组配置参数
      generalBtnOption: {
        hiddenHelp: true,
        hiddenIssue: true
      }
    };
  },
  computed: {
    // 获取CRUD按钮的配置参数
    getCrudBtnOpt() {
      this.$set(this.crudBtnOption, 'hiddenDel', (this.currNode.pid === -1));
      return this.crudBtnOption;
    },
    // 获取上级渠道对象
    getPnode() {
      let _obj = (this.isNew || this.inEdit) ? this.currNodeNew : this.currNode;
      if (_obj.pid === -1) {
        return '已经是顶级渠道';
      } else {
        let _objFlat = this.channelFlat[_obj.pid];
        if (_objFlat) {
          return _objFlat.fullPath;
        } else {
          return '';
        }
      }
    },
    // 获取筛选后的用户
    getUsers() {
      if (this.currFilterWord) {
        let _word = this.currFilterWord;
        return this.users.filter(v => {
          return v.code.includes(_word) || v.namezh.includes(_word);
        });
      } else {
        return this.users;
      }
    },
    getUserName() {
      let _idx = this.users.findIndex(v => {
        if (this.isNew || this.inEdit) {
          return this.currNodeNew.chargemanid === v.id;
        } else {
          return this.currNode.chargemanid === v.id;
        }
      });
      if (_idx > -1) {
        return this.users[_idx].namezh;
      } else {
        return (this.isNew || this.inEdit) ? '点击选择' : '未指定';
      }
    }
  },
  methods: {
    ...mapActions(['queryChannel', 'setNewChannel', 'changeChannelInfo', 'delChannel']),
    // 获取初始化数据
    getInit(queryOption) {
      this.queryChannel({})
        .then(res => {
          this.channelArr = [res.obj];
          this.channelFlat = res.objFlat;
          this.users = res.users;
          this.currNode = res.obj;
        })
        .catch(err => {
          global.terr(err);
        });
    },
    execClick(e) {
      if (this.isNew || this.inEdit) {
        this.currNodeNew.pid = e.value.id;
      } else {
        this.currNode = e.value;
      }
    },
    // 响应新增按钮点击
    execAdd() {
      this.currNodeNew = _getNewNode();
      this.currNodeNew.pid = [this.currNode.id];
      this.isNew = true;
      this.inEdit = true;
    },
    // 响应编辑按钮点击
    execEdit() {
      this.currNodeNew = JSON.parse(JSON.stringify(this.currNode));
      this.inEdit = true;
    },
    // 响应删除按钮点击
    execDel() {
      let x = {
        id: this.currNode.id
      };
      this.delChannel(x)
        .then(res => {
          this.channelArr = [res.obj];
          this.channelFlat = res.objFlat;
          this.currNode = res.obj;
        })
        .catch(err => {
          global.terr(err);
        });
    },
    // 打开负责人选择弹窗
    openUserSelect() {
      this.inUserSelect = true;
      this.currFilterWord = '';
    },
    // 选择负责人
    selectCharge(id) {
      this.currNodeNew.chargemanid = id;
      this.inUserSelect = false;
    },
    execSave() {
      let _func = this.isNew ? this.setNewChannel : this.changeChannelInfo;
      let {
        id,
        pid,
        code,
        namezh,
        chargemanid
      } = this.currNodeNew;
      namezh = namezh.replace(/\s+/g, '');
      let _allowSave = false;
      if (!code) {
        code = tString.cn2Py(namezh);
        let _info = tString.infoOfStr(code);
        if (_info === tEnum.sys.aboutStr.enOnly || _info === tEnum.sys.aboutStr.enOrNum) {
          _allowSave = true;
          if (code.length > 20) {
            code = code.slice(0, 20);
          }
        }
      } else {
        _allowSave = true;
      }
      if (_allowSave) {
        let x = {
          id,
          pid,
          code,
          namezh,
          chargemanid
        };
        x.fullPath = `${this.channelFlat[pid].fullPath} / ${namezh}`;
        _func(x)
          .then(res => {
            this.channelArr = [res.obj];
            this.channelFlat = res.objFlat;
            this.currNode = res.obj;
            if (this.isNew) {
              /* eslint-disable handle-callback-err */
              this.$Confirm('是否继续添加？', '请确认')
                .then(() => {
                  this.execAdd();
                })
                .catch(err => {
                  this.cancelAll();
                });
            } else {
              this.cancelAll();
            }
          })
          .catch(err => {
            global.terr(err);
            this.cancelAll();
          });
      } else {
        global.twarn('自动生成代码失败，请手工输入');
      }
    },
    execCancel() {
      this.cancelAll();
      this.currNode = this.channelArr[0];
    },
    // 编辑或新增后的统一恢复处理
    cancelAll() {
      this.isNew = false;
      this.inEdit = false;
      this.currUserId = -1;
      this.currNodeNew = {};
    }
  },
  mounted() {
    this.getInit();
  }
};
</script>

<style lang="less" scoped>
@import '~@/assets/less/index.less';

.pageTitle {
  padding-left: 132px;
  padding-right: 132px;
  color: #fff;
  background-color: #444;
}

.infoWrapper {
  display: flex;
  justify-content: center;

  .leftZone {
    width: 300px;

    .leftTitle {
      padding: 8px;
      text-align: center;
    }
  }

  .rightZone {
    position: relative;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 60vh;
    background-color: transparent;

    .editCard {
      position: relative;
      width: 654px;
      height: 400px;
      padding: 32px;
      background-image: url('../../../../static/img/code.png');
      background-repeat: repeat;
      border-radius: 10px;
      box-shadow: 5px 5px 110px rgba(0, 0, 0, 0.3);
      transition: .2s;

      .rightTitle {
        font-size: 1rem;
      }

      .itemRow {
        margin: 8px 0;
      }
    }
  }
}

.userPanel {
  max-height: 500px;
  overflow-y: auto;

  li {
    padding: 8px;
    cursor: pointer;

    &:hover {
      background-color: #ccc;
    }
  }
}

@menu-prefix: ~"@{prefix}menu";
.@{menu-prefix}-custom {
  background: @second-color;
}
</style>
