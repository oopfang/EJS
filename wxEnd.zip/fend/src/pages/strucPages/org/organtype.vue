<template>
  <div>组织类型</div>
</template>

<script>
  export default {
    name: 'organtype',
    components: {},
    data: function() {
      return {
        id: 1
      };
    },
    computed: {},
    methods: {}
  };
</script>

<style lang="less" scoped>
</style>