<template>
  <layerMain></layerMain>
</template>

<script>
import layerMain from '@/components/layout/layerMain';

export default {
  name: 'home',
  components: {
    layerMain
  }
};
</script>
