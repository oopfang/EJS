<template>
<basePage :inLoading="inLoading">
  <tPanel>
    <div class="headerRow">
      <div class="topCard">
        <div class="cellLeft">可再销售数</div>
        <div class="cellRight">
          <vueCountUp :start-value="0" :end-value="23"></vueCountUp>
        </div>
      </div>
      <div class="topCard">
        <div class="cellLeft">临保数</div>
        <div class="cellRight">
          <vueCountUp :start-value="0" :end-value="200"></vueCountUp>
        </div>
      </div>
      <div class="topCard">
        <div class="cellLeft">待修补数</div>
        <div class="cellRight">
          <vueCountUp :start-value="0" :end-value="100"></vueCountUp>
        </div>
      </div>
      <div class="topCard">
        <div class="cellLeft">报损数</div>
        <div class="cellRight">
          <vueCountUp :start-value="0" :end-value="87"></vueCountUp>
        </div>
      </div>
    </div>
  </tPanel>
  <div class="rptZone">
    <div class="slidLeft">
      <!-- 退货检验一览 -->
      <tPanel showHeader :topSpace="8">
        <div slot="panelHeader">
          <span class="h-tag chartTag mostBlackLite">退货检验一览</span>
        </div>
        <div>
          <pie ref="vrifyProp"></pie>
        </div>
      </tPanel>
      <!-- 类型走势图 -->
      <tPanel showHeader :topSpace="36">
        <div slot="panelHeader">
          <span class="h-tag chartTag mostBlackLite">类型走势</span>
        </div>
        <div>
          <lineMuti ref="vrifyType"></lineMuti>
        </div>
      </tPanel>
    </div>
    <tPanel showHeader :topSpace="8" asFlex1>
      <div slot="panelHeader">
        <span class="cellTips txtColor1" :class="{ active: viewTypeIdx === 1 }" @click.prevent.stop="viewTypeIdx=1">今日到期</span>
        <span class="cellTips txtColor3" :class="{ active: viewTypeIdx === 2 }" @click.prevent.stop="viewTypeIdx=2">3天内到期</span>
        <span class="cellTips txtColor7" :class="{ active: viewTypeIdx === 3 }" @click.prevent.stop="viewTypeIdx=3">7天内到期</span>
        <span class="cellTips txtColorM" :class="{ active: viewTypeIdx === 4 }" @click.prevent.stop="viewTypeIdx=4">超过7天</span>
        <span class="cellTips txtColor0" :class="{ active: viewTypeIdx === 0 }" @click.prevent.stop="viewTypeIdx=0">效期为空</span>
      </div>
      <p class="dateEndItem asHeader">
        <span class="dateEndCell x1">序号</span>
        <span class="dateEndCell flexSplit">商品名称</span>
        <span class="dateEndCell x2">规格</span>
        <span class="dateEndCell x2">型号</span>
        <span class="dateEndCell x1">单位</span>
        <span class="dateEndCell x2">效期</span>
      </p>
      <div class="dateEndWrapper" :class="geColor">
        <p class="dateEndItem asDetail" v-for="(item, index) of getList" :key="index">
          <span class="dateEndCell x1">{{ index }}</span>
          <span class="dateEndCell flexSplit">{{ item.prodNamezh }}</span>
          <span class="dateEndCell x2">{{ item.specNamezh }}</span>
          <span class="dateEndCell x2">{{ item.sizeNamezh }}</span>
          <span class="dateEndCell x1">{{ item.unit }}</span>
          <span class="dateEndCell x2">{{ item.dateValidityEnd || '-' }}</span>
        </p>
      </div>
    </tPanel>
  </div>
</basePage>
</template>

<script>
import basePage from '@/components/wrapper/base.vue';
import tPanel from '@/components/wrapper/part/tPanel';
import pie from '@/components/charts/pie';
import lineNormal from '@/components/charts/lineNormal';
import lineMuti from '@/components/charts/lineMuti';
import vueCountUp from 'vue-countupjs';
import {
  mapGetters,
  mapActions
} from 'vuex';
let _getChartOpt = (title = '报表', subTitle = '', chartData, chartLegend) => {
  return {
    title: title,
    subTitle: subTitle,
    chartLegend: chartLegend,
    chartData: chartData
  };
};

export default {
  name: 'worktable',
  components: {
    basePage,
    tPanel,
    vueCountUp,
    lineNormal,
    lineMuti,
    pie
  },
  data: function () {
    return {
      inLoading: false,
      viewTypeIdx: 1,
      // 效期预警数据列表
      dateEndList0: [],
      dateEndList1: [],
      dateEndList3: [],
      dateEndList7: [],
      dateEndListM: []
    };
  },
  computed: {
    ...mapGetters(['getBizDefine']),
    getList() {
      if (!this.viewTypeIdx) {
        return this.dateEndList0;
      } else if (this.viewTypeIdx === 1) {
        return this.dateEndList1;
      } else if (this.viewTypeIdx === 2) {
        return this.dateEndList3;
      } else if (this.viewTypeIdx === 3) {
        return this.dateEndList7;
      } else if (this.viewTypeIdx === 4) {
        return this.dateEndListM;
      }
    },
    geColor() {
      return {
        txtColor0: !this.viewTypeIdx,
        txtColor1: this.viewTypeIdx === 1,
        txtColor3: this.viewTypeIdx === 2,
        txtColor7: this.viewTypeIdx === 3,
        txtColorM: this.viewTypeIdx === 4,
      };
    }
  },
  methods: {
    ...mapActions(['queryDateEndList']),
    // 今日货物占比
    onVrifyProp(val) {
      let _vrifyProp = _getChartOpt('', '', val, val.map(v => v.name));
      this.$refs.vrifyProp.update(_vrifyProp);
    },
    onVrifyType(val) {
      let _vrifyType = _getChartOpt('', '', val, val.vals.map(v => {
        return {
          name: v.name,
          textStyle: {
            color: v.lineStyle.color
          }
        }
      }));
      this.$refs.vrifyType.update(_vrifyType);
    }
  },
  async mounted() {
    this.onVrifyProp([{
      id: 1,
      name: '报废',
      value: 300
    }, {
      id: 2,
      name: '再销售',
      value: 400
    }, {
      id: 3,
      name: '临保',
      value: 410
    }, {
      id: 5,
      name: '破损',
      value: 500
    }]);
    this.onVrifyType({
      xAxis:  ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
      vals: [{
        name: '可再销数据',
        type: 'line',
        lineStyle: {
          color: '#89C68A'
        },
        data: [6, 5, 7, 1, 4, 6, 8]
      },
      {
        name: '临保数据',
        type: 'line',
        lineStyle: {
          color: '#ff6633'
        },
        data: [3, 9, 1, 6, 8, 2, 7]
      },
      {
        name: '修补数据',
        type: 'line',
        lineStyle: {
          color: '#FDB546'
        },
        data: [3, 1, 2, 9, 2, 7, 6]
      },
      {
        name: '报损数据',
        type: 'line',
        lineStyle: {
          color: '#999'
        },
        data: [1, 12, 3, 5, 3, 2, 0]
      }
    ]
    });
    let [a, b, c, d, e] = await this.queryDateEndList();
    this.dateEndList0 = a;
    this.dateEndList1 = b;
    this.dateEndList3 = c;
    this.dateEndList7 = d;
    this.dateEndListM = e;
  }
};
</script>

<style lang="less" scoped>
@rptHeight: 83vh;

.chartTag {
  padding: 8px 12px;
  border-color: #b2c872;
  background-color: transparent;
}

.txtColor0 {
  color: #131138;
}

.txtColor1 {
  color: #131138;
}

.txtColor3 {
  color: #7E5A23;
}

.txtColor7 {
  color: #F29D00;
}

.txtColorM {
  color: #F24100;
}

.dateEndItem {
  display: flex;
  justify-content: center;
  align-items: center;

  &.asHeader {
    padding: 8px 0;
    font-weight: 700;
    background-color: #f2f2f2;
  }

  &.asDetail {
    padding: 18px 0;
    border-bottom: 1px #eee solid;
    cursor: pointer;

    &:hover {
      background-color: rgba(206, 205, 224, 0.3);
    }
  }

  .dateEndCell {
    margin: 0 2px;
    text-align: center;

    &.x1 {
      width: 80px;
    }

    &.x2 {
      width: 160px;
    }

    &.x3 {
      width: 240px;
    }
  }
}

.dateEndWrapper {
  height: 72vh;
  overflow-x: hidden;
  overflow-y: auto;
}

.cellTips {
  flex: 1;
  text-align: center;
  cursor: pointer;

  &.active {
    color: #000;
    background-color: #C6DBC0;
  }
}

.headerRow {
  display: flex;
  color: #fff;

  .topCard {
    display: flex;
    flex: 1;
    height: 40px;
    margin: 9px;
    border-radius: 30px;

    .cellLeft {
      display: flex;
      flex: 1;
      justify-content: center;
      align-items: center;
      font-size: .8rem;
      font-weight: 700;
    }

    .cellRight {
      display: inline-block;
      min-width: 120px;
      max-width: 70%;
      height: 40px;
      line-height: 40px;
      padding: 0 8px;
      text-align: center;
      font-size: 1rem;
      font-weight: 700;
      border-top-left-radius: 80px;
      border-top-right-radius: 38px;
      border-bottom-right-radius: 40px;
      background-color: rgba(41, 41, 207, 0.425);
    }

    &:nth-child(1) {
      background-color: #5AAD31;
    }

    &:nth-child(2) {
      // color: #333;
      background-color: #5AAD31;
    }

    &:nth-child(3) {
      background-color: #5AAD31;
    }

    &:nth-child(4) {
      // color: #333;
      background-color: #5AAD31;
    }
  }
}

.rptZone {
  display: flex;
  width: 100%;
  height: @rptHeight;
  overflow: hidden;

  .slidLeft {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    width: 30%;
    height: @rptHeight;
    margin-right: 8px;
  }
}
</style>
