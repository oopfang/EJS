const state = {
  // 当前组织的完整对象数据
  currOrgNodeAll: {},
  // 当前组织数据的JSON对象表示形式
  currOrgJson: {},
  // 当前选中的组织节点
  currOrgNode: {}
};

const getters = {
  // 获取组织的完整对象数据
  getOrgNodeAll: state => state.currOrgNodeAll,
  // 获取组织的JSON对象表示形式
  getOrgOfJson: state => {
    let _checkArr = Object.keys(state.currOrgNodeAll);
    // 确保根节点唯一
    if (_checkArr.length === 1) {
      // let _obj = {};
      for (let v of state.currOrgNodeAll) {
        global.tlog(v);
      }
      // return JSON.stringify(_obj);
      return '';
    } else {
      return '';
    }
  },
  // 获取当前点击或选中的组织节点
  getCurrOrgNode: state => state.currOrgNode
};

const mutations = {
  // 初始化组织的完整节点数据
  initOrgData: (state, obj) => {
    state.currOrgNodeAll = obj;
  },
  // 重设组织根节点下的所有节点
  resetOrg: (state, list) => {
    state.currOrgNodeAll.children = list;
  },
  // 设定当前点击或选中的组织节点
  setCurrOrgNode: (state, node) => {
    state.currOrgNode = node;
  }
};

const actions = {
  // 获取组织机构信息
  queryOrgs(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('/orgs/list', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 新增组织节点
  setNewOrgs(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('/orgs/add', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 修改组织机构名称备注
  changeOrgsInfo(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/orgs/reInfo', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 变更组织机构节点顺序
  resetOrgs(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/orgs/reset', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 注销机构节点
  stopOrg(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/orgs/stop', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 组织注销后的员工从属变更
  resetUserOgr(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/orgs/userReorg', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
