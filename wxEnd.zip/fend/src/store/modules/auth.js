const actions = {
  // 登陆用户在个人中心执行更改密码操作
  changePwd(context, pwds) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/userRePwd', pwds)
        .then(res => {
          localStorage.removeItem('signInfo');
          resolve('修改成功，请重新登陆!');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 查询授权中心基本信息
  querAuth(contex) {
    return new Promise((resolve, reject) => {
      global
        .getFunc('/appro/base', {})
        .then(res => {
          /* eslint-disable no-unused-vars */
          let {
            $unSave,
            ...otherRes
          } = res.result;
          resolve(otherRes);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 封停指定账号
  accForbidden(context, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/acc/forbidden', option)
        .then(res => {
          resolve(`账号${option.id}已封停`);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 对指定账号重置密码
  accRePwd(context, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/acc/rePwd', option)
        .then(res => {
          resolve(`账号${option.id}密码已重置为初始密码`);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 创建角色
  createRole(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('/appro/role/add', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 删除指定ID的角色
  deleletRole(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('/appro/role/del', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 角色变更
  resetRole(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/role/reset', option)
        .then(res => {
          resolve(`账号${option.id}的角色修改成功`);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 对角色进行菜单授权变更
  resetRoleMenu(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/role/reMenu', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 对角色的操作权限进行变更
  resetRoleOperatRight(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/role/reOperat', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 在流程引擎页面获取值设定时的备选记录
  getRecordAsValue(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('/appro/flow/record', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 对指定工作流进行变更
  setFlow(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/appro/flow/add', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};
