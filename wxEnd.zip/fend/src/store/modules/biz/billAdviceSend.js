/**
 * 发货通知单视图的状态单元
 */

import bizDefine from '@/define/billAdviceSend/intro.js';

let getBillAdviceSendEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前发货通知单列表
  billAdviceSendList: [],
  // 当前选定的发货通知单对象
  billAdviceSendObj: getBillAdviceSendEmptyObj()
};

const getters = {
  // 获取发货通知单一览列表数据
  getBillAdviceSendList: state => state.billAdviceSendList,
  // 获取发货通知单对象
  getBillAdviceSendObj: state => state.billAdviceSendObj
};

const mutations = {
  // 绑定发货通知单一览表数据
  setBillAdviceSendList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billAdviceSendList = data;
    }
  },
  // 设置发货通知单对象
  setBillAdviceSendObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billAdviceSendObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的发货通知单记录行
  removeBillAdviceSendObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billAdviceSendList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billAdviceSendList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillAdviceSend: state => {
    state.billAdviceSendList = [];
    state.billAdviceSendObj = getBillAdviceSendEmptyObj();
  }
};

const actions = {
  // 远程获取发货通知单一览表
  queryBillAdviceSendList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billAdviceSend/list', option)
        .then(res => {
          contex.commit('setBillAdviceSendList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的发货通知单对象
  queryBillAdviceSendObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billAdviceSend/obj', option)
        .then(res => {
          contex.commit('setBillAdviceSendObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增发货通知单的请求
  postBillAdviceSendObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billAdviceSend/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },

  // 通过库存再销售
  postBillAdviceSendByInvt(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billAdviceSend/addByInvt', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },



  // 远程发送新增发货通知单的请求
  putSendNotice(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billAdviceSend/sendNotice', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑发货通知单的请求
  putBillAdviceSendObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billAdviceSend/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的发货通知单对象
  delBillAdviceSendMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billAdviceSend/del', option)
        .then(res => {
          contex.commit('removeBillAdviceSendObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
