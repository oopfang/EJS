
const actions = {
  // 远程获取库位管理一览表
  queryStockListByCell(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/stockMgr/list', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};