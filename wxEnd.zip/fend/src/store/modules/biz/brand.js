/**
 * 品牌列表视图的状态单元
 */

import bizDefine from '@/define/brand/intro.js';

let getBrandEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前品牌列表列表
  brandList: [],
  // 当前选定的品牌列表对象
  brandObj: getBrandEmptyObj()
};

const getters = {
  // 获取品牌列表一览列表数据
  getBrandList: state => state.brandList,
  // 获取品牌列表对象
  getBrandObj: state => state.brandObj
};

const mutations = {
  // 绑定品牌列表一览表数据
  setBrandList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.brandList = data;
    }
  },
  // 设置品牌列表对象
  setBrandObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.brandObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的品牌列表记录行
  removeBrandObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.brandList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.brandList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBrand: state => {
    state.brandList = [];
    state.brandObj = getBrandEmptyObj();
  }
};

const actions = {
  // 远程获取品牌列表一览表
  queryBrandList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/brand/list', option)
        .then(res => {
          contex.commit('setBrandList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的品牌列表对象
  queryBrandObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/brand/obj', option)
        .then(res => {
          contex.commit('setBrandObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增品牌列表的请求
  postBrandObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/brand/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑品牌列表的请求
  putBrandObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/brand/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的品牌列表对象
  delBrandMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/brand/del', option)
        .then(res => {
          contex.commit('removeBrandObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
