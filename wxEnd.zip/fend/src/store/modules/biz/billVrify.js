/**
 * 退货鉴验明细表视图的状态单元
 */

import bizDefine from '@/define/billVrify/intro.js';

let getBillVrifyEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前退货鉴验明细表列表
  billVrifyList: [],
  // 当前选定的退货鉴验明细表对象
  billVrifyObj: getBillVrifyEmptyObj()
};

const getters = {
  // 获取退货鉴验明细表一览列表数据
  getBillVrifyList: state => state.billVrifyList,
  // 获取退货鉴验明细表对象
  getBillVrifyObj: state => state.billVrifyObj
};

const mutations = {
  // 绑定退货鉴验明细表一览表数据
  setBillVrifyList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billVrifyList = data;
    }
  },
  // 设置退货鉴验明细表对象
  setBillVrifyObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billVrifyObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的退货鉴验明细表记录行
  removeBillVrifyObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billVrifyList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billVrifyList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillVrify: state => {
    state.billVrifyList = [];
    state.billVrifyObj = getBillVrifyEmptyObj();
  }
};

const actions = {
  // 远程获取退货待验明细列表
  queryBillVrifyListTobe(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billVrify/listTobe', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取退货鉴验明细表一览表
  queryBillVrifyList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billVrify/list', option)
        .then(res => {
          contex.commit('setBillVrifyList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的退货鉴验明细表对象
  queryBillVrifyObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billVrify/obj', option)
        .then(res => {
          contex.commit('setBillVrifyObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增退货鉴验明细表的请求
  postBillVrifyObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billVrify/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程提交单笔鉴验明细
  putBillVrifyCheck(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billVrify/check', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑退货鉴验明细表的请求
  putBillVrifyObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billVrify/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的退货鉴验明细表对象
  delBillVrifyMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billVrify/del', option)
        .then(res => {
          contex.commit('removeBillVrifyObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
