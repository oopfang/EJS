/**
 * 商品管理视图的状态单元
 */

import bizDefine from '@/define/produc/intro.js';

let getProducEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前商品管理列表
  producList: [],
  // 当前选定的商品管理对象
  producObj: getProducEmptyObj()
};

const getters = {
  // 获取商品管理一览列表数据
  getProducList: state => state.producList,
  // 获取商品管理对象
  getProducObj: state => state.producObj
};

const mutations = {
  // 绑定商品管理一览表数据
  setProducList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.producList = data;
    }
  },
  // 设置商品管理对象
  setProducObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.producObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的商品管理记录行
  removeProducObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.producList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.producList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheProduc: state => {
    state.producList = [];
    state.producObj = getProducEmptyObj();
  }
};

const actions = {
  // 远程获取商品管理一览表
  queryProducList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/produc/list', option)
        .then(res => {
          contex.commit('setProducList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的商品管理对象
  queryProducObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/produc/obj', option)
        .then(res => {
          contex.commit('setProducObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增商品管理的请求
  postProducObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/produc/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑商品管理的请求
  putProducObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/produc/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑商品管理的请求
  putProducImg(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/produc/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的商品管理对象
  delProducMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/produc/del', option)
        .then(res => {
          contex.commit('removeProducObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
