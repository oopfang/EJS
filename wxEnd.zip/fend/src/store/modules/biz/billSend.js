/**
 * 出库单视图的状态单元
 */

import bizDefine from '@/define/billSend/intro.js';

let getBillSendEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前出库单列表
  billSendList: [],
  // 当前选定的出库单对象
  billSendObj: getBillSendEmptyObj()
};

const getters = {
  // 获取出库单一览列表数据
  getBillSendList: state => state.billSendList,
  // 获取出库单对象
  getBillSendObj: state => state.billSendObj
};

const mutations = {
  // 绑定出库单一览表数据
  setBillSendList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billSendList = data;
    }
  },
  // 设置出库单对象
  setBillSendObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billSendObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的出库单记录行
  removeBillSendObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billSendList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billSendList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillSend: state => {
    state.billSendList = [];
    state.billSendObj = getBillSendEmptyObj();
  }
};

const actions = {
  // 远程获取出库单一览表
  queryBillSendList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billSend/list', option)
        .then(res => {
          contex.commit('setBillSendList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的出库单对象
  queryBillSendObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billSend/obj', option)
        .then(res => {
          contex.commit('setBillSendObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增出库单的请求
  postBillSendObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billSend/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑出库单的请求
  putBillSendObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billSend/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的出库单对象
  delBillSendMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billSend/del', option)
        .then(res => {
          contex.commit('removeBillSendObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
