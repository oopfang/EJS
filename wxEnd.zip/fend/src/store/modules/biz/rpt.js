const actions = {
  // 按产品统计退货
  querRptByProd(contex, options) {
    return new Promise((resolve, reject) => {
      global
        .getFunc('/rpt/returnByProd', options)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};
