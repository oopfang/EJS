/**
 * 仓库管理视图的状态单元
 */

import bizDefine from '@/define/warehouse/intro.js';

let getWarehouseEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前仓库管理列表
  warehouseList: [],
  // 当前选定的仓库管理对象
  warehouseObj: getWarehouseEmptyObj()
};

const getters = {
  // 获取仓库管理一览列表数据
  getWarehouseList: state => state.warehouseList,
  // 获取仓库管理对象
  getWarehouseObj: state => state.warehouseObj
};

const mutations = {
  // 绑定仓库管理一览表数据
  setWarehouseList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.warehouseList = data;
    }
  },
  // 设置仓库管理对象
  setWarehouseObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.warehouseObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的仓库管理记录行
  removeWarehouseObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.warehouseList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.warehouseList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheWarehouse: state => {
    state.warehouseList = [];
    state.warehouseObj = getWarehouseEmptyObj();
  }
};

const actions = {
  // 远程获取仓库管理一览表
  queryWarehouseList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/warehouse/list', option)
        .then(res => {
          contex.commit('setWarehouseList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的仓库管理对象
  queryWarehouseObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/warehouse/obj', option)
        .then(res => {
          contex.commit('setWarehouseObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增仓库管理的请求
  postWarehouseObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/warehouse/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑仓库管理的请求
  putWarehouseObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/warehouse/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的仓库管理对象
  delWarehouseMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/warehouse/del', option)
        .then(res => {
          contex.commit('removeWarehouseObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
