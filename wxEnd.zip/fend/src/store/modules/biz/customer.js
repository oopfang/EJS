/**
 * 客户档案视图的状态单元
 */

import bizDefine from '@/define/customer/intro.js';

let getCustomerEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前客户档案列表
  customerList: [],
  // 当前选定的客户档案对象
  customerObj: getCustomerEmptyObj()
};

const getters = {
  // 获取客户档案一览列表数据
  getCustomerList: state => state.customerList,
  // 获取客户档案对象
  getCustomerObj: state => state.customerObj
};

const mutations = {
  // 绑定客户档案一览表数据
  setCustomerList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.customerList = data;
    }
  },
  // 设置客户档案对象
  setCustomerObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.customerObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的客户档案记录行
  removeCustomerObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.customerList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.customerList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheCustomer: state => {
    state.customerList = [];
    state.customerObj = getCustomerEmptyObj();
  }
};

const actions = {
  // 远程获取客户档案一览表
  queryCustomerList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/customer/list', option)
        .then(res => {
          contex.commit('setCustomerList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的客户档案对象
  queryCustomerObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/customer/obj', option)
        .then(res => {
          contex.commit('setCustomerObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增客户档案的请求
  postCustomerObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/customer/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑客户档案的请求
  putCustomerObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/customer/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的客户档案对象
  delCustomerMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/customer/del', option)
        .then(res => {
          contex.commit('removeCustomerObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
