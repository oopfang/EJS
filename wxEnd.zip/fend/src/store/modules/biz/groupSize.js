/**
 * 尺码组视图的状态单元
 */

import bizDefine from '@/define/groupSize/intro.js';

let getGroupSizeEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前尺码组列表
  groupSizeList: [],
  // 当前选定的尺码组对象
  groupSizeObj: getGroupSizeEmptyObj()
};

const getters = {
  // 获取尺码组一览列表数据
  getGroupSizeList: state => state.groupSizeList,
  // 获取尺码组对象
  getGroupSizeObj: state => state.groupSizeObj
};

const mutations = {
  // 绑定尺码组一览表数据
  setGroupSizeList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.groupSizeList = data;
    }
  },
  // 设置尺码组对象
  setGroupSizeObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.groupSizeObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的尺码组记录行
  removeGroupSizeObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.groupSizeList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.groupSizeList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheGroupSize: state => {
    state.groupSizeList = [];
    state.groupSizeObj = getGroupSizeEmptyObj();
  }
};

const actions = {
  // 远程获取尺码组一览表
  queryGroupSizeList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/groupSize/list', option)
        .then(res => {
          contex.commit('setGroupSizeList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的尺码组对象
  queryGroupSizeObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/groupSize/obj', option)
        .then(res => {
          contex.commit('setGroupSizeObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增尺码组的请求
  postGroupSizeObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/groupSize/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑尺码组的请求
  putGroupSizeObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/groupSize/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的尺码组对象
  delGroupSizeMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/groupSize/del', option)
        .then(res => {
          contex.commit('removeGroupSizeObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
