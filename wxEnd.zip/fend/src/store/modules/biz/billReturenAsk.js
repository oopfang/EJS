/**
 * 退货申请单视图的状态单元
 */

import bizDefine from '@/define/billReturenAsk/intro.js';

let getBillReturenAskEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前退货申请单列表
  billReturenAskList: [],
  // 当前选定的退货申请单对象
  billReturenAskObj: getBillReturenAskEmptyObj()
};

const getters = {
  // 获取退货申请单一览列表数据
  getBillReturenAskList: state => state.billReturenAskList,
  // 获取退货申请单对象
  getBillReturenAskObj: state => state.billReturenAskObj
};

const mutations = {
  // 绑定退货申请单一览表数据
  setBillReturenAskList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billReturenAskList = data;
    }
  },
  // 设置退货申请单对象
  setBillReturenAskObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billReturenAskObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的退货申请单记录行
  removeBillReturenAskObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billReturenAskList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billReturenAskList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillReturenAsk: state => {
    state.billReturenAskList = [];
    state.billReturenAskObj = getBillReturenAskEmptyObj();
  }
};

const actions = {
  // 远程获取退货申请单一览表
  queryBillReturenAskList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billReturenAsk/list', option)
        .then(res => {
          contex.commit('setBillReturenAskList', res.result.list);
          resolve(res.result.count);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的退货申请单对象
  queryBillReturenAskObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billReturenAsk/obj', option)
        .then(res => {
          contex.commit('setBillReturenAskObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增退货申请单的请求
  postBillReturenAskObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billReturenAsk/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发起类审批操作
  postBillReturenAskAppro(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billReturenAsk/approv', option)
      .then(res => {
        resolve(res.result);
      })
      .catch(err => {
        reject(err);
      });
    });
  },
  // 远程发送编辑退货申请单的请求
  putBillReturenAskObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billReturenAsk/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的退货申请单对象
  delBillReturenAskMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billReturenAsk/del', option)
        .then(res => {
          contex.commit('removeBillReturenAskObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
