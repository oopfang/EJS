/**
 * 退货原因列表视图的状态单元
 */

import bizDefine from '@/define/ruleVerify/intro.js';

let getRuleVerifyEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前退货原因列表列表
  ruleVerifyList: [],
  // 当前选定的退货原因列表对象
  ruleVerifyObj: getRuleVerifyEmptyObj()
};

const getters = {
  // 获取退货原因列表一览列表数据
  getRuleVerifyList: state => state.ruleVerifyList,
  // 获取退货原因列表对象
  getRuleVerifyObj: state => state.ruleVerifyObj
};

const mutations = {
  // 绑定退货原因列表一览表数据
  setRuleVerifyList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.ruleVerifyList = data;
    }
  },
  // 设置退货原因列表对象
  setRuleVerifyObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.ruleVerifyObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的退货原因列表记录行
  removeRuleVerifyObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.ruleVerifyList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.ruleVerifyList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheRuleVerify: state => {
    state.ruleVerifyList = [];
    state.ruleVerifyObj = getRuleVerifyEmptyObj();
  }
};

const actions = {
  // 远程获取退货原因列表一览表
  queryRuleVerifyList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/ruleVerify/list', option)
        .then(res => {
          contex.commit('setRuleVerifyList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的退货原因列表对象
  queryRuleVerifyObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/ruleVerify/obj', option)
        .then(res => {
          contex.commit('setRuleVerifyObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增退货原因列表的请求
  postRuleVerifyObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/ruleVerify/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑退货原因列表的请求
  putRuleVerifyObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/ruleVerify/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的退货原因列表对象
  delRuleVerifyMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/ruleVerify/del', option)
        .then(res => {
          contex.commit('removeRuleVerifyObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
