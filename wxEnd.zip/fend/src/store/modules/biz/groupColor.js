/**
 * 颜色组视图的状态单元
 */

import bizDefine from '@/define/groupColor/intro.js';

let getGroupColorEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前颜色组列表
  groupColorList: [],
  // 当前选定的颜色组对象
  groupColorObj: getGroupColorEmptyObj()
};

const getters = {
  // 获取颜色组一览列表数据
  getGroupColorList: state => state.groupColorList,
  // 获取颜色组对象
  getGroupColorObj: state => state.groupColorObj
};

const mutations = {
  // 绑定颜色组一览表数据
  setGroupColorList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.groupColorList = data;
    }
  },
  // 设置颜色组对象
  setGroupColorObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.groupColorObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的颜色组记录行
  removeGroupColorObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.groupColorList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.groupColorList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheGroupColor: state => {
    state.groupColorList = [];
    state.groupColorObj = getGroupColorEmptyObj();
  }
};

const actions = {
  // 远程获取颜色组一览表
  queryGroupColorList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/groupColor/list', option)
        .then(res => {
          contex.commit('setGroupColorList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的颜色组对象
  queryGroupColorObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/groupColor/obj', option)
        .then(res => {
          contex.commit('setGroupColorObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增颜色组的请求
  postGroupColorObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/groupColor/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑颜色组的请求
  putGroupColorObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/groupColor/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的颜色组对象
  delGroupColorMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/groupColor/del', option)
        .then(res => {
          contex.commit('removeGroupColorObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
