/**
 * 入库单视图的状态单元
 */

import bizDefine from '@/define/billStockIn/intro.js';

let getBillStockInEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前入库单列表
  billStockInList: [],
  // 当前选定的入库单对象
  billStockInObj: getBillStockInEmptyObj()
};

const getters = {
  // 获取入库单一览列表数据
  getBillStockInList: state => state.billStockInList,
  // 获取入库单对象
  getBillStockInObj: state => state.billStockInObj
};

const mutations = {
  // 绑定入库单一览表数据
  setBillStockInList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billStockInList = data;
    }
  },
  // 设置入库单对象
  setBillStockInObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billStockInObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的入库单记录行
  removeBillStockInObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billStockInList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billStockInList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillStockIn: state => {
    state.billStockInList = [];
    state.billStockInObj = getBillStockInEmptyObj();
  }
};

const actions = {
  // 远程获取入库单一览表
  queryBillStockInList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billStockIn/list', option)
        .then(res => {
          contex.commit('setBillStockInList', res.result.list);
          resolve(res.result.count);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的入库单对象
  queryBillStockInObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billStockIn/obj', option)
        .then(res => {
          contex.commit('setBillStockInObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增入库单的请求
  postBillStockInObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billStockIn/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑入库单的请求
  putBillStockInObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billStockIn/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发起类审批操作
  postBillStockInRecive(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billStockIn/edit', option)
      .then(res => {
        resolve(res.result);
      })
      .catch(err => {
        reject(err);
      });
    });
  },
  // 远程删除指定ID的入库单对象
  delBillStockInMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billStockIn/del', option)
        .then(res => {
          contex.commit('removeBillStockInObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
