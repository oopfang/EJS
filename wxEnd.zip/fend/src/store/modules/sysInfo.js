import conf from '../../config/config.json';
import maskUtilt from '../../tModules/utility/mask';

let emptyUser = {
  id: -1,
  pid: -1,
  code: '',
  name: '',
  namezh: '',
  token: '',
  avatar: '',
  channelid: -1,
  organid: -1
};

const state = {
  // 工作区限定高度
  workZoneHeight: 0,
  // 右边栏的显示状态
  sliderRithShown: false,
  // 是否处于锁屏状态
  inLocking: false,
  // 用于顶部提示的信息
  topTipMsg: [],
  // 当前导航的视图信息
  currView: {
    id: '',
    name: '',
    url: ''
  },
  // 当前页面的页脚文字
  currFooterText: [],
  // 系统菜单
  menus: [],
  breadData: [{
    title: '首页',
    icon: 'h-icon-home',
    name: 'home'
  }],
  // 登录用户信息
  userInfo: emptyUser,
  // 是否处于设置页面
  inSetting: false,
  // 全局业务定义
  bizDefine: {}
};

const getters = {
  getCopyRightStr: state => {
    return maskUtilt.intFull2Str(conf.holeCopyRight);
  },
  getCpStr1: state => {
    let _cps = [];
    let currCps = conf.cp1.split('&');
    for (let i = 0; i < currCps.length; i++) {
      if (i === 1) {
        _cps.push(new Date().getFullYear());
      }
      _cps.push(maskUtilt.intFull2Str(currCps[i]));
    }
    return _cps.join('');
  },
  getCpStr2: state => {
    return maskUtilt.intFull2Str(conf.cp2);
  },
  // 从CDN获取 slogan文件地址
  getSlogan: state => `${conf.ImgBaseUrl}img/slogan.png`,
  // 获取工作区限定高度
  getWorkZoneHeight: state => state.workZoneHeight,
  // 获取右边栏的显示状态
  getSliderRithShown: state => state.sliderRithShown,
  // 获取当前是否处于锁屏的状态值
  getInLocking: state => state.inLocking,
  // 获取居中置顶的提示信息
  getTopTipMsg: state => state.topTipMsg,
  // 获取当前导航到的信息
  getCurrView: state => state.currView,
  // 获取当前页脚的显示文本
  getCurrFooterText: state => state.currFooterText,
  // 获取系统菜单
  getMenus: state => {
    if (state.menus && state.menus.length > 0) {
      return state.menus;
    } else {
      let _localMenu = localStorage.getItem('currMenu');
      if (_localMenu) {
        return JSON.parse(_localMenu);
      } else {
        return [];
      }
    }
  },
  // 获取当前登陆的用户信息
  getUserInfo: state => {
    if (!state.userInfo.name) {
      let _uCache = localStorage.getItem('signInfo');
      if (!_uCache) {
        return emptyUser;
      } else {
        state.userInfo = JSON.parse(_uCache);
        return state.userInfo;
      }
    } else {
      return state.userInfo;
    }
  },
  // 获取顶部面包屑的列表
  getBreadData: state => state.breadData,
  // 获取是否处于设置页面的状态值
  getInSetting: state => state.inSetting,
  // 获取全局业务定义
  getBizDefine: state => {
    return state.bizDefine || {};
  }
};

const mutations = {
  // 设置工作区限定高度
  setWorkZoneHeight(state, h) {
    state.workZoneHeight = h;
  },
  // 切换右边栏的显示状态
  toggleSliderRight(state) {
    state.sliderRithShown = !state.sliderRithShown;
  },
  // 设置系统的锁定状态
  setInLocking(state, lockingState) {
    state.inLocking = lockingState;
  },
  // 设置居中置顶的提示信息
  setTopTipMsg(state, msg) {
    if (Array.isArray(msg)) {
      msg.forEach((v, k, arr) => {
        state.topTipMsg.push(v);
      });
    } else {
      state.topTipMsg.push(msg);
    }
  },
  // 设置当前导航到的信息
  setCurrView(state, viewInfo) {
    Object.assign(state.currView, viewInfo);
  },
  // 设置当前页脚显示文本
  setCurrFooterText(state, txt) {
    if (txt) {
      if (Array.isArray(txt)) {
        state.currFooterText = txt;
      } else if (typeof txt === 'string') {
        state.currFooterText.push(txt);
      }
    } else {
      state.currFooterText = [];
    }
  },
  // 设置系统菜单
  setMenu(state, menus) {
    state.menus = menus;
    localStorage.setItem('currMenu', JSON.stringify(menus));
  },
  // 设置当前登陆的用户信息
  setUserInfo(state, uInfo) {
    uInfo.avatar = `/static/img/userHeader${uInfo.gender}.png?v=8.0`;
    uInfo.inLocking = false;
    localStorage.setItem('signInfo', JSON.stringify(uInfo));
    state.userInfo = uInfo;
  },
  // 设置顶部面包屑列表
  setBreadData(state, item) {
    state.breadData = [state.breadData[0], item];
  },
  // 设置是否处于设置页面的状态值
  setInSetting: (state, val) => {
    state.inSetting = val;
  },
  // 设置全局业务定义
  setBizDefine: (state, biz) => {
    state.bizDefine = biz;
  },
  // 清理公共缓存
  clearCacheSysInfo: state => {
    localStorage.removeItem('currMenu');
    localStorage.removeItem('signInfo');
  }
};

const actions = {
  // 系统注册请求
  regist(context, uInfo) {},
  // 系统登陆请求
  signIn(context, uInfo) {
    return new Promise((resolve, reject) => {
      global.getFunc('/sign/in', uInfo)
        .then(res => {
          let {
            $after,
            ...$userInfo
          } = res.result;
          context.commit('setUserInfo', $userInfo);
          if (!$userInfo.stopped) {
            context.commit('setMenu', $after._menu);
            let _dict = {};
            let _bizRight = {};
            if ($after._menu.length > 0) {
              _dict = $after._dict;
              _bizRight = $after._bizRight;
            }
            window.localStorage.setItem('_dict', JSON.stringify(_dict));
            resolve({
              dict: _dict,
              bizRight: _bizRight,
              hasRight: $after._menu.length,
              isStopped: false
            });
          } else {
            resolve({
              isStopped: true
            });
          }
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  tomorrow(contex) {
    return new Promise((resolve, reject) => {
      global.getFunc('/tomorrow/check', {
          check: true
        })
        .then(res => {
          resolve();
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 系统注销请求
  signOut(context, uInfo) {
    return new Promise((resolve, reject) => {
      global.putFunc('/sign/out', uInfo)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 校验token 有效性，用于缓存页面载入
  checkToken(contex) {
    return new Promise((resolve, reject) => {
      global.getFunc('/sign/check')
        .then(res => {
          resolve();
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  sysLock(context, pwds) {
    if (pwds) {
      // 判断提供的密码是否与请求返回的密码一致，若是，返回锁屏前页面，若否，弹出提示告知密码不正确。
    } else {
      // 判断当前路由是否处于锁屏页面，若否，则导航到锁屏页面
    }
  },
  // 公用多表并联查询
  queryRangeParallel(context, option) {
    return new Promise((resolve, reject) => {
      global
        .getFunc('api/range', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程停用指定ID的ORM对象
  voidObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('api/stop', option)
        .then(res => {
          resolve('已废除');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 获取主数据
  queryDict(contex, option) {
    return new Promise((resolve, reject) => {
      global
        .getFunc('master/dict', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 从基础资料中获取主数据，并以字典格式返回
  queryMasterAsDict(contex, option) {
    return new Promise((resolve, reject) => {
      global
        .getFunc('master/masterAsDict', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  setDemo(contex, option) {
    return new Promise((resolve, reject) => {
      global
        .postFunc('/demo', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  setDemoInvt(contex, option) {
    return new Promise((resolve, reject) => {
      global
        .postFunc('/demo/invt', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
