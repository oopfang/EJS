const actions = {
  // 上传文件
  fileUploader(contex, option) {
    return new Promise((resolve, reject) => {
      global.fileLoadFunc('/fLoader/', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 上传文件
  fileRemove(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('/fLoader/', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 补传文件
  appendFile(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/fLoader/append', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 下载文件
  fileDownload(contex, option) {
    return new Promise((resolve, reject) => {
      global.fileLoadFunc('/fDownor/', option)
        .then(res => {
          // resolve(res.result);
          let { fName, fData } = res.result;
          let blob = new Blob([fData], {
            type: 'application/pdf'
          });
          if (window.navigator.msSaveOrOpenBlob) {
            // 兼容IE10
            navigator.msSaveBlob(blob, fName);
          } else {
            //  chrome/firefox
            let aTag = document.createElement('a');
            aTag.download = this.filename;
            aTag.href = URL.createObjectURL(blob);
            aTag.click();
            URL.revokeObjectURL(aTag.href);
          }
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};
