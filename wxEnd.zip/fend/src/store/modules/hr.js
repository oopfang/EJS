const actions = {
  // 获取雇员列表
  queryEmployee(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('/hr/list', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 新增雇员
  addEmployee(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('/hr/add', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 修改雇员资料
  editEmployee(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/hr/edit', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 雇员停职
  stopEmployee(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/hr/stop', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 雇员解聘
  delEmployee(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/hr/del', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};
