const actions = {
  // 获取渠道机构信息
  queryChannel(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('/channel/list', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 新增渠道节点
  setNewChannel(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('/channel/add', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 修改渠道信息
  changeChannelInfo(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/channel/reInfo', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 删除渠道
  delChannel(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('/channel/stop', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};
