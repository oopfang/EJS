const actions = {
  // 获取效期预警列表
  queryDateEndList(contex, option) {
    return new Promise((resolve, reject) => {
      global
        .getFunc('warn/dateEndList', option)
        .then(res => {
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  actions
};
