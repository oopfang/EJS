import Vue from 'vue';
import Vuex from 'vuex';

let subStore = {};
(r => {
    r.keys().forEach(key => {
        subStore[key.substring(2, key.length - 3)] = r(key).default;
    });
})(require.context('./modules/', true, /\.js$/));

Vue.use(Vuex);

export default new Vuex.Store({
    modules: subStore
});
