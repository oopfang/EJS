// 漏斗图数据模型
const darkColor = '#000';
const lightColor = '#FFF';

export default class Schartfunnel {
  /*
    @title：报表标题
    @subTitle：报表子标题
    @chartlabs: 报表数据的标签集合
    @chartdata：报表数据集合
    @darkTheme: 报表皮肤类型（True表示为深底白字，false表示白底深字），默认为True
    @chartLegend：图例名称集合
  */
  constructor(title = '漏斗图', subtitle, chartdata, darkTheme, chartLegend = []) {
    this.title = {
      text: title,
      // subtext: subtitle,
      textStyle: {
        align: 'center',
        color: darkTheme ? lightColor : darkColor,
        fontSize: 24,
        fontWeight: '700'
      },
      subtextStyle: {
        fontSize: 18,
        fontWeight: 100
      },
      padding: [30, 0, 0, 30]
    };
    if (subtitle) {
      this.title.subtext = subtitle;
    }
    this.tooltip = {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c}%'
    };
    this.toolbox = {
      show: true,
      bottom: '5%',
      right: '5%',
      itemGap: 20,
      iconStyle: {
        color: darkTheme ? lightColor : darkColor,
        textPosition: 'top'
      },
      feature: {
        dataView: {
          readOnly: false
        },
        saveAsImage: {}
      }
    };
    this.legend = {
      data: chartLegend,
      top: '10%',
      textStyle: {
        color: darkTheme ? lightColor : darkColor
      },
      inactiveColor: '#999'
    };
    this.calculable = false;
    this.series = [{
      name: title,
      type: 'funnel',
      left: '10%',
      top: '20%',
      bottom: '10%',
      width: '80%',
      height: '70%',
      min: 0,
      max: 100,
      minSize: '0%',
      maxSize: '100%',
      sort: 'descending',
      gap: 0,
      label: {
        normal: {
          show: true,
          position: 'inside'
        },
        emphasis: {
          textStyle: {
            fontSize: 20
          }
        }
      },
      labelLine: {
        normal: {
          length: 10,
          lineStyle: {
            width: 1,
            type: 'solid'
          }
        }
      },
      itemStyle: {
        normal: {
          borderWidth: 0
        }
      },
      data: chartdata
    }];
  }
}
