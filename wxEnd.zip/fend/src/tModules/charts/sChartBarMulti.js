// 柱状图数据模型
import mainColor from './mainColor';
let _colorSet = ['#003366', '#C23531', '#4CABCE'];
let labelOption = {
  normal: {
    show: false,
    position: 'insideBottom',
    distance: 15,
    align: 'left',
    verticalAlign: 'middle',
    rotate: 90,
    formatter: '{c}  {name|{a}}',
    fontSize: 12,
    rich: {
      name: {
        textBorderColor: '#666'
      }
    }
  }
};

export default class SchartBar {
  /*
    @title：报表标题
    @subTitle：报表子标题
    @chartlabs: 报表数据的标签集合
    @chartdata：报表数据集合
    @darkTheme: 报表皮肤类型（True表示为深底白字，false表示白底深字），默认为True,
    @chartAxis：轴系列名称（如果为横向柱图，则表示X轴维度，否则表示Y轴维度
  */
  constructor(title = '集合柱状图', subtitle, chartdata, chartLegend, xAxis) {
    this.color = _colorSet;
    // 标题组件，包含主标题和副标题。
    this.title = {
      text: title,
      subtext: subtitle,
      top: -20,
      textStyle: {
        align: 'left',
        color: '#333',
        fontSize: 14,
        fontWeight: '700'
      },
      subtextStyle: {
        fontSize: 10,
        fontWeight: 500,
        color: mainColor
      },
      padding: [30, 0, 0, 30]
    };
    this.tooltip = {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    };
    this.legend = {
      show: chartLegend && chartLegend.length > 0,
      data: chartLegend,
      top: '20px',
      right: '20px',
      textStyle: {
        fontSize: 12,
        fontWeight: '100',
        color: mainColor
      },
      inactiveColor: '#999'
    };
    this.calculable = true;
    this.xAxis = [{
      type: 'category',
      axisTick: {
        show: false
      },
      data: xAxis
    }];
    this.yAxis = [{
      type: 'value'
    }];
    let _data = [];
    chartLegend.forEach((v, k, arr) => {
      let _val = {
        name: v,
        type: 'bar',
        barGap: 0,
        label: labelOption,
        data: []
      };
      chartdata.forEach((vd, kd, arrd) => {
        _val.data.push(vd[k]);
      });
      _data.push(_val);
    });
    this.series = _data;
  }
}
