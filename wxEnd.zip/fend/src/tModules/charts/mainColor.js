let mainColor = '#6A6B9A';
export default mainColor;
