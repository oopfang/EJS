// const defaultGridColor = 'rgba(246, 246, 246, .2)';
const darkColor = '#000';
const lightColor = '#FFF';
// 图表类型： 【0:柱状图、1:漏斗图、2:折线图、3:地图、4:饼图、5:南丁格尔玫瑰图、6:雷达图、7:旭日图】;
let _chartType = ['bar', 'funnel', 'line', 'map', 'pie', 'rose', 'radar', 'sunburst'];
let _chartTypeName = ['柱状图', '漏斗图', '折线图', '地图', '饼图', '南丁格尔玫瑰图', '雷达图', '旭日图'];
// 对传入的图表数据有效性进行校验
let verifiData = {
  barDataCheck: data => {
    return Array.isArray(data);
  },
  funnelDataCheck: data => {
    return Array.isArray(data);
  },
  lineDataCheck: data => {
    return Array.isArray(data);
  },
  mapDataCheck: data => {
    return Array.isArray(data);
  },
  pieDataCheck: data => {
    return Array.isArray(data);
  },
  roseDataCheck: data => {
    return Array.isArray(data);
  },
  radarDataCheck: data => {
    return Array.isArray(data);
  },
  sunburstDataCheck: data => {
    return Array.isArray(data);
  }
};
let demoData = {
  barDemo: {
    axis: ['演示-1', '演示-2', '演示-3', '演示-4', '演示-5'],
    data: [{
      name: '主题1',
      value: [698, 1300, 2000, 1530, 1210]
    }]
  },
  funnelDemo: {
    legend: ['模拟数据1', '模拟数据2', '模拟数据3', '模拟数据4', '模拟数据5'],
    data: [{
      name: '主题1',
      value: [{
          value: 60,
          name: '模拟数据3'
        },
        {
          value: 40,
          name: '模拟数据4'
        },
        {
          value: 20,
          name: '模拟数据5'
        },
        {
          value: 80,
          name: '模拟数据2'
        },
        {
          value: 100,
          name: '模拟数据1'
        }
      ]
    }]
  },
  lineDemo: {
    axis: ['演示数据1', '演示数据2', '演示数据3', '演示数据4', '演示数据5', '演示数据6', '演示数据7'],
    data: [{
      name: '主题',
      value: [10, 7, 12, 15, 5, 13, 9]
    }]
  }
};

export default function getChartDefine(templateDefine, chartDataSet, option) {
  if (templateDefine) {
    // 生成控制参数项
    let _currOption = {
      // 报表类型
      chartType: (option && option.chartType) ? option.chartType : _chartType[0],
      // // 报表标题
      // chartTitle:
      // 是否以演示数据进行展示
      /* eslint-disable no-undefined */
      showDemo: (option && option.showDemo !== undefined) ? option.showDemo : true,
      // 是否采用深系皮肤主题
      darkTheme: (option && option.darkTheme !== undefined) ? option.darkTheme : true
    };
    // 创建图表标题
    if (!option || !option.chartTitle) {
      let _defaultTypeIdx = _chartType.findIndex(v => v === _currOption.chartType);
      _currOption.chartTitle = _chartTypeName[_defaultTypeIdx];
    } else {
      _currOption.chartTitle = option.chartTitle;
    }
    let _dataValid = false;
    if (!_currOption.showDemo) {
      if (chartDataSet) {
        _dataValid = verifiData[`${_currOption.chartType}DataCheck`](chartDataSet);
      }
    }
    // 创建图表副标题
    if (!_dataValid) {
      _currOption.subTitle = '目前为演示数据';
    } else {
      _currOption.subTitle = (option && option.subTitle) ? option.subTitle : '';
    }
    let x = templateDefine();
    let _color = _currOption.darkTheme ? lightColor : darkColor;
    x.title.text = _currOption.chartTitle;
    x.title.subtext = _currOption.subTitle;
    x.title.textStyle.color = _color;
    x.toolbox.iconStyle.color = _color;
    if (_currOption.chartType === 'bar') {
      x.xaxis.axisLine.color = _color;
      x.xaxis.nameTextStyle.color = _color;
      x.xaxis.data = _dataValid ? chartDataSet.axis : demoData.barDemo.axis;
      x.yaxis = x.yaxis.map(v => {
        v.axisLine.color = _color;
        v.splitLine.lineStyle.color = _color;
        return v;
      });
    } else if (_currOption.chartType === 'funnel') {
      x.legend.textStyle.color = _color;
      x.legend.data = _dataValid ? chartDataSet.legend : demoData[`${_currOption.chartType}Demo`].legend;
    } else if (_currOption.chartType === 'line') {
      x.color = option && option.color ? option.color : ['#1E1E1E'];
      x.xaxis.nameTextStyle.color = _color;
      x.xaxis.axisLabel.color = _color;
      x.xaxis.axisLine.lineStyle.color = _color;
      x.xaxis.data = _dataValid ? chartDataSet.axis : demoData.barDemo.axis;
    }

    let _dt = _dataValid ? chartDataSet.data : demoData[`${_currOption.chartType}Demo`].data;
    x.series = _dt.map((v, k, arr) => {
      let _ser = JSON.parse(JSON.stringify(x.series[0]));
      _ser.name = v.name;
      _ser.data = v.value;
      return _ser;
    });
    return x;
  } else {
    throw new Error('没有为图表加载模板定义');
  }
}
