// 南丁格尔数据模型
// import mainColor from './mainColor';
const itemColor = '#EE975B';

export default class SchartPie {
  /*
    @title：报表标题
    @subTitle：报表子标题
    @chartlabs: 报表数据的标签集合
    @chartdata：报表数据集合
    @darkTheme: 报表皮肤类型（ True表示为深底白字， false表示白底深字）， 默认为True
    @chartLegend： 图例名称集合
  */
  constructor(title = '报表', subtitle, chartdata, chartLegend = [], darkTheme = false) {
    this.backgroundColor = 'transparent';

    this.title = {
      text: title,
      subtext: subtitle,
      top: -20,
      left: 'left',
      textStyle: {
        color: '#888'
      }
    };

    this.tooltip = {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    };

    // 图例组件。
    this.legend = {
      show: chartLegend && chartLegend.length > 0,
      data: chartLegend,
      top: '20px',
      right: '20px',
      textStyle: {
        fontSize: 12,
        fontWeight: '700',
        color: itemColor
      },
      inactiveColor: '#999'
    };

    this.visualMap = {
      show: false,
      min: 80,
      max: 600,
      inRange: {
        colorLightness: [0, 1]
      }
    };
    /* eslint-disable quotes */
    this.series = [{
      name: title,
      type: 'pie',
      radius: '55%',
      center: ['50%', '60%'],
      data: chartdata.sort(function (a, b) {
        return a.value - b.value;
      }),
      roseType: 'radius',
      label: {
        normal: {
          textStyle: {
            color: '#000'
          },
          formatter: `{b}\n{c}`
        }
      },
      labelLine: {
        normal: {
          lineStyle: {
            color: 'rgba(0, 0, 0, 0.3)'
          },
          smooth: 0.2,
          length: 10,
          length2: 20
        }
      },
      itemStyle: {
        normal: {
          color: itemColor,
          shadowBlur: 200,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      },

      animationType: 'scale',
      animationEasing: 'elasticOut',
      animationDelay: function (idx) {
        return Math.random() * 200;
      }
    }];
  }
}
