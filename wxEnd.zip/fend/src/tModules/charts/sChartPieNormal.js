// 饼状图数据模型
import mainColor from './mainColor';

export default class SchartBar {
  /*
    @title：报表标题
    @subTitle：报表子标题
    @chartlabs: 报表数据的标签集合
    @chartdata：报表数据集合
    @darkTheme: 报表皮肤类型（ True表示为深底白字， false表示白底深字）， 默认为True
    @chartLegend： 图例名称集合
  */
  constructor(title = '饼状图', subtitle, chartdata, chartLegend = []) {
    this.backgroundColor = 'transparent';
    // 标题组件，包含主标题和副标题。
    this.title = {
      text: title,
      subtext: subtitle,
      top: -20,
      textStyle: {
        align: 'left',
        color: '#333',
        fontSize: 14,
        fontWeight: '700'
      },
      subtextStyle: {
        fontSize: 10,
        fontWeight: 500,
        color: mainColor
      },
      padding: [30, 0, 0, 30]
    };
    this.tooltip = {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    };
    this.legend = {
      show: chartLegend && chartLegend.length > 0,
      data: chartLegend,
      top: '20px',
      right: '20px',
      textStyle: {
        fontSize: 12,
        fontWeight: '100',
        color: mainColor
      },
      inactiveColor: '#999'
    };
    /* eslint-disable quotes */
    this.series = [{
      name: title,
      type: 'pie',
      radius: '55%',
      center: ['50%', '60%'],
      label: {
        normal: {
          textStyle: {
            color: 'rgba(0, 0, 0, 0.8)'
          },
          formatter: `{b}\n{c}`
        }
      },
      data: chartdata,
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }];
  }
}
