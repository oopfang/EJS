export default () => {
  return {
    color: ['#2B982D'],
    title: {
      text: '',
      subtext: '',
      textStyle: {
        align: 'center',
        color: '#FFF',
        fontSize: 24,
        fontWeight: '700'
      },
      subtextStyle: {
        fontSize: 18,
        fontWeight: '100'
      },
      padding: [30, 0, 0, 30]
    },
    tooltip: {
      // 坐标轴指示器，坐标轴触发有效
      axisPointer: {
        // 默认为直线，可选为：'line' | 'shadow'
        type: 'shadow'
      },
      show: false,
      trigger: 'axis'
    },
    toolbox: {
      show: true,
      bottom: '5%',
      right: '5%',
      itemGap: 20,
      iconStyle: {
        color: '#FFF',
        textPosition: 'top'
      },
      feature: {
        dataZoom: {
          yAxisIndex: 'none'
        },
        dataView: {
          readOnly: false
        },
        magicType: {
          type: ['bar', 'line']
        },
        restore: {},
        saveAsImage: {}
      }
    },
    xaxis: {
      data: [],
      name: 'X轴',
      axisLine: {
        show: true,
        lineStyle: {
          color: '#000'
        }
      },
      type: 'category',
      boundaryGap: false,
      nameLocation: 'end',
      nameTextStyle: {
        color: '#000',
        fontSize: 12
      },
      axisLabel: {
        color: '#000',
        fontSize: 14
      }
    },
    yaxis: {
      type: 'value',
      name: 'Y轴',
      nameTextStyle: {
        color: '#000',
        fontSize: 12
      },
      splitLine: {
        // 是否显示y轴上的网格线
        show: true,
        lineStyle: {
          // 网格线颜色
          color: 'rgba(246, 246, 246, .2)',
          width: 1,
          type: 'solid'
        }
      },
      axisLabel: {
        color: '#000',
        fontSize: 14
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: '#000'
        }
      }
    },
    grid: {
      top: '20%',
      bottom: '15%'
    },
    series: [{
      name: '主题',
      type: 'bar',
      data: [],
      legend: {
        data: [],
        top: '5%',
        textStyle: {
          color: '#FFF'
        },
        inactiveColor: '#999'
      },
      calculable: false,
      color: ['#2B982D'],
      backgroundColor: '#2c343c',
      visualMap: {
        show: false,
        min: 80,
        max: 400,
        inRange: {
          colorLightness: [0, 1]
        }
      },
      radar: {
        indicator: []
      }
    }]
  };
};
