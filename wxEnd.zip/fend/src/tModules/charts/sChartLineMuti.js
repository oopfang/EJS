// 折线图数据模型
import mainColor from './mainColor';

export default class SchartLine {
  /*
    @title：报表标题
    @subTitle：报表子标题
    @chartlabs: 报表数据的标签集合
    @chartdata：报表数据集合
    @darkTheme: 报表皮肤类型（ True表示为深底白字， false表示白底深字）， 默认为True
    @chartAxis： 轴系列名称（ 如果为横向柱图， 则表示X轴维度， 否则表示Y轴维度
  */
  constructor(title = '多维折线图', subtitle, chartdata, chartLegend) {
    this.color = ['#2B982D'];
    // 标题组件，包含主标题和副标题。
    this.title = {
      text: title,
      subtext: subtitle,
      top: -20,
      textStyle: {
        align: 'left',
        color: '#333',
        fontSize: 14,
        fontWeight: '700'
      },
      subtextStyle: {
        fontSize: 10,
        fontWeight: 500,
        color: mainColor
      },
      padding: [30, 0, 0, 30]
    };
    this.tooltip = {
      trigger: 'axis',
      // 坐标轴指示器，坐标轴触发有效
      axisPointer: {
        snap: true,
        // 默认为直线，可选为：'line' | 'shadow'
        type: 'cross',
        crossStyle: {
          color: 'red'
        }
      }
    };
    this.legend = {
      data: chartLegend
    };
    this.xAxis = {
      type: 'category',
      data: chartdata.xAxis
    };
    this.yAxis = {
      type: 'value'
    };
    this.series = chartdata.vals;
  }
}
