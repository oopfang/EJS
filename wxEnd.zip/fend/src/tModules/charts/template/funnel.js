export default () => {
  let x = {};
  x.title = {
    // text: title,
    // subtext: verifiData(chartdata) ? subtitle : '未提供，或提供的数据无效，自动调用演示数据',
    textStyle: {
      align: 'center',
      // color: darkTheme ? lightColor : darkColor,
      fontSize: 24,
      fontWeight: '700'
    },
    subtextStyle: {
      fontSize: 18,
      fontWeight: 100
    },
    padding: [30, 0, 0, 30]
  };
  x.tooltip = {
    trigger: 'item',
    formatter: '{a} <br/>{b} : {c}%'
  };
  x.toolbox = {
    show: true,
    bottom: '5%',
    right: '5%',
    itemGap: 20,
    iconStyle: {
      // color: darkTheme ? lightColor : darkColor,
      textPosition: 'top'
    },
    feature: {
      dataView: {
        readOnly: false
      },
      saveAsImage: {}
    }
  };
  x.legend = {
    // data: chartLegend,
    top: '10%',
    textStyle: {
      // color: darkTheme ? lightColor : darkColor
    },
    inactiveColor: '#999'
  };
  x.calculable = false;
  x.series = [{
    // name: title,
    type: 'funnel',
    left: '10%',
    top: '20%',
    bottom: '10%',
    width: '80%',
    height: '70%',
    min: 0,
    max: 100,
    minSize: '0%',
    maxSize: '100%',
    sort: 'descending',
    gap: 0,
    label: {
      normal: {
        show: true,
        position: 'inside'
      },
      emphasis: {
        textStyle: {
          fontSize: 20
        }
      }
    },
    labelLine: {
      normal: {
        length: 10,
        lineStyle: {
          width: 1,
          type: 'solid'
        }
      }
    },
    itemStyle: {
      normal: {
        borderWidth: 0
      }
    }
    // data: verifiData(chartdata) ? chartdata : demoData
  }];
  return x;
};
