export default () => {
  let x = {};
  x.title = {
    // text: options.chartTitle,
    // subtext: options.subTitle,
    textStyle: {
      align: 'center',
      // color: options.darkTheme ? lightColor : darkColor,
      fontSize: 24,
      fontWeight: '700'
    },
    subtextStyle: {
      fontSize: 18,
      fontWeight: 100
    },
    padding: [30, 0, 0, 30]
  };
  x.tooltip = {
    trigger: 'axis',
    // 坐标轴指示器，坐标轴触发有效
    axisPointer: {
      // 默认为直线，可选为：'line' | 'shadow'
      type: 'shadow'
    }
  };
  x.toolbox = {
    show: true,
    bottom: '5%',
    right: '5%',
    itemGap: 20,
    iconStyle: {
      // color: options.darkTheme ? lightColor : darkColor,
      textPosition: 'top'
    },
    feature: {
      dataZoom: {
        yAxisIndex: 'none'
      },
      dataView: {
        readOnly: false
      },
      magicType: {
        type: ['bar', 'line']
      },
      restore: {},
      saveAsImage: {}
    }
  };
  // 直角坐标系 grid 中的 x 轴，一般情况下单个 grid 组件最多只能放上下两个 x 轴，
  // 多于两个 x 轴需要通过配置 offset 属性防止同个位置多个 x 轴的重叠。
  x.xaxis = {
    // data: _dataValid ? chartDataSet.axis : demoData.barDemo.axis,
    name: 'X轴',
    nameLocation: 'end',
    // 坐标轴轴线相关设置
    axisLine: {
      show: true,
      lineStyle: {
        // color: options.darkTheme ? lightColor : darkColor
      }
    },
    nameTextStyle: {
      // color: options.darkTheme ? lightColor : darkColor,
      fontSize: 12
    }
  };
  // 直角坐标系 grid 中的 y 轴，一般情况下单个 grid 组件最多只能放左右两个 y 轴，
  // 多于两个 y 轴需要通过配置 offset 属性防止同个位置多个 Y 轴的重叠。
  x.yaxis = [{
    type: 'value',
    name: 'Y轴',
    // 坐标轴轴线相关设置
    axisLine: {
      show: true,
      lineStyle: {
        // color: options.darkTheme ? lightColor : darkColor
      }
    },
    // 网格线的格式
    splitLine: {
      // 是否显示y轴上的网格线
      show: true,
      lineStyle: {
        // 网格线颜色
        // color: defaultGridColor,
        // 网格线宽度
        width: 1,
        // 网格线样式
        type: 'solid'
      }
    }
  }]; // 直角坐标系内绘图网格，单个 grid 内最多可以放置上下两个 X 轴，左右两个 Y 轴。
  // 可以在网格上绘制折线图，柱状图，散点图（气泡图）。
  x.grid = {
    // show: true,
    top: x.title.subtext === '' ? '10%' : '20%',
    left: '10%',
    right: '10%',
    bottom: '10%',
    containLabel: true
  };
  x.series = [{
    // name: '主题',
    type: 'bar',
    itemStyle: {
      normal: {
        /* eslint-disable no-undef */
        color: new echarts.graphic.LinearGradient(
          0, 0, 0, 1,
          [{
              offset: 0,
              color: '#83bff6'
            },
            {
              offset: 0.5,
              color: '#188df0'
            },
            {
              offset: 1,
              color: '#188df0'
            }
          ]
        )
      },
      emphasis: {
        /* eslint-disable no-undef */
        color: new echarts.graphic.LinearGradient(
          0, 0, 0, 1,
          [{
              offset: 0,
              color: '#2378f7'
            },
            {
              offset: 0.7,
              color: '#2378f7'
            },
            {
              offset: 1,
              color: '#83bff6'
            }
          ]
        )
      }
    },
    // data: _dataValid ? chartDataSet.data : demoData[`${options.chartType}Demo`].data,
    markLine: {
      lineStyle: {
        color: 'red'
      },
      data: [{
        type: 'average',
        name: '平均值'
      }]
    }
  }];
  return x;
};
