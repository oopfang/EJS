export default () => {
  let x = {};
  // x.color = ['#1E1E1E'];
  // 标题组件，包含主标题和副标题。
  x.title = {
    // text: title,
    // subtext: verifiData(chartdata) ? subtitle : '未提供，或提供的数据无效，自动调用演示数据',
    textStyle: {
      align: 'center',
      // color: darkTheme ? lightColor : darkColor,
      fontSize: 24,
      fontWeight: '700'
    },
    subtextStyle: {
      fontSize: 18,
      fontWeight: 100
    },
    padding: [30, 0, 0, 30]
  };
  x.tooltip = {
    trigger: 'axis',
    // 坐标轴指示器，坐标轴触发有效
    axisPointer: {
      snap: true,
      // 默认为直线，可选为：'line' | 'shadow'
      type: 'cross',
      crossStyle: {
        color: 'red'
      }
    }
  };
  x.toolbox = {
    show: true,
    bottom: '5%',
    right: '5%',
    itemGap: 20,
    iconStyle: {
      // color: darkTheme ? lightColor : darkColor,
      textPosition: 'top'
    },
    feature: {
      dataZoom: {
        yAxisIndex: 'none'
      },
      dataView: {
        readOnly: false
      },
      magicType: {
        type: ['line', 'bar']
      },
      restore: {},
      saveAsImage: {}
    }
  };
  x.grid = {
    top: '20%',
    bottom: '15%'
  };
  x.xaxis = {
    type: 'category',
    boundaryGap: false,
    // data: chartAxis,
    name: 'X轴',
    nameLocation: 'end',
    nameTextStyle: {
      // color: darkTheme ? lightColor : darkColor,
      fontSize: 12
    },
    axisLabel: {
      // color: darkTheme ? lightColor : darkColor,
      fontSize: 14
    },
    // 坐标轴轴线相关设置
    axisLine: {
      show: true,
      lineStyle: {
        // color: darkTheme ? '#3398DB' : darkColor
      }
    }
  };
  x.yaxis = {
    type: 'value',
    name: 'Y轴',
    nameTextStyle: {
      // color: darkTheme ? lightColor : darkColor,
      fontSize: 12
    },
    // 网格线的格式
    splitLine: {
      // 是否显示y轴上的网格线
      show: true,
      lineStyle: {
        // 网格线颜色
        // color: defaultGridColor,
        // 网格线宽度
        width: 1,
        // 网格线样式
        type: 'solid'
      }
    },
    axisLabel: {
      // color: darkTheme ? lightColor : darkColor,
      fontSize: 14
    },
    // 坐标轴轴线相关设置
    axisLine: {
      show: true,
      lineStyle: {
        // color: darkTheme ? '#3398DB' : darkColor
      }
    }
  };
  x.series = [{
    name: '主题',
    type: 'line',
    // data: verifiData(chartdata) ? chartdata : demoData,
    markLine: {
      lineStyle: {
        color: 'red'
      },
      data: [{
        type: 'average',
        name: '平均值'
      }]
    }
  }];
  return x;
};
