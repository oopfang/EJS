// 雷达图数据模型
const darkColor = '#000';
const lightColor = '#FFF';


export default class Schartfunnel {
  /*
    @title：报表标题
    @subTitle：报表子标题
    @chartlabs: 报表数据的标签集合
    @chartdata：报表数据集合
    @darkTheme: 报表皮肤类型（ True表示为深底白字， false表示白底深字）， 默认为True
    @chartLegend： 图例名称集合
    @chartIndicator：轴量指示器（代表各个轴的最大值）
  */
  constructor(title = '雷达图', subtitle, chartdata, darkTheme = true, chartLegend, chartIndicator) {
    this.title = {
      text: title,
      // subtext: subtitle,
      textStyle: {
        align: 'center',
        color: darkTheme ? lightColor : darkColor,
        fontSize: 24,
        fontWeight: '700'
      },
      subtextStyle: {
        fontSize: 18,
        fontWeight: 100
      },
      padding: [30, 0, 0, 30]
    };
    if (subtitle) {
      this.title.subtext = subtitle;
    }
    this.tooltip = {
      show: false
    };
    this.toolbox = {
      show: true,
      bottom: '5%',
      right: '5%',
      itemGap: 20,
      iconStyle: {
        color: darkTheme ? lightColor : darkColor,
        textPosition: 'top'
      },
      feature: {
        dataView: {
          readOnly: false
        },
        saveAsImage: {}
      }
    };
    this.legend = {
      data: chartLegend,
      top: '5%',
      textStyle: {
        color: darkTheme ? lightColor : darkColor
      },
      inactiveColor: '#999'
    };
    this.radar = {
      indicator: chartIndicator
      // indicator: [{
      //     name: '模拟数据1',
      //     max: 6500,
      //     color: darkTheme ? lightColor : darkColor
      //   },
      //   {
      //     name: '模拟数据2',
      //     max: 16000,
      //     color: darkTheme ? lightColor : darkColor
      //   },
      //   {
      //     name: '模拟数据3',
      //     max: 30000,
      //     color: darkTheme ? lightColor : darkColor
      //   },
      //   {
      //     name: '模拟数据4',
      //     max: 38000,
      //     color: darkTheme ? lightColor : darkColor
      //   },
      //   {
      //     name: '模拟数据5',
      //     max: 25000,
      //     color: darkTheme ? lightColor : darkColor
      //   }
      // ]
    };
    this.series = [{
      // name: '预算 vs 开销（Budget vs spending）',
      type: 'radar',
      data: chartdata
      // data: [{
      //     value: [4300, 10000, 28000, 35000, 19000],
      //     name: '系列1',
      //     lineStyle: {
      //       color: 'yellow'
      //     }
      //   },
      //   {
      //     value: [5000, 14000, 28000, 31000, 21000],
      //     name: '系列2',
      //     lineStyle: {
      //       color: '#188DF0'
      //     }
      //   }
      // ]
    }];
  }
}
