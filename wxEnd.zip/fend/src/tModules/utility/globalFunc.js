import enumObj from 'tframe-enum';
import {
  tLog,
  infoLog,
  warnLog,
  errLog,
  tLoading
} from './fendLog';
import {
  getFunc,
  postFunc,
  putFunc,
  deleteFunc
} from './api';

/* 预清理请求数据
   @data：需要预处理的原始数据
   @newId: 如果提供，则会将 data参数中的每一项的 pid 替换为该值
*/
let preReqData = (data, newPid) => {
  /* eslint-disable no-unused-vars */
  if (Array.isArray(data)) {
    let _arr = [];
    for (let v of data) {
      let {
        $unSave,
        ...otherData
      } = v;
      if (newPid) {
        otherData.pid = newPid;
      }
      _arr.push(otherData);
    }
    return _arr;
  } else {
    let {
      $unSave,
      ...otherData
    } = data;
    if (newPid) {
      otherData.pid = newPid;
    }
    return otherData;
  }
};

// 获取当前时间的已格式化字符串
let getNowStr = () => {
  /* eslint-disable no-undef */
  return dayjs().format(enumObj.sys.dateFormatStr.strDateTime);
};

// 获取CRUD表单的编辑视图定义简集
let getBaseDefine = (def) => {
  let _arr = [];
  if (def.intro) {
    _arr.push({
      idx: 0,
      ident: def.intro.code,
      code: def.intro.code,
      namezh: def.intro.namezh
    });
    if (def.subs) {
      let i = 1;
      for (let v of Object.keys(def.subs)) {
        _arr.push({
          idx: i,
          ident: v,
          code: def.subs[v].intro.code,
          namezh: def.subs[v].intro.namezh
        });
        i++;
      }
    }
  }
  return _arr;
};

// 全局前端日志引擎
global.tlog = tLog;
global.tinfo = infoLog;
global.twarn = warnLog;
global.terr = errLog;
global.tloading = tLoading;
global.getFunc = getFunc;
global.postFunc = postFunc;
global.putFunc = putFunc;
global.deleteFunc = deleteFunc;
// 格式化请求参数中的 data 数据集
global.preReqData = preReqData;
// 获取格式化后的当前时间
global.getNowStr = getNowStr;
// 获取CRUD表单的编辑视图定义简集
global.getBaseDefine = getBaseDefine;
