let conf = require('@/config/config.json');
let db = null;

// 创建缓存库
let creatDb = () => {
    return new Promise((resolve, reject) => {
        let _ver = conf.localDbVer || 1;
        let openRequest = indexedDB.open(conf.appName, _ver);
        openRequest.onupgradeneeded = e => {
            let tbls = conf.bizObjects;
            let _db = e.target.result;
            tbls.forEach((v, k, arr) => {
                if (!_db.objectStoreNames.contains(v)) {
                    _db.createObjectStore(v, {
                        keyPath: 'id'
                    });
                }
            });
        };
        openRequest.onsuccess = e => {
            db = e.target.result;
            resolve(db);
        };
        openRequest.onerror = err => {
            reject(err);
        };
    });
};

// 关闭缓存库
let closeDb = () => {
    db.close();
};

// 删除缓存库
let delDb = () => {
    let res = db.deleteDatabase(conf.appName);
    res.onerror = e => {
        global.terr(`数据库删除失败，原因：${e.target.message}`);
    };
    res.onsuccess = e => {
        global.tinfo('数据库删除成功');
    };
};

// 写缓存
let addData = (key, val) => {
    return new Promise((resolve, reject) => {
        if (!val) {
            reject(new Error('没有提供待插入的数据'));
        } else {
            if (!db) {
                creatDb()
                    .then(res => {
                        let t = db.transaction(key, 'readwrite');
                        let s = t.objectStore(key);
                        if (Array.isArray(val)) {
                            val.forEach((v, k, arr) => {
                                s.add(v);
                            });
                        } else {
                            s.add(val);
                        }
                        resolve();
                    })
                    .catch(err => {
                        reject(err);
                    });
            } else {
                let t = db.transaction(key, 'readwrite');
                let s = t.objectStore(key);
                if (Array.isArray(val)) {
                    val.forEach((v, k, arr) => {
                        s.add(v);
                    });
                } else {
                    s.add(val);
                }
                resolve();
            }
        }
    });
};

// 更新缓存
let upData = (key, val) => {
    return new Promise((resolve, reject) => {
        if (!val) {
            reject(new Error('没有提供待更新的数据'));
        } else {
            if (!db) {
                creatDb()
                    .then(res => {
                        let t = db.transaction(key, 'readwrite');
                        let s = t.objectStore(key);
                        if (Array.isArray(val)) {
                            val.forEach((v, k, arr) => {
                                s.put(v);
                            });
                        } else {
                            s.put(val);
                        }
                        resolve();
                    })
                    .catch(err => {
                        reject(err);
                    });
            } else {
                let t = db.transaction(key, 'readwrite');
                let s = t.objectStore(key);
                if (Array.isArray(val)) {
                    val.forEach((v, k, arr) => {
                        s.put(v);
                    });
                } else {
                    s.put(val);
                }
                resolve();
            }
        }
    });
};

// 读取指定ID的缓存
let getData = (key, id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
            reject(new Error('没有指定ID'));
        } else {
            if (!db) {
                reject(new Error('没有缓存数据'));
            } else {
                let t = db.transaction(key, 'readwrite');
                let s = t.objectStore(key);
                if (!s) {
                    reject(new Error('指定的key不存在'));
                } else {
                    let val = s.get(id);
                    val.onsuccess = e => {
                        resolve(e.target.result);
                    };
                    val.onerror = err => {
                        reject(err);
                    };
                }
            }
        }
    });
};

// 读取指定objectStore下的所有记录
let getList = key => {
    return new Promise((resolve, reject) => {
        if (!db) {
            reject(new Error('没有缓存数据'));
        } else {
            let t = db.transaction(key, 'readwrite');
            let s = t.objectStore(key);
            if (!s) {
                reject(new Error('指定的key不存在'));
            } else {
                let cursor = s.openCursor();
                let _arr = [];
                cursor.onsuccess = e => {
                    let res = e.target.result;
                    if (res) {
                        _arr.push(res.value);
                        res.continue();
                    }
                    resolve(_arr);
                };
                cursor.onerror = err => {
                    reject(err);
                };
            }
        }
    });
};

// 删除指定缓存
let delData = (key, id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
            reject(new Error('没有指定ID'));
        } else {
            if (!db) {
                resolve();
            } else {
                let t = db.transaction(key, 'readwrite');
                let s = t.objectStore(key);
                if (!s) {
                    reject(new Error('指定的key不存在'));
                } else {
                    let val = s.delete(id);
                    val.onsuccess = e => {
                        resolve();
                    };
                    val.onerror = err => {
                        reject(err);
                    };
                }
            }
        }
    });
};

// 删除指定objectStore下的所有记录
let delList = key => {
    return new Promise((resolve, reject) => {
        if (!db) {
            resolve();
        } else {
            let t = db.transaction(key, 'readwrite');
            let s = t.objectStore(key);
            if (!s) {
                reject(new Error('指定的key不存在'));
            } else {
                let cursor = s.openCursor();
                cursor.onsuccess = e => {
                    let res = e.target.result;
                    if (res) {
                        res.delete();
                        res.continue();
                    }
                    resolve();
                };
                cursor.onerror = err => {
                    reject(err);
                };
            }
        }
    });
};

export default {
    addData,
    upData,
    getData,
    getList,
    delData,
    closeDb,
    delDb,
    delList
};
