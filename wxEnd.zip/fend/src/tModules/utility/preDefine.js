import {
  preView
} from 'tframe-prefend';

let rFunc = r => {
  let _arr = r.keys().sort((a, b) => {
    return a.localeCompare(b, 'zh-Hans-CN', {
      sensitivity: 'variant'
    });
  });
  let _resObj = {};
  _arr.forEach((v, k, arr) => {
    let L1 = v.split('.')[1];
    let L2 = L1.split('/');
    L2.splice(0, 1);
    if (L2.length === 2) {
      let _bizId = L2[0];
      _resObj[_bizId] = {};
      _resObj[_bizId][L2[1]] = r(v).default;
    } else if ((L2.length === 4) && (L2[1] === 'subs')) {
      let _pOjb = _resObj[L2[0]];
      let _subKey = L2[1];
      if (!_pOjb[_subKey]) {
        _pOjb[_subKey] = {};
      }
      let x = {};
      x[L2[3]] = r(v).default;
      _pOjb[_subKey][L2[2]] = x;
    }
  });
  return _resObj;
};

export default subject => {
  let resS = rFunc(subject);
  return preView(resS);
};
