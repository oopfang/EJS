/* eslint-disable */
let Tdate = globalThis.smpoo.Tdate;

// 各个维度的长度定义
const _lenDef = {
	fromCustId: 10,
	prodId: 4,
	spec: 2,
	size: 2,
	dateCheck: 14,
	opteratorId: 2,
	state: 2
};

// 各个维度在全码状态时的格式化有序定义
const _formatDef = [
	// fromCustId - index === 0
	val => `${val}`.padStart(_lenDef.fromCustId, '0'),
	// prodId - index === 1
	val => `${val}`.padStart(_lenDef.prodId, '0'),
	// spec - index === 2
	val => `${val}`.padStart(_lenDef.spec, '0'),
	// size - index === 3
	val => `${val}`.padStart(_lenDef.size, '0'),
	// dateCheck - index === 4
	val => (new Tdate(val)).format('YYYYMMDDHHmmss'),
	// opteratorId - index === 5
	val => `${val}`.padStart(_lenDef.opteratorId, '0'),
	// state - index === 6
	val => `${val}`.padStart(_lenDef.state, '0')
];

/** 创建唯一码
 * 
 * @param { Object } obj 用于创建唯一码的信息载荷
 */
let _getUud = obj => {
	let { fromCustId, prodId, spec, size, dateCheck, opteratorId, state } = obj;
	if (!fromCustId || !prodId || !spec || !size || !dateCheck || !opteratorId || !state) throw new Error('唯一码的构建维度不齐全');
	let _uudStr = [fromCustId, prodId, spec, size, dateCheck, opteratorId, state].map((v, k) => {
		return _formatDef[k](v);
	}).join('');

	return _uudStr;
};

/** 唯一码压缩
 * 
 * @param { String } codeStr 待压缩的唯一码字符串
 * @return { Object } { pubKey, prvKey } 其中，pubKey为唯一码公钥，prvKey为唯一码私钥
 */
let _encodeUud = uudStr => {
	let _fingerArr = [];
	let _vals = [];
	let x = [...uudStr];
	while (x.length) {
		let [a, b, c] = x.splice(0, 3).map(v => parseInt(v));
		if (!a && !b && !c) {
			_fingerArr.push('*');
		} else {
			let _currV = parseInt(`${a}${b}${c}`) - (a ? a * 100 : 100);
			if (!_currV || _currV > 0) {
				_fingerArr.push(_currV);
				_vals.push(a);
			} else {
				_fingerArr.push(`${a}${b}${c}`);
			}
		}
	}
	return {
		pubKey: _vals.join(''),
		prvKey: _fingerArr.join('-')
	};
};

/** 还原唯一码
 * 
 * @param { String | Number } pubKey 唯一码公钥
 * @param { String } prvKey 唯一码私钥
 */
let _decodeUUd = (pubKey, prvKey) => {
	let _arr = prvKey.split('-');
	let _code = [...`${pubKey}`];
	let _lenDiff = _arr.filter(v => v.length < 3).length - _code.length;
	let i = 0;
	let _vals = [];
	for (let v of _arr) {
		if (v === '*') {
			_vals.push('000');
		} else if (v.length === 3) {
			_vals.push(`${v}`);
		} else if (v === '0') {
			_vals.push(`${_code[i]}00`);
			i++;
		} else {
			let _padV = v.padStart(2, '0');
			_vals.push(`${_code[i]}${_padV}`)
			i++;
		}
	}
	return _vals.join('');
};

/** 解析唯一码
 * 
 * @param { String } uudStr 完整长度的唯一码
 */
let _resolveUUd = uudStr => {
	let _arr = [...uudStr];
	let _obj = {};
	let getPart = (key, isDate) => {
		let _val = _arr.splice(0, _lenDef[key]).join('');
		let _toNum = str => {
			return str.replace(/(^2[0-9]{3})([0-9]{2})([0-9]{2})(([0-9]{2})([0-9]{2})([0-9]{2}))*/, (mat, ...$x) => {
				let [$1, $2, $3, $4, $5, $6, $7, $8, $9, $10] = $x;
				let _tm = $4 ? ` ${$5}:${$6}:${$7}` : '';
				let _ms = (_tm && $8) ? `.${$8}` : '';
				return `${$1}-${$2}-${$3}${_tm}${_ms}`;
			});
		}
		return isDate ? (new Tdate(_toNum(_val))).toString(null, true) : parseInt(_val);
	};
	_obj.fromCustId = getPart('fromCustId');
	_obj.prodId = getPart('prodId');
	_obj.spec = getPart('spec');
	_obj.size = getPart('size');
	_obj.dateCheck = getPart('dateCheck', true);
	_obj.opteratorId = getPart('opteratorId');
	_obj.state = getPart('state');
	return _obj;
};

class UudCode {
	constructor () {};

	/** 创建唯一码
	 * 
	 * @param { Object } obj 用于创建唯一码的信息载荷
	 */
	static getUud(obj) {
		return _getUud(obj);
	};

	/** 唯一码压缩
	 * 
	 * @param { String } uudStr 待压缩的唯一码字符串
	 * @return { Object } { pubKey, prvKey } 其中，pubKey为唯一码公钥，prvKey为唯一码私钥
	 */
	static encodeUud(uudStr) {
		return _encodeUud(uudStr);
	};

	/** 还原唯一码
	 * 
	 * @param { String | Number } pubKey 唯一码公钥
	 * @param { String } prvKey 唯一码私钥
	 */
	static decodeUUd(pubKey, prvKey) {
		return _decodeUUd(pubKey, prvKey);
	};

	/** 解析唯一码
	 * 
	 * @param { String } uudStr 完整长度的唯一码
	 */
	static resolveUUd(uudStr) {
		return _resolveUUd(uudStr);
	};
};

export default UudCode;
