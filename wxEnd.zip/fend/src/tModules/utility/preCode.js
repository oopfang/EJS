import { upFirst } from 'tframe-string/preString';

export default {
  install(Vue, config) {
    // 依据传入的Code字符串格式化 name，并对 code 进行长度修正
    Vue.prototype.$preCode = code => {
			if (code.length > 19) {
				let _dt = new Date();
				let _m = `${_dt.getMonth() + 1}`.padStart(2, 0);
				let _d = `${_dt.getDate()}`.padStart(2, 0);
				let _h = `${_dt.getHours()}`.padStart(2, 0);
				let _mt = `${_dt.getMinutes()}`.padStart(2, 0);
				let _s = `${_dt.getSeconds()}`.padStart(2, 0);
				let _sss = `${_dt.getMilliseconds()}`.padStart(3, 0);
				let _tmpCode = `${code.substr(0, 3)}${_dt.getFullYear()}${_m}${_d}${_h}${_mt}${_s}${_sss}`;
				return {
					code: _tmpCode,
					name: upFirst(_tmpCode)
				};
			} else {
				return {
					code,
					name: upFirst(code)
				};
			}
		};
  }
};