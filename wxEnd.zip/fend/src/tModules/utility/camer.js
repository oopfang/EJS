export default {
	start: (obj, param) => {
		let { width = 375, height = 375, audio = false } = param;
		let opt = {
			audio,
			video: {
				width: width,
				height: height
			}
		};
		navigator.mediaDevices.getUserMedia(opt)
			.then(mediaStream => {
				// let video = document.querySelector('video');
				obj.srcObject = mediaStream;
				obj.onloadedmetadata = e => {
					obj.play();
				};
			})
			.catch(function (err) {
				/* eslint-disable no-console */
				console.error(err);
				throw err;
			});
	},
	stop: obj => {
		obj.pause();
	}
};
