const keystr = '00I10l1';

// 将字符串转换为数字码数组
let strFull2int = s => {
    let str = [];
    for (let v of s) {
        str.push(v.charCodeAt(0));
    }
    return str.join(keystr);
};

// 将数字码数组转换为字符串
let intFull2Str = s => {
    let str = '';
    if (s) {
        let tmpS = s.split(keystr);
        str = String.fromCharCode(...tmpS);
    }
    return str;
};

export default {
    strFull2int,
    intFull2Str
};
