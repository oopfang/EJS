/** 全局字典过滤器
 *  
 */
export default (val, root, dictGroup) => {
	/* eslint-disable */
	if (val !== undefined && root && dictGroup) {
		let _dictObj = root[dictGroup] || (root._dict && root._dict[dictGroup]) || ((root.$root && root.$root._dict) && root.$root._dict[dictGroup]) || 
		((root.$data && root.$data._dict) && root.$data._dict[dictGroup]) || null;
		if (_dictObj) {
			let currObj = _dictObj.find(v => {
				return `${v.key}` === `${val}`;
			});
			return currObj ? currObj.title : '';
		} else {
			return '';
		}
	} else {
		return '';
	}
};