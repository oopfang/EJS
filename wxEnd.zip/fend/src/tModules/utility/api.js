import axios from 'axios';
import tObj from 'tframe-utility';
import tEnum from 'tframe-enum';
import conf from '../../config/config.json';
let judgeJsType = tObj.preObject.getJsObjectType;

/**
 * 预清洗上传服务端的数据，去除类似于 $unSave 等属性
 * @param {Ojbect | Arrar} data
 */
const preClear = data => {
  if (data) {
    if (Array.isArray(data)) {
      let _arr = [];
      for (let v of data) {
        let resV = preClear(v);
        _arr.push(resV);
      }
      return _arr;
    } else if (typeof data === 'object') {
      if (data.$unSave) {
        delete data['$unSave'];
      }
      let keys = Object.keys(data);
      for (let v of keys) {
        let _obj = data[v];
        if (typeof _obj === 'object' && !Array.isArray(_obj)) {
          data[v] = preClear(_obj);
        }
      }
      return data;
    } else {
      return data;
    }
  } else {
    return data;
  }
};

/**
 * 将url地址格式化为不含 / 开头
 * @param {*} urlStr
 */
const urlStartWithoutSmbol = urlStr => {
  let i = urlStr.length;
  if (urlStr && i > 0) {
    let str = '';
    if (urlStr.startsWith('/')) {
      str = urlStr.substring(1, i);
    } else {
      str = urlStr;
    }
    return str;
  } else {
    return '';
  }
};

/**
 * 将url地址格式化为 / 结尾
 * @param {*} urlStr
 */
const urlEndwithSmbol = urlStr => {
  if (urlStr) {
    let str = '';
    if (urlStr.endsWith('/')) {
      str = urlStr;
    } else {
      str = urlStr + '/';
    }
    return str;
  } else {
    return '';
  }
};

let remotBaseUrl = urlEndwithSmbol(conf.appSvrAdd);

let _getUrl = (subUrl) => {
  return remotBaseUrl + urlStartWithoutSmbol(subUrl);
};

// 返回值属性追加器
let _appendProp = res => {
  let _resJudge = judgeJsType(res);
  if (_resJudge === tEnum.sys.aboutObject.Obj) {
    res.$unSave = {};
    return res;
  } else if (_resJudge === tEnum.sys.aboutObject.Arr) {
    return res.map(v => {
      return _appendProp(v);
    });
  } else {
    return res;
  }
};

// axios配置
let config = {
  // api的base_url
  baseURL: remotBaseUrl,
  // 请求超时时间
  timeout: 5000,
  // 允许携带cookie
  withCredentials: true,
  // 全局的允许连接过期重试次数
  retry: 3,
  // 全局的重试延迟间隙
  retryDelay: 500
};

// 创建axios实例
const service = axios.create(config);

// request拦截器
service.interceptors.request.use(
  config => {
    global.tloading('加载中...');
    config.headers = {
      'Content-Type': 'application/json'
    };
    let _token = localStorage.getItem('signInfo');
    if (config.params) {
      config.params = JSON.stringify(preClear(config.params));
    }
    if (config.data && config.data.data) {
      config.data.data = preClear(config.data.data);
    }

    if (_token) {
      let _currUser = JSON.parse(_token);
      config.headers['x-access-token'] = JSON.parse(_token).token;
      config.headers['x-access-id'] = _currUser.id;
    }
    config.withCredentials = true;
    return config;
  },
  error => {
    global.terr(error);
    global.tloading();
    return Promise.reject(error);
  }
);

service.interceptors.response.use(res => {
  global.tloading();
  let _resGet = null;
  if (res.config.method === 'get') {
    if (res.data && res.data.apiStatus === 'ok' && res.data.result) {
      _resGet = _appendProp(res.data.result);
      res.data.result = _resGet;
    }
  }
  if (!res.config.url.includes('/sign/out')) {
    global.tinfo('服务端响应成功');
  }
  return res;
}, err => {
  /* eslint-disable no-undef */
  global.tloading();
  return Promise.reject(err);
});

/*
GET方法（查询）
	@subUrl：远端地址
	@option：执行参数
*/
export function getFunc(subUrl, option = {}) {
  return new Promise((resolve, reject) => {
    service
      .get(_getUrl(subUrl), {
        params: option
      })
      .then(res => {
        resolve(res.data);
      })
      .catch(err => {
        reject(err);
      });
  });
}

/*
POST方法（新增）
	@subUrl：远端地址
	@params：执行参数
*/
export function postFunc(subUrl, option = {}) {
  return new Promise((resolve, reject) => {
    service
      .post(_getUrl(subUrl), option)
      .then(res => {
        resolve(res.data);
      })
      .catch(err => {
        reject(err);
      });
  });
}

/*
PUT方法（修改）
	@subUrl：远端地址
	@params：执行参数
*/
export function putFunc(subUrl, option = {}) {
  return new Promise((resolve, reject) => {
    service
      .put(_getUrl(subUrl), option)
      .then(res => {
        resolve(res.data);
      })
      .catch(err => {
        reject(err);
      });
  });
}

/*
	DELETE方法
	@subUrl：远端地址
	@params：执行参数
	@delType：删除类型（true：物理删除，false：伪删除），默认为false
*/
export function deleteFunc(subUrl, option = {}) {
  return new Promise((resolve, reject) => {
    service
      .delete(_getUrl(subUrl), {
        params: option
      })
      .then(res => {
        resolve(res.data);
      })
      .catch(err => {
        reject(err);
      });
  });
}
