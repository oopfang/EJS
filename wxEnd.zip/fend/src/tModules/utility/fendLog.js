/* eslint-disable */
// 前端控制台回显引擎

const _infoPool = [];
const _warnPool = [];
const _errPool = [];
let _delay = 0;

/* 警告响应
   @msg：要弹出的提示信息
   @setCache: 该信息是否存入前端缓存， 默认为 true
*/
let _setWarn = (msg, setCache = true) => {
  if (setCache) {
    let _dateStr = new Date();
    let _dateD = _dateStr.toLocaleDateString().replace(/\//g, '_');
    let _dataT = _dateStr.toLocaleTimeString();
    localStorage.setItem(`[warnInfo]${_dateD}${_dataT}`, `${msg}`);
    console.warn(msg);
  }
  return msg.length > 15 ? `${msg.substring(0, 15)}...` : msg;
}

let _setErr = err => {
  let _errStr = '未描述的异常';
  let _arArr = false;
  let _errType = typeof err;
  let _errDetail = '';
  if (_errType !== 'undefined') {
    if (_errType === 'string') {
      _errStr = err;
    } else if (_errType === 'number') {
      let _errCode = _errFastCode[`${err}`];
      if (_errCode) {
        _errStr = _errCode;
      }
    } else {
      let _errMsg = '';
      if (err.response) {
        if (err.response.data && err.response.data.reason) {
          _errMsg = err.response.data.reason;
        } else {
          _errMsg = _errFastCode[`${err.response.status}`] || err.response.statusText;
        }
      } else {
        if (err.message) {
          _errMsg = err.message;
        }
      }
      if (_errMsg) {
        switch (_errMsg) {
          case 'Network Error':
            _arArr = true;
            _errStr = '通讯异常，可能是服务器的连接已断开，或服务器发生了故障';
            break;
          default:
            if (_errMsg.startsWith('timeout of') && _errMsg.endsWith('ms exceeded')) {
              _errStr = '请求超时或服务端已停止响应';
            } else {
              _errStr = _errMsg;
            }
        }
      }
      _errDetail = err.stack || _errMsg;
    }
  }
  let _dateStr = new Date();
  let _dateD = _dateStr.toLocaleDateString().replace(/\//g, '_');
  let _dataT = _dateStr.toLocaleTimeString();
  let _errDetailStr = _errDetail ? `\n${_errDetail}` : '';
  localStorage.setItem(`[errInfo]${_dateD}${_dataT}`, `${_errStr}${_errDetailStr}`);
  console.error(_errStr);
  if (_arArr) {
    return [_errStr.length > 15 ? `${_errStr.substring(0, 15)}...` : _errStr];
  } else {
    return _errStr.length > 15 ? `${_errStr.substring(0, 15)}...` : _errStr
  }
}

let _msgSetHandler = (val, type, setCache=true) => {
  let _currPool = (type === 'warn' && _warnPool) || (type === 'error' && _errPool) || _infoPool;
  if (val) {
    if (Array.isArray(val)) {
      _currPool.push(...val);
      for (let v of val) {
        if (!_currPool.includes(v)) {
          _currPool.push(v);
        }
      }
    } else {
      if (!_currPool.includes(val)) {
        _currPool.push(val);
      }
    }
    if (_delay === 0) {
      _msgGetHandler(type, setCache);
    } else {
      while (_delay === 0) {
        _msgGetHandler(type, setCache);
      }
    }
  }
};

let _msgGetHandler = (type, setCache=true) => {
  let _currPool = (type === 'warn' && _warnPool) || (type === 'error' && _errPool) || _infoPool;
  let _showMsg = () => {
    let _msg = _currPool.pop();
    if (type === 'warn') {
      _msg = _setWarn(_msg, setCache);
    } else if (type === 'error') {
      _msg = _setErr(_msg);
    }
    if (Array.isArray(_msg) && type === 'error') {
      HeyUI.$Notice({
        type: 'error',
        title: _msg[1] || '异常',
        content: _msg[0]
      });
    } else {
      _delay += 1000;
      HeyUI.$Message({
        text: _msg,
        type: type,
        timeout: _delay
      });
    }
    setTimeout(() => {
      if (_currPool.length > 0) {
        _showMsg();
      } else {
        _delay = 0;
      }
    }, 1200);
  };
  _showMsg();
}


// HTTP响应码
const _errFastCode = {
  '400': '请求错误(400)',
  '401': '未登陆，或登陆已过期(401)',
  '403': '拒绝访问(403)',
  '404': '请求出错(404)',
  '408': '请求超时(408)',
  '500': '服务器错误(500)',
  '501': '服务未实现(501)',
  '502': '网络错误(502)',
  '503': '服务不可用(503)',
  '504': '网络超时(504)',
  '505': 'HTTP版本不受支持(505)'
};

// 生成 GUID
let guid = () => {
  function S4() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  }
  return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
};

// 输出调试信息
export function tLog(msg) {
  let _guid = guid();
  console.warn(`------------------------------- 调试信息 [id: ${_guid}] 开始 -------------------------------`);
  if (Array.isArray(msg)) {
    for (let v of msg) {
      console.log(v);
    }
  } else {
    console.log(msg);
  }
  console.log(`------------------------------- 调试信息 [id: ${_guid}] 结束 -------------------------------`);
};

// 弹出成功提示信息
export function infoLog(msg) {
  _msgSetHandler(msg, 'success');
};

// 警告处理
export function warnLog(msg, setCache=true) {
  _msgSetHandler(msg, 'warn', setCache);
};

// 异常处理
export function errLog(err) {
  _msgSetHandler(err, 'error');
};

// 弹出加载提示信息
export function tLoading(msg) {
  if (msg !== undefined) {
    HeyUI.$Loading(msg || '加载中...');
  } else {
    HeyUI.$Loading.close();
  }
};
