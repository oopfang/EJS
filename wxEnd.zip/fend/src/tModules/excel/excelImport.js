import excel2Json from './excel2json';

export default function(file, next) {
  for (let i = 0; i < file.length; i++) {
    excel2Json(file[i], next);
  }
}
