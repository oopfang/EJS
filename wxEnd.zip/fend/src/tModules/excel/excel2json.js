let XLSX = require('xlsx');

let singleImport = function(f, next) {
  let reader = new FileReader();
  let workbook = null;
  let report = {
    name: f.name,
    sheets: [],
    size: f.size,
    type: f.type,
    range: [],
    rowsCount: 0,
    columnsCount: 0,
    jsonData: [],
    successed: false
  };
  reader.onload = function (e) {
    try {
      let dataBuffer = [];
      let data = e.target.result;
      workbook = XLSX.read(data, {
        type: 'binary'
      });
      report.sheets = Object.keys(workbook.Sheets);
      for (let sheet in workbook.Sheets) {
        report.range.push(workbook.Sheets[sheet]['!ref']);
        dataBuffer = dataBuffer.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
      }
      report.successed = true;
      report.jsonData = dataBuffer;
    } catch (error) {
      report.successed = false;
      report.jsonData = [];
    } finally {
      next(report);
    }
  };
  reader.readAsBinaryString(f);
};

export default function(file, next) {
  for (let i = 0; i < file.length; i++) {
    singleImport(file[i], next);
  }
}
