/*
*   binary system of 26
*/
let convertDsTo26 = num => {
    let code = '';
    let reg = /^\d+$/g;
    if (!reg.test(num)) {
        return code;
    }
    while (num > 0) {
        let m = num % 26;
        if (m === 0) {
            m = 26;
        }
        code = String.fromCharCode(64 + parseInt(m)) + code;
        num = (num - m) / 26;
    }
    return code;
};

let convert26ToDS = code => {
    let num = -1;
    let reg = /^[A-Z]+$/g;
    if (!reg.test(code)) {
        return num;
    }
    num = 0;
    for (let i = code.length - 1, j = 1; i >= 0; i--, j *= 26) {
        num += (code[i].charCodeAt() - 64) * j;
    }
    return num;
};

export default {
    convertDsTo26,
    convert26ToDS
};
