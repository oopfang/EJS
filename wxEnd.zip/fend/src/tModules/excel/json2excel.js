let XLSX = require('xlsx');
let FileSaver = require('file-saver');

let s2ab = function (s) {
  if (typeof ArrayBuffer !== 'undefined') {
    let buf = new ArrayBuffer(s.length);
    let view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  } else {
    let buf = new Array(s.length);
    for (let i = 0; i !== s.length; ++i) buf[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
};

// 定义导出的格式类型
const wopts = { bookType: 'xlsx', bookSST: false, type: 'binary' };
// ods格式
// const wopts = { bookType: 'csv', bookSST: false, type: 'binary' };
// ods格式
// const wopts = { bookType: 'ods', bookSST: false, type: 'binary' };
// xlsb格式
// const wopts = { bookType: 'xlsb', bookSST: false, type: 'binary' };
// fods格式
// const wopts = { bookType: 'fods', bookSST: false, type: 'binary' };
// xls格式
// const wopts = { bookType: 'biff2', bookSST: false, type: 'binary' };

/**
 * 导出Json数据到Excel表
 * @param {any} fielName 文件名称
 * @param {any} shtName： sheet表的名称
 * @param {any} val ： 表格数据信息
 * @param {any} hedr： 表格标题栏信息
 */
export default function(fielName, shtName, val, hedr = null) {
  const wb = { SheetNames: [shtName], Sheets: {}, Props: {} };
  let valArr = [];
  if (Array.isArray(val)) {
    valArr = val.map(v => {
      /* eslint-disable no-unused-vars */
      let { $unSave, ...valOther } = v;
      return valOther;
    });
  } else {
    /* eslint-disable no-unused-vars */
    let { $unSave, ...valOther } = val;
    valArr.push(valOther);
  }
  let ws = (hedr && Array.isArray(hedr) && hedr.length > 0) ? XLSX.utils.json_to_sheet(valArr, hedr) : XLSX.utils.json_to_sheet(valArr);
  wb.Sheets[shtName] = ws;
  let blob = new Blob([s2ab(XLSX.write(wb, wopts))], { type: 'application/octet-stream' });
  FileSaver.saveAs(blob, fielName + '.' + wopts.bookType);
}
