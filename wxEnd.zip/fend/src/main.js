// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill';
import './tModules/utility/globalFunc';
import App from './App';
import store from './store';
import {
  router
} from './router/index';
import fullscreenVue from 'vue-fullscreen';
import PreCode from './tModules/utility/preCode';
import localDict from './tModules/utility/localDict';
import globalInit from 'tframe-globalext';
import './assets/css/comm.css';
import './assets/less/index.less';
// import 'echarts/lib/component/tooltip'
import ECharts from 'vue-echarts/components/ECharts.vue';
// 中国省份城市经纬度数据
import loglat from './tModules/charts/loglat.json';
import '@grapecity/wijmo.vue2.olap';
import Vue from 'vue';

globalInit();

/* eslint-disable no-undef  */
Vue.config.productionTip = true;
/* eslint-disable no-undef  */
Vue.use(fullscreenVue);
const printOptions = {
  name: '_blank',
  specs: ['fullscreen=yes', 'titlebar=yes', 'scrollbars=yes'],
  styles: ['http://localhost:8080/static/css/print.css']
};
Vue.use(ECharts);
Vue.use(PreCode);
let VueHtmlToPaper = () => import(/* webpackChunkName:'pdf' */ 'vue-html-to-paper');
Vue.use(VueHtmlToPaper, printOptions);
Vue.filter('localDict', localDict);

/* eslint-disable no-undef */
HeyUI.config('category.configs', {
  orgOpt: {
    title: '请选择组织',
    keyName: 'id',
    parentName: 'pid',
    titleName: 'namezh',
    dataMode: 'list',
    datas: []
  }
});

// Vue.filter('localDict', (val, dictGroup) => {
//   /* eslint-disable */
//   console.log('dict');
//   console.log(this.$root);
// });

/* eslint-disable no-new, vue/no-reserved-keys */
new Vue({
  el: '#app',
  store,
  router,
  components: {
    App
  },
  data: {
    eventHub: new Vue(),
    // 组织管理页面拖放操作的定义
    dragOpt: {
      group: 'orgGroup',
      animation: 150
    },
    loglat,
    // 全局嵌入字典
    _dict: {},
    _dictFlat: {},
    // 全局权限容器
    rights: {}
  },
  template: '<App/>'
});
