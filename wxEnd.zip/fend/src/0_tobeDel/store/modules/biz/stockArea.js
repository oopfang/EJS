/**
 * 库区管理视图的状态单元
 */

import bizDefine from '@/define/stockArea/intro.js';

let getStockAreaEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前库区管理列表
  stockAreaList: [],
  // 当前选定的库区管理对象
  stockAreaObj: getStockAreaEmptyObj()
};

const getters = {
  // 获取库区管理一览列表数据
  getStockAreaList: state => state.stockAreaList,
  // 获取库区管理对象
  getStockAreaObj: state => state.stockAreaObj
};

const mutations = {
  // 绑定库区管理一览表数据
  setStockAreaList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.stockAreaList = data;
    }
  },
  // 设置库区管理对象
  setStockAreaObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.stockAreaObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的库区管理记录行
  removeStockAreaObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.stockAreaList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.stockAreaList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheStockArea: state => {
    state.stockAreaList = [];
    state.stockAreaObj = getStockAreaEmptyObj();
  }
};

const actions = {
  // 远程获取库区管理一览表
  queryStockAreaList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/stockArea/list', option)
        .then(res => {
          contex.commit('setStockAreaList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的库区管理对象
  queryStockAreaObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/stockArea/obj', option)
        .then(res => {
          contex.commit('setStockAreaObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增库区管理的请求
  postStockAreaObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/stockArea/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑库区管理的请求
  putStockAreaObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/stockArea/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的库区管理对象
  delStockAreaMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/stockArea/del', option)
        .then(res => {
          contex.commit('removeStockAreaObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
