/**
 * 库位管理视图的状态单元
 */

import bizDefine from '@/define/stockCell/intro.js';

let getStockCellEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前库位管理列表
  stockCellList: [],
  // 当前选定的库位管理对象
  stockCellObj: getStockCellEmptyObj()
};

const getters = {
  // 获取库位管理一览列表数据
  getStockCellList: state => state.stockCellList,
  // 获取库位管理对象
  getStockCellObj: state => state.stockCellObj
};

const mutations = {
  // 绑定库位管理一览表数据
  setStockCellList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.stockCellList = data;
    }
  },
  // 设置库位管理对象
  setStockCellObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.stockCellObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的库位管理记录行
  removeStockCellObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.stockCellList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.stockCellList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheStockCell: state => {
    state.stockCellList = [];
    state.stockCellObj = getStockCellEmptyObj();
  }
};

const actions = {
  // 远程获取库位管理一览表
  queryStockCellList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/stockCell/list', option)
        .then(res => {
          contex.commit('setStockCellList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的库位管理对象
  queryStockCellObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/stockCell/obj', option)
        .then(res => {
          contex.commit('setStockCellObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增库位管理的请求
  postStockCellObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/stockCell/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑库位管理的请求
  putStockCellObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/stockCell/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的库位管理对象
  delStockCellMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/stockCell/del', option)
        .then(res => {
          contex.commit('removeStockCellObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
