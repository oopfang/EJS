/**
 * 容器管理视图的状态单元
 */

import bizDefine from '@/define/container/intro.js';

let getContainerEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前容器管理列表
  containerList: [],
  // 当前选定的容器管理对象
  containerObj: getContainerEmptyObj()
};

const getters = {
  // 获取容器管理一览列表数据
  getContainerList: state => state.containerList,
  // 获取容器管理对象
  getContainerObj: state => state.containerObj
};

const mutations = {
  // 绑定容器管理一览表数据
  setContainerList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.containerList = data;
    }
  },
  // 设置容器管理对象
  setContainerObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.containerObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的容器管理记录行
  removeContainerObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.containerList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.containerList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheContainer: state => {
    state.containerList = [];
    state.containerObj = getContainerEmptyObj();
  }
};

const actions = {
  // 远程获取容器管理一览表
  queryContainerList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/container/list', option)
        .then(res => {
          contex.commit('setContainerList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的容器管理对象
  queryContainerObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/container/obj', option)
        .then(res => {
          contex.commit('setContainerObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增容器管理的请求
  postContainerObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/container/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑容器管理的请求
  putContainerObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/container/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的容器管理对象
  delContainerMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/container/del', option)
        .then(res => {
          contex.commit('removeContainerObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
