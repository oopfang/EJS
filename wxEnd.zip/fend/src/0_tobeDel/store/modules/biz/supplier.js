/**
 * 供应商名录视图的状态单元
 */

import bizDefine from '@/define/supplier/intro.js';

let getSupplierEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前供应商名录列表
  supplierList: [],
  // 当前选定的供应商名录对象
  supplierObj: getSupplierEmptyObj()
};

const getters = {
  // 获取供应商名录一览列表数据
  getSupplierList: state => state.supplierList,
  // 获取供应商名录对象
  getSupplierObj: state => state.supplierObj
};

const mutations = {
  // 绑定供应商名录一览表数据
  setSupplierList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.supplierList = data;
    }
  },
  // 设置供应商名录对象
  setSupplierObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.supplierObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的供应商名录记录行
  removeSupplierObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.supplierList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.supplierList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheSupplier: state => {
    state.supplierList = [];
    state.supplierObj = getSupplierEmptyObj();
  }
};

const actions = {
  // 远程获取供应商名录一览表
  querySupplierList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/supplier/list', option)
        .then(res => {
          contex.commit('setSupplierList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的供应商名录对象
  querySupplierObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/supplier/obj', option)
        .then(res => {
          contex.commit('setSupplierObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增供应商名录的请求
  postSupplierObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/supplier/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑供应商名录的请求
  putSupplierObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/supplier/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的供应商名录对象
  delSupplierMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/supplier/del', option)
        .then(res => {
          contex.commit('removeSupplierObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
