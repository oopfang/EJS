/**
 * 申退规则视图的状态单元
 */

import bizDefine from '@/define/ruleReturnAsk/intro.js';

let getRuleReturnAskEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前申退规则列表
  ruleReturnAskList: [],
  // 当前选定的申退规则对象
  ruleReturnAskObj: getRuleReturnAskEmptyObj()
};

const getters = {
  // 获取申退规则一览列表数据
  getRuleReturnAskList: state => state.ruleReturnAskList,
  // 获取申退规则对象
  getRuleReturnAskObj: state => state.ruleReturnAskObj
};

const mutations = {
  // 绑定申退规则一览表数据
  setRuleReturnAskList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.ruleReturnAskList = data;
    }
  },
  // 设置申退规则对象
  setRuleReturnAskObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.ruleReturnAskObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的申退规则记录行
  removeRuleReturnAskObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.ruleReturnAskList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.ruleReturnAskList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheRuleReturnAsk: state => {
    state.ruleReturnAskList = [];
    state.ruleReturnAskObj = getRuleReturnAskEmptyObj();
  }
};

const actions = {
  // 远程获取申退规则一览表
  queryRuleReturnAskList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/ruleReturnAsk/list', option)
        .then(res => {
          contex.commit('setRuleReturnAskList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的申退规则对象
  queryRuleReturnAskObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/ruleReturnAsk/obj', option)
        .then(res => {
          contex.commit('setRuleReturnAskObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增申退规则的请求
  postRuleReturnAskObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/ruleReturnAsk/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑申退规则的请求
  putRuleReturnAskObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/ruleReturnAsk/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的申退规则对象
  delRuleReturnAskMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/ruleReturnAsk/del', option)
        .then(res => {
          contex.commit('removeRuleReturnAskObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
