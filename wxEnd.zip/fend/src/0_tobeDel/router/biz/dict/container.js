/**
 * 容器管理主数据视图的路由
 */

const containerView = () => import(/* webpackChunkName:'container' */ '@/pages/bizPages/dict/container/view.vue');

module.exports = [{
  path: 'container',
  name: 'container',
  meta: {
    title: '容器管理'
  },
  component: containerView
}];
