/**
 * 申退规则主数据视图的路由
 */

const ruleReturnAskView = () => import(/* webpackChunkName:'ruleReturnAsk' */ '@/pages/bizPages/dict/ruleReturnAsk/view.vue');

module.exports = [{
  path: 'ruleReturnAsk',
  name: 'ruleReturnAsk',
  meta: {
    title: '申退规则'
  },
  component: ruleReturnAskView
}];
