/**
 * 库区管理主数据视图的路由
 */

const stockAreaView = () => import(/* webpackChunkName:'stockArea' */ '@/pages/bizPages/dict/stockArea/view.vue');

module.exports = [{
  path: 'stockArea',
  name: 'stockArea',
  meta: {
    title: '库区管理'
  },
  component: stockAreaView
}];
