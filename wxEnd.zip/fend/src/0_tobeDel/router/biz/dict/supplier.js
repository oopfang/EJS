/**
 * 供应商名录主数据视图的路由
 */

const supplierView = () => import(/* webpackChunkName:'supplier' */ '@/pages/bizPages/dict/supplier/view.vue');

module.exports = [{
  path: 'supplier',
  name: 'supplier',
  meta: {
    title: '供应商名录'
  },
  component: supplierView
}];
