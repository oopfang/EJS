/**
 * 库位管理主数据视图的路由
 */

const stockCellView = () => import(/* webpackChunkName:'stockCell' */ '@/pages/bizPages/dict/stockCell/view.vue');

module.exports = [{
  path: 'stockCell',
  name: 'stockCell',
  meta: {
    title: '库位管理'
  },
  component: stockCellView
}];
