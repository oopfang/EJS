/**
 * 鉴验规则主数据视图的路由
 */

const ruleVerifyView = () => import(/* webpackChunkName:'ruleVerify' */ '@/pages/bizPages/dict/ruleVerify/view.vue');

module.exports = [{
  path: 'ruleVerify',
  name: 'ruleVerify',
  meta: {
    title: '鉴验规则'
  },
  component: ruleVerifyView
}];
