export default {
  code: 'ruleVerify',
  name: 'RuleVerify',
  namezh: '鉴验规则',
  guidUrl: '',
  showHeader: true,
  showFooter: true,
  useFilter: true,
  titleField: 'namezh',
  fullWidthInCol: false,
  header: [],
  buttons: [],
  subSequence: [],
  emptyVal: {
    id: '',
    pid: '-1',
    code: '',
    name: '',
    namezh: '',
    memo: '',
    stopped: '0'
  }
};
