export default {
  code: 'stockCell',
  name: 'StockCell',
  namezh: '库位管理',
  guidUrl: '',
  showHeader: true,
  showFooter: true,
  useFilter: true,
  titleField: 'namezh',
  fullWidthInCol: false,
  header: [{
    title: '名称',
    prop: 'namezh',
    width: 100,
    viewType: 'text',
    viewTypeParam: '',
    align: 'center',
    widthUnit: 'px',
    fullWidth: false,
    allowClickEvent: false
  }, {
    title: '备注',
    prop: 'memo',
    width: 100,
    viewType: 'text',
    viewTypeParam: '',
    align: 'center',
    widthUnit: 'px',
    fullWidth: false,
    allowClickEvent: false
  }],
  buttons: [],
  subSequence: [],
  emptyVal: {
    id: '',
    pid: '-1',
    code: '',
    name: '',
    namezh: '',
    memo: '',
    stopped: '0'
  }
};
