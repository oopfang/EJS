export default {
  code: 'ruleReturnAsk',
  name: 'RuleReturnAsk',
  namezh: '申退规则',
  guidUrl: '',
  showHeader: true,
  showFooter: true,
  useFilter: true,
  titleField: 'namezh',
  fullWidthInCol: false,
  header: [],
  buttons: [],
  subSequence: [],
  emptyVal: {
    id: '',
    pid: '-1',
    code: '',
    name: '',
    namezh: '',
    memo: '',
    stopped: '0'
  }
};
