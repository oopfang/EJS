import Main from '@/pages/strucPages/home/index.vue';
import errRouter from './errPage';
const reportWall = () => import(/* webpackChunkName:'reportWall' */ '@/pages/strucPages/reportWall/index.vue');
const lockScreen = () => import(/* webpackChunkName:'lockScreen' */ '@/pages/strucPages/lock/index.vue');
const orgSchema = () => import(/* webpackChunkName:'orgs' */ '@/pages/strucPages/org/orgSchema.vue');
const channel = () => import(/* webpackChunkName:'orgs' */ '@/pages/strucPages/org/channel.vue');
const organtype = () => import(/* webpackChunkName:'orgs' */ '@/pages/strucPages/org/organtype.vue');
const duty = () => import(/* webpackChunkName:'hr' */ '@/pages/strucPages/hr/duty.vue');
const employee = () => import(/* webpackChunkName:'hr' */ '@/pages/strucPages/hr/employee.vue');
const auth = () => import(/* webpackChunkName:'sys' */ '@/pages/strucPages/sys/auth/index.vue');
const icoSet = () => import(/* webpackChunkName:'sys' */ '@/pages/strucPages/sys/icoSet.vue');

let bizs = () => {
  let x = (r => {
    return r.keys().map(key => r(key));
  })(require.context('./biz/', true, /^.*\.js$/));
  let _arr = [];
  x.forEach((v, k, arr) => {
    _arr.push(...v);
  });
  return _arr;
};

// 注册
const registRouter = {
  path: '/regist',
  name: 'regist',
  meta: {
    title: '注册'
  },
  component: resolve => {
    require(['@/pages/strucPages/sign/up.vue'], resolve);
  }
};

// 登录
const signRouter = {
  path: '/sign',
  name: 'sign',
  meta: {
    title: '登录'
  },
  component: resolve => {
    require(['@/pages/strucPages/sign/inout.vue'], resolve);
  }
};

// 锁屏
const lockRouter = {
  path: '/locking',
  name: 'locking',
  meta: {
    title: '屏幕锁定中...'
  },
  component: lockScreen
};

// 业务大屏
const wallRouter = {
  path: '/reportwall',
  name: 'reportWall',
  params: {
    test: 1
  },
  meta: {
    title: '业务大屏'
  },
  component: reportWall
};


// 作为Main组件的子页面，但不在菜单栏显示的路由
const mainRouter = {
  path: '/',
  name: 'home',
  redirect: '/home',
  component: Main,
  children: [
    // 工作台
    {
      path: '/home',
      name: 'dashboard',
      component: resolve => {
        require(['@/pages/dashboard/indexDash.vue'], resolve);
      }
    },
    // 个人信息管理
    {
      path: '/profile',
      name: 'profile',
      meta: {
        title: '个人中心'
      },
      component: resolve => {
        require(['@/pages/ucenter/profile.vue'], resolve);
      }
    },
    // 组织架构
    {
      path: '/orgSchema',
      name: 'orgSchema',
      meta: {
        title: '组织架构'
      },
      component: orgSchema
    },
    // 组织类型
    {
      path: '/organtype',
      name: 'organtype',
      meta: {
        title: '组织类型'
      },
      component: organtype
    },
    // 渠道管理
    {
      path: '/channel',
      name: 'channel',
      meta: {
        title: '渠道管理'
      },
      component: channel
    },
    // 职务设置
    {
      path: '/duty',
      name: 'duty',
      meta: {
        title: '职务设置'
      },
      component: duty
    },
    // 职员管理
    {
      path: '/employee',
      name: 'employee',
      meta: {
        title: '职员管理'
      },
      component: employee
    },
    // 图标集
    {
      path: '/icoSet',
      name: 'icoSet',
      meta: {
        title: '图标集'
      },
      component: icoSet
    },
    // 授权中心
    {
      path: '/auth',
      name: 'auth',
      meta: {
        title: '授权中心'
      },
      component: auth
    },
    ...bizs()
  ]
};

export default [
  registRouter,
  signRouter,
  lockRouter,
  wallRouter,
  mainRouter,
  ...errRouter
];
