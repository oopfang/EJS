/* eslint-disable */
let util = {

};
util.title = function (title) {
  title = title ? title + ' - Home' : 'ErGongDa - 上海深普软件有限公司';
  window.document.title = title;
};

util.navPage = function (routers, name, route, next) {
  let len = routers.length;
  let i = 0;
  let notHandle = true;
  while (i < len) {
    if (routers[i].name === name && routers[i].children && routers[i].redirect === undefined) {
      route.replace({
        name: routers[i].children[0].name
      });
      notHandle = false;
      next();
      break;
    }
    i++;
  }
  if (notHandle) {
    next();
  }
};

export default util;
