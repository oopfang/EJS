const forbidden = () => import(/* webpackChunkName:'errpage' */ '@/pages/strucPages/err/forbidden.vue');
const p403 = () => import(/* webpackChunkName:'errpage' */ '@/pages/strucPages/err/403.vue');
const p404 = () => import(/* webpackChunkName:'errpage' */ '@/pages/strucPages/err/404.vue');
const p500 = () => import(/* webpackChunkName:'errpage' */ '@/pages/strucPages/err/500.vue');


const pageForbidden = {
    path: '/forbidden',
    name: 'error-forbidden',
    meta: {
        title: '账号被禁用'
    },
    component: forbidden
};

const page403 = {
    path: '/403',
    name: 'error-403',
    meta: {
        title: '403-权限不足'
    },
    component: p403
};

const page404 = {
    path: '/*',
    name: 'error-404',
    meta: {
        title: '404-页面不存在'
    },
    component: p404
};

const page500 = {
    path: '/500',
    name: 'error-500',
    meta: {
        title: '500-服务端错误'
    },
    component: p500
};

export default [pageForbidden, page403, page404, page500];
