import Util from './/util';
import routes from './router';

/* eslint-disable no-undef  */
Vue.use(VueRouter);

// 路由配置
const RouterConfig = {
  mode: 'history',
  routes: routes
};

export const router = new VueRouter(RouterConfig);

router.beforeEach((to, from, next) => {
  let uInfo = JSON.parse(localStorage.getItem('signInfo'));
  let _token = uInfo ? uInfo.token : '';
  if (!_token && to.name !== 'sign') {
    global.twarn('未登陆或者登陆已过期');
    // 未登录，且目的地址不是登录页
    next({
      name: 'sign'
    });
  } else {
    if (uInfo && uInfo.inLocking && to.name !== 'locking') {
      next(false);
    } else {
      /* eslint-disable no-undef */
      HeyUI.$LoadingBar.start();
      Util.title();
      Util.navPage([...routes], to.name, router, next);
    }
  }
});

router.afterEach(to => {
  HeyUI.$LoadingBar.success();
  window.scrollTo(0, 0);
});
