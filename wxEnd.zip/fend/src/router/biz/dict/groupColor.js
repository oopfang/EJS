/**
 * 颜色组主数据视图的路由
 */

const groupColorView = () => import(/* webpackChunkName:'groupColor' */ '@/pages/bizPages/dict/groupColor/view.vue');

module.exports = [{
  path: 'groupColor',
  name: 'groupColor',
  component: groupColorView
}];
