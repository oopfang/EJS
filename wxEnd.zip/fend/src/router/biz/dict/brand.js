/**
 * 品牌列表主数据视图的路由
 */

const brandView = () => import(/* webpackChunkName:'brand' */ '@/pages/bizPages/dict/brand/view.vue');

module.exports = [{
  path: 'brand',
  name: 'brand',
  meta: {
    title: '品牌管理'
  },
  component: brandView
}];
