/**
 * 仓库管理主数据视图的路由
 */

const warehouseView = () => import(/* webpackChunkName:'warehouse' */ '@/pages/bizPages/dict/warehouse/view.vue');

module.exports = [{
  path: 'warehouse',
  name: 'warehouse',
  meta: {
    title: '仓库管理'
  },
  component: warehouseView
}];
