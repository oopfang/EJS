/**
 * 尺码组主数据视图的路由
 */

const groupSizeView = () => import(/* webpackChunkName:'groupSize' */ '@/pages/bizPages/dict/groupSize/view.vue');

module.exports = [{
  path: 'groupSize',
  name: 'groupSize',
  component: groupSizeView
}];
