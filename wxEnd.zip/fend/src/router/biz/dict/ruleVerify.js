/**
 * 品牌列表主数据视图的路由
 */

const ruleVerifyView = () => import(/* webpackChunkName:'brand' */ '@/pages/bizPages/dict/ruleVerify/view.vue');

module.exports = [{
  path: 'ruleVerify',
  name: 'ruleVerify',
  meta: {
    title: '退货原因管理'
  },
  component: ruleVerifyView
}];
