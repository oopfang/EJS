/**
 * 客户档案主数据视图的路由
 */

const customerView = () => import(/* webpackChunkName:'customer' */ '@/pages/bizPages/dict/customer/view.vue');

module.exports = [{
  path: 'customer',
  name: 'customer',
  meta: {
    title: '客户档案'
  },
  component: customerView
}];
