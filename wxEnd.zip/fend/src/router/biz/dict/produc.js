/**
 * 商品管理主数据视图的路由
 */

const producView = () => import(/* webpackChunkName:'produc' */ '@/pages/bizPages/dict/produc/view.vue');

module.exports = [{
  path: 'produc',
  name: 'produc',
  meta: {
    title: '商品管理'
  },
  component: producView
}];
