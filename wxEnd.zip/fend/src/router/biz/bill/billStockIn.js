/**
 * 入库单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billStockIn' */ '@/pages/bizPages/bill/billStockIn/list.vue');
// const add = () => import(/* webpackChunkName:'billStockIn' */ '@/pages/bizPages/bill/billStockIn/add.vue');
const edit = () => import(/* webpackChunkName:'billStockIn' */ '@/pages/bizPages/bill/billStockIn/edit.vue');
// const view = () => import(/* webpackChunkName:'billStockIn' */ '@/pages/bizPages/bill/billStockIn/view.vue');

module.exports = [{
    path: '/billStockIn',
    name: 'billStockIn',
    meta: {
      title: '收货入库单'
    },
    component: list
  },
  {
    path: '/billStockIn/add',
    name: 'billStockInAdd',
    meta: {
      title: '创建收货入库单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billStockIn/edit',
    name: 'billStockInEdit',
    meta: {
      title: '编辑收货入库单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billStockIn/view',
    name: 'billStockInView',
    meta: {
      title: '查看收货入库单'
    },
    props: true,
    component: edit
  }
];
