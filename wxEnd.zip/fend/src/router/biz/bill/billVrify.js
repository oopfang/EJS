/**
 * 退货鉴验明细表表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billVrify' */ '@/pages/bizPages/bill/billVrify/list.vue');
// const add = () => import(/* webpackChunkName:'billVrify' */ '@/pages/bizPages/bill/billVrify/add.vue');
const edit = () => import(/* webpackChunkName:'billVrify' */ '@/pages/bizPages/bill/billVrify/edit.vue');
const optBill = () => import(/* webpackChunkName:'billVrify' */ '@/pages/bizPages/bill/billVrify/optBill.vue');
// const view = () => import(/* webpackChunkName:'billVrify' */ '@/pages/bizPages/bill/billVrify/view.vue');

module.exports = [{
    path: '/billVrify',
    name: 'billVrify',
    meta: {
      title: '退货检验单'
    },
    component: list
  },
  {
    path: '/billVrify/add',
    name: 'billVrifyAdd',
    meta: {
      title: '创建退货检验单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billVrify/edit',
    name: 'billVrifyEdit',
    meta: {
      title: '编辑退货检验单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billVrify/view',
    name: 'billVrifyView',
    meta: {
      title: '查看退货检验单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billVrify/opt',
    meta: {
      title: '鉴验作业台'
    },
    name: 'billVrifyOpt',
    props: true,
    component: optBill
  }
];
