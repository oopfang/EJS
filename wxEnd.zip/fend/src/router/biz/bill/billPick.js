/**
 * 拣货单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billPick' */ '@/pages/bizPages/bill/billPick/list.vue');
// const add = () => import(/* webpackChunkName:'billPick' */ '@/pages/bizPages/bill/billPick/add.vue');
const edit = () => import(/* webpackChunkName:'billPick' */ '@/pages/bizPages/bill/billPick/edit.vue');
// const view = () => import(/* webpackChunkName:'billPick' */ '@/pages/bizPages/bill/billPick/view.vue');

module.exports = [{
    path: '/billPick',
    name: 'billPick',
    meta: {
      title: '拣货单'
    },
    component: list
  },
  {
    path: '/billPick/add',
    name: 'billPickAdd',
    meta: {
      title: '创建拣货单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billPick/edit',
    name: 'billPickEdit',
    meta: {
      title: '编辑拣货单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billPick/view',
    name: 'billPickView',
    meta: {
      title: '查看拣货单'
    },
    props: true,
    component: edit
  }
];
