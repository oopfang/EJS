/**
 * 退货申请单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/bizPages/bill/billReturenAsk/list.vue');
// const add = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/bizPages/bill/billReturenAsk/add.vue');
const edit = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/bizPages/bill/billReturenAsk/edit.vue');
// const view = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/bizPages/bill/billReturenAsk/view.vue');

module.exports = [{
    path: '/billReturenAsk',
    name: 'billReturenAsk',
    meta: {
      title: '退货申请单'
    },
    component: list
  },
  {
    path: '/billReturenAsk/add',
    name: 'billReturenAskAdd',
    meta: {
      title: '创建退货申请'
    },
    props: true,
    component: edit
  },
  {
    path: '/billReturenAsk/edit',
    name: 'billReturenAskEdit',
    meta: {
      title: '编辑退货申请'
    },
    props: true,
    component: edit
  },
  {
    path: '/billReturenAsk/view',
    name: 'billReturenAskView',
    meta: {
      title: '查看退货申请'
    },
    props: true,
    component: edit
  }
];
