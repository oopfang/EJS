/**
 * 发货通知单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/list.vue');
// const add = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/add.vue');
const edit = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/edit.vue');
// const view = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/view.vue');

module.exports = [{
    path: '/billAdviceSend',
    name: 'billAdviceSend',
    meta: {
      title: '发货通知单'
    },
    component: list
  },
  {
    path: '/billAdviceSend/add',
    name: 'billAdviceSendAdd',
    meta: {
      title: '创建发货通知'
    },
    props: true,
    component: edit
  },
  {
    path: '/billAdviceSend/edit',
    name: 'billAdviceSendEdit',
    meta: {
      title: '修改发货通知'
    },
    props: true,
    component: edit
  },
  {
    path: '/billAdviceSend/view',
    name: 'billAdviceSendView',
    meta: {
      title: '查看发货通知'
    },
    props: true,
    component: edit
  }
];
