/**
 * 出库单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billSend' */ '@/pages/bizPages/bill/billSend/list.vue');
// const add = () => import(/* webpackChunkName:'billSend' */ '@/pages/bizPages/bill/billSend/add.vue');
const edit = () => import(/* webpackChunkName:'billSend' */ '@/pages/bizPages/bill/billSend/edit.vue');
// const view = () => import(/* webpackChunkName:'billSend' */ '@/pages/bizPages/bill/billSend/view.vue');

module.exports = [{
    path: '/billSend',
    name: 'billSend',
    meta: {
      title: '出库单'
    },
    component: list
  },
  {
    path: '/billSend/add',
    name: 'billSendAdd',
    meta: {
      title: '创建出库单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billSend/edit',
    name: 'billSendEdit',
    meta: {
      title: '编辑出库单'
    },
    props: true,
    component: edit
  },
  {
    path: '/billSend/view',
    name: 'billSendView',
    meta: {
      title: '查看出库单'
    },
    props: true,
    component: edit
  }
];
