/**
 * 库存管理视图的路由
 */

const list = () => import(/* webpackChunkName:'stockMgr' */ '@/pages/bizPages/bill/stockMgr/list.vue');

module.exports = [{
    path: '/stockMgr',
    name: 'stockMgr',
    meta: {
      title: '库存管理'
    },
    component: list
  }
];
