/**
 * 退货申请单表单视图的路由
 */

const show = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/report/show.vue');
const analysis = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/report/analysis.vue');
const warn = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/report/warn.vue');
const rptRetrun = () => import(/* webpackChunkName:'billReturenAsk' */ '@/pages/report/rptRetrun.vue');

module.exports = [{
    path: '/rpt/show',
    name: 'rptShow',
    component: show
  },
  {
    path: '/rpt/analysis',
    name: 'rptAnalysis',
    props: true,
    component: analysis
  },
  {
    path: '/rpt/warn',
    name: 'rptWarn',
    props: true,
    component: warn
  },
  {
    path: '/rpt/rptRetrun',
    name: 'rptRetrun',
    props: true,
    component: rptRetrun
  }
];
