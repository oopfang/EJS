<template>
<!-- 开发版APP.VUE文件 -->
<Row id="app" class="mainPage">{{ getOnlineState }}
  <div v-if="isChormeCore">
    <router-view></router-view>
  </div>
  <div v-else class="unSupport">
    <div class="tipsPanel">
      <h2>不支持该浏览器</h2>
      <h3>为保证一致的体验和完整的功能，在WINDOWS系统中，请使用 Chrome 浏览器，或 webkit 内核的浏览器</h3>
      <h3>在Mac OS系统中，可使用 Safari 浏览器，或其他 webkit 内核的浏览器</h3>
      <br />
      <h4>推荐列表：</h4>
      <ul>
        <li>
          <img height="36" width="36" src="/static/img/logo_chrome.png" />
          <p><a href="https://www.google.cn/chrome/">Chrome<br />[优先推荐]</a></p>
        </li>
        <li>
          <img height="36" width="36" src="/static/img/logo_safari.png" />
          <p><a href="https://www.apple.com/cn/safari/">Safari<br />[macOs Only]</a></p>
        </li>
        <li>
          <img height="36" width="36" src="/static/img/logo_other.png" />
          <p><a href="https://www.apple.com/cn/safari/">其他现代浏览器<br />兼容webkit内核的</a></p>
        </li>
      </ul>
      <div class="dividing"></div>
      <h4>不支持的列表</h4>
      <ul>
        <li>
          <img height="36" width="36" src="/static/img/logo_firefox.png" />
          <p><a href="http://www.firefox.com.cn/">Firefox<br />[推荐度：有限]<br />部分版本兼容</a></p>
        </li>
        <li>
          <img height="36" width="36" src="/static/img/logo_edge.png" />
          <p><a href="https://www.microsoft.com/zh-cn/windows/microsoft-edge#mainContent">Edge<br />[推荐度：有限]<br />Chrome内核的版本兼容</a></p>
        </li>
        <li>
          <img height="36" width="36" src="/static/img/logo_ie.png" />
          <p><a href="https://www.google.cn/chrome/">IE&nbsp;(全系列)<br /><br />(严重不支持)</a></p>
        </li>
      </ul>
    </div>
  </div>
</Row>
</template>

<script>
import {
  mapGetters,
  mapActions
} from 'vuex';

export default {
  name: 'App',
  data: function () {
    return {
      isChormeCore: false,
      // 当前网络状态
      isOnline: navigator.onLine,
      // 离线次数种子
      offTimes: 0
    };
  },
  computed: {
    ...mapGetters(['getUserInfo']),
    getOnlineState: function () {
      if (!this.isOnline) {
        this.offTimes++;
        this.$Notice({
          type: 'warn',
          title: '警告！',
          content: '网络连接已断开，请检查'
        });
      } else {
        if (this.offTimes > 0) {
          this.offTimes++;
          this.$Notice({
            type: 'success',
            title: '正常',
            content: '网络连接已恢复'
          });
        }
      }
      return '';
    }
  },
  methods: {
    ...mapActions(['signOut']),
    updateOnlineStatus(e) {
      const {
        type
      } = e;
      this.isOnline = type === 'online';
    }
  },

  mounted() {
    let userAgent = navigator.userAgent;
    // this.isChormeCore = userAgent.indexOf('Chrome') > -1 && userAgent.indexOf('Safari') > -1;
    this.isChormeCore = true;
    window.addEventListener('online', this.updateOnlineStatus);
    window.addEventListener('offline', this.updateOnlineStatus);
    let _dictCache = this.$root.$data._dict.gender;
    if (!_dictCache) {
      _dictCache = window.localStorage.getItem('_dict');
      if (_dictCache) {
        this.$root.$data._dict = JSON.parse(_dictCache);
      } else {
        this.$Message({
          type: 'error',
          text: '缓存已失效，需要登录'
        });
        this.signOut(this.getUserInfo);
        this.$router.push('/sign');
      }
    }
  },
  destroyed() {
    window.removeEventListener('online', this.updateOnlineStatus);
    window.removeEventListener('offline', this.updateOnlineStatus);
  }
};
</script>

<style lang="less" scoped>
.mainPage {
  width: 100vw;
  height: 100vh;
  overflow: hidden;

  .unSupport {
    width: 100vw;
    height: 100vh;
    padding-top: 30vh;
    text-align: center;

    .tipsPanel {
      width: 100vw;
      height: 40vh;

      h2 {
        padding: 18px 0;
      }

      h3,
      h4 {
        padding: 8px 0;
      }

      ul {
        margin-top: 18px;
        list-style: none;

        li {
          display: inline-block;
          margin: 0 18px;
        }
      }
    }
  }
}
</style>
