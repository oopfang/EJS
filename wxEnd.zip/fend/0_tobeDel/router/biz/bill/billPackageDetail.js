/**
 * 装箱单明细表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billPackageDetail' */ '@/pages/bizPages/bill/billPackageDetail/list.vue');
// const add = () => import(/* webpackChunkName:'billPackageDetail' */ '@/pages/bizPages/bill/billPackageDetail/add.vue');
const edit = () => import(/* webpackChunkName:'billPackageDetail' */ '@/pages/bizPages/bill/billPackageDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'billPackageDetail' */ '@/pages/bizPages/bill/billPackageDetail/view.vue');

module.exports = [{
    path: '/billPackageDetail',
    name: 'billPackageDetail',
    component: list
  },
  {
    path: '/billPackageDetail/add',
    name: 'billPackageDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/billPackageDetail/edit',
    name: 'billPackageDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/billPackageDetail/view',
    name: 'billPackageDetailView',
    props: true,
    component: edit
  }
];
