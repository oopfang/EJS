/**
 * 发货明细表表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billAdviceSendDetail' */ '@/pages/bizPages/bill/billAdviceSendDetail/list.vue');
// const add = () => import(/* webpackChunkName:'billAdviceSendDetail' */ '@/pages/bizPages/bill/billAdviceSendDetail/add.vue');
const edit = () => import(/* webpackChunkName:'billAdviceSendDetail' */ '@/pages/bizPages/bill/billAdviceSendDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'billAdviceSendDetail' */ '@/pages/bizPages/bill/billAdviceSendDetail/view.vue');

module.exports = [{
    path: '/billAdviceSendDetail',
    name: 'billAdviceSendDetail',
    component: list
  },
  {
    path: '/billAdviceSendDetail/add',
    name: 'billAdviceSendDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/billAdviceSendDetail/edit',
    name: 'billAdviceSendDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/billAdviceSendDetail/view',
    name: 'billAdviceSendDetailView',
    props: true,
    component: edit
  }
];
