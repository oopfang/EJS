/**
 * 盘点盈亏单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'pandianyingkuidan' */ '@/pages/bizPages/bill/pandianyingkuidan/list.vue');
// const add = () => import(/* webpackChunkName:'pandianyingkuidan' */ '@/pages/bizPages/bill/pandianyingkuidan/add.vue');
const edit = () => import(/* webpackChunkName:'pandianyingkuidan' */ '@/pages/bizPages/bill/pandianyingkuidan/edit.vue');
// const view = () => import(/* webpackChunkName:'pandianyingkuidan' */ '@/pages/bizPages/bill/pandianyingkuidan/view.vue');

module.exports = [{
    path: '/pandianyingkuidan',
    name: 'pandianyingkuidan',
    component: list
  },
  {
    path: '/pandianyingkuidan/add',
    name: 'pandianyingkuidanAdd',
    props: true,
    component: edit
  },
  {
    path: '/pandianyingkuidan/edit',
    name: 'pandianyingkuidanEdit',
    props: true,
    component: edit
  },
  {
    path: '/pandianyingkuidan/view',
    name: 'pandianyingkuidanView',
    props: true,
    component: edit
  }
];
