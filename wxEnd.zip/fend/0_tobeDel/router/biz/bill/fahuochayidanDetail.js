/**
 * 发货差异明细表表单视图的路由
 */

const list = () => import(/* webpackChunkName:'fahuochayidanDetail' */ '@/pages/bizPages/bill/fahuochayidanDetail/list.vue');
// const add = () => import(/* webpackChunkName:'fahuochayidanDetail' */ '@/pages/bizPages/bill/fahuochayidanDetail/add.vue');
const edit = () => import(/* webpackChunkName:'fahuochayidanDetail' */ '@/pages/bizPages/bill/fahuochayidanDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'fahuochayidanDetail' */ '@/pages/bizPages/bill/fahuochayidanDetail/view.vue');

module.exports = [{
    path: '/fahuochayidanDetail',
    name: 'fahuochayidanDetail',
    component: list
  },
  {
    path: '/fahuochayidanDetail/add',
    name: 'fahuochayidanDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/fahuochayidanDetail/edit',
    name: 'fahuochayidanDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/fahuochayidanDetail/view',
    name: 'fahuochayidanDetailView',
    props: true,
    component: edit
  }
];
