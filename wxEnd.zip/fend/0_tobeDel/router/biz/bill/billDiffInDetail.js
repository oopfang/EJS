/**
 * 退货差异明细表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billDiffInDetail' */ '@/pages/bizPages/bill/billDiffInDetail/list.vue');
// const add = () => import(/* webpackChunkName:'billDiffInDetail' */ '@/pages/bizPages/bill/billDiffInDetail/add.vue');
const edit = () => import(/* webpackChunkName:'billDiffInDetail' */ '@/pages/bizPages/bill/billDiffInDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'billDiffInDetail' */ '@/pages/bizPages/bill/billDiffInDetail/view.vue');

module.exports = [{
    path: '/billDiffInDetail',
    name: 'billDiffInDetail',
    component: list
  },
  {
    path: '/billDiffInDetail/add',
    name: 'billDiffInDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/billDiffInDetail/edit',
    name: 'billDiffInDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/billDiffInDetail/view',
    name: 'billDiffInDetailView',
    props: true,
    component: edit
  }
];
