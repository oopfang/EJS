/**
 * 上架明细单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billStockInDetail' */ '@/pages/bizPages/bill/billStockInDetail/list.vue');
// const add = () => import(/* webpackChunkName:'billStockInDetail' */ '@/pages/bizPages/bill/billStockInDetail/add.vue');
const edit = () => import(/* webpackChunkName:'billStockInDetail' */ '@/pages/bizPages/bill/billStockInDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'billStockInDetail' */ '@/pages/bizPages/bill/billStockInDetail/view.vue');

module.exports = [{
    path: '/billStockInDetail',
    name: 'billStockInDetail',
    component: list
  },
  {
    path: '/billStockInDetail/add',
    name: 'billStockInDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/billStockInDetail/edit',
    name: 'billStockInDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/billStockInDetail/view',
    name: 'billStockInDetailView',
    props: true,
    component: edit
  }
];
