/**
 * 退货申请明细表单视图的路由
 */

const list = () => import(/* webpackChunkName:'returenAskDetail' */ '@/pages/bizPages/bill/returenAskDetail/list.vue');
// const add = () => import(/* webpackChunkName:'returenAskDetail' */ '@/pages/bizPages/bill/returenAskDetail/add.vue');
const edit = () => import(/* webpackChunkName:'returenAskDetail' */ '@/pages/bizPages/bill/returenAskDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'returenAskDetail' */ '@/pages/bizPages/bill/returenAskDetail/view.vue');

module.exports = [{
    path: '/returenAskDetail',
    name: 'returenAskDetail',
    component: list
  },
  {
    path: '/returenAskDetail/add',
    name: 'returenAskDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/returenAskDetail/edit',
    name: 'returenAskDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/returenAskDetail/view',
    name: 'returenAskDetailView',
    props: true,
    component: edit
  }
];
