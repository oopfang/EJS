/**
 * 退货差异单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billDiffIn' */ '@/pages/bizPages/bill/billDiffIn/list.vue');
// const add = () => import(/* webpackChunkName:'billDiffIn' */ '@/pages/bizPages/bill/billDiffIn/add.vue');
const edit = () => import(/* webpackChunkName:'billDiffIn' */ '@/pages/bizPages/bill/billDiffIn/edit.vue');
// const view = () => import(/* webpackChunkName:'billDiffIn' */ '@/pages/bizPages/bill/billDiffIn/view.vue');

module.exports = [{
    path: '/billDiffIn',
    name: 'billDiffIn',
    component: list
  },
  {
    path: '/billDiffIn/add',
    name: 'billDiffInAdd',
    props: true,
    component: edit
  },
  {
    path: '/billDiffIn/edit',
    name: 'billDiffInEdit',
    props: true,
    component: edit
  },
  {
    path: '/billDiffIn/view',
    name: 'billDiffInView',
    props: true,
    component: edit
  }
];
