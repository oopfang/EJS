/**
 * 装箱单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billPackage' */ '@/pages/bizPages/bill/billPackage/list.vue');
// const add = () => import(/* webpackChunkName:'billPackage' */ '@/pages/bizPages/bill/billPackage/add.vue');
const edit = () => import(/* webpackChunkName:'billPackage' */ '@/pages/bizPages/bill/billPackage/edit.vue');
// const view = () => import(/* webpackChunkName:'billPackage' */ '@/pages/bizPages/bill/billPackage/view.vue');

module.exports = [{
    path: '/billPackage',
    name: 'billPackage',
    component: list
  },
  {
    path: '/billPackage/add',
    name: 'billPackageAdd',
    props: true,
    component: edit
  },
  {
    path: '/billPackage/edit',
    name: 'billPackageEdit',
    props: true,
    component: edit
  },
  {
    path: '/billPackage/view',
    name: 'billPackageView',
    props: true,
    component: edit
  }
];
