/**
 * 发货差异单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'fahuochayidan' */ '@/pages/bizPages/bill/fahuochayidan/list.vue');
// const add = () => import(/* webpackChunkName:'fahuochayidan' */ '@/pages/bizPages/bill/fahuochayidan/add.vue');
const edit = () => import(/* webpackChunkName:'fahuochayidan' */ '@/pages/bizPages/bill/fahuochayidan/edit.vue');
// const view = () => import(/* webpackChunkName:'fahuochayidan' */ '@/pages/bizPages/bill/fahuochayidan/view.vue');

module.exports = [{
    path: '/fahuochayidan',
    name: 'fahuochayidan',
    component: list
  },
  {
    path: '/fahuochayidan/add',
    name: 'fahuochayidanAdd',
    props: true,
    component: edit
  },
  {
    path: '/fahuochayidan/edit',
    name: 'fahuochayidanEdit',
    props: true,
    component: edit
  },
  {
    path: '/fahuochayidan/view',
    name: 'fahuochayidanView',
    props: true,
    component: edit
  }
];
