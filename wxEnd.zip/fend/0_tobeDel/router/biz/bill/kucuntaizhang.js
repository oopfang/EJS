/**
 * 库存台账表单视图的路由
 */

const list = () => import(/* webpackChunkName:'kucuntaizhang' */ '@/pages/bizPages/bill/kucuntaizhang/list.vue');
// const add = () => import(/* webpackChunkName:'kucuntaizhang' */ '@/pages/bizPages/bill/kucuntaizhang/add.vue');
const edit = () => import(/* webpackChunkName:'kucuntaizhang' */ '@/pages/bizPages/bill/kucuntaizhang/edit.vue');
// const view = () => import(/* webpackChunkName:'kucuntaizhang' */ '@/pages/bizPages/bill/kucuntaizhang/view.vue');

module.exports = [{
    path: '/kucuntaizhang',
    name: 'kucuntaizhang',
    component: list
  },
  {
    path: '/kucuntaizhang/add',
    name: 'kucuntaizhangAdd',
    props: true,
    component: edit
  },
  {
    path: '/kucuntaizhang/edit',
    name: 'kucuntaizhangEdit',
    props: true,
    component: edit
  },
  {
    path: '/kucuntaizhang/view',
    name: 'kucuntaizhangView',
    props: true,
    component: edit
  }
];
