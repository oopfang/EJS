/**
 * 出库明细表表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billSendDetail' */ '@/pages/bizPages/bill/billSendDetail/list.vue');
// const add = () => import(/* webpackChunkName:'billSendDetail' */ '@/pages/bizPages/bill/billSendDetail/add.vue');
const edit = () => import(/* webpackChunkName:'billSendDetail' */ '@/pages/bizPages/bill/billSendDetail/edit.vue');
// const view = () => import(/* webpackChunkName:'billSendDetail' */ '@/pages/bizPages/bill/billSendDetail/view.vue');

module.exports = [{
    path: '/billSendDetail',
    name: 'billSendDetail',
    component: list
  },
  {
    path: '/billSendDetail/add',
    name: 'billSendDetailAdd',
    props: true,
    component: edit
  },
  {
    path: '/billSendDetail/edit',
    name: 'billSendDetailEdit',
    props: true,
    component: edit
  },
  {
    path: '/billSendDetail/view',
    name: 'billSendDetailView',
    props: true,
    component: edit
  }
];
