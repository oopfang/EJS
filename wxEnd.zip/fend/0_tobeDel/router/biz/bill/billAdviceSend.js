/**
 * 发货通知单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/list.vue');
// const add = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/add.vue');
const edit = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/edit.vue');
// const view = () => import(/* webpackChunkName:'billAdviceSend' */ '@/pages/bizPages/bill/billAdviceSend/view.vue');

module.exports = [{
    path: '/billAdviceSend',
    name: 'billAdviceSend',
    component: list
  },
  {
    path: '/billAdviceSend/add',
    name: 'billAdviceSendAdd',
    props: true,
    component: edit
  },
  {
    path: '/billAdviceSend/edit',
    name: 'billAdviceSendEdit',
    props: true,
    component: edit
  },
  {
    path: '/billAdviceSend/view',
    name: 'billAdviceSendView',
    props: true,
    component: edit
  }
];
