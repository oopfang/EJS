/**
 * 盘点单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'pandiandan' */ '@/pages/bizPages/bill/pandiandan/list.vue');
// const add = () => import(/* webpackChunkName:'pandiandan' */ '@/pages/bizPages/bill/pandiandan/add.vue');
const edit = () => import(/* webpackChunkName:'pandiandan' */ '@/pages/bizPages/bill/pandiandan/edit.vue');
// const view = () => import(/* webpackChunkName:'pandiandan' */ '@/pages/bizPages/bill/pandiandan/view.vue');

module.exports = [{
    path: '/pandiandan',
    name: 'pandiandan',
    component: list
  },
  {
    path: '/pandiandan/add',
    name: 'pandiandanAdd',
    props: true,
    component: edit
  },
  {
    path: '/pandiandan/edit',
    name: 'pandiandanEdit',
    props: true,
    component: edit
  },
  {
    path: '/pandiandan/view',
    name: 'pandiandanView',
    props: true,
    component: edit
  }
];
