/**
 * 发货明细表视图的状态单元
 */

import bizDefine from '@/define/billAdviceSendDetail/intro.js';

let getBillAdviceSendDetailEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前发货明细表列表
  billAdviceSendDetailList: [],
  // 当前选定的发货明细表对象
  billAdviceSendDetailObj: getBillAdviceSendDetailEmptyObj()
};

const getters = {
  // 获取发货明细表一览列表数据
  getBillAdviceSendDetailList: state => state.billAdviceSendDetailList,
  // 获取发货明细表对象
  getBillAdviceSendDetailObj: state => state.billAdviceSendDetailObj
};

const mutations = {
  // 绑定发货明细表一览表数据
  setBillAdviceSendDetailList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billAdviceSendDetailList = data;
    }
  },
  // 设置发货明细表对象
  setBillAdviceSendDetailObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billAdviceSendDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的发货明细表记录行
  removeBillAdviceSendDetailObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billAdviceSendDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billAdviceSendDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillAdviceSendDetail: state => {
    state.billAdviceSendDetailList = [];
    state.billAdviceSendDetailObj = getBillAdviceSendDetailEmptyObj();
  }
};

const actions = {
  // 远程获取发货明细表一览表
  queryBillAdviceSendDetailList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billAdviceSendDetail/list', option)
        .then(res => {
          contex.commit('setBillAdviceSendDetailList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的发货明细表对象
  queryBillAdviceSendDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billAdviceSendDetail/obj', option)
        .then(res => {
          contex.commit('setBillAdviceSendDetailObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增发货明细表的请求
  postBillAdviceSendDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billAdviceSendDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑发货明细表的请求
  putBillAdviceSendDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billAdviceSendDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的发货明细表对象
  delBillAdviceSendDetailMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billAdviceSendDetail/del', option)
        .then(res => {
          contex.commit('removeBillAdviceSendDetailObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
