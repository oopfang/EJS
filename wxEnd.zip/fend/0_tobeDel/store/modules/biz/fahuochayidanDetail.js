/**
 * 发货差异明细表视图的状态单元
 */

import bizDefine from '@/define/fahuochayidanDetail/intro.js';

let getFahuochayidanDetailEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前发货差异明细表列表
  fahuochayidanDetailList: [],
  // 当前选定的发货差异明细表对象
  fahuochayidanDetailObj: getFahuochayidanDetailEmptyObj()
};

const getters = {
  // 获取发货差异明细表一览列表数据
  getFahuochayidanDetailList: state => state.fahuochayidanDetailList,
  // 获取发货差异明细表对象
  getFahuochayidanDetailObj: state => state.fahuochayidanDetailObj
};

const mutations = {
  // 绑定发货差异明细表一览表数据
  setFahuochayidanDetailList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.fahuochayidanDetailList = data;
    }
  },
  // 设置发货差异明细表对象
  setFahuochayidanDetailObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.fahuochayidanDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的发货差异明细表记录行
  removeFahuochayidanDetailObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.fahuochayidanDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.fahuochayidanDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheFahuochayidanDetail: state => {
    state.fahuochayidanDetailList = [];
    state.fahuochayidanDetailObj = getFahuochayidanDetailEmptyObj();
  }
};

const actions = {
  // 远程获取发货差异明细表一览表
  queryFahuochayidanDetailList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/fahuochayidanDetail/list', option)
        .then(res => {
          contex.commit('setFahuochayidanDetailList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的发货差异明细表对象
  queryFahuochayidanDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/fahuochayidanDetail/obj', option)
        .then(res => {
          contex.commit('setFahuochayidanDetailObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增发货差异明细表的请求
  postFahuochayidanDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/fahuochayidanDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑发货差异明细表的请求
  putFahuochayidanDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/fahuochayidanDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的发货差异明细表对象
  delFahuochayidanDetailMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/fahuochayidanDetail/del', option)
        .then(res => {
          contex.commit('removeFahuochayidanDetailObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
