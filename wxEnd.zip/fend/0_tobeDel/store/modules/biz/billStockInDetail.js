/**
 * 上架明细单视图的状态单元
 */

import bizDefine from '@/define/billStockInDetail/intro.js';

let getBillStockInDetailEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前上架明细单列表
  billStockInDetailList: [],
  // 当前选定的上架明细单对象
  billStockInDetailObj: getBillStockInDetailEmptyObj()
};

const getters = {
  // 获取上架明细单一览列表数据
  getBillStockInDetailList: state => state.billStockInDetailList,
  // 获取上架明细单对象
  getBillStockInDetailObj: state => state.billStockInDetailObj
};

const mutations = {
  // 绑定上架明细单一览表数据
  setBillStockInDetailList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billStockInDetailList = data;
    }
  },
  // 设置上架明细单对象
  setBillStockInDetailObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billStockInDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的上架明细单记录行
  removeBillStockInDetailObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billStockInDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billStockInDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillStockInDetail: state => {
    state.billStockInDetailList = [];
    state.billStockInDetailObj = getBillStockInDetailEmptyObj();
  }
};

const actions = {
  // 远程获取上架明细单一览表
  queryBillStockInDetailList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billStockInDetail/list', option)
        .then(res => {
          contex.commit('setBillStockInDetailList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的上架明细单对象
  queryBillStockInDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billStockInDetail/obj', option)
        .then(res => {
          contex.commit('setBillStockInDetailObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增上架明细单的请求
  postBillStockInDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billStockInDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑上架明细单的请求
  putBillStockInDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billStockInDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的上架明细单对象
  delBillStockInDetailMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billStockInDetail/del', option)
        .then(res => {
          contex.commit('removeBillStockInDetailObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
