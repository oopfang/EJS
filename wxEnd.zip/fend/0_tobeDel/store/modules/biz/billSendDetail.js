/**
 * 出库明细表视图的状态单元
 */

import bizDefine from '@/define/billSendDetail/intro.js';

let getBillSendDetailEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前出库明细表列表
  billSendDetailList: [],
  // 当前选定的出库明细表对象
  billSendDetailObj: getBillSendDetailEmptyObj()
};

const getters = {
  // 获取出库明细表一览列表数据
  getBillSendDetailList: state => state.billSendDetailList,
  // 获取出库明细表对象
  getBillSendDetailObj: state => state.billSendDetailObj
};

const mutations = {
  // 绑定出库明细表一览表数据
  setBillSendDetailList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billSendDetailList = data;
    }
  },
  // 设置出库明细表对象
  setBillSendDetailObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billSendDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的出库明细表记录行
  removeBillSendDetailObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billSendDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billSendDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillSendDetail: state => {
    state.billSendDetailList = [];
    state.billSendDetailObj = getBillSendDetailEmptyObj();
  }
};

const actions = {
  // 远程获取出库明细表一览表
  queryBillSendDetailList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billSendDetail/list', option)
        .then(res => {
          contex.commit('setBillSendDetailList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的出库明细表对象
  queryBillSendDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billSendDetail/obj', option)
        .then(res => {
          contex.commit('setBillSendDetailObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增出库明细表的请求
  postBillSendDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billSendDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑出库明细表的请求
  putBillSendDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billSendDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的出库明细表对象
  delBillSendDetailMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billSendDetail/del', option)
        .then(res => {
          contex.commit('removeBillSendDetailObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
