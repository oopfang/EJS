/**
 * 盘点盈亏单视图的状态单元
 */

import bizDefine from '@/define/pandianyingkuidan/intro.js';

let getPandianyingkuidanEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前盘点盈亏单列表
  pandianyingkuidanList: [],
  // 当前选定的盘点盈亏单对象
  pandianyingkuidanObj: getPandianyingkuidanEmptyObj()
};

const getters = {
  // 获取盘点盈亏单一览列表数据
  getPandianyingkuidanList: state => state.pandianyingkuidanList,
  // 获取盘点盈亏单对象
  getPandianyingkuidanObj: state => state.pandianyingkuidanObj
};

const mutations = {
  // 绑定盘点盈亏单一览表数据
  setPandianyingkuidanList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.pandianyingkuidanList = data;
    }
  },
  // 设置盘点盈亏单对象
  setPandianyingkuidanObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.pandianyingkuidanObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的盘点盈亏单记录行
  removePandianyingkuidanObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.pandianyingkuidanList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.pandianyingkuidanList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCachePandianyingkuidan: state => {
    state.pandianyingkuidanList = [];
    state.pandianyingkuidanObj = getPandianyingkuidanEmptyObj();
  }
};

const actions = {
  // 远程获取盘点盈亏单一览表
  queryPandianyingkuidanList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/pandianyingkuidan/list', option)
        .then(res => {
          contex.commit('setPandianyingkuidanList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的盘点盈亏单对象
  queryPandianyingkuidanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/pandianyingkuidan/obj', option)
        .then(res => {
          contex.commit('setPandianyingkuidanObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增盘点盈亏单的请求
  postPandianyingkuidanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/pandianyingkuidan/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑盘点盈亏单的请求
  putPandianyingkuidanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/pandianyingkuidan/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的盘点盈亏单对象
  delPandianyingkuidanMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/pandianyingkuidan/del', option)
        .then(res => {
          contex.commit('removePandianyingkuidanObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
