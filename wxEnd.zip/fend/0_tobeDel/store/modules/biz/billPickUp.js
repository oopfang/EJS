/**
 * 取件单视图的状态单元
 */

import bizDefine from '@/define/billPickUp/intro.js';

let getBillPickUpEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前取件单列表
  billPickUpList: [],
  // 当前选定的取件单对象
  billPickUpObj: getBillPickUpEmptyObj()
};

const getters = {
  // 获取取件单一览列表数据
  getBillPickUpList: state => state.billPickUpList,
  // 获取取件单对象
  getBillPickUpObj: state => state.billPickUpObj
};

const mutations = {
  // 绑定取件单一览表数据
  setBillPickUpList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billPickUpList = data;
    }
  },
  // 设置取件单对象
  setBillPickUpObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billPickUpObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的取件单记录行
  removeBillPickUpObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billPickUpList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billPickUpList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillPickUp: state => {
    state.billPickUpList = [];
    state.billPickUpObj = getBillPickUpEmptyObj();
  }
};

const actions = {
  // 远程获取取件单一览表
  queryBillPickUpList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billPickUp/list', option)
        .then(res => {
          contex.commit('setBillPickUpList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的取件单对象
  queryBillPickUpObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billPickUp/obj', option)
        .then(res => {
          contex.commit('setBillPickUpObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增取件单的请求
  postBillPickUpObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billPickUp/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑取件单的请求
  putBillPickUpObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billPickUp/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的取件单对象
  delBillPickUpMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billPickUp/del', option)
        .then(res => {
          contex.commit('removeBillPickUpObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
