/**
 * 装箱单明细视图的状态单元
 */

import bizDefine from '@/define/billPackageDetail/intro.js';

let getBillPackageDetailEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前装箱单明细列表
  billPackageDetailList: [],
  // 当前选定的装箱单明细对象
  billPackageDetailObj: getBillPackageDetailEmptyObj()
};

const getters = {
  // 获取装箱单明细一览列表数据
  getBillPackageDetailList: state => state.billPackageDetailList,
  // 获取装箱单明细对象
  getBillPackageDetailObj: state => state.billPackageDetailObj
};

const mutations = {
  // 绑定装箱单明细一览表数据
  setBillPackageDetailList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billPackageDetailList = data;
    }
  },
  // 设置装箱单明细对象
  setBillPackageDetailObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billPackageDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的装箱单明细记录行
  removeBillPackageDetailObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billPackageDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billPackageDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillPackageDetail: state => {
    state.billPackageDetailList = [];
    state.billPackageDetailObj = getBillPackageDetailEmptyObj();
  }
};

const actions = {
  // 远程获取装箱单明细一览表
  queryBillPackageDetailList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billPackageDetail/list', option)
        .then(res => {
          contex.commit('setBillPackageDetailList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的装箱单明细对象
  queryBillPackageDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billPackageDetail/obj', option)
        .then(res => {
          contex.commit('setBillPackageDetailObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增装箱单明细的请求
  postBillPackageDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billPackageDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑装箱单明细的请求
  putBillPackageDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billPackageDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的装箱单明细对象
  delBillPackageDetailMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billPackageDetail/del', option)
        .then(res => {
          contex.commit('removeBillPackageDetailObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
