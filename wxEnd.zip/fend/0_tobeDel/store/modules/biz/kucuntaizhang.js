/**
 * 库存台账视图的状态单元
 */

import bizDefine from '@/define/kucuntaizhang/intro.js';

let getKucuntaizhangEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前库存台账列表
  kucuntaizhangList: [],
  // 当前选定的库存台账对象
  kucuntaizhangObj: getKucuntaizhangEmptyObj()
};

const getters = {
  // 获取库存台账一览列表数据
  getKucuntaizhangList: state => state.kucuntaizhangList,
  // 获取库存台账对象
  getKucuntaizhangObj: state => state.kucuntaizhangObj
};

const mutations = {
  // 绑定库存台账一览表数据
  setKucuntaizhangList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.kucuntaizhangList = data;
    }
  },
  // 设置库存台账对象
  setKucuntaizhangObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.kucuntaizhangObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的库存台账记录行
  removeKucuntaizhangObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.kucuntaizhangList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.kucuntaizhangList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheKucuntaizhang: state => {
    state.kucuntaizhangList = [];
    state.kucuntaizhangObj = getKucuntaizhangEmptyObj();
  }
};

const actions = {
  // 远程获取库存台账一览表
  queryKucuntaizhangList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/kucuntaizhang/list', option)
        .then(res => {
          contex.commit('setKucuntaizhangList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的库存台账对象
  queryKucuntaizhangObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/kucuntaizhang/obj', option)
        .then(res => {
          contex.commit('setKucuntaizhangObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增库存台账的请求
  postKucuntaizhangObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/kucuntaizhang/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑库存台账的请求
  putKucuntaizhangObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/kucuntaizhang/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的库存台账对象
  delKucuntaizhangMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/kucuntaizhang/del', option)
        .then(res => {
          contex.commit('removeKucuntaizhangObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
