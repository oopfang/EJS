/**
 * 装箱单视图的状态单元
 */

import bizDefine from '@/define/billPackage/intro.js';

let getBillPackageEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前装箱单列表
  billPackageList: [],
  // 当前选定的装箱单对象
  billPackageObj: getBillPackageEmptyObj()
};

const getters = {
  // 获取装箱单一览列表数据
  getBillPackageList: state => state.billPackageList,
  // 获取装箱单对象
  getBillPackageObj: state => state.billPackageObj
};

const mutations = {
  // 绑定装箱单一览表数据
  setBillPackageList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billPackageList = data;
    }
  },
  // 设置装箱单对象
  setBillPackageObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billPackageObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的装箱单记录行
  removeBillPackageObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billPackageList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billPackageList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillPackage: state => {
    state.billPackageList = [];
    state.billPackageObj = getBillPackageEmptyObj();
  }
};

const actions = {
  // 远程获取装箱单一览表
  queryBillPackageList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billPackage/list', option)
        .then(res => {
          contex.commit('setBillPackageList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的装箱单对象
  queryBillPackageObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billPackage/obj', option)
        .then(res => {
          contex.commit('setBillPackageObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增装箱单的请求
  postBillPackageObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billPackage/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑装箱单的请求
  putBillPackageObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billPackage/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的装箱单对象
  delBillPackageMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billPackage/del', option)
        .then(res => {
          contex.commit('removeBillPackageObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
