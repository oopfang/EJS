/**
 * 退货差异单视图的状态单元
 */

import bizDefine from '@/define/billDiffIn/intro.js';

let getBillDiffInEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前退货差异单列表
  billDiffInList: [],
  // 当前选定的退货差异单对象
  billDiffInObj: getBillDiffInEmptyObj()
};

const getters = {
  // 获取退货差异单一览列表数据
  getBillDiffInList: state => state.billDiffInList,
  // 获取退货差异单对象
  getBillDiffInObj: state => state.billDiffInObj
};

const mutations = {
  // 绑定退货差异单一览表数据
  setBillDiffInList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billDiffInList = data;
    }
  },
  // 设置退货差异单对象
  setBillDiffInObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billDiffInObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的退货差异单记录行
  removeBillDiffInObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billDiffInList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billDiffInList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillDiffIn: state => {
    state.billDiffInList = [];
    state.billDiffInObj = getBillDiffInEmptyObj();
  }
};

const actions = {
  // 远程获取退货差异单一览表
  queryBillDiffInList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billDiffIn/list', option)
        .then(res => {
          contex.commit('setBillDiffInList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的退货差异单对象
  queryBillDiffInObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billDiffIn/obj', option)
        .then(res => {
          contex.commit('setBillDiffInObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增退货差异单的请求
  postBillDiffInObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billDiffIn/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑退货差异单的请求
  putBillDiffInObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billDiffIn/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的退货差异单对象
  delBillDiffInMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billDiffIn/del', option)
        .then(res => {
          contex.commit('removeBillDiffInObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
