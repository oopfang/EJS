/**
 * 盘点单视图的状态单元
 */

import bizDefine from '@/define/pandiandan/intro.js';

let getPandiandanEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前盘点单列表
  pandiandanList: [],
  // 当前选定的盘点单对象
  pandiandanObj: getPandiandanEmptyObj()
};

const getters = {
  // 获取盘点单一览列表数据
  getPandiandanList: state => state.pandiandanList,
  // 获取盘点单对象
  getPandiandanObj: state => state.pandiandanObj
};

const mutations = {
  // 绑定盘点单一览表数据
  setPandiandanList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.pandiandanList = data;
    }
  },
  // 设置盘点单对象
  setPandiandanObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.pandiandanObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的盘点单记录行
  removePandiandanObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.pandiandanList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.pandiandanList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCachePandiandan: state => {
    state.pandiandanList = [];
    state.pandiandanObj = getPandiandanEmptyObj();
  }
};

const actions = {
  // 远程获取盘点单一览表
  queryPandiandanList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/pandiandan/list', option)
        .then(res => {
          contex.commit('setPandiandanList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的盘点单对象
  queryPandiandanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/pandiandan/obj', option)
        .then(res => {
          contex.commit('setPandiandanObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增盘点单的请求
  postPandiandanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/pandiandan/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑盘点单的请求
  putPandiandanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/pandiandan/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的盘点单对象
  delPandiandanMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/pandiandan/del', option)
        .then(res => {
          contex.commit('removePandiandanObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
