/**
 * 退货申请明细视图的状态单元
 */

import bizDefine from '@/define/returenAskDetail/intro.js';

let getRetuEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前退货申请明细列表
  returenAskDetailList: [],
  // 当前选定的退货申请明细对象
  returenAskDetailObj: getRetuEmptyObj()
};

const getters = {
  // 获取退货申请明细一览列表数据
  getRetuList: state => state.returenAskDetailList,
  // 获取退货申请明细对象
  getRetuObj: state => state.returenAskDetailObj
};

const mutations = {
  // 绑定退货申请明细一览表数据
  setRetuList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.returenAskDetailList = data;
    }
  },
  // 设置退货申请明细对象
  setRetuObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.returenAskDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的退货申请明细记录行
  removeRetuObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.returenAskDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.returenAskDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheRetu: state => {
    state.returenAskDetailList = [];
    state.returenAskDetailObj = getRetuEmptyObj();
  }
};

const actions = {
  // 远程获取退货申请明细一览表
  queryRetuList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/returenAskDetail/list', option)
        .then(res => {
          contex.commit('setRetuList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的退货申请明细对象
  queryRetuObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/returenAskDetail/obj', option)
        .then(res => {
          contex.commit('setRetuObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增退货申请明细的请求
  postRetuObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/returenAskDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑退货申请明细的请求
  putRetuObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/returenAskDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的退货申请明细对象
  delRetuMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/returenAskDetail/del', option)
        .then(res => {
          contex.commit('removeRetuObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
