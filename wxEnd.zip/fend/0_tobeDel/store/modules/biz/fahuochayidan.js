/**
 * 发货差异单视图的状态单元
 */

import bizDefine from '@/define/fahuochayidan/intro.js';

let getFahuochayidanEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前发货差异单列表
  fahuochayidanList: [],
  // 当前选定的发货差异单对象
  fahuochayidanObj: getFahuochayidanEmptyObj()
};

const getters = {
  // 获取发货差异单一览列表数据
  getFahuochayidanList: state => state.fahuochayidanList,
  // 获取发货差异单对象
  getFahuochayidanObj: state => state.fahuochayidanObj
};

const mutations = {
  // 绑定发货差异单一览表数据
  setFahuochayidanList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.fahuochayidanList = data;
    }
  },
  // 设置发货差异单对象
  setFahuochayidanObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.fahuochayidanObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的发货差异单记录行
  removeFahuochayidanObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.fahuochayidanList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.fahuochayidanList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheFahuochayidan: state => {
    state.fahuochayidanList = [];
    state.fahuochayidanObj = getFahuochayidanEmptyObj();
  }
};

const actions = {
  // 远程获取发货差异单一览表
  queryFahuochayidanList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/fahuochayidan/list', option)
        .then(res => {
          contex.commit('setFahuochayidanList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的发货差异单对象
  queryFahuochayidanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/fahuochayidan/obj', option)
        .then(res => {
          contex.commit('setFahuochayidanObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增发货差异单的请求
  postFahuochayidanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/fahuochayidan/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑发货差异单的请求
  putFahuochayidanObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/fahuochayidan/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的发货差异单对象
  delFahuochayidanMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/fahuochayidan/del', option)
        .then(res => {
          contex.commit('removeFahuochayidanObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
