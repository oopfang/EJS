/**
 * 退货差异明细视图的状态单元
 */

import bizDefine from '@/define/billDiffInDetail/intro.js';

let getBillDiffInDetailEmptyObj = () => {
  return JSON.parse(JSON.stringify(bizDefine.emptyVal));
};

const state = {
  // 当前退货差异明细列表
  billDiffInDetailList: [],
  // 当前选定的退货差异明细对象
  billDiffInDetailObj: getBillDiffInDetailEmptyObj()
};

const getters = {
  // 获取退货差异明细一览列表数据
  getBillDiffInDetailList: state => state.billDiffInDetailList,
  // 获取退货差异明细对象
  getBillDiffInDetailObj: state => state.billDiffInDetailObj
};

const mutations = {
  // 绑定退货差异明细一览表数据
  setBillDiffInDetailList: (state, data) => {
    if (data && Array.isArray(data)) {
      state.billDiffInDetailList = data;
    }
  },
  // 设置退货差异明细对象
  setBillDiffInDetailObj: (state, obj) => {
    if (obj && Object.keys(obj).length > 0) {
      state.billDiffInDetailObj = obj;
    }
  },
  // 从当前加载列表中移除指定ID的退货差异明细记录行
  removeBillDiffInDetailObjs: (state, ids) => {
    let _removeFunc = id => {
      let _idx = state.billDiffInDetailList.findIndex(v => {
        return v.id === id;
      });
      if (_idx > -1) {
        state.billDiffInDetailList.splice(_idx, 1);
      }
    };
    if (Array.isArray(ids)) {
      for (let vid of ids) {
        _removeFunc(vid);
      }
    } else {
      _removeFunc(ids);
    }
  },
  // 清除对象内存缓存
  clearCacheBillDiffInDetail: state => {
    state.billDiffInDetailList = [];
    state.billDiffInDetailObj = getBillDiffInDetailEmptyObj();
  }
};

const actions = {
  // 远程获取退货差异明细一览表
  queryBillDiffInDetailList(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billDiffInDetail/list', option)
        .then(res => {
          contex.commit('setBillDiffInDetailList', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程获取指定ID的退货差异明细对象
  queryBillDiffInDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.getFunc('biz/billDiffInDetail/obj', option)
        .then(res => {
          contex.commit('setBillDiffInDetailObj', res.result);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送新增退货差异明细的请求
  postBillDiffInDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.postFunc('biz/billDiffInDetail/add', option)
        .then(res => {
          resolve(res.result.insertId);
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程发送编辑退货差异明细的请求
  putBillDiffInDetailObj(contex, option) {
    return new Promise((resolve, reject) => {
      global.putFunc('biz/billDiffInDetail/edit', option)
        .then(res => {
          resolve('保存成功');
        })
        .catch(err => {
          reject(err);
        });
    });
  },
  // 远程删除指定ID的退货差异明细对象
  delBillDiffInDetailMulti(contex, option) {
    return new Promise((resolve, reject) => {
      global.deleteFunc('biz/billDiffInDetail/del', option)
        .then(res => {
          contex.commit('removeBillDiffInDetailObjs', option.by.id);
          resolve(res.result);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
