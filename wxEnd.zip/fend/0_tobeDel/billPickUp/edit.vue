<template>
<baseCrudEdit :baseDefine="baseDefine" :inLoading="inLoading" :currId="currId" :inEdit="inEdit" @onAdd="onAdd" @onEdit="onEdit" @saveEvnt="saveHandler">
  <Row :space="18">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">客户名称</span>
      <input v-if="inEdit" type="text" v-model="dataset.custId" />
      <span v-else class="billItemData">{{dataset.custId}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">要求取件日期</span>
      <DatePicker v-if="inEdit" v-model="dataset.datePickAsk" format="YYYY-MM-DD"></DatePicker>
      <span v-else class="billItemData">{{dataset.datePickAsk}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">联系电话</span>
      <NumberInput v-if="inEdit" v-model="dataset.custPhone" :useOperate="true"></NumberInput>
      <span v-else class="billItemData">{{dataset.custPhone}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">客户地址</span>
      <input v-if="inEdit" type="text" v-model="dataset.custAddr" />
      <span v-else class="billItemData">{{dataset.custAddr}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">取件员</span>
      <input v-if="inEdit" type="text" v-model="dataset.operator" />
      <span v-else class="billItemData">{{dataset.operator}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">取件状态</span>
      <input v-if="inEdit" type="text" v-model="dataset.pickStateId" disabled />
      <span v-else class="billItemData">{{dataset.pickStateId}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">照片地址</span>
      <input v-if="inEdit" type="text" v-model="dataset.picAddr" />
      <span v-else class="billItemData">{{dataset.picAddr}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">备注</span>
      <textarea v-if="inEdit" rows="5" v-autosize v-model="dataset.memo" :readonly="!inEdit"></textarea>
    </Col>
      <Col :width="24" class="h-input-group">
        <span class="h-input-addon">备注</span>
        <textarea v-if="inEdit" rows="5" v-autosize v-model="dataset.memo" :readonly="!inEdit"></textarea>
      </Col>
  </Row>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billPickUp';

export default {
  name: 'billPickUpEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {}
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillPickUpObj', 'getUserInfo'])
  },
  methods: {
    ...mapActions(['queryBillPickUpObj', 'putBillPickUpObj', 'postBillPickUpObj', 'queryMaster']),
    // 保存操作的响应
    async saveHandler() {
      try {
        let _func = this.isAdd ? this.postBillPickUpObj : this.putBillPickUpObj;
        let x = {};
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset, this.dataset.id)]
          }
        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };
        }
        let res = await _func(x);
        this.inEdit = false;
        x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: res
          }
        }];
        let resObj = await this.queryBillPickUpObj(x);
        this.dataset = resObj[0];
      } catch (err) {
        terr(err);
      }
    },
    onAdd() {
      this.inEdit = true;
      this.dataset = this.bizDefine.emptyVal();
    },
    onEdit() {
      this.inEdit = true;
    }
  },
  async mounted() {
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        if (id && id > 0) {
          this.isAdd = false;
          let x = [{
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          }];
          let res = await this.queryBillPickUpObj(x);
          this.dataset = this.getBillPickUpObj[0];
          this.inLoading = false;
        } else {
          this.isAdd = true;
          this.dataset = this.bizDefine.emptyVal();
        }
      } else {
        this.isAdd = true;
        this.dataset = this.bizDefine.emptyVal();
      }
      
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>
