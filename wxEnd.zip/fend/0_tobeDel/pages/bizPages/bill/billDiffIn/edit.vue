<template>
<baseCrudEdit :baseDefine="baseDefine" :inLoading="inLoading" :currId="currId" :inEdit="inEdit" @onAdd="onAdd" @onEdit="onEdit" @saveEvnt="saveHandler">
  <Row :space="18">
    <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">ID</span>
      <span>{{dataset.id}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">退货单ID</span>
      <NumberInput v-if="inEdit" v-model="dataset.pid" :useOperate="true"></NumberInput>
      <span v-else class="billItemData">{{dataset.pid}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">代码</span>
      <input v-if="inEdit" type="text" v-model="dataset.code" />
      <span v-else class="billItemData">{{dataset.code}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">英文名称</span>
      <input v-if="inEdit" type="text" v-model="dataset.name" />
      <span v-else class="billItemData">{{dataset.name}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">差异发生日期</span>
      <DatePicker v-if="inEdit" v-model="dataset.dateDiff" format="YYYY-MM-DD"></DatePicker>
      <span v-else class="billItemData">{{dataset.dateDiff}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">中文名称</span>
      <input v-if="inEdit" type="text" v-model="dataset.namezh" />
      <span v-else class="billItemData">{{dataset.namezh}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">备注</span>
      <textarea v-if="inEdit" rows="5" v-autosize v-model="dataset.memo" :readonly="!inEdit"></textarea>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">退货申请单ID</span>
      <NumberInput v-if="inEdit" v-model="dataset.billReturnAskId" :useOperate="true"></NumberInput>
      <span v-else class="billItemData">{{dataset.billReturnAskId}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">仓管员ID</span>
      <NumberInput v-if="inEdit" v-model="dataset.operator" :useOperate="true"></NumberInput>
      <span v-else class="billItemData">{{dataset.operator}}</span>
    </Col>
      <Col :width="24" class="h-input-group">
        <span class="h-input-addon">备注</span>
        <textarea v-if="inEdit" rows="5" v-autosize v-model="dataset.memo" :readonly="!inEdit"></textarea>
      </Col>
  </Row>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billDiffIn';

export default {
  name: 'billDiffInEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {}
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillDiffInObj', 'getUserInfo'])
  },
  methods: {
    ...mapActions(['queryBillDiffInObj', 'putBillDiffInObj', 'postBillDiffInObj', 'queryMaster']),
    // 保存操作的响应
    async saveHandler() {
      try {
        let _func = this.isAdd ? this.postBillDiffInObj : this.putBillDiffInObj;
        let x = {};
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset, this.dataset.id)]
          }
        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };
        }
        let res = await _func(x);
        this.inEdit = false;
        x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: res
          }
        }];
        let resObj = await this.queryBillDiffInObj(x);
        this.dataset = resObj[0];
      } catch (err) {
        terr(err);
      }
    },
    onAdd() {
      this.inEdit = true;
      this.dataset = this.bizDefine.emptyVal();
    },
    onEdit() {
      this.inEdit = true;
    }
  },
  async mounted() {
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        if (id && id > 0) {
          this.isAdd = false;
          let x = [{
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          }];
          let res = await this.queryBillDiffInObj(x);
          this.dataset = this.getBillDiffInObj[0];
          this.inLoading = false;
        } else {
          this.isAdd = true;
          this.dataset = this.bizDefine.emptyVal();
        }
      } else {
        this.isAdd = true;
        this.dataset = this.bizDefine.emptyVal();
      }
      
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>
