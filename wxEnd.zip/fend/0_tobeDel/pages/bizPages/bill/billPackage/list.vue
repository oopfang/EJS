<template>
<tBaseCrudList :define="bizDefine" :inLoading="inLoading" :footerCustom="footMsg" @eventFilter="filterHandler" @eventFind="findHandler"></tBaseCrudList>
</template>

<script>
import tBaseCrudList from '@/components/wrapper/baseCrudList';
import enumObj from 'tframe-enum';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billPackage';

export default {
  name: 'billPackageList',
  components: {
    tBaseCrudList
  },
  data: function() {
    return {
      bizDefine: {},
      // 控制页面显示加载状态遮罩
      inLoading: false,
      filterParams: {},
      footMsg: ['数量合计： ', '金额总计：  元']
    };
  },
  computed: {
    ...mapGetters(['getBizDefine'])
  },
  methods: {
    ...mapActions(['queryBillPackageList', 'delBillPackageMulti']),
    // 组合查找事件的响应
    findHandler: function(fObj) {
      this.inLoading = true;
      let x = {
        $act: enumObj.crud.act.read,
        bizIdent: bizIdent,
        by: fObj
      };
      this.queryBillPackageList(x)
        .then(res => {
          this.inLoading = false;
        })
        .catch(err => {
          this.inLoading = false;
          global.terr(err);
        });
    },
    // 页内筛选事件的响应
    filterHandler: function() {}
  },
  mounted() {
    this.bizDefine = this.getBizDefine[bizIdent];
    let x = {
      $act: enumObj.crud.act.read,
      bizIdent: bizIdent,
      by: {
        $gte: {
          /* eslint-disable no-undef */
          changeby: dayjs().subtract(2, 'month')
        }
      }
    };
    this.queryBillPackageList(x)
      .then(res => {
        this.inLoading = false;
      })
      .catch(err => {
        this.inLoading = false;
        global.terr(err);
      });
  }
};
</script>
