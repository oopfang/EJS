<template>
<baseCrudEdit :baseDefine="baseDefine" :inLoading="inLoading" :currId="currId" :inEdit="inEdit" @onAdd="onAdd" @onEdit="onEdit" @saveEvnt="saveHandler">
  <Row :space="18">
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">商品唯一码</span>
      <input v-if="inEdit" type="text" v-model="dataset.code" />
      <span v-else class="billItemData">{{dataset.code}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">单位</span>
      <input v-if="inEdit" type="text" v-model="dataset.unit" />
      <span v-else class="billItemData">{{dataset.unit}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">数量</span>
      <NumberInput v-if="inEdit" v-model="dataset.quantity" :useOperate="true"></NumberInput>
      <span v-else class="billItemData">{{dataset.quantity}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">质量类型</span>
      <Select :disabled="!inEdit" v-model="dataset.qualityType" :datas="$root.$data._dict.returnQualityType" :nullOption="false"></Select>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">质量程度</span>
      <Select :disabled="!inEdit" v-model="dataset.qualityLevel" :datas="$root.$data._dict.returnQualityType" :nullOption="false"></Select>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">可再销</span>
      <h-switch v-if="inEdit" v-model="dataset.resaleAble" :trueValue="1" :falseValue="0" small>可再销</h-switch>
      <span v-else class="billItemData">{{dataset.resaleAble}}</span>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">鉴验员ID</span>
      <Select :disabled="!inEdit" v-model="dataset.operator" :datas="$root.$data._dict.hr" :nullOption="false"></Select>
    </Col>
      <Col :xl="8" :lg="8" :md="12" :sm="24" :xs="24" class="h-input-group">
      <span class="h-input-addon">照片地址</span>
      <input v-if="inEdit" type="text" v-model="dataset.picAddr" />
      <span v-else class="billItemData">{{dataset.picAddr}}</span>
    </Col>
      <Col :width="24" class="h-input-group">
        <span class="h-input-addon">备注</span>
        <textarea v-if="inEdit" rows="5" v-autosize v-model="dataset.memo" :readonly="!inEdit"></textarea>
      </Col>
  </Row>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'billVrifyDetail';

export default {
  name: 'billVrifyDetailEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {}
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getBillVrifyDetailObj', 'getUserInfo'])
  },
  methods: {
    ...mapActions(['queryBillVrifyDetailObj', 'putBillVrifyDetailObj', 'postBillVrifyDetailObj', 'queryMaster']),
    // 保存操作的响应
    async saveHandler() {
      try {
        let _func = this.isAdd ? this.postBillVrifyDetailObj : this.putBillVrifyDetailObj;
        let x = {};
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset, this.dataset.id)]
          }
        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };
        }
        let res = await _func(x);
        this.inEdit = false;
        x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: res
          }
        }];
        let resObj = await this.queryBillVrifyDetailObj(x);
        this.dataset = resObj[0];
      } catch (err) {
        terr(err);
      }
    },
    onAdd() {
      this.inEdit = true;
      this.dataset = this.bizDefine.emptyVal();
    },
    onEdit() {
      this.inEdit = true;
    }
  },
  async mounted() {
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        if (id && id > 0) {
          this.isAdd = false;
          let x = [{
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          }];
          let res = await this.queryBillVrifyDetailObj(x);
          this.dataset = this.getBillVrifyDetailObj[0];
          this.inLoading = false;
        } else {
          this.isAdd = true;
          this.dataset = this.bizDefine.emptyVal();
        }
      } else {
        this.isAdd = true;
        this.dataset = this.bizDefine.emptyVal();
      }
        
		let resMaster = await this.queryMaster({
			keys: ['returnQualityType', 'hr']
		});
		let _keys = Object.keys(resMaster);
		for (let v of _keys) {
			this.$set(this.$root.$data._dict, v, resMaster[v]);
		}
      
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>
