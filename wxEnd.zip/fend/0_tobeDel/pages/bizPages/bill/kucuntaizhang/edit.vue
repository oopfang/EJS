<template>
<baseCrudEdit :baseDefine="baseDefine" :inLoading="inLoading" :currId="currId" :inEdit="inEdit" @onAdd="onAdd" @onEdit="onEdit" @saveEvnt="saveHandler">
  <Row :space="18">
    
  </Row>
</baseCrudEdit>
</template>

<script>
import baseCrudEdit from '@/components/wrapper/baseCrudEdit';
import tCrudPanel from '@/components/wrapper/part/tCrudPanel';
import enumObj from 'tframe-enum';
import dayjs from 'dayjs';
import { mapGetters, mapActions } from 'vuex';
// 定义本视图业务标识
const bizIdent = 'kucuntaizhang';

export default {
  name: 'kucuntaizhangEdit',
  components: {
    baseCrudEdit,
    tCrudPanel
  },
  data: function () {
    return {
      bizDefine: {},
      currId: -1,
      // 传递给EDIT模板钉钉定义简集
      baseDefine: [],
      currStep: 0,
      inLoading: false,
      // 明细对象的数量
      subCount: 0,
      // 编辑类型：TRUE：新增，FALSE：修改
      isAdd: false,
      // 是否处于编辑状态
      inEdit: false,
      dataset: {}
    };
  },
  computed: {
    ...mapGetters(['getBizDefine', 'getKucuntaizhangObj', 'getUserInfo'])
  },
  methods: {
    ...mapActions(['queryKucuntaizhangObj', 'putKucuntaizhangObj', 'postKucuntaizhangObj', 'queryMaster']),
    // 保存操作的响应
    async saveHandler() {
      try {
        let _func = this.isAdd ? this.postKucuntaizhangObj : this.putKucuntaizhangObj;
        let x = {};
        if (this.isAdd) {
          let _initCode = parseInt(dayjs().format('YYYYMMDDHHmmsss'));
          if (!this.dataset.code) {
            this.$set(this.dataset, 'code', `${_initCode}${this.getUserInfo.id}`);
          }
          x = {
            $act: enumObj.crud.act.add,
            bizIdent: this.bizDefine.intro.code,
            data: [global.preReqData(this.dataset, this.dataset.id)]
          }
        } else {
          x = {
            $act: enumObj.crud.act.edit,
            bizIdent: this.bizDefine.intro.code,
            data: global.preReqData(this.dataset),
            by: {
              id: this.dataset.id
            }
          };
        }
        let res = await _func(x);
        this.inEdit = false;
        x = [{
          $act: enumObj.crud.act.read,
          bizIdent: bizIdent,
          by: {
            id: res
          }
        }];
        let resObj = await this.queryKucuntaizhangObj(x);
        this.dataset = resObj[0];
      } catch (err) {
        terr(err);
      }
    },
    onAdd() {
      this.inEdit = true;
      this.dataset = this.bizDefine.emptyVal();
    },
    onEdit() {
      this.inEdit = true;
    }
  },
  async mounted() {
    try {
      this.bizDefine = this.getBizDefine[bizIdent];
      this.baseDefine = global.getBaseDefine(this.bizDefine);
      if (this.$route.params) {
        let {
          inEdit,
          id
        } = this.$route.params;
        this.inEdit = inEdit;
        if (id && id > 0) {
          this.isAdd = false;
          let x = [{
            $act: enumObj.crud.act.read,
            bizIdent: bizIdent,
            by: {
              id: id
            }
          }];
          let res = await this.queryKucuntaizhangObj(x);
          this.dataset = this.getKucuntaizhangObj[0];
          this.inLoading = false;
        } else {
          this.isAdd = true;
          this.dataset = this.bizDefine.emptyVal();
        }
      } else {
        this.isAdd = true;
        this.dataset = this.bizDefine.emptyVal();
      }
      
    } catch (err) {
      this.inLoading = false;
      terr(err);
    }
  }
};
</script>
