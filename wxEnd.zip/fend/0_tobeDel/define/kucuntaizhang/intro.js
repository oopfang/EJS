export default {
  code: 'kucuntaizhang',
  name: 'Kucuntaizhang',
  namezh: '库存台账',
  guidUrl: '',
  showHeader: true,
  showFooter: true,
  useFilter: true,
  titleField: 'namezh',
  fullWidthInCol: false,
  header: [],
  buttons: [],
  subSequence: [],
  emptyVal: {
    id: '',
    pid: '-1',
    code: '',
    name: '',
    namezh: '',
    memo: '',
    stopped: '0'
  }
};
