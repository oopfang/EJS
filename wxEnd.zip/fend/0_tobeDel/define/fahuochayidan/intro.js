export default {
  code: 'fahuochayidan',
  name: 'Fahuochayidan',
  namezh: '发货差异单',
  guidUrl: '',
  showHeader: true,
  showFooter: true,
  useFilter: true,
  titleField: 'namezh',
  fullWidthInCol: false,
  header: [],
  buttons: [],
  subSequence: [],
  emptyVal: {
    id: '',
    pid: '-1',
    code: '',
    name: '',
    namezh: '',
    dateDiff: '',
    orderId: '-1',
    operator: '-1',
    memo: '',
    stopped: '0'
  }
};
