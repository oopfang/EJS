export default {
  code: 'billPackage',
  name: 'BillPackage',
  namezh: '装箱单',
  guidUrl: '',
  showHeader: true,
  showFooter: true,
  useFilter: true,
  titleField: 'namezh',
  fullWidthInCol: false,
  header: [],
  buttons: [],
  subSequence: [],
  emptyVal: {
    id: '',
    pid: '-1',
    code: '',
    name: '',
    dateBox: '',
    namezh: '',
    boxNo: '',
    operator: '-1',
    quantityInBox: '0',
    picAddr: '',
    orderId: '-1',
    memo: '',
    stopped: '0'
  }
};
