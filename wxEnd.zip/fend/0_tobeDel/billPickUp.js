/**
 * 取件单表单视图的路由
 */

const list = () => import(/* webpackChunkName:'billPickUp' */ '@/pages/bizPages/bill/billPickUp/list.vue');
// const add = () => import(/* webpackChunkName:'billPickUp' */ '@/pages/bizPages/bill/billPickUp/add.vue');
const edit = () => import(/* webpackChunkName:'billPickUp' */ '@/pages/bizPages/bill/billPickUp/edit.vue');
// const view = () => import(/* webpackChunkName:'billPickUp' */ '@/pages/bizPages/bill/billPickUp/view.vue');

module.exports = [{
    path: '/billPickUp',
    name: 'billPickUp',
    component: list
  },
  {
    path: '/billPickUp/add',
    name: 'billPickUpAdd',
    props: true,
    component: edit
  },
  {
    path: '/billPickUp/edit',
    name: 'billPickUpEdit',
    props: true,
    component: edit
  },
  {
    path: '/billPickUp/view',
    name: 'billPickUpView',
    props: true,
    component: edit
  }
];
